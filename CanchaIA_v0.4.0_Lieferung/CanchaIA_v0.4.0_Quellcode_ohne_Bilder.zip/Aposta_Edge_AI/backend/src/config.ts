/**
 * Zentrale Konfiguration. Alle Secrets kommen ausschließlich aus Umgebungsvariablen.
 * Es gibt bewusst keine Defaults für Schlüssel.
 */
import path from 'node:path';

export type DataMode = 'mock' | 'live';
export type Strategy = 'CONSERVATIVE' | 'BALANCED' | 'AGGRESSIVE';

function bool(v: string | undefined, d = false): boolean {
  if (v === undefined || v === '') return d;
  return ['1', 'true', 'yes', 'on'].includes(v.toLowerCase());
}
function num(v: string | undefined, d: number): number {
  const n = Number(v);
  return v !== undefined && v !== '' && Number.isFinite(n) ? n : d;
}

export interface Config {
  port: number;
  host: string;
  dbPath: string;
  dataMode: DataMode;
  timezone: string;
  /** Optionales Service-Token für Server-zu-Server-Zugriff (z. B. Base44-Backend). Nie im Browser verwenden. */
  adminToken: string | null;
  readToken: string | null;
  /** Erstes Admin-Konto (nur beim ersten Start, wenn noch kein Admin existiert). */
  adminEmail: string | null;
  adminPassword: string | null;
  allowRegistration: boolean;
  cookieSecure: boolean;
  /** X-Forwarded-For nur auswerten, wenn ein vertrauenswürdiger Reverse-Proxy davor steht. */
  trustProxy: boolean;
  highlightly: {
    apiKey: string | null;
    baseUrl: string;
    rapidApiHost: string | null;
    dailyBudget: number;
    /** Muss vom Betreiber ausdrücklich gesetzt werden, nachdem die Nutzungsrechte für Wettanalysen schriftlich geklärt sind. */
    bettingUseConfirmed: boolean;
  };
  theOddsApi: {
    apiKey: string | null;
    baseUrl: string;
    regions: string;
    sportKeys: string[];
    monthlyBudget: number;
    /** Internes Tagesbudget in Credits (Standard: Monatsbudget / 30, mind. 5). */
    dailyBudget: number;
    /** BTTS über den teuren Event-Endpunkt (Kosten je Spiel). Standard aus. */
    includeBtts: boolean;
    /** Höchstens so viele BTTS-Abrufe je Lauf (die nächsten Anstöße zuerst). */
    bttsMaxEventsPerRun: number;
    /** BTTS nur, solange mindestens dieser Anteil des Monatsbudgets frei ist (Kernmärkte haben Vorrang). */
    bttsReservePct: number;
    /** Ergebnisse über /scores?daysFrom=3 (2 Credits je Wettbewerb) für die Abrechnung. */
    resultsEnabled: boolean;
    /** v0.4.0: Intervall der KOSTENLOSEN Spielsuche (/events) in Minuten (mind. 10). */
    discoveryIntervalMinutes: number;
    /** v0.4.0: Intervall der KOSTENPFLICHTIGEN Quotenabrufe + Analyse in Minuten (mind. 15). */
    oddsIntervalMinutes: number;
  };
  /** Kontrollierter Pilotbetrieb: nur ausgewählte Wettbewerbe und begrenzte Spiele je Lauf. */
  pilot: {
    enabled: boolean;
    sportKeys: string[];
    maxEventsPerRun: number;
  };
  /** Optionaler KI-Analyst. Modell, Aufwand und Ausgabelänge per Umgebung steuerbar; ohne Schlüssel lokaler Regelmodus. */
  anthropic: { apiKey: string | null; model: string; effort: 'low' | 'medium' | 'high' | 'xhigh' | 'max' | null; maxTokens: number; serverFallback: boolean };
  alerts: {
    telegramBotToken: string | null;
    telegramChatId: string | null;
    webhookUrl: string | null;
  };
  analysis: {
    horizonHours: number;
    minEv: number;
    maxRecommendations: number;
    strategy: Strategy;
    oddsMaxAgeMinutes: number;
    syncIntervalMinutes: number;
  };
  schedulerEnabled: boolean;
  frontendDir: string;
  /** Tarifverwaltung (v0.3.0). Ohne SUBSCRIPTIONS_ENFORCE=true bleiben alle bisherigen Funktionen für alle Benutzer frei. */
  subscriptions: {
    enforce: boolean;
    bankTransfer: { enabled: boolean; bankName: string | null; alias: string | null; accountHolder: string | null };
    /** uPay: nur 'disabled' oder 'test'. Ein Live-Modus ist ohne bestätigte Händlerfreigabe nicht vorgesehen. */
    upayMode: 'disabled' | 'test';
    upayLiveRequested: boolean;
    proofRetentionDays: number;
  };
}

/** Ungültige Konfiguration: Start wird mit klarer Meldung abgebrochen (keine stille Ersatzannahme). */
export class ConfigError extends Error {}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): Config {
  // v0.4.0: ungültige Werte werden NICHT mehr stillschweigend als Mock bzw. BALANCED übernommen
  const dm = (env.DATA_MODE ?? '').trim();
  if (dm && dm !== 'mock' && dm !== 'live') throw new ConfigError(`DATA_MODE="${dm.slice(0, 20)}" ist ungültig: erlaubt sind "mock" oder "live".`);
  const dataMode = (dm === 'live' ? 'live' : 'mock') as DataMode;
  const st = (env.STRATEGY ?? '').trim().toUpperCase();
  if (st && !['CONSERVATIVE', 'BALANCED', 'AGGRESSIVE'].includes(st)) throw new ConfigError(`STRATEGY="${st.slice(0, 20)}" ist ungültig: erlaubt sind CONSERVATIVE, BALANCED, AGGRESSIVE.`);
  const strategy = (st || 'BALANCED') as Strategy;
  return {
    port: num(env.PORT, 8080),
    host: env.HOST || '0.0.0.0',
    dbPath: env.DB_PATH || path.resolve('data', 'aposta-edge.sqlite'),
    dataMode,
    timezone: env.APP_TIMEZONE || 'America/Asuncion',
    adminToken: env.ADMIN_TOKEN && env.ADMIN_TOKEN.length >= 32 ? env.ADMIN_TOKEN : null,
    readToken: env.READ_TOKEN && env.READ_TOKEN.length >= 32 && env.READ_TOKEN !== env.ADMIN_TOKEN ? env.READ_TOKEN : null,
    adminEmail: env.ADMIN_EMAIL || null,
    adminPassword: env.ADMIN_PASSWORD || null,
    allowRegistration: bool(env.ALLOW_REGISTRATION, false),
    cookieSecure: bool(env.COOKIE_SECURE, true),
    trustProxy: bool(env.TRUST_PROXY, false),
    highlightly: {
      apiKey: env.HIGHLIGHTLY_API_KEY || null,
      baseUrl: env.HIGHLIGHTLY_BASE_URL || 'https://soccer.highlightly.net',
      rapidApiHost: env.HIGHLIGHTLY_RAPIDAPI_HOST || null,
      dailyBudget: num(env.HIGHLIGHTLY_DAILY_BUDGET, 6500),
      bettingUseConfirmed: bool(env.HIGHLIGHTLY_BETTING_USE_CONFIRMED, false),
    },
    theOddsApi: {
      apiKey: env.THE_ODDS_API_KEY || null,
      baseUrl: env.THE_ODDS_API_BASE_URL || 'https://api.the-odds-api.com',
      // v0.3.3: eine Region als Standard (Kosten = Märkte × Regionen); vorher 'eu,uk'
      regions: env.THE_ODDS_API_REGIONS || 'eu',
      sportKeys: (env.THE_ODDS_API_SPORT_KEYS || '').split(',').map(s => s.trim()).filter(Boolean),
      monthlyBudget: num(env.THE_ODDS_API_MONTHLY_BUDGET, 500),
      // Tagesbudget: explizit oder wie bisher Monatsbudget / 30 (mind. 5) → 500 / 30 = 16
      dailyBudget: Math.max(1, num(env.THE_ODDS_API_DAILY_BUDGET, Math.max(5, Math.floor(num(env.THE_ODDS_API_MONTHLY_BUDGET, 500) / 30)))),
      includeBtts: bool(env.THE_ODDS_API_INCLUDE_BTTS, false),
      bttsMaxEventsPerRun: Math.max(0, Math.min(50, num(env.THE_ODDS_API_BTTS_MAX_EVENTS, 5))),
      bttsReservePct: Math.max(0, Math.min(90, num(env.THE_ODDS_API_BTTS_RESERVE_PCT, 25))),
      resultsEnabled: bool(env.THE_ODDS_API_RESULTS, true),
      discoveryIntervalMinutes: Math.max(10, num(env.THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES, 30)),
      oddsIntervalMinutes: Math.max(15, num(env.THE_ODDS_API_ODDS_INTERVAL_MINUTES, num(env.SYNC_INTERVAL_MINUTES, 60))),
    },
    pilot: {
      enabled: bool(env.PILOT_MODE, false),
      sportKeys: (env.PILOT_SPORT_KEYS || 'soccer_epl,soccer_spain_la_liga,soccer_uefa_champs_league').split(',').map(s => s.trim()).filter(Boolean),
      maxEventsPerRun: Math.max(1, Math.min(200, num(env.PILOT_MAX_EVENTS, 30))),
    },
    anthropic: {
      apiKey: env.ANTHROPIC_API_KEY || null,
      // Modell-ID laut offizieller Modellübersicht (Stand 2026-10); per ANTHROPIC_MODEL änderbar
      model: env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
      // output_config.effort; leer/"none" = nicht senden (für ältere Modelle ohne effort-Unterstützung)
      effort: (() => { const e = (env.ANTHROPIC_EFFORT ?? 'low').trim().toLowerCase(); return (['low', 'medium', 'high', 'xhigh', 'max'] as const).find(x => x === e) ?? null; })(),
      maxTokens: Math.max(512, Math.min(32000, num(env.ANTHROPIC_MAX_TOKENS, 4000))),
      serverFallback: bool(env.ANTHROPIC_SERVER_FALLBACK, true),
    },
    alerts: {
      telegramBotToken: env.TELEGRAM_BOT_TOKEN || null,
      telegramChatId: env.TELEGRAM_CHAT_ID || null,
      webhookUrl: env.ALERT_WEBHOOK_URL || null,
    },
    analysis: {
      horizonHours: num(env.ANALYSIS_HORIZON_HOURS, 48),
      minEv: num(env.MIN_EV, 0.05),
      maxRecommendations: Math.min(5, Math.max(1, num(env.MAX_RECOMMENDATIONS, 5))),
      strategy,
      oddsMaxAgeMinutes: num(env.ODDS_MAX_AGE_MINUTES, 90),
      // Kostenpflichtiger Lauf (Quoten + Analyse); THE_ODDS_API_ODDS_INTERVAL_MINUTES hat Vorrang vor dem Altnamen SYNC_INTERVAL_MINUTES
      syncIntervalMinutes: Math.max(15, num(env.THE_ODDS_API_ODDS_INTERVAL_MINUTES, num(env.SYNC_INTERVAL_MINUTES, 60))),
    },
    schedulerEnabled: bool(env.SCHEDULER_ENABLED, true),
    frontendDir: env.FRONTEND_DIR || path.resolve('..', 'frontend', 'dist'),
    subscriptions: {
      enforce: bool(env.SUBSCRIPTIONS_ENFORCE, false),
      bankTransfer: {
        enabled: bool(env.PAYMENT_BANK_TRANSFER_ENABLED, true),
        bankName: env.PAYMENT_BANK_NAME || null, alias: env.PAYMENT_BANK_ALIAS || null, accountHolder: env.PAYMENT_ACCOUNT_HOLDER || null,
      },
      upayMode: env.UPAY_MODE === 'test' ? 'test' : 'disabled',
      upayLiveRequested: env.UPAY_MODE === 'live',
      proofRetentionDays: Math.max(30, num(env.PAYMENT_PROOF_RETENTION_DAYS, 180)),
    },
  };
}

export type ProviderReadiness = 'READY' | 'NOT CONFIGURED' | 'BLOCKED' | 'MOCK MODE';
export interface ProviderState { provider: string; roles: ('fixtures' | 'odds' | 'history' | 'results')[]; status: ProviderReadiness; reason: string | null }

/** Wirksame Wettbewerbe für The Odds API: im Pilotmodus die Pilot-Keys, sonst THE_ODDS_API_SPORT_KEYS (leer = alle aktiven). */
export function effectiveSportKeys(c: Config): string[] { return c.pilot.enabled ? c.pilot.sportKeys : c.theOddsApi.sportKeys; }

/**
 * Bereitschaft aller Provider – eine Quelle der Wahrheit für Diagnose, Statusseite und Konfigurationsprüfung.
 * The Odds API ist ein vollwertiger Fixture-Provider (Spielplan kostenlos aus /events, Quoten aus /odds); die Modell-Historie kommt dann aus dem CSV-Import.
 */
export function providerStates(c: Config): ProviderState[] {
  if (c.dataMode === 'mock') return [
    { provider: 'mock', roles: ['fixtures', 'odds', 'history', 'results'], status: 'READY', reason: 'fiktive Daten (DATA_MODE=mock)' },
    { provider: 'highlightly', roles: ['fixtures', 'odds', 'history', 'results'], status: 'MOCK MODE', reason: 'im Mock-Modus nicht verwendet' },
    { provider: 'theoddsapi', roles: ['fixtures', 'odds', 'results'], status: 'MOCK MODE', reason: 'im Mock-Modus nicht verwendet' },
  ];
  const hl: ProviderState = { provider: 'highlightly', roles: ['fixtures', 'odds', 'history', 'results'], status: 'READY', reason: null };
  if (!c.highlightly.apiKey) { hl.status = 'NOT CONFIGURED'; hl.reason = 'HIGHLIGHTLY_API_KEY fehlt'; }
  else if (!c.highlightly.bettingUseConfirmed) { hl.status = 'BLOCKED'; hl.reason = 'Nutzungsrechte für Wettanalysen nicht schriftlich bestätigt (HIGHLIGHTLY_BETTING_USE_CONFIRMED)'; }
  const oa: ProviderState = { provider: 'theoddsapi', roles: c.theOddsApi.resultsEnabled ? ['fixtures', 'odds', 'results'] : ['fixtures', 'odds'], status: 'READY', reason: null };
  if (!c.theOddsApi.apiKey) { oa.status = 'NOT CONFIGURED'; oa.reason = 'THE_ODDS_API_KEY fehlt'; }
  return [hl, oa, { provider: 'football-data-csv', roles: ['history'], status: 'READY', reason: 'manueller Import (npm run import:csv)' }];
}

/** Prüft, ob die Konfiguration für den gewählten Modus vollständig ist. Gibt fehlende Punkte zurück. */
export function configIssues(c: Config): string[] {
  const issues: string[] = [];
  if (!process.env.DATA_MODE) issues.push('DATA_MODE nicht gesetzt: Mock-Modus mit fiktiven Daten. Für echte Daten DATA_MODE=live setzen.');
  if (process.env.ADMIN_TOKEN && !c.adminToken) issues.push('ADMIN_TOKEN ignoriert: mindestens 32 Zeichen erforderlich.');
  if (process.env.READ_TOKEN && !c.readToken) issues.push('READ_TOKEN ignoriert: mindestens 32 Zeichen und verschieden von ADMIN_TOKEN.');
  if (!c.cookieSecure && c.dataMode === 'live') issues.push('COOKIE_SECURE=false im Live-Modus: Session-Cookies ohne Secure-Flag. Nur hinter HTTPS betreiben.');
  if (c.dataMode === 'live') {
    const st = providerStates(c);
    const ready = (role: ProviderState['roles'][number]) => st.filter(p => p.status === 'READY' && p.roles.includes(role) && p.provider !== 'football-data-csv');
    const hl = st.find(p => p.provider === 'highlightly')!;
    if (!ready('fixtures').length) {
      // Nichts nutzbar: konkret sagen, was fehlt
      for (const p of st) if (p.status !== 'READY') issues.push(`${p.provider}: ${p.status} – ${p.reason}`);
      issues.push('Kein freigegebener Fixture-Provider: THE_ODDS_API_KEY setzen (oder Highlightly mit bestätigten Nutzungsrechten). Ohne ihn findet die Discovery keine Spiele.');
    } else if (hl.status === 'BLOCKED') issues.push(`highlightly: BLOCKED – ${hl.reason}`);
    if (!ready('odds').length) issues.push('Kein freigegebener Quoten-Provider konfiguriert (THE_ODDS_API_KEY oder freigegebenes Highlightly).');
    if (c.theOddsApi.apiKey) {
      const regions = c.theOddsApi.regions.split(',').filter(Boolean).length;
      if (regions > 1) issues.push(`THE_ODDS_API_REGIONS=${c.theOddsApi.regions}: ${regions} Regionen vervielfachen die Kosten jedes Quotenabrufs (×${regions}). Empfohlen: eu.`);
      if (!effectiveSportKeys(c).length) issues.push('THE_ODDS_API_SPORT_KEYS leer: es würden ALLE aktiven Fußball-Wettbewerbe abgefragt (je 2 Credits pro Region). Empfohlen: soccer_uefa_champs_league.');
      if (/[?&]apiKey=/i.test(c.theOddsApi.baseUrl)) issues.push('THE_ODDS_API_BASE_URL enthält einen Schlüssel: Schlüssel nur in THE_ODDS_API_KEY eintragen.');
      if (c.theOddsApi.dailyBudget * 28 > c.theOddsApi.monthlyBudget * 1.5) issues.push(`THE_ODDS_API_DAILY_BUDGET=${c.theOddsApi.dailyBudget} ist hoch im Verhältnis zum Monatsbudget ${c.theOddsApi.monthlyBudget}: das Monatsbudget kann vor Monatsende aufgebraucht sein.`);
    }
    if (c.theOddsApi.apiKey && c.theOddsApi.includeBtts && c.theOddsApi.bttsMaxEventsPerRun === 0) issues.push('THE_ODDS_API_INCLUDE_BTTS=true, aber THE_ODDS_API_BTTS_MAX_EVENTS=0: es werden keine BTTS-Quoten abgerufen.');
    if (c.pilot.enabled && !c.pilot.sportKeys.length) issues.push('PILOT_MODE=true ohne PILOT_SPORT_KEYS.');
  }
  if (c.subscriptions.upayLiveRequested) issues.push('UPAY_MODE=live wird ignoriert: Ohne bestätigte uPay-Händlerfreigabe sind keine echten Zahlungen vorgesehen (uPay bleibt deaktiviert).');
  if (c.subscriptions.enforce && c.subscriptions.bankTransfer.enabled && !c.subscriptions.bankTransfer.alias) issues.push('Banküberweisung aktiv, aber PAYMENT_BANK_ALIAS fehlt: Benutzer sehen keine Überweisungsdaten.');
  return issues;
}
