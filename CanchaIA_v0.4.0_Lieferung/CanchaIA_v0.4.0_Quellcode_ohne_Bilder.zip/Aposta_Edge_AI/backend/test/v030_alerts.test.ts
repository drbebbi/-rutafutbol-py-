/**
 * v0.3.0 – Verbesserung 5: benutzerspezifische Benachrichtigungen.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { ANCHOR, mockApp, TEST_ADMIN, testConfig, memDb } from './helpers.js';
import { createServer } from '../src/server.js';
import { AuthService } from '../src/auth.js';
import { AlertEngine, dispatchPersonal, type AlertDraft } from '../src/engines/alerts.js';
import { SubscriptionService } from '../src/subscriptions.js';

const drafts: AlertDraft[] = [
  { kind: 'new_value', dedupeKey: 'new:1:1X2:HOME::VALUE:2.30', title: 'Nueva value bet', body: 'A – B', ev: 0.06, eventId: 1 },
  { kind: 'new_value', dedupeKey: 'new:2:OU:OVER:2.5:VALUE:2.10', title: 'Nueva value bet', body: 'C – D', ev: 0.11, eventId: 2 },
  { kind: 'removed', dedupeKey: 'rm:3:1X2:AWAY::77', title: 'Value bet retirada', body: 'E – F', ev: 0.01, eventId: 3 },
  { kind: 'odds_change', dedupeKey: 'odds:2:OU:OVER:2.5:2.25', title: 'Cambio de cuota', body: 'C – D', ev: 0.13, eventId: 2 },
];

function setup(over: Record<string, string> = {}) {
  const db = memDb();
  const cfg = testConfig(over);
  const auth = new AuthService(db, null);
  const a = auth.createUser('a@example.test', 'passwort-a-123456', 'user'), b = auth.createUser('b@example.test', 'passwort-b-123456', 'user'), c = auth.createUser('c@example.test', 'passwort-c-123456', 'user');
  const subs = new SubscriptionService(db, cfg, () => ANCHOR);
  const set = (id: number, s: Record<string, number | null>) => { db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', id); for (const [k, v] of Object.entries(s)) db.run(`UPDATE user_settings SET ${k} = ? WHERE user_id = ?`, v, id); };
  return { db, cfg, subs, a, b, c, set, ent: (uid: number, role: string) => subs.entitlements(uid, role).effective };
}

test('V5: Filter je Benutzer (Typen, Mindest-EV), Deduplizierung je Benutzer, Opt-in', () => {
  const t = setup();
  t.set(t.a.id, { personal_alerts_enabled: 1, alert_min_ev: 0.10 });                       // nur EV ≥ 10 % + Rückzüge
  t.set(t.b.id, { personal_alerts_enabled: 1, notify_new_value: 0, notify_odds_change: 0 });   // nur Rückzüge (EV-Grenze = System 5 %)
  // c hat persönliche Meldungen nicht eingeschaltet → bekommt nichts
  assert.equal(dispatchPersonal(t.db, drafts, t.ent, 0.05), 3 + 1);
  const of = (id: number) => t.db.all<{ dedupe_key: string }>('SELECT dedupe_key FROM user_alerts WHERE user_id = ? ORDER BY id', id).map(r => r.dedupe_key);
  assert.deepEqual(of(t.a.id), [drafts[1].dedupeKey, drafts[2].dedupeKey, drafts[3].dedupeKey]);
  assert.deepEqual(of(t.b.id), [drafts[2].dedupeKey]);
  assert.deepEqual(of(t.c.id), []);
  assert.equal(dispatchPersonal(t.db, drafts, t.ent, 0.05), 0, 'erneuter Lauf: keine Duplikate je Benutzer');
});

test('V5: Tarif-Durchsetzung – persönliche Meldungen nur mit berechtigtem Tarif', () => {
  const t = setup({ SUBSCRIPTIONS_ENFORCE: 'true' });
  t.set(t.a.id, { personal_alerts_enabled: 1 }); t.set(t.b.id, { personal_alerts_enabled: 1 });
  const admin = new AuthService(t.db, null).createUser('adm@example.test', 'admin-passwort-1234', 'admin');
  t.subs.grant(admin.id, { userId: t.a.id, planId: 'PRO', months: 1, reason: 'Testkonto Pilotphase' });
  dispatchPersonal(t.db, drafts, t.ent, 0.05);
  assert.ok(t.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM user_alerts WHERE user_id = ?', t.a.id)!.n > 0, 'PRO bekommt Meldungen');
  assert.equal(t.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM user_alerts WHERE user_id = ?', t.b.id)!.n, 0, 'FREE bekommt keine, obwohl eingeschaltet');
});

test('V5: Systemweite Kanäle (Telegram/Webhook) werden für persönliche Meldungen nie verwendet', async () => {
  const app = await mockApp({ TELEGRAM_BOT_TOKEN: '123456:test-token-not-real-abcdefghij', TELEGRAM_CHAT_ID: '-100', ALERT_WEBHOOK_URL: 'https://hook.example.test/x' });
  const sent: string[] = [];
  const engine = new AlertEngine(app.db, app.cfg, async (url) => { sent.push(url); });
  const auth = new AuthService(app.db, null);
  for (const i of [1, 2, 3]) { const u = auth.createUser(`u${i}@example.test`, `passwort-u${i}-12345`, 'user'); app.db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', u.id); app.db.run('UPDATE user_settings SET personal_alerts_enabled = 1 WHERE user_id = ?', u.id); }
  const n = await engine.dispatch(drafts);
  const personal = dispatchPersonal(app.db, drafts, () => ({ personalAlerts: true, customAlertMinEv: true }), 0.05);
  assert.ok(personal >= 6);
  assert.equal(sent.length, n * 2, 'nur je Systemmeldung einmal Telegram + einmal Webhook – nicht je Benutzer');
});

test('V5: Zugriffskontrolle – A kann weder Meldungen noch Lesestatus von B verändern', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const auth = new AuthService(app.db, null);
  const a = auth.createUser('a@example.test', 'passwort-a-123456', 'user'), b = auth.createUser('b@example.test', 'passwort-b-123456', 'user');
  for (const u of [a, b]) { app.db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', u.id); app.db.run('UPDATE user_settings SET personal_alerts_enabled = 1 WHERE user_id = ?', u.id); }
  dispatchPersonal(app.db, drafts, () => ({ personalAlerts: true, customAlertMinEv: true }), 0.05);
  const server = createServer(app, null, { clock: () => new Date(ANCHOR.getTime() + 60_000) });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const login = async (email: string, password: string) => {
    const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const cookie = (r.headers.get('set-cookie') ?? '').split(';')[0], csrf = (await r.json() as any).csrfToken;
    return async (p: string, method = 'GET', body?: unknown) => { const x = await fetch(base + p, { method, headers: { 'content-type': 'application/json', cookie, 'x-csrf-token': csrf }, body: body === undefined ? undefined : JSON.stringify(body) }); return { status: x.status, body: await x.json().catch(() => null) as any }; };
  };
  try {
    const A = await login('a@example.test', 'passwort-a-123456'), B = await login('b@example.test', 'passwort-b-123456');
    const mineA = (await A('/api/me/alerts')).body, mineB = (await B('/api/me/alerts')).body;
    assert.ok(mineA.length && mineB.length);
    assert.ok(mineA.every((x: any) => !mineB.some((y: any) => y.id === x.id)), 'getrennte Listen');
    // A versucht B's Meldung als gelesen zu markieren
    assert.equal((await A(`/api/me/alerts/${mineB[0].id}/read`, 'POST')).status, 404);
    assert.equal(app.db.get<{ r: string | null }>('SELECT read_at AS r FROM user_alerts WHERE id = ?', mineB[0].id)!.r, null);
    assert.equal((await A(`/api/me/alerts/${mineA[0].id}/read`, 'POST')).body.changed, 1);
    // Systemmeldung: Lesestatus je Benutzer
    const sysA = (await A('/api/alerts')).body;
    assert.ok(sysA.length, 'Mock-Lauf erzeugt Systemmeldungen');
    await A(`/api/alerts/${sysA[0].id}/read`, 'POST');
    assert.ok((await A('/api/alerts')).body.find((x: any) => x.id === sysA[0].id).read_at);
    assert.equal((await B('/api/alerts')).body.find((x: any) => x.id === sysA[0].id).read_at, null, 'B sieht die Meldung weiterhin ungelesen');
    // Einstellungen: nur die eigenen
    const put = await A('/api/settings', 'PUT', { alert_min_ev: 0.09, notify_ev_change: false });
    assert.equal(put.status, 200);
    assert.equal(app.db.get<{ v: number }>('SELECT alert_min_ev AS v FROM user_settings WHERE user_id = ?', a.id)!.v, 0.09);
    assert.equal(app.db.get<{ v: number | null }>('SELECT alert_min_ev AS v FROM user_settings WHERE user_id = ?', b.id)!.v, null);
    assert.equal((await A('/api/settings', 'PUT', { alert_min_ev: 5 })).status, 400, 'Bereich 1–50 %');
  } finally { server.close(); }
});

test('V5: Mit Durchsetzung – Einschalten persönlicher Meldungen nur mit Tarif (402), Admin immer', async () => {
  const app = await mockApp({ SUBSCRIPTIONS_ENFORCE: 'true' });
  const server = createServer(app, null, { clock: () => new Date(ANCHOR.getTime() + 60_000) });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  new AuthService(app.db, null).createUser('free@example.test', 'passwort-free-1234', 'user');
  const login = async (email: string, password: string) => {
    const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const cookie = (r.headers.get('set-cookie') ?? '').split(';')[0], csrf = (await r.json() as any).csrfToken;
    return (body: unknown) => fetch(base + '/api/settings', { method: 'PUT', headers: { 'content-type': 'application/json', cookie, 'x-csrf-token': csrf }, body: JSON.stringify(body) });
  };
  try {
    const F = await login('free@example.test', 'passwort-free-1234'), ADM = await login(TEST_ADMIN.email, TEST_ADMIN.password);
    assert.equal((await F({ personal_alerts_enabled: true })).status, 402);
    assert.equal((await F({ language: 'de' })).status, 200, 'übrige Einstellungen bleiben frei');
    assert.equal((await ADM({ personal_alerts_enabled: true, alert_min_ev: 0.07 })).status, 200);
  } finally { server.close(); }
});
