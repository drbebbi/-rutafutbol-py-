/**
 * App-Kontext, Icons und Diagramme. Das UI-Kit (Buttons, Karten, KPI, Zustände …) liegt in ui.tsx.
 */
import React, { createContext, useContext } from 'react';
import { DICTS, UI, type Lang, type Dict, type UiDict } from './i18n';
import { BRAND } from './brand';

export interface Ctx {
  lang: Lang; t: Dict; u: UiDict; tz: string; isMock: boolean; dataMode: 'mock' | 'live'; go: (path: string) => void;
  role: 'admin' | 'user'; email: string | null; plan: string | null;
}
export const AppCtx = createContext<Ctx>({ lang: 'es', t: DICTS.es, u: UI.es, tz: BRAND.defaultTz, isMock: false, dataMode: 'mock', go: () => {}, role: 'user', email: null, plan: null });
export const useApp = () => useContext(AppCtx);

const PATHS: Record<string, React.ReactNode> = {
  home: <><rect x="3" y="3" width="7" height="9" rx="1.5" /><rect x="14" y="3" width="7" height="5" rx="1.5" /><rect x="14" y="12" width="7" height="9" rx="1.5" /><rect x="3" y="16" width="7" height="5" rx="1.5" /></>,
  matches: <><rect x="3" y="4" width="18" height="17" rx="2" /><path d="M3 9h18M8 2v4M16 2v4" /></>,
  edge: <><path d="M4 19V5M4 19h16" /><path d="m7 15 4-5 3 3 5-6" /></>,
  perf: <><path d="M4 20V10M10 20V4M16 20v-7M22 20H2" /></>,
  settings: <><path d="M4 7h10M18 7h2M4 17h4M12 17h8" /><circle cx="16" cy="7" r="2" /><circle cx="10" cy="17" r="2" /></>,
  admin: <><path d="M12 3 4 6v6c0 4.5 3.4 8.3 8 9 4.6-.7 8-4.5 8-9V6z" /><path d="m9 12 2 2 4-4" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8h.01" /></>,
  warn: <><path d="M10.3 3.9 2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z" /><path d="M12 9v4M12 17h.01" /></>,
  error: <><circle cx="12" cy="12" r="9" /><path d="m15 9-6 6M9 9l6 6" /></>,
  ok: <><circle cx="12" cy="12" r="9" /><path d="m8 12 3 3 5-6" /></>,
  refresh: <><path d="M20 11a8 8 0 0 0-14.9-3.5M4 4v4h4M4 13a8 8 0 0 0 14.9 3.5M20 20v-4h-4" /></>,
  logout: <><path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3M10 17l5-5-5-5M15 12H4" /></>,
  back: <><path d="M15 18 9 12l6-6" /></>,
  next: <><path d="m9 18 6-6-6-6" /></>,
  send: <><path d="M4 12h15M13 6l6 6-6 6" /></>,
  empty: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18M8 15h4" /></>,
  ball: <><circle cx="12" cy="12" r="9" /><path d="m12 7 4 3-1.5 5h-5L8 10z" /></>,
};
export const Icon = ({ name, className }: { name: string; className?: string }) =>
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{PATHS[name] ?? PATHS.info}</svg>;

/**
 * Markenzeichen CanchaIA: Spielfeld von oben (Cancha) mit Mittelkreis in Cyan (Analyse)
 * und grünem Strafraum (der „Vorteil“ / Value-Signal). Farben aus dem Design-System.
 * Gleiche Geometrie wie public/favicon.svg.
 */
export const BrandMark = () => <svg className="mark" viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" rx="14" fill="#182436" /><rect x="10.5" y="15.5" width="43" height="33" rx="4" fill="none" stroke="#e6edf5" strokeWidth="3" /><path d="M32 15.5v33" stroke="#e6edf5" strokeWidth="3" /><circle cx="32" cy="32" r="7" fill="none" stroke="#4fc3e3" strokeWidth="3" /><rect x="44" y="25" width="8" height="14" rx="1.5" fill="#3fd18c" /></svg>;

/** Wortmarke „Cancha·IA“, optional mit Slogan darunter. */
export const BrandWord = ({ slogan = false }: { slogan?: boolean }) =>
  <span className={slogan ? 'word-stack' : undefined}>
    <span className="word">{BRAND.wordA}<b>{BRAND.wordB}</b></span>
    {slogan ? <span className="tagline">{BRAND.slogan}</span> : null}
  </span>;

/** Liniendiagramm (z. B. kumulierter Gewinn). Eine Skala für Linie, Raster und Beschriftung. */
export function LineChart({ data, height = 190, unit = 'u' }: { data: { t: string; y: number }[]; height?: number; unit?: string }) {
  if (!data.length) return null;
  const W = 640, H = height, pl = 44, pr = 12, pt = 12, pb = 24;
  const ys = data.map(d => d.y), lo = Math.min(0, ...ys), hi = Math.max(0, ...ys), span = hi - lo || 1;
  const x = (i: number) => pl + (data.length === 1 ? 0 : (i / (data.length - 1)) * (W - pl - pr));
  const y = (v: number) => pt + (1 - (v - lo) / span) * (H - pt - pb);
  const ticks = [...new Set([lo, lo + span / 2, hi].map(v => Math.round(v * 10) / 10))];
  const path = data.map((d, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(d.y).toFixed(1)}`).join(' ');
  const last = data[data.length - 1];
  return (
    <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label={`${data.length} Punkte, letzter Wert ${last.y.toFixed(2)}${unit}`}>
      <g className="grid">{ticks.map(v => <line key={v} x1={pl} x2={W - pr} y1={y(v)} y2={y(v)} />)}</g>
      {ticks.map(v => <text key={'t' + v} x={pl - 8} y={y(v) + 3} textAnchor="end">{v}{unit}</text>)}
      <line x1={pl} x2={W - pr} y1={y(0)} y2={y(0)} stroke="var(--text-3)" strokeDasharray="3 4" />
      <path d={`${path} L${x(data.length - 1)},${y(0)} L${x(0)},${y(0)} Z`} fill="rgba(79,195,227,.10)" />
      <path d={path} fill="none" stroke="var(--accent)" strokeWidth="2" />
      <circle cx={x(data.length - 1)} cy={y(last.y)} r="4" fill={last.y >= 0 ? 'var(--value)' : 'var(--avoid)'} />
      <text x={pl} y={H - 6}>{data[0].t.slice(0, 10)}</text><text x={W - pr} y={H - 6} textAnchor="end">{last.t.slice(0, 10)}</text>
    </svg>
  );
}

/** Kalibrierungsdiagramm: vorhergesagt vs. beobachtet, Punktgröße ~ Anzahl. */
export function CalibrationChart({ bins }: { bins: { predicted: number; observed: number; n: number }[] }) {
  if (!bins?.length) return null;
  const S = 260, p = 32, inner = S - 2 * p;
  const sc = (v: number) => p + v * inner;
  const maxN = Math.max(...bins.map(b => b.n));
  return (
    <svg className="chart" viewBox={`0 0 ${S} ${S}`} style={{ maxWidth: 300 }} role="img" aria-label="calibration">
      <g className="grid">{[0, .25, .5, .75, 1].map(v => <line key={v} x1={p} x2={S - p} y1={S - sc(v)} y2={S - sc(v)} />)}</g>
      {[0, .5, 1].map(v => <text key={v} x={p - 5} y={S - sc(v) + 3} textAnchor="end">{v * 100}%</text>)}
      {[0, .5, 1].map(v => <text key={'x' + v} x={sc(v)} y={S - 10} textAnchor="middle">{v * 100}%</text>)}
      <line x1={sc(0)} y1={S - sc(0)} x2={sc(1)} y2={S - sc(1)} stroke="var(--text-3)" strokeDasharray="4 4" />
      {bins.map((b, i) => <circle key={i} cx={sc(b.predicted)} cy={S - sc(b.observed)} r={3 + 6 * Math.sqrt(b.n / maxN)} fill="var(--accent)" fillOpacity=".75" stroke="var(--surface)" />)}
    </svg>
  );
}

// Kompatibilität für Bausteine aus v0.3.0
export { Loading, ErrorBox, StatusChip, MockChip, Tiles } from './ui';
