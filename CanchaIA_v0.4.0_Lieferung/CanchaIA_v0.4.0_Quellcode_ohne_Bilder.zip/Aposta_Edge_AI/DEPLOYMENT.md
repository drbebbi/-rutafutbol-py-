# Deployment (v0.3.0)

## Variante 1: Docker auf einem kleinen VPS (empfohlen)

1 vCPU und 1 GB RAM reichen. Die Datenbank ist SQLite (WAL) in einem Volume.

```bash
git clone <dein-repo> aposta-edge-ai && cd aposta-edge-ai
cp .env.example .env
# in .env setzen: ADMIN_EMAIL, ADMIN_PASSWORD (≥ 12 Zeichen), DATA_MODE
docker compose up -d --build
docker compose logs -f        # "Admin-Konto … angelegt"
# danach ADMIN_PASSWORD aus .env entfernen und neu starten
```

Für den Zugriff von außen gehört ein Reverse-Proxy mit HTTPS davor. Beispiel Caddy: `aposta.example.com { reverse_proxy localhost:8080 }`. Dazu in `.env`:

- `TRUST_PROXY=true`, damit Rate-Limits die echte Client-IP sehen
- `COOKIE_SECURE=true` (Standard)

Hinweis: Das Docker-Image wurde nicht gebaut, weil in der Entwicklungsumgebung weder Docker noch Paket-Registries verfügbar waren (Status NOT VERIFIED). Beim ersten Build löst `npm install` die Versionen auf. Danach `package-lock.json` einchecken.

## Variante 2: direkt mit Node

```bash
npm run install:all && npm run build
cd backend
set -a; . ../.env; set +a
DB_PATH=./data/aposta-edge.sqlite FRONTEND_DIR=../frontend/dist npm start
```

systemd:

```ini
[Unit]
Description=CanchaIA (technisch: aposta-edge-ai)
After=network.target
[Service]
WorkingDirectory=/opt/aposta-edge-ai/backend
EnvironmentFile=/opt/aposta-edge-ai/.env
Environment=FRONTEND_DIR=/opt/aposta-edge-ai/frontend/dist
ExecStart=/usr/bin/node --disable-warning=ExperimentalWarning dist/src/main.js
Restart=always
User=aposta
[Install]
WantedBy=multi-user.target
```

## Upgrade von v0.2.0 auf v0.3.0

1. **Datenbank sichern** (siehe Backups). Pflicht vor jedem Upgrade.
2. Neue Version bauen und starten. Die Migrationen `004`–`006` laufen automatisch:
   - nur ergänzend: keine Tabelle wird gelöscht, keine bestehenden Daten werden überschrieben
   - getestet mit einer echten, von v0.2.0 erzeugten Datenbank und einem zweiten Lauf ohne Änderung
3. Was sich nach dem Upgrade ändert:
   - **Lesestatus von Meldungen:** gilt jetzt je Benutzer. Der bisher globale Lesestatus wird für alle bestehenden Konten übernommen.
   - **Persönliche Meldungen:** für alle aus (Opt-in in Einstellungen).
   - **Tarife:** werden angezeigt, aber nicht durchgesetzt (`SUBSCRIPTIONS_ENFORCE=false`). Niemand verliert eine Funktion.
   - **Modellversionen:** sind unveränderlich (Trigger).
4. Neue Umgebungsvariablen (alle optional, siehe `.env.example`):
   - Pilot: `PILOT_MODE`, `PILOT_SPORT_KEYS`, `PILOT_MAX_EVENTS`
   - The Odds API: `THE_ODDS_API_INCLUDE_BTTS`, `THE_ODDS_API_BTTS_MAX_EVENTS`, `THE_ODDS_API_BTTS_RESERVE_PCT`, `THE_ODDS_API_RESULTS`
   - Tarife und Zahlungen: `SUBSCRIPTIONS_ENFORCE`, `PAYMENT_BANK_*`, `PAYMENT_PROOF_RETENTION_DAYS`, `UPAY_MODE`
5. CSV-Dateien, die mit v0.2.0 importiert wurden, haben im Winter eine um 1 h zu frühe Anstoßzeit. Ein erneuter Import derselben Dateien korrigiert sie. Für Backtests empfohlen.

## Kontrollierter Pilotbetrieb (The Odds API)

Ablauf und Prüfpunkte stehen in [LIVE_API_TEST_REPORT.md](LIVE_API_TEST_REPORT.md). Empfehlung:

1. `PILOT_MODE=true` setzen.
2. Zunächst nur manuelle Läufe über Admin → Kontrollierter Sync, dann `SYNC_INTERVAL_MINUTES` passend zum Credit-Budget wählen (siehe [API_INTEGRATION.md](API_INTEGRATION.md#the-odds-api-v4)).

## Historische Validierung

```bash
npm --prefix backend run import:csv -- E0_2223.csv E0_2324.csv E0_2425.csv SP1_2324.csv SP1_2425.csv
npm --prefix backend run data-quality     # Datenqualität als JSON
npm --prefix backend run validate         # Datenqualität → Backtest → Bericht in backend/data/validation/
```

Oder Admin → Historische Validierung. Der Status (VALIDATED, UNVALIDATED, FAILED) wird als unveränderliche Modellversion gespeichert. Nur VALIDATED ändert Gewichte und gibt STRONG_VALUE frei.

## Upgrade von v0.1.0

1. Datenbank sichern (siehe Backups).
2. Neue Version bauen und starten. Migration `003_v020_lifecycle_security.sql` läuft automatisch. Sie ergänzt nur Spalten und Tabellen, bestehende Daten bleiben erhalten (getestet mit einer echten v0.1.0-Datenbank).
3. **Wichtig:** v0.1.0 nutzte nur `ADMIN_TOKEN`. In v0.2.0 meldet sich der Browser mit E-Mail und Passwort an. Vor dem ersten Start `ADMIN_EMAIL`/`ADMIN_PASSWORD` setzen. `ADMIN_TOKEN` funktioniert nur noch als Service-Token für Server-zu-Server und braucht mindestens 32 Zeichen.
4. Analyse-Einstellungen (Mindest-EV, Strategie, Modellgewicht, Buchmacher) übernimmt die Migration aus v0.1.0 in die systemweiten Einstellungen.

## Benutzer und Rollen

| Rolle | Darf |
|---|---|
| `user` | Dashboard, Spiele, Detailseiten, EDGE ANALYST, Performance lesen, eigene Sprache/Zeitzone/Benachrichtigungen |
| `admin` | zusätzlich: Analyse-Einstellungen, Jobs starten, Backtest, CSV-Import, Team-Aliase, Benutzerverwaltung, Diagnose, Provider-Sperre aufheben |
| `READ_TOKEN` (Server-zu-Server) | nur GET mit Benutzerrechten, z. B. für eine Base44-Backend-Funktion ([BASE44_INTEGRATION.md](BASE44_INTEGRATION.md)) |
| `ADMIN_TOKEN` (Server-zu-Server) | Admin-Rechte ohne CSRF. Nur verwenden, wenn wirklich nötig |

Konten anlegen: Admin → Benutzer, oder per Kommandozeile:

```bash
NEW_USER_PASSWORD='…' npm --prefix backend run user:create -- name@example.com user
```

Passwort vergessen: `NEW_USER_PASSWORD='…' npm --prefix backend run user:password -- name@example.com`. Das hebt eine Sperre auf und beendet alle Sessions des Kontos.

Das Passwort wird bewusst über die Umgebung übergeben, damit es nicht in der Shell-Historie landet.

## Scheduler

| Job | Intervall | Inhalt |
|---|---|---|
| `hourly_sync` | `SYNC_INTERVAL_MINUTES` (Default 60, min. 15) | Discovery, Quoten, Prognosen, Signale, Top 5, Alerts |
| `settlement` | 30 min | Ergebnisse abrechnen, CLV |
| `backtest` | täglich 04:00 (`APP_TIMEZONE`) | Walk-Forward + Holdout, Validierungsstatus |
| `cleanup` | täglich | abgelaufener Cache, alte Request-Logs, abgelaufene Sessions |

Robustheit:

- **Lock mit Heartbeat:** Das Lock gilt 10 min und wird jede Minute verlängert. Stirbt der Prozess, ist es nach spätestens 10 min frei.
- **Abgestürzte Läufe:** Läufe ohne Heartbeat seit 15 min werden als `interrupted` markiert.
- **Fälligkeit:** gemessen am letzten erfolgreichen Lauf. Nach Fehler oder Absturz wird frühestens nach 10 min erneut versucht. Ein verpasster Lauf wird nach dem Neustart **einmal** nachgeholt.
- **Kein Überholen:** Derselbe Job läuft nie zweimal gleichzeitig, auch nicht bei mehreren Instanzen auf derselben Datenbank.

Status in Admin → Scheduler. Manuell starten: ▶ oder `POST /api/admin/jobs/{name}/run`.

## Tarife und Zahlungen (Testmodus)

Siehe [SUBSCRIPTION_SYSTEM.md](SUBSCRIPTION_SYSTEM.md) und [PAYMENT_INTEGRATION.md](PAYMENT_INTEGRATION.md). Bankdaten nur in `.env`, nie im Code. Zahlungen prüft ein Admin im Bereich Admin → Zahlungen.

## Benachrichtigungen

Systemweit: In-App (immer), Telegram (`TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID`), Webhook (`ALERT_WEBHOOK_URL`). Inhaltlich unveränderte Signale erzeugen keine zweite Meldung (eindeutiger Schlüssel inkl. Quote).

Persönlich (v0.3.0):
- nur In-App, Opt-in in Einstellungen
- je Benutzer: Meldungstypen, optionaler Mindest-EV, eigener Lesestatus, Deduplizierung
- Telegram und Webhook werden für persönliche Meldungen nicht verwendet

## Backups

```bash
docker compose exec aposta-edge-ai node -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('/data/aposta-edge.sqlite').exec(\"VACUUM INTO '/data/backup.sqlite'\")"
```

## Später: Wechsel auf Postgres

Alle Zugriffe laufen über `backend/src/db/db.ts`. Der Migrationsplan steht in [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md#datenbank). Für einen Betreiber mit stündlichem Lauf ist SQLite ausreichend. Postgres lohnt sich erst bei mehreren App-Instanzen oder vielen gleichzeitigen Benutzern.
