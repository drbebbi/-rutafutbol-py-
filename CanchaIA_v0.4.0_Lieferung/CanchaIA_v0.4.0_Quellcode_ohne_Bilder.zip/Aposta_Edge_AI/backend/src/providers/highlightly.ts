/**
 * Highlightly Football API Adapter.
 * Endpunkte, Parameter und Feldnamen gemäß offizieller OpenAPI-Spezifikation
 * (https://highlightly.net/football-api/documentation/docs.json, API-Version 8.2.7, gelesen am 12.10.2026).
 *
 * WICHTIG: Gegen die Live-API wurde dieser Adapter NICHT getestet (Netzwerkzugang aus der
 * Entwicklungsumgebung gesperrt). Die Bezeichnungen der Odds-Märkte (`market`, `values[].value`)
 * sind in der Spezifikation nicht als Enum dokumentiert; der Mapper erkennt gängige Bezeichnungen
 * und protokolliert unbekannte Märkte in `missing_data` (Admin → Missing Data).
 *
 * Nutzungsrechte: Der Adapter wird nur aktiv, wenn HIGHLIGHTLY_BETTING_USE_CONFIRMED=true gesetzt ist.
 */
import { ODDS_CACHE_MAX_SECONDS, minutesToNextKickoff, oddsCacheMaxAgeSeconds } from '../engines/freshness.js';
import type { ApiQueue } from '../api/apiQueue.js';
import type {
  FootballDataProvider, OddsProvider, ProviderCapabilities, ProviderCompetition, ProviderFixture,
  ProviderLineup, ProviderMatchStat, ProviderOddsQuote, ProviderStanding, ProviderTeamStats, EventStatus, MarketId, SelectionId,
} from './types.js';
import { ProviderBlockedError } from './types.js';

export interface HighlightlyOptions {
  apiKey: string | null;
  baseUrl: string;
  rapidApiHost: string | null;
  bettingUseConfirmed: boolean;
  onUnmappedMarket?: (market: string, sample: string) => void;
}

// --- Antwortformen laut OpenAPI ---------------------------------------------------
interface HlTeam { id: number; name: string; logo?: string; type?: 'club' | 'national' }
interface HlMatch {
  id: number; round: string; date: string;
  country: { code?: string; name?: string; logo?: string };
  homeTeam: HlTeam; awayTeam: HlTeam;
  league: { id: number; season: number; name: string; logo?: string };
  state: { description: string; clock?: number; score?: { current?: string; penalties?: string } };
  venue?: { city?: string; name?: string; country?: string; capacity?: string };
}
interface HlPage<T> { data: T[]; pagination: { totalCount: number; offset: number; limit: number }; plan?: { tier: string; message: string } }
interface HlOdds { matchId: number; odds: { bookmakerId: number; bookmakerName?: string; type?: string; market: string; values: { odd: number; value: string }[] }[] }

const STATE_MAP: Record<string, EventStatus> = {
  'To be announced': 'scheduled', 'Not started': 'scheduled',
  'First half': 'live', 'Half time': 'live', 'Second half': 'live', 'Extra time': 'live', 'Break time': 'live', 'Penalties': 'live', 'In progress': 'live',
  'Suspended': 'live', 'Interrupted': 'live',
  'Finished': 'finished', 'Finished after penalties': 'finished', 'Finished after extra time': 'finished', 'Awarded': 'finished',
  'Postponed': 'postponed', 'Cancelled': 'cancelled', 'Abandoned': 'abandoned', 'Unknown': 'unknown',
};

export function parseScore(s: string | undefined | null): [number, number] | null {
  if (!s) return null;
  const m = /(\d+)\s*[-:]\s*(\d+)/.exec(s);
  return m ? [Number(m[1]), Number(m[2])] : null;
}

export function mapHlMatch(m: HlMatch): ProviderFixture {
  const status = STATE_MAP[m.state?.description] ?? 'unknown';
  const sc = parseScore(m.state?.score?.current);
  return {
    provider: 'highlightly',
    providerEventId: String(m.id),
    competition: { providerId: String(m.league.id), name: m.league.name, countryCode: m.country?.code ?? null, countryName: m.country?.name ?? null, season: m.league.season != null ? String(m.league.season) : null },
    round: m.round ?? null,
    home: { providerId: String(m.homeTeam.id), name: m.homeTeam.name, type: m.homeTeam.type, countryCode: m.country?.code ?? null },
    away: { providerId: String(m.awayTeam.id), name: m.awayTeam.name, type: m.awayTeam.type, countryCode: m.country?.code ?? null },
    kickoffUtc: new Date(m.date).toISOString(),
    status,
    // Für das Modell zählt das Ergebnis nach regulärer Spielzeit; Highlightly liefert "current".
    homeGoals: status === 'finished' && sc ? sc[0] : null,
    awayGoals: status === 'finished' && sc ? sc[1] : null,
    venue: m.venue?.name ?? null,
  };
}

/** Ordnet einen Highlightly-Odds-Markt den drei MVP-Märkten zu. null = nicht unterstützt/unbekannt. */
export function mapHlMarket(market: string, values: { odd: number; value: string }[]):
  { market: MarketId; line: number | null; prices: Partial<Record<SelectionId, number>> }[] | null {
  const m = market.trim().toLowerCase();
  if (/(half|1st|2nd|corner|card|booking|team total|home team|away team|asian|handicap|exact|double chance|draw no bet|minute|player)/.test(m)) return [];
  const clean = values.filter(v => Number.isFinite(v.odd) && v.odd > 1);
  if (/^(full ?time result|match winner|match result|1x2|3[- ]?way( result)?|fulltime result|result)$/.test(m)) {
    const p: Partial<Record<SelectionId, number>> = {};
    for (const v of clean) {
      const s = v.value.trim().toLowerCase();
      if (s === 'home' || s === '1') p.HOME = v.odd; else if (s === 'draw' || s === 'x') p.DRAW = v.odd; else if (s === 'away' || s === '2') p.AWAY = v.odd;
    }
    return [{ market: '1X2', line: null, prices: p }];
  }
  if (/(over ?\/ ?under|goals over|total goals|^totals?$|^goals$)/.test(m)) {
    const byLine = new Map<number, Partial<Record<SelectionId, number>>>();
    for (const v of clean) {
      const mm = /^(over|under)\s*([0-9]+(?:\.[0-9]+)?)$/i.exec(v.value.trim());
      if (!mm) continue;
      const line = Number(mm[2]);
      const rec = byLine.get(line) ?? {};
      rec[mm[1].toLowerCase() === 'over' ? 'OVER' : 'UNDER'] = v.odd;
      byLine.set(line, rec);
    }
    return [...byLine.entries()].map(([line, prices]) => ({ market: 'OU' as MarketId, line, prices }));
  }
  if (/(both teams to score|both teams score|btts|gg\/ng)/.test(m)) {
    const p: Partial<Record<SelectionId, number>> = {};
    for (const v of clean) { const s = v.value.trim().toLowerCase(); if (s === 'yes') p.YES = v.odd; else if (s === 'no') p.NO = v.odd; }
    return [{ market: 'BTTS', line: null, prices: p }];
  }
  return null;
}

const STAT_KEYS: [RegExp, string][] = [
  [/^expected goals( \(xg\))?$|^xg$/i, 'xg'],
  [/^shots on (target|goal)$/i, 'shots_on_target'],
  [/^(total shots|shots total|shots)$/i, 'shots'],
  [/^(ball )?possession/i, 'possession'],
  [/^corner/i, 'corners'],
];

export class HighlightlyProvider implements FootballDataProvider, OddsProvider {
  readonly name = 'highlightly';
  readonly sharesEventIdsWith = 'highlightly';
  readonly capabilities: ProviderCapabilities = {
    fixtures: true, history: true, teamStats: true, standings: true, lineups: true, matchStats: true,
    injuries: false, // In der Spezifikation 8.2.7 gibt es keinen Verletzungs-Endpunkt.
    odds: true, liveScores: true,
  };

  constructor(private q: ApiQueue, private o: HighlightlyOptions) {}

  private guard(): void {
    if (!this.o.apiKey) throw new ProviderBlockedError(this.name, 'HIGHLIGHTLY_API_KEY ist nicht gesetzt.');
    if (!this.o.bettingUseConfirmed) throw new ProviderBlockedError(this.name, 'Highlightly ist für Wettanalysen gesperrt (HIGHLIGHTLY_BETTING_USE_CONFIRMED=false).');
  }

  private async get<T>(path: string, params: Record<string, string | number | undefined>, ttlSeconds: number, priority = 0): Promise<T> {
    return (await this.getMeta<T>(path, params, ttlSeconds, priority)).data;
  }

  private getMeta<T>(path: string, params: Record<string, string | number | undefined>, ttlSeconds: number, priority = 0, maxCacheAgeSeconds?: (data: any, now: Date) => number | null) {
    this.guard();
    // Pfade hängen an die Basis an (wichtig für die All-Sports-Variante mit /football-Präfix)
    const u = new URL(this.o.baseUrl.replace(/\/$/, '') + path);
    for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== '') u.searchParams.set(k, String(v));
    const headers: Record<string, string> = { 'x-rapidapi-key': this.o.apiKey! };
    if (this.o.rapidApiHost) headers['x-rapidapi-host'] = this.o.rapidApiHost;
    return this.q.requestMeta<T>({ provider: this.name, url: u.toString(), headers, ttlSeconds, priority, maxCacheAgeSeconds, note: path });
  }

  private async paged<T>(path: string, params: Record<string, string | number | undefined>, limit: number, ttl: number, maxPages = 20): Promise<T[]> {
    const out: T[] = [];
    for (let page = 0, offset = 0; page < maxPages; page++, offset += limit) {
      const r = await this.get<HlPage<T>>(path, { ...params, limit, offset }, ttl);
      out.push(...(r?.data ?? []));
      const total = r?.pagination?.totalCount ?? 0;
      if (!r?.data?.length || offset + limit >= total) break;
    }
    return out;
  }

  async upcomingFixtures(fromUtc: Date, toUtc: Date): Promise<ProviderFixture[]> {
    const days: string[] = [];
    for (let d = new Date(Date.UTC(fromUtc.getUTCFullYear(), fromUtc.getUTCMonth(), fromUtc.getUTCDate())); d <= toUtc; d = new Date(d.getTime() + 86_400_000)) days.push(d.toISOString().slice(0, 10));
    const all: ProviderFixture[] = [];
    for (const date of days) {
      const rows = await this.paged<HlMatch>('/matches', { date, timezone: 'Etc/UTC' }, 100, 30 * 60);
      for (const m of rows) {
        const f = mapHlMatch(m);
        const t = new Date(f.kickoffUtc);
        if (t >= fromUtc && t <= toUtc) all.push(f);
      }
    }
    return all;
  }

  async historicalResults(c: ProviderCompetition, season: string | null): Promise<ProviderFixture[]> {
    const rows = await this.paged<HlMatch>('/matches', { leagueId: c.providerId, season: season ?? undefined, timezone: 'Etc/UTC' }, 100, 12 * 3600, 30);
    return rows.map(mapHlMatch).filter(f => f.status === 'finished' && f.homeGoals != null);
  }

  async lastGames(teamProviderId: string): Promise<ProviderFixture[]> {
    const rows = await this.get<HlMatch[]>('/last-five-games', { teamId: teamProviderId }, 6 * 3600);
    return (rows ?? []).map(mapHlMatch);
  }

  async headToHead(a: string, b: string): Promise<ProviderFixture[]> {
    const rows = await this.get<HlMatch[]>('/head-2-head', { teamIdOne: a, teamIdTwo: b }, 24 * 3600);
    return (rows ?? []).map(mapHlMatch);
  }

  async matchDetails(id: string): Promise<ProviderFixture | null> {
    const rows = await this.get<HlMatch[]>(`/matches/${encodeURIComponent(id)}`, {}, 10 * 60, 5);
    return rows?.[0] ? mapHlMatch(rows[0]) : null;
  }

  async matchStatistics(id: string): Promise<ProviderMatchStat[]> {
    const rows = await this.get<{ team: HlTeam; statistics: { value: number; displayName: string }[] }[]>(`/statistics/${encodeURIComponent(id)}`, {}, 24 * 3600);
    const out: ProviderMatchStat[] = [];
    for (const t of rows ?? []) for (const s of t.statistics ?? []) {
      const k = STAT_KEYS.find(([re]) => re.test(s.displayName.trim()));
      if (k && Number.isFinite(s.value)) out.push({ teamProviderId: String(t.team.id), key: k[1], value: s.value });
    }
    return out;
  }

  async lineups(id: string): Promise<ProviderLineup[]> {
    type P = { id?: number; name: string; number: number; position: string };
    type T = { id: number; formation: string; name: string; substitutes: P[]; initialLineup: P[] | P[][] };
    const r = await this.get<{ homeTeam: T; awayTeam: T }>(`/lineups/${encodeURIComponent(id)}`, {}, 20 * 60, 3);
    if (!r) return [];
    return [r.homeTeam, r.awayTeam].filter(Boolean).map(t => ({
      teamProviderId: String(t.id),
      status: 'confirmed' as const,
      formation: t.formation ?? null,
      players: [
        ...(t.initialLineup ?? []).flat().map(p => ({ name: p.name, number: p.number, position: p.position, starter: true })),
        ...(t.substitutes ?? []).map(p => ({ name: p.name, number: p.number, position: p.position, starter: false })),
      ],
    }));
  }

  async teamStatistics(teamProviderId: string, fromDate: string): Promise<ProviderTeamStats[]> {
    type S = { games: { played: number; wins: number; loses: number; draws: number }; goals: { scored: number; received: number } };
    const rows = await this.get<{ leagueId: number; season: number; leagueName: string; total: S; home: S; away: S }[]>(`/teams/statistics/${encodeURIComponent(teamProviderId)}`, { fromDate, timezone: 'Etc/UTC' }, 12 * 3600);
    const out: ProviderTeamStats[] = [];
    for (const r of rows ?? []) for (const scope of ['total', 'home', 'away'] as const) {
      const s = r[scope]; if (!s) continue;
      out.push({ teamProviderId, competitionProviderId: String(r.leagueId), season: String(r.season), scope,
        played: s.games.played, wins: s.games.wins, draws: s.games.draws, losses: s.games.loses, goalsFor: s.goals.scored, goalsAgainst: s.goals.received });
    }
    return out;
  }

  async standings(leagueId: string, season: string): Promise<ProviderStanding[]> {
    type St = { wins: number; draws: number; games: number; loses: number; scoredGoals: number; receivedGoals: number };
    const r = await this.get<{ groups: { name: string; standings: { team: HlTeam; total: St; points: number; position: number }[] }[] }>('/standings', { leagueId, season }, 6 * 3600);
    return (r?.groups ?? []).flatMap(g => g.standings.map(s => ({
      teamProviderId: String(s.team.id), teamName: s.team.name, position: s.position, points: s.points,
      played: s.total.games, goalsFor: s.total.scoredGoals, goalsAgainst: s.total.receivedGoals,
    })));
  }

  async bookmakers(): Promise<{ providerId: string; name: string }[]> {
    const rows = await this.paged<{ id: number; name: string }>('/bookmakers', {}, 100, 7 * 86400, 5);
    return rows.map(b => ({ providerId: String(b.id), name: b.name }));
  }

  async oddsForFixtures(fixtures: ProviderFixture[]): Promise<ProviderOddsQuote[]> {
    const out: ProviderOddsQuote[] = [];
    for (const f of fixtures.filter(x => x.provider === this.name)) {
      // v0.3.0: dynamische Cache-Regel nach Anstoß; Highlightly liefert keinen Quellzeitstempel → strengere Grenze
      const kick = f.kickoffUtc;
      const meta = await this.getMeta<HlPage<HlOdds>>('/odds', { matchId: f.providerEventId, oddsType: 'prematch' }, ODDS_CACHE_MAX_SECONDS, 2,
        (_d, now) => { const m = minutesToNextKickoff([kick], now); return m == null ? null : oddsCacheMaxAgeSeconds(m, 90, false); });
      const r = meta.data, retrievedAt = meta.fetchedAt;
      for (const d of r?.data ?? []) for (const o of d.odds ?? []) {
        if (o.type && !/pre/i.test(o.type)) continue;
        const mapped = mapHlMarket(o.market, o.values ?? []);
        if (mapped === null) { this.o.onUnmappedMarket?.(o.market, (o.values ?? []).slice(0, 3).map(v => v.value).join('|')); continue; }
        for (const mm of mapped) out.push({
          provider: this.name, providerEventId: String(d.matchId),
          bookmakerProviderId: String(o.bookmakerId), bookmakerName: o.bookmakerName ?? `Bookmaker ${o.bookmakerId}`,
          market: mm.market, line: mm.line, marketStatus: 'open', prices: mm.prices,
          retrievedAt, sourceTimestamp: null, fromCache: meta.fromCache, snapshotKind: 'live', // Highlightly liefert keinen Quoten-Zeitstempel → strengere Frische-Grenze
        });
      }
    }
    return out;
  }
}
