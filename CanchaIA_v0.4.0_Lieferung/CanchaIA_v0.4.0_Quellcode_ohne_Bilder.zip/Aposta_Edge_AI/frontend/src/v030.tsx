/**
 * v0.3.0-Oberflächen: Provider-Bereitschaft, kontrollierter Diagnose-Sync, Abrufprotokoll, Validierung (Admin),
 * Tarif/Zahlung und persönliche Benachrichtigungen (Benutzer), Zahlungsprüfung (Admin).
 * Fügt sich in die bestehende Struktur ein (gleiche Klassen, keine neue Bibliothek).
 */
import React, { useState } from 'react';
import { api, localTime, pct } from './api';
import { useApp, Loading, ErrorBox } from './components';
import { useLoad } from './hooks';
import { tr } from './reasons';
import { ANALYST, LOCALE } from './brand';

type L3 = 'es' | 'de' | 'en';
const D = {
  es: { providers: 'Proveedores', controlled: 'Sincronización controlada', runOnce: 'Ejecutar una vez', maxEvents: 'Máx. partidos', checks: 'Comprobaciones', requests: 'Llamadas API', credits: 'Créditos', events: 'Partidos', notVerified: 'NO VERIFICADO EN VIVO', plan: 'Plan', subscription: 'Suscripción', choose: 'Elegir', monthly: 'mensual', yearly: 'anual', status: 'Estado', expires: 'Vence', pending: 'Pagos pendientes', reference: 'Concepto', amount: 'Monto', upload: 'Subir comprobante', proofHint: 'El comprobante no activa el plan: se activa solo después de verificar el ingreso.', personal: 'Notificaciones personales', enable: 'Activar notificaciones personales (solo en la app)', minEv: 'EV mínimo para avisos (%)', inbox: 'Mis avisos', markRead: 'Marcar todo como leído', payments: 'Pagos (verificación manual)', verify: 'Verificar', reject: 'Rechazar', bankRef: 'Referencia bancaria', received: 'Monto recibido (Gs.)', receivedAt: 'Fecha de ingreso', confirm: 'Confirmo que el monto está acreditado en la cuenta', subsAdmin: 'Suscripciones', grant: 'Activar sin pago (con motivo)', reason: 'Motivo', months: 'Meses', validation: 'Validación histórica', runValidation: 'Ejecutar validación', dataQuality: 'Calidad de datos', notEnforced: 'Los planes todavía no se aplican: todas las funciones siguen disponibles.', cancel: 'Cancelar suscripción', testMode: 'MODO DE PRUEBA – no se realizan cobros', noBank: 'Datos de transferencia aún no configurados por el operador.' },
  de: { providers: 'Provider', controlled: 'Kontrollierter Sync', runOnce: 'Einmal ausführen', maxEvents: 'Max. Spiele', checks: 'Prüfungen', requests: 'API-Abrufe', credits: 'Credits', events: 'Spiele', notVerified: 'NICHT LIVE VERIFIZIERT', plan: 'Tarif', subscription: 'Abonnement', choose: 'Wählen', monthly: 'monatlich', yearly: 'jährlich', status: 'Status', expires: 'Läuft ab', pending: 'Offene Zahlungen', reference: 'Verwendungszweck', amount: 'Betrag', upload: 'Beleg hochladen', proofHint: 'Der Beleg schaltet nichts frei: Freischaltung erst nach geprüftem Zahlungseingang.', personal: 'Persönliche Benachrichtigungen', enable: 'Persönliche Benachrichtigungen aktivieren (nur in der App)', minEv: 'Mindest-EV für Meldungen (%)', inbox: 'Meine Meldungen', markRead: 'Alle als gelesen markieren', payments: 'Zahlungen (manuelle Prüfung)', verify: 'Bestätigen', reject: 'Ablehnen', bankRef: 'Bankreferenz', received: 'Erhaltener Betrag (Gs.)', receivedAt: 'Eingangsdatum', confirm: 'Ich bestätige, dass der Betrag auf dem Konto eingegangen ist', subsAdmin: 'Abonnements', grant: 'Ohne Zahlung freischalten (mit Begründung)', reason: 'Begründung', months: 'Monate', validation: 'Historische Validierung', runValidation: 'Validierung ausführen', dataQuality: 'Datenqualität', notEnforced: 'Tarife werden noch nicht durchgesetzt: alle Funktionen bleiben verfügbar.', cancel: 'Abo kündigen', testMode: 'TESTMODUS – es werden keine Zahlungen ausgelöst', noBank: 'Überweisungsdaten vom Betreiber noch nicht hinterlegt.' },
  en: { providers: 'Providers', controlled: 'Controlled sync', runOnce: 'Run once', maxEvents: 'Max. matches', checks: 'Checks', requests: 'API calls', credits: 'Credits', events: 'Matches', notVerified: 'NOT LIVE VERIFIED', plan: 'Plan', subscription: 'Subscription', choose: 'Choose', monthly: 'monthly', yearly: 'yearly', status: 'Status', expires: 'Expires', pending: 'Pending payments', reference: 'Reference', amount: 'Amount', upload: 'Upload receipt', proofHint: 'A receipt does not activate the plan: activation only after the payment has been verified.', personal: 'Personal notifications', enable: 'Enable personal notifications (in-app only)', minEv: 'Minimum EV for alerts (%)', inbox: 'My alerts', markRead: 'Mark all read', payments: 'Payments (manual review)', verify: 'Verify', reject: 'Reject', bankRef: 'Bank reference', received: 'Amount received (PYG)', receivedAt: 'Received on', confirm: 'I confirm the amount has been credited to the account', subsAdmin: 'Subscriptions', grant: 'Activate without payment (with reason)', reason: 'Reason', months: 'Months', validation: 'Historical validation', runValidation: 'Run validation', dataQuality: 'Data quality', notEnforced: 'Plans are not enforced yet: all features remain available.', cancel: 'Cancel subscription', testMode: 'TEST MODE – no charges are made', noBank: 'Transfer details not yet configured by the operator.' },
};
const INSTR: Record<L3, Record<string, string>> = {
  es: { procedure: 'Procedimiento', bank: 'Banco', alias: 'Alias', accountHolder: 'Titular', amountPyg: 'Monto (Gs.)', reference: 'Concepto', note: 'Nota',
    sipap_alias_manual_review: 'Transferencia SIPAP al alias (verificación manual)', upay_test_mode_no_charge: 'uPay MODO DE PRUEBA – sin cobro',
    activation_after_verified_payment: 'Activación solo después de verificar el ingreso.', bank_details_not_configured: 'Datos bancarios aún no configurados.', no_merchant_approval_manual_review_only: 'Sin habilitación de comercio: pago simulado, verificación manual.' },
  de: { procedure: 'Verfahren', bank: 'Bank', alias: 'Alias', accountHolder: 'Kontoinhaber', amountPyg: 'Betrag (Gs.)', reference: 'Verwendungszweck', note: 'Hinweis',
    sipap_alias_manual_review: 'SIPAP-Überweisung an den Alias (manuelle Prüfung)', upay_test_mode_no_charge: 'uPay TESTMODUS – keine Belastung',
    activation_after_verified_payment: 'Freischaltung erst nach geprüftem Zahlungseingang.', bank_details_not_configured: 'Bankdaten noch nicht hinterlegt.', no_merchant_approval_manual_review_only: 'Keine Händlerfreigabe: Zahlung simuliert, manuelle Prüfung.' },
  en: { procedure: 'Procedure', bank: 'Bank', alias: 'Alias', accountHolder: 'Account holder', amountPyg: 'Amount (PYG)', reference: 'Reference', note: 'Note',
    sipap_alias_manual_review: 'SIPAP transfer to alias (manual review)', upay_test_mode_no_charge: 'uPay TEST MODE – no charge',
    activation_after_verified_payment: 'Activation only after the payment is verified.', bank_details_not_configured: 'Bank details not configured yet.', no_merchant_approval_manual_review_only: 'No merchant approval: simulated payment, manual review.' },
};
const useT = () => { const { lang } = useApp(); return D[(lang as L3)] ?? D.es; };
/** Guaraní immer im paraguayischen Format (1.250.000 Gs.), unabhängig von der UI-Sprache */
const gs = (n: number | null | undefined) => n == null ? '–' : `${new Intl.NumberFormat(LOCALE.es).format(n)} Gs.`;
const chipFor = (s: string) => ['READY', 'ACTIVE', 'VERIFIED', 'DONE', 'AVAILABLE', 'LIVE VERIFIED'].includes(s) ? 'ok' : ['NONE', 'NOT CONFIGURED', 'PENDING', 'AWAITING_PAYMENT', 'PROOF_SUBMITTED', 'MOCK MODE', 'NOT VERIFIED', 'UNVALIDATED'].includes(s) ? 'neutral' : 'bad';

// ------------------------------------------------------------------ ADMIN: Provider + kontrollierter Sync
export function ProviderStates({ states, pilot }: { states: any[]; pilot?: any }) {
  const T = useT();
  return <div className="card"><h2>{T.providers}{pilot?.enabled ? <small> · PILOT {pilot.sportKeys.join(', ')}</small> : null}</h2>
    <div className="tablewrap"><table><tbody>{states.map(p => <tr key={p.provider}><td><b>{p.provider}</b></td><td><span className={`chip ${chipFor(p.status)}`}>{p.status}</span></td><td className="small">{p.roles.join(', ')}</td><td className="small muted">{p.reason ?? ''}</td></tr>)}</tbody></table></div></div>;
}

export function ControlledSync() {
  const T = useT(); const { lang, tz } = useApp();
  const [max, setMax] = useState(10), [busy, setBusy] = useState(false), [rep, setRep] = useState<any>(null), [err, setErr] = useState('');
  const run = async () => { setBusy(true); setErr(''); try { setRep(await api('/api/admin/diagnostics/controlled-sync', { method: 'POST', body: JSON.stringify({ maxEvents: max }) })); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); } };
  return <div className="card stack"><h2>{T.controlled}</h2>
    <div className="flex"><label className="f">{T.maxEvents}<input id="cs-max" type="number" min={1} max={60} value={max} onChange={e => setMax(Number(e.target.value))} /></label>
      <button className="btn" onClick={run} disabled={busy}>{busy ? '…' : T.runOnce}</button></div>
    {err ? <div className="banner err">{err}</div> : null}
    {rep ? <>
      <div className="flex"><span className={`chip ${chipFor(rep.status)}`}>{rep.status}</span><span className={`chip ${chipFor(rep.liveVerification)}`}>{rep.liveVerification === 'NOT VERIFIED' ? T.notVerified : rep.liveVerification}</span>
        <span className="small muted">#{rep.diagnosticId} · {localTime(rep.startedAt, tz, lang)} · {T.credits}: {Object.entries(rep.creditsUsed).map(([p, c]) => `${p} ${c}`).join(', ') || 0}</span></div>
      {rep.notes.map((n: string) => <div key={n} className="banner info">{n}</div>)}
      <h3>{T.checks}</h3>
      <div className="tablewrap"><table><tbody>{rep.checks.map((c: any) => <tr key={c.name}><td><span className={`chip ${c.ok ? 'ok' : 'bad'}`}>{c.ok ? 'OK' : '✗'}</span></td><td>{c.name}</td><td className="small muted">{c.detail}</td></tr>)}</tbody></table></div>
      <h3>{T.events} ({rep.events.length})</h3>
      <div className="tablewrap"><table><thead><tr><th>Kick-off</th><th></th><th>1X2</th><th>O/U</th><th>BTTS</th><th></th></tr></thead><tbody>{rep.events.map((e: any) => <tr key={e.eventId}>
        <td className="num small">{localTime(e.kickoffUtc, tz, lang)}</td><td><b>{e.home} – {e.away}</b><div className="small muted">{e.competition} · {e.providerEventIds.join(' ')}</div></td>
        {(['1X2', 'OU', 'BTTS'] as const).map(m => <td key={m} className="n small">{e.markets[m].books ? `${e.markets[m].fresh}/${e.markets[m].books}` : '–'}</td>)}
        <td className="small muted">{e.prediction}{e.topSignal ? ` · ${e.topSignal}` : ''}</td></tr>)}</tbody></table></div>
      <h3>{T.requests} ({rep.apiRequests.length})</h3>
      <div className="tablewrap"><table><tbody>{rep.apiRequests.map((r: any, i: number) => <tr key={i}><td className="num small">{localTime(r.at, tz, lang)}</td><td>{r.provider}</td><td className="small">{r.endpoint}<div className="muted">{r.query ?? ''}</div></td><td className="n">{r.status}</td><td>{r.fromCache ? 'cache' : ''}</td><td className="n">{r.cost}</td><td className="small muted">{r.note ?? ''}</td></tr>)}</tbody></table></div>
      {rep.mapping.unlinkedTeams.length || rep.mapping.unmatchedEvents.length ? <ul className="reasons">{[...rep.mapping.unlinkedTeams, ...rep.mapping.unmatchedEvents].map((m: any) => <li key={m.ref}>{m.ref}: {m.detail}</li>)}</ul> : null}
    </> : null}
  </div>;
}

export function ApiLog({ rows }: { rows: any[] }) {
  const T = useT(); const { lang, tz } = useApp();
  return <details className="card"><summary><b>{T.requests}</b> <small className="muted">({rows.length})</small></summary><div className="tablewrap"><table><tbody>{rows.map(r => <tr key={r.id}>
    <td className="num small">{localTime(r.created_at, tz, lang)}</td><td>{r.provider}</td><td className="small">{r.endpoint}<div className="muted">{r.query ?? ''}</div></td><td className="n">{r.status}</td><td>{r.from_cache ? 'cache' : ''}</td><td className="n">{r.cost}</td><td className="small muted">{r.note ?? ''}</td></tr>)}</tbody></table></div></details>;
}

export function Validation() {
  const T = useT();
  const v = useLoad<any>('/api/admin/validation/latest');
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState('');
  const run = async () => { setBusy(true); setMsg(''); try { const r = await api<any>('/api/admin/validation/run', { method: 'POST' }); setMsg(`#${r.id}: ${r.status}`); v.reload(); } catch (e) { setMsg((e as Error).message); } finally { setBusy(false); } };
  const r = v.data;
  return <div className="card stack"><h2>{T.validation}</h2>
    <div className="flex"><button className="btn ghost" onClick={run} disabled={busy}>{busy ? '…' : T.runValidation}</button><span className="small muted">{msg}</span></div>
    {r ? <>
      <div className="flex"><span className={`chip ${chipFor(r.status)}`}>{r.status}</span><span className="small muted">#{r.id} · {r.generatedAt}</span></div>
      <ul className="reasons">{r.reasons.map((x: string) => <li key={x}>{x}</li>)}</ul>
      <h3>{T.dataQuality}</h3>
      <div className="tablewrap"><table><thead><tr><th></th><th className="n">n</th><th className="n">✗ result</th><th className="n">dup</th><th className="n">alias?</th><th className="n">pre 1X2</th><th></th></tr></thead>
        <tbody>{r.dataQuality.competitions.map((c: any) => <tr key={c.competitionId}><td>{c.name}{c.isMock ? ' · MOCK' : ''}</td><td className="n">{c.finishedWithResult}</td><td className="n">{c.missingResults}</td><td className="n">{c.duplicateMatches.length}</td><td className="n">{c.possibleDuplicateTeams.length}</td><td className="n">{pct(c.oddsCoverage.preClosing1x2, 0)}</td><td><span className={`chip ${c.usableForBacktest ? 'ok' : 'neutral'}`}>{c.usableForBacktest ? 'OK' : '–'}</span></td></tr>)}</tbody></table></div>
      <details><summary className="small muted">Markdown</summary><pre className="code">{r.markdown}</pre></details>
    </> : <span className="small muted">–</span>}
  </div>;
}

// ------------------------------------------------------------------ ADMIN: Zahlungen und Abos
export function PaymentsAdmin() {
  const T = useT(); const { lang, tz } = useApp();
  const p = useLoad<any[]>('/api/admin/payments'), s = useLoad<any[]>('/api/admin/subscriptions'), ev = useLoad<any[]>('/api/admin/subscription-events');
  const [open, setOpen] = useState<number | null>(null), [form, setForm] = useState<any>({}), [msg, setMsg] = useState(''), [proof, setProof] = useState<any[] | null>(null);
  const [g, setG] = useState<any>({ planId: 'PRO', months: 1 });
  const reload = () => { p.reload(); s.reload(); ev.reload(); };
  const act = async (url: string, body: object) => { setMsg(''); try { await api(url, { method: 'POST', body: JSON.stringify(body) }); setOpen(null); setForm({}); reload(); } catch (e) { setMsg((e as Error).message); } };
  const showProof = async (id: number) => { setProof(null); try { setProof(await api<any[]>(`/api/admin/payments/${id}/proof`)); } catch (e) { setMsg((e as Error).message); } };
  return <>
    <div className="card stack"><h2>{T.payments}</h2>
      {msg ? <div className="banner err">{msg}</div> : null}
      <div className="tablewrap"><table><thead><tr><th>#</th><th>E-Mail</th><th>{T.plan}</th><th className="n">{T.amount}</th><th>{T.reference}</th><th>{T.status}</th><th></th></tr></thead>
        <tbody>{(p.data ?? []).map(x => <React.Fragment key={x.id}><tr>
          <td className="n">{x.id}</td><td className="small">{x.email}</td><td>{x.plan_id} · {x.billing_period}</td><td className="n">{gs(x.amount_pyg)}</td><td className="num small">{x.reference}<div className="muted">{x.method}{x.provider_mode === 'test' ? ' · TEST' : ''}</div></td>
          <td><span className={`chip ${chipFor(x.status)}`}>{x.status}</span>{x.proofs ? <button className="btn ghost" style={{ padding: '2px 8px' }} onClick={() => showProof(x.id)}>📎 {x.proofs}</button> : null}</td>
          <td>{['AWAITING_PAYMENT', 'PROOF_SUBMITTED'].includes(x.status) ? <button className="btn ghost" style={{ padding: '2px 8px' }} onClick={() => { setOpen(x.id); setForm({ receivedAmountPyg: '', receivedAt: new Date().toISOString().slice(0, 10) }); }}>…</button> : <span className="small muted">{x.bank_reference ?? x.decision_note ?? ''}</span>}</td></tr>
          {open === x.id ? <tr><td colSpan={7}><div className="stack">
            <label className="f">{T.bankRef}<input value={form.bankReference ?? ''} onChange={e => setForm({ ...form, bankReference: e.target.value })} /></label>
            <label className="f">{T.received}<input type="number" value={form.receivedAmountPyg} onChange={e => setForm({ ...form, receivedAmountPyg: e.target.value })} placeholder={String(x.amount_pyg)} /></label>
            <label className="f">{T.receivedAt}<input type="date" value={form.receivedAt} onChange={e => setForm({ ...form, receivedAt: e.target.value })} /></label>
            <label className="flex"><input type="checkbox" checked={!!form.confirmReceived} onChange={e => setForm({ ...form, confirmReceived: e.target.checked })} /> {T.confirm}</label>
            <div className="flex"><button className="btn" disabled={!form.confirmReceived || !form.bankReference} onClick={() => act(`/api/admin/payments/${x.id}/verify`, { bankReference: form.bankReference, receivedAmountPyg: Number(form.receivedAmountPyg), receivedAt: new Date(form.receivedAt + 'T12:00:00Z') > new Date() ? new Date().toISOString() : new Date(form.receivedAt + 'T12:00:00Z').toISOString(), confirmReceived: true })}>{T.verify}</button>
              <input placeholder={T.reason} value={form.reason ?? ''} onChange={e => setForm({ ...form, reason: e.target.value })} /><button className="btn ghost" disabled={!form.reason} onClick={() => act(`/api/admin/payments/${x.id}/reject`, { reason: form.reason })}>{T.reject}</button></div>
          </div></td></tr> : null}</React.Fragment>)}</tbody></table></div>
      {proof ? <div className="stack">{proof.map(f => <div key={f.id} className="small">{f.file_name} · {f.mime} · {f.size} B · sha256 {f.sha256.slice(0, 12)}… {f.content ? <a href={`data:${f.mime};base64,${f.content}`} download={f.file_name}>↓</a> : '(gelöscht nach Aufbewahrungsfrist)'}</div>)}</div> : null}
    </div>
    <div className="card stack"><h2>{T.subsAdmin}</h2>
      <div className="tablewrap"><table><tbody>{(s.data ?? []).map(x => <tr key={x.id}><td className="n">{x.id}</td><td className="small">{x.email}</td><td>{x.plan_id} · {x.billing_period}</td><td><span className={`chip ${chipFor(x.status)}`}>{x.status}</span></td><td className="num small">{x.expires_at ? localTime(x.expires_at, tz, lang) : '–'}</td><td className="small muted">{x.note ?? ''}</td>
        <td>{['ACTIVE', 'PENDING'].includes(x.status) ? <button className="btn ghost" style={{ padding: '2px 8px' }} onClick={() => { const r = prompt(T.reason); if (r) act(`/api/admin/subscriptions/${x.id}/cancel`, { reason: r }); }}>✕</button> : null}</td></tr>)}</tbody></table></div>
      <div className="flex"><span className="small muted">{T.grant}:</span>
        <input type="number" placeholder="userId" style={{ width: 90 }} value={g.userId ?? ''} onChange={e => setG({ ...g, userId: Number(e.target.value) })} />
        <select value={g.planId} onChange={e => setG({ ...g, planId: e.target.value })}><option>PRO</option><option>PREMIUM</option></select>
        <input type="number" min={1} max={12} style={{ width: 70 }} value={g.months} onChange={e => setG({ ...g, months: Number(e.target.value) })} aria-label={T.months} />
        <input placeholder={T.reason} value={g.reason ?? ''} onChange={e => setG({ ...g, reason: e.target.value })} />
        <button className="btn ghost" disabled={!g.userId || !(g.reason?.length >= 5)} onClick={() => act('/api/admin/subscriptions/grant', g)}>OK</button></div>
      <details><summary className="small muted">Log ({ev.data?.length ?? 0})</summary><div className="tablewrap"><table><tbody>{(ev.data ?? []).map(e => <tr key={e.id}><td className="num small">{localTime(e.created_at, tz, lang)}</td><td>{e.action}</td><td className="small">{e.user_email ?? ''}</td><td className="small">{e.from_status ?? ''} → {e.to_status ?? ''}</td><td className="small muted">{e.actor_email ?? 'system'} · {e.detail ?? ''}</td></tr>)}</tbody></table></div></details>
    </div>
  </>;
}

// ------------------------------------------------------------------ BENUTZER: Tarif, Zahlung, persönliche Meldungen
/** Tarif und Zahlung (Logik unverändert aus v0.3.0, aufgeteilt für die neue Einstellungsseite). */
export function PlanSection() {
  const T = useT(); const { lang, tz } = useApp();
  const o = useLoad<any>('/api/subscription');
  const [msg, setMsg] = useState(''), [period, setPeriod] = useState<'monthly' | 'yearly'>('monthly'), [method, setMethod] = useState('bank_transfer');
  if (o.err) return <ErrorBox e={o.err} />;
  if (!o.data) return <Loading />;
  const x = o.data;
  const order = async (planId: string) => { setMsg(''); try { await api('/api/subscription/checkout', { method: 'POST', body: JSON.stringify({ planId, period, method }) }); o.reload(); } catch (e) { setMsg((e as Error).message); } };
  const upload = async (paymentId: number, f: File) => {
    setMsg('');
    try {
      const b64 = await new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1] ?? ''); r.onerror = rej; r.readAsDataURL(f); });
      const r = await api<any>(`/api/payments/${paymentId}/proof`, { method: 'POST', body: JSON.stringify({ fileName: f.name, mime: f.type, dataBase64: b64 }) });
      setMsg(r.note); o.reload();
    } catch (e) { setMsg((e as Error).message); }
  };
  return <div className="stack lg">
    {!x.enforced ? <div className="banner info"><span>{T.notEnforced}</span></div> : null}
    <div className="row-flex"><span className="badge info">{x.plan}</span><span className={`chip ${chipFor(x.status)}`}>{x.status}</span>{x.expiresAt ? <span className="small t-2">{T.expires}: {localTime(x.expiresAt, tz, lang)}</span> : null}
      {x.current && x.current.status === 'ACTIVE' ? <button className="btn danger sm" onClick={async () => { await api('/api/subscription/cancel', { method: 'POST' }); o.reload(); }}>{T.cancel}</button> : null}</div>
    <div className="row-flex">
      <div className="seg" role="group" aria-label="period">{(['monthly', 'yearly'] as const).map(k => <button key={k} aria-pressed={period === k} onClick={() => setPeriod(k)}>{k === 'monthly' ? T.monthly : T.yearly}</button>)}</div>
      <select value={method} onChange={e => setMethod(e.target.value)} aria-label="method">{x.methods.map((m: any) => <option key={m.method} value={m.method}>{m.method === 'bank_transfer' ? 'SIPAP / Alias' : `uPay (${m.mode})`}</option>)}</select>
    </div>
    <div className="grid two">{x.plans.filter((p: any) => p.id !== 'FREE').map((p: any) => <div key={p.id} className="card stack" style={{ background: 'var(--raised)' }}>
      <div className="row-flex between"><b>{p.name}</b>{x.plan === p.id ? <span className="badge value">✓</span> : null}</div>
      <span className="kpi" style={{ padding: 0, border: 0, background: 'none' }}><span className="v">{gs(period === 'yearly' ? p.price_yearly_pyg : p.price_monthly_pyg)}</span><span className="h">/ {period === 'yearly' ? T.yearly : T.monthly}</span></span>
      <ul className="plain">
        <li>Top {p.entitlements.maxRecommendations}</li>
        <li>{ANALYST[lang]} {p.entitlements.edgeAnalystPerDay} / {lang === 'de' ? 'Tag' : lang === 'en' ? 'day' : 'día'}</li>
        {p.entitlements.personalAlerts ? <li>{T.personal}</li> : null}
        {p.entitlements.customAlertMinEv ? <li>{T.minEv}</li> : null}
      </ul>
      <button className="btn secondary" onClick={() => order(p.id)}>{T.choose}</button></div>)}</div>
    {x.pendingPayments.length ? <div className="stack"><h3>{T.pending}</h3>{x.pendingPayments.map((p: any) => <div key={p.id} className="card stack" style={{ background: 'var(--raised)' }}>
      <div className="row-flex"><span className={`chip ${chipFor(p.status)}`}>{p.status}</span><b className="num">{gs(p.amountPyg)}</b><span className="small">{T.reference}: <b className="num">{p.reference}</b></span>{p.mode === 'test' ? <span className="chip neutral">{T.testMode}</span> : null}</div>
      {p.instructions ? <dl className="kv">{Object.entries(p.instructions).filter(([, v]) => v != null && v !== '').map(([k, v]) => <React.Fragment key={k}><dt>{INSTR[(lang as L3)]?.[k] ?? k}</dt><dd>{INSTR[(lang as L3)]?.[String(v)] ?? String(v)}</dd></React.Fragment>)}</dl> : null}
      {p.method === 'bank_transfer' && !p.instructions?.alias ? <div className="banner warnb"><span>{T.noBank}</span></div> : null}
      <label className="field">{T.upload}<input type="file" accept="application/pdf,image/png,image/jpeg" onChange={e => { const f = e.target.files?.[0]; if (f) upload(p.id, f); }} /><span className="hint">{T.proofHint}</span></label>
    </div>)}</div> : null}
    {msg ? <div className="banner info"><span>{tr(msg, lang)}</span></div> : null}
  </div>;
}

/** Persönliche Benachrichtigungen + Posteingang (Logik unverändert aus v0.3.0). */
export function PersonalAlertsSection() {
  const T = useT(); const { lang, tz } = useApp();
  const st = useLoad<any>('/api/settings'), inbox = useLoad<any[]>('/api/me/alerts');
  const [msg, setMsg] = useState('');
  if (st.err) return <ErrorBox e={st.err} />;
  if (!st.data) return <Loading />;
  const s = st.data;
  const save = async (patch: object) => { setMsg(''); try { await api('/api/settings', { method: 'PUT', body: JSON.stringify(patch) }); st.reload(); } catch (e) { setMsg((e as Error).message); } };
  const unread = (inbox.data ?? []).filter(a => !a.read_at).length;
  return <div className="stack lg">
    <label className="check"><input type="checkbox" checked={!!s.personal_alerts_enabled} disabled={!s.entitlements.personalAlerts && !s.personal_alerts_enabled} onChange={e => save({ personal_alerts_enabled: e.target.checked })} /><span>{T.enable}</span></label>
    <label className="check"><input type="checkbox" checked={!!s.notify_ev_change} onChange={e => save({ notify_ev_change: e.target.checked })} /><span>EV Δ ≥ 3 pp</span></label>
    <label className="field" style={{ maxWidth: 260 }}>{T.minEv}<input type="number" min={1} max={50} step={0.5} disabled={!s.entitlements.customAlertMinEv} defaultValue={s.alert_min_ev != null ? s.alert_min_ev * 100 : ''} placeholder="auto"
      onBlur={e => save({ alert_min_ev: e.target.value === '' ? null : Number(e.target.value) / 100 })} /></label>
    {msg ? <div className="banner err"><span>{msg}</span></div> : null}
    <div className="stack">
      <div className="row-flex between"><h3>{T.inbox} <span className="t-3" style={{ fontWeight: 400 }}>{unread}</span></h3>{unread ? <button className="btn quiet sm" onClick={async () => { await api('/api/me/alerts/read-all', { method: 'POST' }); inbox.reload(); }}>{T.markRead}</button> : null}</div>
      {(inbox.data ?? []).length ? <div className="list">{(inbox.data ?? []).slice(0, 30).map(a => <div key={a.id} className="card tight small" style={{ opacity: a.read_at ? .6 : 1 }}><div className="row-flex between"><b>{a.title}</b><span className="t-3 xs">{localTime(a.created_at, tz, lang)}{a.ev != null ? ` · EV ${pct(a.ev)}` : ''}</span></div><div style={{ whiteSpace: 'pre-wrap', marginTop: 4 }} className="t-2">{a.body}</div></div>)}</div>
        : <div className="empty"><span className="e-text">–</span></div>}
    </div>
  </div>;
}

/** Kompatibilität: frühere Gesamtansicht. */
export function Account() { return <><PlanSection /><PersonalAlertsSection /></>; }
