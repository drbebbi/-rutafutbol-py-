# Base44-Integration: Architektur-Leitfaden

**Status: NOT IMPLEMENTED.** Es wurde **keine** Base44-Integration gebaut oder getestet. Es gab weder ein Base44-Projekt noch einen Zugang. Dieses Dokument beschreibt, wie eine Anbindung sicher aussehen sollte. Die Angaben zu Base44 stammen aus der öffentlichen Base44-Dokumentation (gelesen am 12.10.2026) und müssen vor der Umsetzung gegen die aktuelle Fassung geprüft werden.

## Empfohlene Architektur

```
Browser (Base44-App, UI)
   │  base44.functions.invoke("getRecommendations")   ← Base44-Benutzerkontext, KEIN Aposta-Token
   ▼
Base44-Backend-Funktion (Deno, serverseitig)
   │  liest READ_TOKEN aus Base44-Secrets
   │  GET https://aposta.example.com/api/recommendations
   │  Authorization: Bearer <READ_TOKEN>
   ▼
Aposta Edge AI (dieses Projekt, eigener Server)
   Discovery · Quoten · Modelle · Value · Revalidierung · Scheduler · API-Schlüssel der Provider
```

Grundsätze:

1. **Die Analyse bleibt in Aposta Edge AI.** Base44 ist nur Oberfläche. Modelle, Quotenprüfung, Freshness, Lebenszyklus und Scheduler nicht in Base44 nachbauen. Doppelte Logik führt zu abweichenden Ergebnissen.
2. **Provider-Schlüssel nie in Base44.** Highlightly- und The-Odds-API-Schlüssel bleiben auf dem Aposta-Server.
3. **Token nie im Base44-Frontend.** Das Token steht nur in den Base44-Secrets und wird nur in der Backend-Funktion gelesen.
4. **Lese-Token statt Admin-Token.** Für die Anzeige `READ_TOKEN` verwenden: nur GET, Rolle `user`, kein Zugriff auf Admin-Endpunkte. `ADMIN_TOKEN` nur, wenn eine Funktion bewusst Admin-Aktionen auslösen soll, und dann nur für Base44-Admins.
5. **Benutzerprüfung in der Funktion.** Laut Base44-Doku liefert `createClientFromRequest(req)` + `base44.auth.me()` den angemeldeten Base44-Benutzer. Ohne Benutzer (direkter HTTP-Aufruf der Funktions-URL) mit 401 antworten.
6. **Keine eigenen Kopien von Empfehlungen in Base44-Entitäten.** Sonst wird die Revalidierung umgangen und es erscheinen wieder veraltete Empfehlungen. Wenn gespeichert werden muss, dann mit `valid_until` und nie über dessen Ablauf hinaus anzeigen.

## Skizze einer Backend-Funktion (ungetestet)

```ts
// Base44-Backend-Funktion "getRecommendations" – SKIZZE, nicht getestet
import { secrets } from "base44:runtime";
import { createClientFromRequest } from "npm:@base44/sdk"; // Importpfad laut aktueller Base44-Doku prüfen

export default async function (req: Request): Promise<Response> {
  const b44 = createClientFromRequest(req);
  const user = await b44.auth.me().catch(() => null);
  if (!user) return Response.json({ error: "unauthorized" }, { status: 401 });

  const base = secrets.get("APOSTA_BASE_URL");   // z. B. https://aposta.example.com
  const token = secrets.get("APOSTA_READ_TOKEN"); // READ_TOKEN des Aposta-Servers
  if (!base || !token) return Response.json({ error: "not_configured" }, { status: 500 });

  const r = await fetch(`${base}/api/recommendations`, { headers: { authorization: `Bearer ${token}` } });
  if (!r.ok) return Response.json({ error: "upstream", status: r.status }, { status: 502 });
  return Response.json(await r.json()); // unverändert durchreichen, inkl. valid_until und Statusmeldungen
}
```

## Nutzbare Endpunkte mit Lese-Token

| Endpunkt | Inhalt |
|---|---|
| `GET /api/status` | Datenstand, letzter Sync, Provider-Status, Validierungsstatus, Warnungen |
| `GET /api/recommendations` | höchstens 5 aktuelle Empfehlungen (bei jedem Abruf revalidiert), kürzlich zurückgezogene, `NO QUALIFIED VALUE BETS` |
| `GET /api/matches`, `GET /api/matches/:id` | Spiele, Quoten mit Alter und Herkunft, Modelle, Signale |
| `GET /api/signals` | Signale mit Status |
| `GET /api/performance` | Auswertung echt/Mock getrennt, Backtest |
| `GET /api/health` | öffentlich, für Monitoring |

Nicht mit Lese-Token möglich: Einstellungen, Jobs, Backtest starten, Import, Benutzer, EDGE ANALYST (POST).

## Pflichtanzeigen in einer Base44-Oberfläche

Damit Base44 nicht mehr verspricht als das Backend, müssen diese Felder sichtbar übernommen werden:

- `modelValidation.status` aus `/api/status` → Banner **UNVALIDATED MODEL**, solange nicht `VALIDATED`
- Odds-Alter, Quelle, `valid_until` je Empfehlung
- **NO QUALIFIED VALUE BETS**, wenn die Liste leer ist (keine Platzhalter, keine „besten Tipps“ aus anderen Quellen)
- **PROVIDER UNAVAILABLE**, **STALE ODDS**, **MARKET SUSPENDED**, **INSUFFICIENT DATA** aus den Statusfeldern
- Hinweis, dass keine Wetten platziert werden und EV keine Gewinnzusage ist
- Mock-Kennzeichnung, falls der Server im Mock-Modus läuft

## Nächste Schritte für eine echte Integration

1. Aposta-Server mit HTTPS betreiben (siehe [DEPLOYMENT.md](DEPLOYMENT.md)) und `READ_TOKEN` setzen.
2. In Base44 die Secrets `APOSTA_BASE_URL` und `APOSTA_READ_TOKEN` anlegen.
3. Backend-Funktion nach obiger Skizze schreiben und gegen die aktuelle Base44-Doku abgleichen.
4. Ende-zu-Ende testen:
   - Token erscheint nicht im Browser-Netzwerkverkehr
   - Funktions-URL ohne Anmeldung liefert 401
   - abgelaufene Empfehlung verschwindet in Base44 ohne eigenes Zutun
5. Erst danach den Status hier auf IMPLEMENTED/TESTED ändern.
