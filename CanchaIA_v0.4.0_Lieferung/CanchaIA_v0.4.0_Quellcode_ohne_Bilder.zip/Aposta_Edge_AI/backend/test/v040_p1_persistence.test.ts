/**
 * v0.4.0 – Priorität 1: Regressionstests für Signalpersistenz und Prognose-Cache.
 * Diese Tests wurden VOR der Korrektur geschrieben und schlugen mit v0.3.4 fehl (siehe CHANGES_v0.4.0.md).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, mockApp } from './helpers.js';
import { ValueBettingEngine, type Signal, type StoredSignal, type ValueSettings } from '../src/engines/value.js';
import { PredictionEngine } from '../src/engines/prediction/index.js';
import { OddsStore } from '../src/engines/odds.js';

const base: ValueSettings = { minEv: 0.05, strategy: 'BALANCED', oddsMaxAgeMinutes: 90, preferredBookmakers: [], modelValidated: false, isMock: true };

async function setup() {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  // Ein Spiel mit mindestens einem Signal, das einen Marktpreis ohne den besten Buchmacher hat
  const row = app.db.get<{ event_id: number }>(`SELECT event_id FROM value_signals WHERE active = 1 AND novig_prob IS NOT NULL AND best_snapshot_id IS NOT NULL ORDER BY id LIMIT 1`)!;
  assert.ok(row, 'Signal mit Marktreferenz erwartet');
  const pred = new PredictionEngine(app.db).predictEvent(row.event_id, ANCHOR)!;
  const v = new ValueBettingEngine(app.db);
  return { app, v, pred, eventId: row.event_id };
}
const active = (app: Awaited<ReturnType<typeof mockApp>>, s: Signal) =>
  app.db.get<StoredSignal>(`SELECT * FROM value_signals WHERE event_id = ? AND market_id = ? AND selection_id = ? AND ${s.line == null ? 'line IS NULL' : 'line = ' + s.line} AND active = 1`, s.eventId, s.market, s.selection)!;

test('P1: identische Neuberechnung erzeugt keine neue Signalversion', async () => {
  const { app, v, pred } = await setup();
  v.persist(v.evaluate(pred, base, ANCHOR), ANCHOR);
  const before = app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM value_signals')!.n;
  const ch = v.persist(v.evaluate(pred, base, ANCHOR), ANCHOR);
  assert.equal(ch.length, 0, 'keine Änderung gemeldet');
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM value_signals')!.n, before);
});

test('P1: geändertes Modellgewicht → gespeicherte decision_prob/EV entsprechen der neuen Berechnung', async () => {
  const { app, v, pred } = await setup();
  v.persist(v.evaluate(pred, { ...base, modelWeight: 0.35 }, ANCHOR), ANCHOR);
  const next = v.evaluate(pred, { ...base, modelWeight: 0.6 }, ANCHOR);
  v.persist(next, ANCHOR);
  for (const s of next.filter(x => x.decisionProb != null)) {
    const st = active(app, s);
    assert.ok(Math.abs(st.decision_prob! - s.decisionProb!) < 1e-12, `${s.market}/${s.selection}: gespeichert ${st.decision_prob}, berechnet ${s.decisionProb}`);
    assert.ok(Math.abs(st.ev! - s.ev!) < 1e-12);
    assert.equal(st.model_weight, 0.6);
  }
});

test('P1: geänderte Strategie → neue Signalversion mit neuer Untergrenze', async () => {
  const { app, v, pred } = await setup();
  v.persist(v.evaluate(pred, base, ANCHOR), ANCHOR);
  const next = v.evaluate(pred, { ...base, strategy: 'CONSERVATIVE', modelWeight: 0.35 }, ANCHOR);
  v.persist(next, ANCHOR);
  for (const s of next.filter(x => x.probLow != null)) {
    const st = active(app, s);
    assert.ok(Math.abs(st.prob_low! - s.probLow!) < 1e-12, `${s.market}/${s.selection}: prob_low ${st.prob_low} vs ${s.probLow}`);
  }
});

test('P1: geänderte Referenzquote bei unveränderter bester Quote → neue novig_prob gespeichert', async () => {
  const { app, v, pred, eventId } = await setup();
  const first = v.evaluate(pred, base, ANCHOR);
  v.persist(first, ANCHOR);
  const s0 = first.find(s => s.novigProb != null && s.bestBookmakerId)!;
  // Neuer Snapshot eines ANDEREN Buchmachers mit klar schlechteren Preisen (bleibt nicht der beste)
  const views = new OddsStore(app.db).latestPerBookmaker(eventId, s0.market, s0.line);
  const other = views.find(x => x.bookmakerId !== s0.bestBookmakerId)!;
  const prices = Object.fromEntries(Object.entries(other.prices).map(([k, p]) => [k, +(Math.max(1.01, (p as number) * (k === s0.selection ? 0.9 : 1.08))).toFixed(2)]));
  new OddsStore(app.db).save(eventId, { provider: 'mock', providerEventId: 'x', bookmakerProviderId: other.bookmakerId, bookmakerName: other.bookmakerId, market: s0.market, line: s0.line,
    prices, marketStatus: 'open', retrievedAt: new Date(ANCHOR.getTime() + 60_000).toISOString(), sourceTimestamp: null, snapshotKind: 'live' }, [], true);
  const now2 = new Date(ANCHOR.getTime() + 120_000);
  const next = v.evaluate(pred, base, now2);
  const s1 = next.find(s => s.market === s0.market && s.selection === s0.selection)!;
  assert.equal(s1.bestSnapshotId, s0.bestSnapshotId, 'beste Quote unverändert (Testvoraussetzung)');
  assert.notEqual(s1.novigProb, s0.novigProb, 'Marktreferenz hat sich geändert (Testvoraussetzung)');
  v.persist(next, now2);
  const st = active(app, s1);
  assert.ok(Math.abs(st.novig_prob! - s1.novigProb!) < 1e-12, `gespeichert ${st.novig_prob}, berechnet ${s1.novigProb}`);
  assert.ok(Math.abs(st.decision_prob! - s1.decisionProb!) < 1e-12);
});

test('P1: eingefrorene Performance-Einträge bleiben bei Neuberechnung unverändert', async () => {
  const { app, v, pred } = await setup();
  const before = app.db.all('SELECT * FROM prediction_outcomes ORDER BY id');
  v.persist(v.evaluate(pred, { ...base, modelWeight: 0.9 }, ANCHOR), ANCHOR);
  app.sync.report(ANCHOR);
  assert.deepEqual(app.db.all('SELECT * FROM prediction_outcomes ORDER BY id'), before);
});

test('P1: korrigiertes historisches Ergebnis → neuer Fit und neue, konsistent gespeicherte Prognose', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const ev = app.db.get<{ id: number; competition_id: number }>(`SELECT id, competition_id FROM events WHERE status = 'scheduled' AND kickoff_utc > ? ORDER BY kickoff_utc LIMIT 1`, ANCHOR.toISOString())!;
  const pe = new PredictionEngine(app.db);
  const a = pe.predictEvent(ev.id, ANCHOR)!;
  // Ein abgeschlossenes Spiel des Heimteams wird nachträglich korrigiert (z. B. Datenfehler beim Provider)
  const e = app.db.get<{ home_team_id: number }>('SELECT home_team_id FROM events WHERE id = ?', ev.id)!;
  const h = app.db.get<{ id: number; home_goals: number }>(`SELECT id, home_goals FROM events WHERE competition_id = ? AND status = 'finished' AND home_team_id = ? ORDER BY kickoff_utc DESC LIMIT 1`, ev.competition_id, e.home_team_id)!;
  app.db.run('UPDATE events SET home_goals = ? WHERE id = ?', h.home_goals + 4, h.id);
  const b = pe.predictEvent(ev.id, ANCHOR)!;
  assert.notDeepEqual(b.ensemble.probs, a.ensemble.probs, 'Prognose muss die Korrektur berücksichtigen');
  assert.notEqual(b.id, a.id, 'neue Prognose-ID erwartet');
  const stored = JSON.parse(app.db.get<{ probs: string }>('SELECT probs FROM predictions WHERE id = ?', b.id)!.probs);
  assert.deepEqual(stored, JSON.parse(JSON.stringify(b.ensemble.probs)), 'gespeicherte und zurückgegebene Prognose stimmen überein');
});

test('P1: korrigierte xG-Statistik → neuer Fit (Cache-Schlüssel enthält den Datenstand)', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const ev = app.db.get<{ id: number; competition_id: number }>(`SELECT id, competition_id FROM events WHERE status = 'scheduled' AND kickoff_utc > ? ORDER BY kickoff_utc LIMIT 1`, ANCHOR.toISOString())!;
  const pe = new PredictionEngine(app.db);
  const k1 = pe.leagueFits(ev.competition_id, ANCHOR.toISOString()).key;
  const st = app.db.get<{ event_id: number; team_id: number }>(`SELECT s.event_id, s.team_id FROM match_statistics s JOIN events e ON e.id = s.event_id WHERE e.competition_id = ? AND s.stat_key = 'xg' LIMIT 1`, ev.competition_id);
  assert.ok(st, 'Mock-Daten enthalten xG');
  app.db.run(`UPDATE match_statistics SET value = value + 1.5 WHERE event_id = ? AND team_id = ? AND stat_key = 'xg'`, st!.event_id, st!.team_id);
  const k2 = pe.leagueFits(ev.competition_id, ANCHOR.toISOString()).key;
  assert.notEqual(k2, k1);
});
