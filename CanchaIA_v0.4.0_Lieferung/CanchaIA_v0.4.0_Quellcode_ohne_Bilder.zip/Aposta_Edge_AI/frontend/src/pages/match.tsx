/** Spieldetail: Kopf, Kennzahlenkarten, Tabs Überblick/Quoten/Statistik/Modell/Verlauf/KI. Datenlogik wie v0.3.0. */
import React, { useMemo, useState } from 'react';
import { fx, pct, signed, localTime } from '../api';
import { SEL, MKT } from '../i18n';
import { tr } from '../reasons';
import { useApp } from '../components';
import { useLoad } from '../hooks';
import { Badge, Banner, Button, Card, EdgeMeter, EmptyState, ErrorBox, Kpi, Loading, MockChip, ProbBar, SignalBadge, StatusBadge, Tabs, Tiles } from '../ui';
import { Console } from './edge';
import { dayLabel } from './shared';

type Tab = 'overview' | 'odds' | 'statistics' | 'model' | 'history' | 'ai';
const order = (s: string) => ['STRONG_VALUE', 'VALUE', 'WATCH', 'NO_VALUE', 'AVOID', 'INSUFFICIENT_DATA', 'STALE', 'MARKET_SUSPENDED'].indexOf(s);
const selsOf = (m: string) => m === '1X2' ? ['HOME', 'DRAW', 'AWAY'] : m === 'OU' ? ['OVER', 'UNDER'] : ['YES', 'NO'];
const isBest = (books: any[], s: string, b: any) => b.valid && b.prices[s] === Math.max(...books.filter(x => x.valid).map(x => x.prices[s] ?? 0));
const C1 = 'var(--accent)', C2 = 'var(--text-3)', C3 = 'var(--teal)';

export function MatchDetail({ id }: { id: number }) {
  const { t, u, lang, tz, go } = useApp();
  const d = useLoad<any>(`/api/matches/${id}`, [id]);
  const [tab, setTab] = useState<Tab>('overview');
  if (d.err) return <><Button variant="quiet" icon="back" onClick={() => go('/matches')}>{t.back}</Button><ErrorBox e={d.err} onRetry={d.reload} /></>;
  if (!d.data) return <Loading lines={8} />;
  const x = d.data, p = x.prediction, dq = p?.data_quality;
  const sigs = (x.signals ?? []).filter(Boolean).sort((a: any, b: any) => order(a.status) - order(b.status) || (b.ev_low ?? -9) - (a.ev_low ?? -9));
  const best = sigs[0];
  const [home, away] = String(x.event.match).split(' – ');
  const started = new Date(x.event.kickoff_utc).getTime() <= Date.now();

  return (
    <>
      <div className="mhero">
        <div className="crumbs">
          <Button variant="quiet" size="sm" icon="back" onClick={() => go('/matches')}>{t.back}</Button>
          <span>{x.event.competition}</span>
          {x.event.mock ? <MockChip /> : null}
          <StatusBadge s={started ? 'RUNNING' : 'OK'} label={x.event.status} />
          {best ? <SignalBadge s={best.status} /> : null}
        </div>
        <div className="vs">
          <div className="team">{home}</div>
          <div className="ko"><span className="t">{localTime(x.event.kickoff_utc, tz, lang, false)}</span><span className="d">{dayLabel(x.event.kickoff_utc, tz, lang)} · {tz}</span></div>
          <div className="team away">{away}</div>
        </div>
      </div>

      {started ? <Banner tone="warn" title={tr('Spiel hat begonnen', lang)}>{t.staleHint}</Banner> : null}

      <div className="kpis six">
        <Kpi label={u.sumModel} value={best ? pct(best.model_prob) : '–'} hint={best ? `${MKT[best.market]} · ${SEL[lang][best.selection]}` : u.noSignal} />
        <Kpi label={u.sumFair} value={best ? fx(best.fair_odds) : '–'} hint={best ? `${t.noVig} ${pct(best.novig_prob)}` : undefined} />
        <Kpi label={u.sumBest} value={best ? fx(best.best_odds) : '–'} hint={best?.bookmaker ?? undefined} />
        <Kpi label={u.sumEv} value={best ? signed(best.ev) : '–'} tone={best ? (best.ev > 0 ? (best.ev_low > 0 ? 'value' : 'watch') : 'avoid') : undefined} hint={best ? `${t.evLow} ${signed(best.ev_low)}` : undefined} />
        <Kpi label={u.sumConf} value={best ? `${best.quality_score}/100` : '–'} size="md" hint={u.sumConfH} />
        <Kpi label={u.sumDq} value={dq ? `${dq.score}/100` : '–'} size="md" hint={dq?.status} tone={dq ? (dq.status === 'good' ? 'value' : dq.status === 'insufficient' ? 'avoid' : 'watch') : undefined} />
      </div>

      <Tabs<Tab> label="Match" value={tab} onChange={setTab} items={[['overview', u.tOverview], ['odds', u.tOdds], ['statistics', u.tStats], ['model', u.tModel], ['history', u.tHistory], ['ai', u.tAi]]} />

      {tab === 'overview' && <div className="grid main-side">
        <div className="stack lg">
          <Card title={u.bestSignal} actions={best ? <SignalBadge s={best.status} /> : null}>
            {best ? <div className="stack">
              <div className="row-flex between"><b>{MKT[best.market]} · {SEL[lang][best.selection]}</b><span className="t-2 small">{best.bookmaker} · {fx(best.best_odds)}</span></div>
              <EdgeMeter decision={best.decision_prob ?? best.model_prob} fair={best.novig_prob} odds={best.best_odds} />
              <p className="t-3 xs">{u.edgeExplain}</p>
              {best.reasons?.length ? <ul className="reasons">{best.reasons.map((r: string) => <li key={r}>{tr(r, lang)}</li>)}</ul> : null}
            </div> : <EmptyState title={u.noSignal} icon="ok" />}
          </Card>
        </div>
        <div className="stack lg">
          <Card title={u.probs} sub={p ? `${p.model_version} · λ ${fx(p.lambda_home)} – ${fx(p.lambda_away)}` : undefined}>
            {p ? <div className="stack lg">
              <ProbBar parts={[{ label: '1', p: p.probs['1X2']?.HOME, color: C1 }, { label: 'X', p: p.probs['1X2']?.DRAW, color: C2 }, { label: '2', p: p.probs['1X2']?.AWAY, color: C3 }]} />
              <ProbBar parts={[{ label: SEL[lang].OVER, p: p.probs.OU?.OVER, color: C1 }, { label: SEL[lang].UNDER, p: p.probs.OU?.UNDER, color: C3 }]} />
              <ProbBar parts={[{ label: SEL[lang].YES, p: p.probs.BTTS?.YES, color: C1 }, { label: SEL[lang].NO, p: p.probs.BTTS?.NO, color: C3 }]} />
            </div> : <EmptyState title={t.noData} text={t.analysis.insufficient_data} />}
          </Card>
          {dq ? <Card title={t.dataQuality} actions={<Badge tone={dq.status === 'good' ? 'value' : dq.status === 'insufficient' ? 'avoid' : 'watch'}>{dq.score}/100</Badge>}>
            <dl className="kv small"><dt>{t.lineups}</dt><dd>{dq.lineups}</dd><dt>Home / Away</dt><dd>{dq.homeGames} / {dq.awayGames}</dd><dt>League</dt><dd>{dq.leagueGames}</dd>{dq.xgCoverage != null ? <><dt>xG</dt><dd>{pct(dq.xgCoverage, 0)}</dd></> : null}</dl>
            {dq.issues?.length ? <ul className="reasons" style={{ marginTop: 10 }}>{dq.issues.map((i: string) => <li key={i}>{tr(i, lang)}</li>)}</ul> : null}
          </Card> : null}
        </div>
      </div>}
      {tab === 'overview' && <Card title={u.allSignals}>
            {sigs.length ? <div className="tablewrap"><table>
              <thead><tr><th>{t.market}</th><th>{t.status}</th><th className="n">{t.modelProb}</th><th className="n">{t.noVig}</th><th className="n">{t.decisionProb}</th><th className="n">{t.odds}</th><th className="n">EV</th><th className="n">{t.evLow}</th><th className="n">{t.quality}</th></tr></thead>
              <tbody>{sigs.map((s: any) => <tr key={s.signal_id} className={s === best ? 'hl' : ''}><td className="nw">{MKT[s.market]} · {SEL[lang][s.selection]}</td><td><SignalBadge s={s.status} /></td><td className="n">{pct(s.model_prob)}</td><td className="n">{pct(s.novig_prob)}</td><td className="n">{pct(s.decision_prob)}</td><td className="n">{fx(s.best_odds)}</td><td className={`n ${s.ev > 0 ? 'pos' : 'neg'}`}>{signed(s.ev)}</td><td className="n">{signed(s.ev_low)}</td><td className="n">{s.quality_score}</td></tr>)}</tbody>
            </table></div> : <EmptyState title={t.noData} />}
          </Card>}

      {tab === 'odds' && <div className="stack lg">{x.odds.map((m: any) => (
        <Card key={m.market} title={MKT[m.market]} actions={m.availability ? <StatusBadge s={m.availability.status === 'AVAILABLE' ? 'OK' : m.availability.status === 'MARKET SUSPENDED' ? 'PAUSED' : 'FAILED'} label={m.availability.status} /> : null}>
          {m.books.length ? <div className="tablewrap"><table>
            <thead><tr><th>{t.bookmaker}</th>{selsOf(m.market).map(s => <th key={s} className="n">{SEL[lang][s]}</th>)}<th className="n">{t.overround}</th><th>{t.retrieved}</th><th className="n">{t.oddsAge}</th><th>{t.oddsSource}</th><th>{t.status}</th></tr></thead>
            <tbody>{m.books.map((b: any) => <tr key={b.snapshotId}><td>{b.bookmakerName}{b.isSharp ? <span className="t-3" title="sharp"> · sharp</span> : ''}</td>{selsOf(m.market).map(s => <td key={s} className={`n ${isBest(m.books, s, b) ? 'cy' : ''}`}>{fx(b.prices[s])}</td>)}<td className="n">{pct(b.overround, 2)}</td>
              <td className="small">{localTime(b.retrievedAt, tz, lang)}{b.sourceTimestamp ? <div className="t-3">src {localTime(b.sourceTimestamp, tz, lang, false)}</div> : null}</td>
              <td className="n">{b.ageMinutes != null ? `${Math.round(b.ageMinutes)}/${b.limitMinutes}` : '–'}</td><td className="small">{b.provider}{b.fromCache ? ` · ${t.fromCache}` : ''}</td>
              <td>{!b.valid ? <Badge tone="avoid" title={b.errors.map((e: string) => tr(e, lang)).join('; ')}>{t.invalid}</Badge> : b.fresh ? <Badge tone="value">{t.current}</Badge> : <Badge tone="avoid" title={(b.freshnessReasons ?? []).map((e: string) => tr(e, lang)).join('; ')}>STALE ODDS</Badge>}</td></tr>)}</tbody>
          </table></div> : null}
          {m.books.some((b: any) => !b.valid || !b.fresh) ? <ul className="reasons" style={{ marginTop: 10 }}>{[...new Set(m.books.flatMap((b: any) => [...b.errors, ...(b.fresh ? [] : b.freshnessReasons ?? [])]))].map((e: any) => <li key={e}>{tr(e, lang)}</li>)}</ul> : null}
          {m.availability && m.availability.status !== 'AVAILABLE' ? <p className="t-2 small" style={{ marginTop: 8 }}>{m.availability.reason ? tr(m.availability.reason, lang) : ''}</p> : null}
        </Card>))}
        <Card title={t.provenance}><div className="tablewrap"><table><tbody>{(x.provenance ?? []).map((pv: any) => <tr key={pv.provider + pv.provider_event_id}><td>{pv.provider}</td><td className="small t-2">{pv.provider_event_id}</td><td className="n">{fx(pv.confidence)}</td><td className="small">{pv.method}</td></tr>)}</tbody></table></div></Card>
      </div>}

      {tab === 'statistics' && <div className="grid two">{(['home', 'away'] as const).map(side => {
        const s = x.statistics[side];
        return <Card key={side} title={side === 'home' ? home : away}>
          <div className="stack">
            <Tiles items={[[t.form, `${s.form.points} pts / ${s.form.games}`], ['GF', String(s.form.gf)], ['GA', String(s.form.ga)], ['xG', s.form.xgFor != null ? `${fx(s.form.xgFor)} / ${fx(s.form.xgAgainst)}` : '–']]} />
            {s.last.length ? <div className="tablewrap"><table><thead><tr><th>{t.last}</th><th className="n">Score</th><th className="n">xG</th></tr></thead>
              <tbody>{s.last.map((g: any) => <tr key={g.kickoff}><td>{g.home} – {g.away}<div className="t-3 xs">{g.kickoff.slice(0, 10)}</div></td><td className="n">{g.hg}:{g.ag}</td><td className="n">{g.xgH != null ? `${fx(g.xgH, 1)}–${fx(g.xgA, 1)}` : '–'}</td></tr>)}</tbody></table></div> : <EmptyState title={t.noData} />}
          </div>
        </Card>; })}
        <Card title={t.injuries}><p className="t-2 small">{tr(x.injuries, lang)}</p></Card>
      </div>}

      {tab === 'model' && (p ? <div className="stack lg">
        <Card title={t.models} sub={`${t.modelsUsed}: ${Object.entries(p.uncertainty.modelsUsed ?? {}).map(([k, v]: any) => `${k}: ${v.join(', ')}`).join(' · ')}`}>
          <div className="tablewrap"><table>
            <thead><tr><th>Model</th><th>{t.status}</th><th className="n">λ</th><th className="n">1</th><th className="n">X</th><th className="n">2</th><th className="n">O 2.5</th><th className="n">BTTS</th></tr></thead>
            <tbody>{p.components.map((c: any) => <tr key={c.model}><td>{c.model}</td><td>{c.available ? <Badge tone="value">{t.available}</Badge> : <Badge tone="outline" title={tr(c.reason ?? '', lang)}>{t.unavailable}</Badge>}</td>
              <td className="n">{c.lambdaHome ? `${fx(c.lambdaHome)}–${fx(c.lambdaAway)}` : '–'}</td>
              <td className="n">{pct(c.probs?.['1X2']?.HOME)}</td><td className="n">{pct(c.probs?.['1X2']?.DRAW)}</td><td className="n">{pct(c.probs?.['1X2']?.AWAY)}</td><td className="n">{pct(c.probs?.OU?.OVER)}</td><td className="n">{pct(c.probs?.BTTS?.YES)}</td></tr>)}
              <tr className="hl"><td><b>Ensemble</b></td><td></td><td className="n">{fx(p.lambda_home)}–{fx(p.lambda_away)}</td><td className="n">{pct(p.probs['1X2']?.HOME)}</td><td className="n">{pct(p.probs['1X2']?.DRAW)}</td><td className="n">{pct(p.probs['1X2']?.AWAY)}</td><td className="n">{pct(p.probs.OU?.OVER)}</td><td className="n">{pct(p.probs.BTTS?.YES)}</td></tr>
              <tr><td className="t-3">σ</td><td></td><td></td><td className="n t-3">{pct(p.uncertainty.sd['1X2']?.HOME)}</td><td className="n t-3">{pct(p.uncertainty.sd['1X2']?.DRAW)}</td><td className="n t-3">{pct(p.uncertainty.sd['1X2']?.AWAY)}</td><td className="n t-3">{pct(p.uncertainty.sd.OU?.OVER)}</td><td className="n t-3">{pct(p.uncertainty.sd.BTTS?.YES)}</td></tr>
            </tbody></table></div>
          {p.components.some((c: any) => !c.available) ? <ul className="reasons" style={{ marginTop: 10 }}>{p.components.filter((c: any) => !c.available).map((c: any) => <li key={c.model}>{c.model}: {tr(c.reason, lang)}</li>)}</ul> : null}
        </Card>
      </div> : <EmptyState title={t.noData} text={t.analysis.insufficient_data} />)}

      {tab === 'history' && <div className="grid two">
        <Card title={t.h2h}>{x.h2h.length ? <div className="tablewrap"><table><tbody>{x.h2h.map((g: any) => <tr key={g.kickoff_utc}><td>{g.home} – {g.away}<div className="t-3 xs">{g.kickoff_utc.slice(0, 10)}</div></td><td className="n">{g.home_goals}:{g.away_goals}</td></tr>)}</tbody></table></div> : <EmptyState title={t.noData} />}</Card>
        <Card title={t.oddsHistory}><OddsHistory rows={x.oddsHistory} /></Card>
      </div>}

      {tab === 'ai' && <Console eventQuery={x.event.match} />}
    </>
  );
}

function OddsHistory({ rows }: { rows: any[] }) {
  const { lang, tz, t } = useApp();
  const grouped = useMemo(() => {
    const g = new Map<string, any>();
    for (const r of rows) { const k = `${r.retrieved_at}|${r.name}|${r.market_id}`; const o = g.get(k) ?? { t: r.retrieved_at, book: r.name, market: r.market_id, p: {} }; o.p[r.selection_id] = r.odds; g.set(k, o); }
    return [...g.values()].reverse().slice(0, 40);
  }, [rows]);
  if (!grouped.length) return <EmptyState title={t.noData} />;
  return <div className="tablewrap"><table><tbody>{grouped.map(g => <tr key={g.t + g.book + g.market}><td className="small">{localTime(g.t, tz, lang)}</td><td>{g.book}</td><td>{MKT[g.market]}</td><td className="n">{Object.values(g.p).map((v: any) => fx(v)).join(' / ')}</td></tr>)}</tbody></table></div>;
}
