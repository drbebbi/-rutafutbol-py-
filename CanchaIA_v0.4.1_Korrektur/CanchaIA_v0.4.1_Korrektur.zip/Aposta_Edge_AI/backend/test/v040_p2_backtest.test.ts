/**
 * v0.4.0 – Priorität 2: Backtest/Live-Konsistenz und marktbezogene Validierung.
 * Synthetische Daten prüfen nur die LOGIK. Sie sind kein Qualitäts- oder Profitabilitätsnachweis.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, insertSyntheticLeague, memDb, mockApp } from './helpers.js';
import { BacktestingEngine, DECISION_LEAD_MS, knownAt, RESULT_AVAILABLE_AFTER_MS } from '../src/engines/backtest.js';
import { combine } from '../src/engines/prediction/ensemble.js';
import { PredictionEngine } from '../src/engines/prediction/index.js';
import { decide, type DecisionInput } from '../src/engines/value.js';
import { selectTop } from '../src/engines/recommendation.js';
import { runValidation } from '../src/engines/validation.js';
import { Scheduler } from '../src/scheduler.js';
import type { HistMatch } from '../src/engines/prediction/history.js';
import { Repository } from '../src/engines/repository.js';

// Eine größere synthetische Liga (einmal berechnet): 1X2 validierbar, BTTS ohne Quoten
let big: { db: ReturnType<typeof memDb>; eng: BacktestingEngine; r: ReturnType<BacktestingEngine['run']> } | null = null;
function bigLeague() {
  if (big) return big;
  const db = memDb();
  insertSyntheticLeague(db, { teams: 20, seasons: 5, marketNoise: 0.12, seed: 'val' });
  const eng = new BacktestingEngine(db);
  big = { db, eng, r: eng.run({ refitDays: 90, minMatches: 200 }) };
  return big;
}

test('P2: Backtest-Ensemble behält λ und nutzt dieselbe Stichprobengröße wie live (gleiche Unsicherheit)', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 14, seasons: 3, seed: 'p2' });
  const eng = new BacktestingEngine(db);
  const r = eng.run({ refitDays: 60, minMatches: 200 });
  const rows = eng.lastRows.filter(x => x.segment === 'holdout');
  assert.ok(rows.length > 50);
  let larger = 0;
  for (const row of rows) {
    assert.ok(row.outputs.some(o => o.lambdaHome != null), 'λ-Werte vorhanden');
    const live = combine(row.outputs, r.metrics.weights, Math.min(row.dq.homeGames, row.dq.awayGames));
    assert.deepEqual(row.ensSd, live.sd, 'Unsicherheit identisch zur Live-Berechnung');
    // v0.3.4: λ gingen verloren → nur Streuung zwischen den Modellen, n fest 30
    const old = combine(row.outputs.map(o => ({ model: o.model, available: true, probs: o.probs })), r.metrics.weights, 30);
    if (live.sd['1X2']!.HOME! > old.sd['1X2']!.HOME! + 1e-9) larger++;
  }
  assert.equal(larger, rows.length, 'mit λ ist die Unsicherheit größer als im alten Backtest-Pfad');
});

test('P2: Informationsstand – laufende Spiele zum Entscheidungszeitpunkt sind nicht bekannt', () => {
  const T = Date.parse('2025-03-01T18:00:00Z');
  const iso = (ms: number) => new Date(ms).toISOString();
  const mk = (id: number, kickMs: number): HistMatch => ({ eventId: id, competitionId: 1, kickoff: iso(kickMs), home: 1, away: 2, hg: 1, ag: 0 });
  const all = [mk(1, T - 6 * 3_600_000), mk(2, T - 3 * 3_600_000), mk(3, T - 90 * 60_000)]; // #3 läuft zur Entscheidung (T − 60 min) noch
  const decisionAt = iso(T - DECISION_LEAD_MS);
  const known = knownAt(all, decisionAt).map(m => m.eventId);
  assert.deepEqual(known, [1], `bekannt: ${known}`);
  // Alte Regel ("Anstoß vor Zielspiel") hätte #2 und #3 verwendet
  assert.equal(all.filter(m => m.kickoff < iso(T)).length, 3);
  assert.equal(RESULT_AVAILABLE_AFTER_MS, 150 * 60_000);
});

test('P2: Backtest bei dichtem Spielplan: kein Modell sieht ein Ergebnis, das zur Entscheidung noch nicht vorlag', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 12, seasons: 3, spacingHours: 1, seed: 'dense', withOdds: false });
  const eng = new BacktestingEngine(db);
  eng.run({ refitDays: 30, minMatches: 200 });
  const all = eng.lastRows;
  assert.ok(all.length > 0);
  const hist = new Repository(db).competitionHistory(all[0].competitionId);
  for (const row of all.slice(0, 40)) {
    // Teamspiele in der Datenqualität zählen nur Spiele, deren Ergebnis zur Entscheidung vorlag
    const home = hist.find(x => x.eventId === row.eventId)!.home;
    const known = knownAt(hist, row.decisionAt).filter(m => m.home === home || m.away === home).length;
    const naive = hist.filter(m => m.kickoff < row.kickoff && (m.home === home || m.away === home)).length;
    assert.equal(row.dq.homeGames, known, 'Teamhistorie nur aus bekannten Ergebnissen');
    assert.ok(naive >= known);
  }
});

// v0.4.1 angepasst: v0.4.0 prüfte hier Kennzahlen des Tagesfensters (windows, maxBetsInAWindow, beyondWindowLimit) – genau die
// fehlerhafte nachträgliche Tagesauswahl (Befund 2). Geprüft werden jetzt dieselben Grenzen für die chronologische Live-Regel.
test('P2: Wettsimulation = Live-Auswahl: höchstens 1 Wette je Spiel, höchstens 5 gleichzeitig aktiv', () => {
  const db = memDb();
  // 2 h Abstand → 12 Spiele je Tag
  insertSyntheticLeague(db, { teams: 14, seasons: 3, spacingHours: 2, marketNoise: 0.08, seed: 'p2sel' });
  const r = new BacktestingEngine(db).run({ refitDays: 60, minMatches: 200 });
  const b = r.metrics.betting!;
  assert.ok(b.selection, 'Auswahl wird ausgewiesen');
  assert.ok(b.selection!.maxBetsPerEvent <= 1, `max je Spiel ${b.selection!.maxBetsPerEvent}`);
  assert.ok(b.selection!.maxActiveObserved <= 5);
  assert.ok(b.bets <= b.qualifiedSignals);
  assert.match(b.selection!.restricted, /ein Entscheidungszeitpunkt/);
  assert.match(b.decisionRule, /BALANCED/);
  assert.ok(b.oddsTimes && b.oddsTimes.estimatedShare > 0, 'geschätzte Quotenzeitpunkte ausgewiesen');
  assert.match(b.note, /GESCHÄTZT/);
});

test('P2: Live und Backtest nutzen dieselbe Entscheidungsregel (Datenqualität, AVOID, Strategie)', () => {
  const base: DecisionInput = { p: 0.5, sd: 0.02, bestOdds: 2.3, novig: 0.47, strategy: 'BALANCED', minEv: 0.05, dqScore: 80, agreement: 0.9, modelValidated: false, marketEdgeProven: false, isMock: false, freshness: 1, freshBooks: 4, marketRefSource: 'sharp:x' };
  assert.equal(decide(base).status, 'VALUE');
  assert.equal(decide({ ...base, dqScore: 50 }).status, 'WATCH', 'Datenqualität unter Mindestwert BALANCED');
  assert.equal(decide({ ...base, p: 0.65 }).status, 'AVOID', '> 12 Pp. vom Markt');
  assert.ok(decide({ ...base, strategy: 'CONSERVATIVE' }).probLow < decide(base).probLow, 'Strategie-z wirkt');
  // STRONG_VALUE nur mit validiertem Modell UND belegtem Mehrwert gegenüber dem Markt
  const strong = { ...base, p: 0.56, bestOdds: 2.4, novig: 0.5, modelValidated: true };
  assert.equal(decide({ ...strong, marketEdgeProven: false }).status, 'VALUE');
  assert.ok(decide({ ...strong, marketEdgeProven: false }).reasons.some(x => /kein statistisch nachgewiesener Mehrwert/.test(x)));
  assert.equal(decide({ ...strong, marketEdgeProven: true }).status, 'STRONG_VALUE');
  assert.ok(decide(base).reasons.some(x => /experimentelles Signal/.test(x)), 'UNVALIDATED wird als experimentell bezeichnet');
  // Auswahl: selectTop liefert je Spiel eine Auswahl, Rang deterministisch
  const c = [{ id: 1, event_id: 7, ev_low: 0.02, quality_score: 80 }, { id: 2, event_id: 7, ev_low: 0.05, quality_score: 80 }, { id: 3, event_id: 8, ev_low: 0.01, quality_score: 80 }];
  const top = selectTop(c, 5);
  assert.deepEqual(top.map(t => t.pick.id), [2, 3]);
  assert.deepEqual(top[0].correlated.map(x => x.id), [1]);
});

test('P2: Validierung je Markt – fehlende BTTS-Quoten blockieren 1X2 nicht und validieren BTTS nicht mit', () => {
  const { r } = bigLeague();
  const sc = r.metrics.scopes!;
  const x1 = sc.find(s => s.market === '1X2')!, bt = sc.find(s => s.market === 'BTTS')!;
  assert.equal(x1.status, 'VALIDATED', JSON.stringify(x1.reasons));
  assert.equal(bt.status, 'UNVALIDATED');
  assert.equal(bt.marketEvidence, 'NOT_TESTABLE');
  assert.ok(bt.reasons.some(x => /Marktquoten/.test(x)));
  assert.equal(r.metrics.validation.status, 'PARTIAL', 'Gesamt nur teilweise validiert');
  assert.ok(x1.oddsTimesEstimated, 'geschätzte Quotenzeitpunkte gekennzeichnet');
});

test('P2: "nicht signifikant schlechter als der Markt" wird nicht als Mehrwert ausgegeben', () => {
  const { r } = bigLeague();
  const x1 = r.metrics.scopes!.find(s => s.market === '1X2')!;
  assert.equal(x1.marketEvidence, 'NOT_WORSE', `${JSON.stringify(x1.blendVsMarket)}`);
  assert.ok(x1.reasons.some(x => /KEIN Nachweis eines Mehrwerts/.test(x)));
  assert.ok(!r.metrics.validation.reasons.some(x => /mit Mehrwert gegenüber dem Markt/.test(x)), 'alte Formulierung entfernt');
});

test('P2: validierte Version gilt nur für geprüfte Wettbewerbe und Märkte', () => {
  const { db, r } = bigLeague();
  const comp = r.metrics.scopes![0].competitionId;
  const pe = new PredictionEngine(db);
  const a = pe.currentModelVersion(comp);
  assert.equal(a.status, 'VALIDATED');
  assert.deepEqual(a.validatedMarkets, ['1X2']);
  assert.deepEqual(a.marketEdgeMarkets, [], 'kein Mehrwert belegt → STRONG_VALUE gesperrt');
  assert.ok(a.weights && a.weights['1X2'] && !a.weights.OU && !a.weights.BTTS, 'Gewichte nur für validierte Märkte');
  // Anderer (ungeprüfter) Wettbewerb: Basisversion, nichts validiert
  const other = Number(db.run("INSERT INTO competitions (name, region, is_mock) VALUES ('UEFA Champions League', 'europe', 0)").lastInsertRowid);
  const b = pe.currentModelVersion(other);
  assert.equal(b.status, 'UNVALIDATED');
  assert.deepEqual(b.validatedMarkets, []);
  // Eine alte, global als VALIDATED markierte Version ohne Scope-Einträge wird nicht mehr übernommen
  db.run("INSERT INTO model_versions (id, description, weights, validation_status, created_at) VALUES ('legacy-global', 'alt', '{}', 'VALIDATED', '2099-01-01T00:00:00Z')");
  assert.equal(pe.currentModelVersion(other).status, 'UNVALIDATED');
  assert.equal(pe.currentModelVersion(comp).id, a.id);
});

test('P2: Scheduler nutzt denselben Validierungsweg mit Datenqualitätsprüfung wie der manuelle Weg', async () => {
  const app = await mockApp();
  insertSyntheticLeague(app.db, { teams: 14, seasons: 3, seed: 'sched', providerId: 'schedliga', name: 'Sched Liga' });
  const comp = app.db.get<{ competition_id: number }>("SELECT competition_id FROM competition_aliases WHERE provider_id = 'schedliga'")!.competition_id;
  // Doppeltes Spiel → harter Datenqualitätsbefund nur für diese Liga
  const e = app.db.get<{ home_team_id: number; away_team_id: number; kickoff_utc: string }>('SELECT home_team_id, away_team_id, kickoff_utc FROM events WHERE competition_id = ? LIMIT 1', comp)!;
  app.db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status, home_goals, away_goals) VALUES (?, ?, ?, ?, 'finished', 1, 1)", comp, e.home_team_id, e.away_team_id, new Date(Date.parse(e.kickoff_utc) + 3_600_000).toISOString());
  const res = await new Scheduler(app).runJob('backtest', ANCHOR);
  assert.equal(res.started, true, res.error);
  const v = app.db.get<{ id: number; report: string }>("SELECT id, report FROM diagnostic_runs WHERE kind = 'validation' ORDER BY id DESC LIMIT 1");
  assert.ok(v, 'Validierungsbericht des Scheduler-Laufs vorhanden');
  const rep = JSON.parse(v!.report);
  assert.ok(rep.dataQuality.competitions.some((c: { competitionId: number; duplicateMatches: unknown[] }) => c.competitionId === comp && c.duplicateMatches.length > 0));
  const scopes = app.db.all<{ reasons: string; status: string }>('SELECT reasons, status FROM model_scope_validations WHERE competition_id = ?', comp);
  assert.ok(scopes.length === 3 && scopes.every(s => s.status !== 'VALIDATED' && /Datenqualität: Sched Liga: 1 doppelte Spiele/.test(s.reasons)), JSON.stringify(scopes));
  // Manueller Weg liefert denselben Befund
  const manual = runValidation(app.db, { includeMock: true });
  assert.ok(manual.reasons.some(x => /Sched Liga: 1 doppelte Spiele/.test(x)));
});
