/**
 * Authentifizierung und Autorisierung (v0.2.0)
 * - Benutzerkonten mit Rollen: admin | user  (system = interner Platzhalter ohne Login)
 * - Passwort-Hashing: scrypt (N=2^15, r=8, p=1, 32-Byte-Salt), zeitkonstanter Vergleich
 * - Sessions: zufälliges 256-Bit-Token im HttpOnly-Cookie; in der DB nur der SHA-256-Hash
 *   Ablauf absolut 12 h, Leerlauf 2 h; Logout löscht die Session
 * - CSRF: Synchronizer-Token je Session, Pflicht-Header x-csrf-token bei POST/PUT/DELETE mit Cookie-Auth
 * - Sperre nach 5 Fehlversuchen für 15 min; alle sicherheitsrelevanten Ereignisse in security_events
 * - Service-Token (ADMIN_TOKEN, optional, Rolle admin) und Lese-Token (READ_TOKEN, optional, nur GET mit Rolle user)
 *   nur für Server-zu-Server (z. B. Base44-Backend-Funktion), nie im Browser
 */
import crypto from 'node:crypto';
import type { Db } from './db/db.js';
import { AppError, nowIso } from './util/core.js';

export type Role = 'admin' | 'user';
export interface Principal { kind: 'session' | 'service'; userId: number | null; email: string | null; role: Role; csrf: string | null; sessionId: string | null; readOnly?: boolean }

export const SESSION_ABSOLUTE_H = 12;
export const SESSION_IDLE_MIN = 120;
export const MAX_FAILED = 5;
export const LOCK_MIN = 15;
export const MIN_PASSWORD = 12;
const SCRYPT = { N: 32768, r: 8, p: 1, maxmem: 64 * 1024 * 1024 };

export function hashPassword(pw: string): string {
  const salt = crypto.randomBytes(32);
  const h = crypto.scryptSync(pw, salt, 64, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${h.toString('base64')}`;
}
export function verifyPassword(pw: string, stored: string | null): boolean {
  if (!stored) { crypto.scryptSync(pw, 'dummy-salt-for-timing', 64, SCRYPT); return false; }
  const [alg, N, r, p, salt, hash] = stored.split('$');
  if (alg !== 'scrypt') return false;
  const want = Buffer.from(hash, 'base64');
  const got = crypto.scryptSync(pw, Buffer.from(salt, 'base64'), want.length, { N: Number(N), r: Number(r), p: Number(p), maxmem: SCRYPT.maxmem });
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}
const sha256 = (s: string) => crypto.createHash('sha256').update(s).digest('hex');
const token = () => crypto.randomBytes(32).toString('base64url');

export function validEmail(e: unknown): string {
  const s = String(e ?? '').trim().toLowerCase();
  if (!/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/.test(s)) throw new AppError('invalid_input', 'email: ungültige E-Mail-Adresse');
  return s;
}
export function validPassword(p: unknown): string {
  const s = String(p ?? '');
  if (s.length < MIN_PASSWORD || s.length > 200) throw new AppError('invalid_input', `password: mindestens ${MIN_PASSWORD} Zeichen`);
  if (!/[a-zA-Z]/.test(s) || !/[0-9]/.test(s)) throw new AppError('invalid_input', 'password: muss Buchstaben und Ziffern enthalten');
  return s;
}

export class AuthService {
  constructor(private db: Db, private serviceToken: string | null, private readToken: string | null = null) {}

  event(kind: string, detail: { userId?: number | null; email?: string | null; ip?: string | null; detail?: string } = {}) {
    this.db.run('INSERT INTO security_events (kind, user_id, email, ip, detail, created_at) VALUES (?, ?, ?, ?, ?, ?)',
      kind, detail.userId ?? null, detail.email ?? null, detail.ip ?? null, detail.detail ?? null, nowIso());
  }

  createUser(email: string, password: string, role: Role, by: Principal | null = null): { id: number; email: string; role: Role } {
    const e = validEmail(email), p = validPassword(password);
    if (!['admin', 'user'].includes(role)) throw new AppError('invalid_input', 'role: admin oder user');
    if (this.db.get('SELECT 1 FROM users WHERE email = ?', e)) throw new AppError('conflict', 'E-Mail bereits registriert', 409);
    const id = this.db.run('INSERT INTO users (name, email, password_hash, role, active) VALUES (?, ?, ?, ?, 1)', e.split('@')[0], e, hashPassword(p), role).lastInsertRowid;
    this.db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', id);
    this.event('user_created', { userId: id, email: e, detail: `role=${role}; by=${by?.email ?? by?.kind ?? 'bootstrap'}` });
    return { id, email: e, role };
  }

  /** Legt beim ersten Start ein Admin-Konto aus ADMIN_EMAIL/ADMIN_PASSWORD an, falls noch keins existiert. */
  bootstrapAdmin(email: string | null, password: string | null): 'created' | 'exists' | 'missing' {
    if (this.db.get("SELECT 1 FROM users WHERE role = 'admin' AND active = 1 AND password_hash IS NOT NULL")) return 'exists';
    if (!email || !password) return 'missing';
    this.createUser(email, password, 'admin');
    return 'created';
  }

  hasAdmin(): boolean { return !!this.db.get("SELECT 1 FROM users WHERE role = 'admin' AND active = 1 AND password_hash IS NOT NULL"); }

  login(email: string, password: string, ip: string | null, ua: string | null, now = new Date()): { token: string; csrf: string; user: { id: number; email: string; role: Role }; expiresAt: string } {
    const e = String(email ?? '').trim().toLowerCase();
    const u = this.db.get<{ id: number; email: string; password_hash: string | null; role: Role; active: number; failed_logins: number; locked_until: string | null }>(
      "SELECT id, email, password_hash, role, active, failed_logins, locked_until FROM users WHERE email = ? AND role IN ('admin','user')", e);
    const generic = new AppError('invalid_credentials', 'E-Mail oder Passwort falsch.', 401);
    if (!u) { verifyPassword(String(password ?? ''), null); this.event('login_failed', { email: e, ip, detail: 'unbekannt' }); throw generic; }
    if (u.locked_until && u.locked_until > nowIso(now)) { this.event('login_failed', { userId: u.id, email: e, ip, detail: 'gesperrt' }); throw new AppError('locked', `Konto vorübergehend gesperrt. Bitte nach ${LOCK_MIN} min erneut versuchen.`, 423); }
    if (!u.active || !verifyPassword(String(password ?? ''), u.password_hash)) {
      const failed = u.failed_logins + 1;
      const lock = failed >= MAX_FAILED ? new Date(now.getTime() + LOCK_MIN * 60_000).toISOString() : null;
      this.db.run('UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?', lock ? 0 : failed, lock, u.id);
      this.event(lock ? 'locked' : 'login_failed', { userId: u.id, email: e, ip, detail: u.active ? `Fehlversuch ${failed}` : 'inaktiv' });
      throw generic;
    }
    this.db.run('UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = ? WHERE id = ?', nowIso(now), u.id);
    const t = token(), csrf = token();
    const exp = new Date(now.getTime() + SESSION_ABSOLUTE_H * 3_600_000).toISOString();
    this.db.run('INSERT INTO sessions (id, user_id, csrf_token, created_at, expires_at, last_seen_at, ip, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      sha256(t), u.id, csrf, nowIso(now), exp, nowIso(now), ip, (ua ?? '').slice(0, 200));
    this.event('login_ok', { userId: u.id, email: e, ip });
    return { token: t, csrf, user: { id: u.id, email: u.email, role: u.role }, expiresAt: exp };
  }

  session(tok: string | null, now = new Date()): Principal | null {
    if (!tok) return null;
    const s = this.db.get<{ id: string; user_id: number; csrf_token: string; expires_at: string; last_seen_at: string; email: string; role: Role; active: number }>(
      'SELECT s.id, s.user_id, s.csrf_token, s.expires_at, s.last_seen_at, u.email, u.role, u.active FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id = ?', sha256(tok));
    if (!s) return null;
    const idle = now.getTime() - new Date(s.last_seen_at).getTime() > SESSION_IDLE_MIN * 60_000;
    if (s.expires_at <= nowIso(now) || idle || !s.active || !['admin', 'user'].includes(s.role)) { this.db.run('DELETE FROM sessions WHERE id = ?', s.id); return null; }
    this.db.run('UPDATE sessions SET last_seen_at = ? WHERE id = ?', nowIso(now), s.id);
    return { kind: 'session', userId: s.user_id, email: s.email, role: s.role, csrf: s.csrf_token, sessionId: s.id };
  }

  service(bearer: string | null): Principal | null {
    if (!bearer) return null;
    const eq = (t: string | null) => { if (!t) return false; const a = Buffer.from(bearer), b = Buffer.from(t); return a.length === b.length && crypto.timingSafeEqual(a, b); };
    if (eq(this.serviceToken)) return { kind: 'service', userId: null, email: 'service-token', role: 'admin', csrf: null, sessionId: null };
    if (eq(this.readToken)) return { kind: 'service', userId: null, email: 'read-token', role: 'user', csrf: null, sessionId: null, readOnly: true };
    return null;
  }

  logout(p: Principal) { if (p.sessionId) this.db.run('DELETE FROM sessions WHERE id = ?', p.sessionId); this.event('logout', { userId: p.userId, email: p.email }); }

  listUsers() { return this.db.all("SELECT id, email, role, active, last_login_at, created_at, locked_until FROM users WHERE role IN ('admin','user') ORDER BY id"); }

  /** Passwort neu setzen (Betreiber, per CLI). Hebt Sperren auf und beendet alle Sessions des Kontos. */
  setPassword(email: string, password: string): { id: number; email: string } {
    const e = validEmail(email), p = validPassword(password);
    const u = this.db.get<{ id: number }>("SELECT id FROM users WHERE email = ? AND role IN ('admin','user')", e);
    if (!u) throw new AppError('not_found', 'Benutzer nicht gefunden', 404);
    this.db.run('UPDATE users SET password_hash = ?, failed_logins = 0, locked_until = NULL WHERE id = ?', hashPassword(p), u.id);
    this.db.run('DELETE FROM sessions WHERE user_id = ?', u.id);
    this.event('password_reset', { userId: u.id, email: e, detail: 'cli' });
    return { id: u.id, email: e };
  }

  updateUser(id: number, patch: { role?: unknown; active?: unknown }, by: Principal) {
    const u = this.db.get<{ id: number; role: Role; active: number; email: string }>("SELECT id, role, active, email FROM users WHERE id = ? AND role IN ('admin','user')", id);
    if (!u) throw new AppError('not_found', 'Benutzer nicht gefunden', 404);
    const role = patch.role === undefined ? u.role : (['admin', 'user'].includes(String(patch.role)) ? String(patch.role) as Role : (() => { throw new AppError('invalid_input', 'role: admin oder user'); })());
    const active = patch.active === undefined ? u.active : (patch.active ? 1 : 0);
    // letzter aktiver Admin darf sich nicht selbst entmachten
    if ((role !== 'admin' || !active) && u.role === 'admin') {
      const others = this.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND active = 1 AND id != ?", id)!.n;
      if (!others) throw new AppError('conflict', 'Der letzte aktive Admin kann nicht herabgestuft oder deaktiviert werden.', 409);
    }
    this.db.run('UPDATE users SET role = ?, active = ? WHERE id = ?', role, active, id);
    if (!active || role !== u.role) this.db.run('DELETE FROM sessions WHERE user_id = ?', id);
    this.event('role_changed', { userId: id, email: u.email, detail: `role=${role}; active=${active}; by=${by.email}` });
    return { id, role, active };
  }
}

export function parseCookies(h: string | undefined): Record<string, string> {
  const out: Record<string, string> = {};
  for (const part of (h ?? '').split(';')) { const i = part.indexOf('='); if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
  return out;
}
export const SESSION_COOKIE = 'aea_session';
export function sessionCookie(tok: string, maxAgeSec: number, secure: boolean): string {
  return `${SESSION_COOKIE}=${tok}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}${secure ? '; Secure' : ''}`;
}
