/**
 * UI-Kit "Professional Analytics" (v0.3.1). Kleine, zustandslose Bausteine; Styles in styles.css.
 * Regeln: Bedeutungsfarben nur für Bedeutung (VALUE grün, WATCH/Warnung bernstein, AVOID/veraltet/Fehler rot),
 * Cyan nur für Interaktion. Zahlen immer tabellarisch. Jeder Datenbereich hat Lade-, Fehler- und Leerzustand.
 */
import React from 'react';
import { Icon, useApp } from './components';
import { pct } from './api';

type Tone = 'neutral' | 'value' | 'watch' | 'avoid' | 'info' | 'outline';

export function Button({ variant = 'primary', size, block, icon, children, ...p }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'quiet' | 'danger'; size?: 'sm'; block?: boolean; icon?: string }) {
  const cls = ['btn', variant !== 'primary' ? variant : '', size ?? '', block ? 'block' : '', p.className ?? ''].filter(Boolean).join(' ');
  return <button {...p} className={cls}>{icon ? <Icon name={icon} /> : null}{children}</button>;
}

export function Card({ title, sub, actions, children, className = '', as = 'section', id }: { title?: React.ReactNode; sub?: React.ReactNode; actions?: React.ReactNode; children?: React.ReactNode; className?: string; as?: 'section' | 'div' | 'article'; id?: string }) {
  const Tag = as as any;
  return <Tag className={`card ${className}`} id={id}>
    {title || actions ? <div className="card-h">{title ? <h2>{title}</h2> : <span style={{ flex: 1 }} />}{actions}{sub ? <p className="sub">{sub}</p> : null}</div> : null}
    {children}
  </Tag>;
}

export function Badge({ tone = 'neutral', dot, children, title }: { tone?: Tone; dot?: boolean; children: React.ReactNode; title?: string }) {
  return <span className={`badge ${tone}`} title={title}>{dot ? <i className="dot" /> : null}{children}</span>;
}

const SIGNAL_TONE: Record<string, string> = { STRONG_VALUE: 'st-STRONG_VALUE', VALUE: 'st-VALUE', WATCH: 'st-WATCH', AVOID: 'st-AVOID', STALE: 'st-STALE', MARKET_SUSPENDED: 'st-MARKET_SUSPENDED', NO_VALUE: 'st-NO_VALUE', INSUFFICIENT_DATA: 'st-INSUFFICIENT_DATA' };
/** Signalstatus als feststehender Code (VALUE, WATCH …). */
export const SignalBadge = ({ s }: { s: string }) => <span className={`badge sig ${SIGNAL_TONE[s] ?? ''}`}>{s.replace(/_/g, ' ')}</span>;
export const StatusChip = SignalBadge;
export const MockChip = () => <Badge tone="watch">MOCK</Badge>;

/** Ampelton für technische Status (Provider, Jobs, Validierung). */
export function statusTone(s: string | null | undefined): Tone {
  const v = String(s ?? '').toUpperCase();
  if (['OK', 'DONE', 'READY', 'ACTIVE', 'CONNECTED', 'VERIFIED', 'VALIDATED', 'AVAILABLE', 'LIVE VERIFIED'].includes(v)) return 'value';
  if (['FAILED', 'DOWN', 'BLOCKED', 'ERROR', 'DISCONNECTED', 'REJECTED', 'EXPIRED', 'INTERRUPTED'].includes(v)) return 'avoid';
  if (['PAUSED', 'PAUSED_QUOTA', 'DEGRADED', 'UNVALIDATED', 'PARTIAL', 'NO FIXTURES', 'INSUFFICIENT DATA', 'PENDING', 'PROOF_SUBMITTED', 'AWAITING_PAYMENT', 'RUNNING', 'NOT VERIFIED', 'NOT CONNECTED', 'BUDGET'].includes(v)) return 'watch';
  return 'outline';
}
export const StatusBadge = ({ s, label }: { s: string | null | undefined; label?: string }) => <Badge tone={statusTone(s)} dot>{label ?? s ?? '–'}</Badge>;

export function Banner({ tone = 'info', title, children, action }: { tone?: 'info' | 'warn' | 'error'; title?: React.ReactNode; children?: React.ReactNode; action?: React.ReactNode }) {
  return <div className={`banner ${tone}`} role={tone === 'error' ? 'alert' : 'status'}>
    <Icon name={tone === 'error' ? 'error' : tone === 'warn' ? 'warn' : 'info'} className="b-icon" />
    <div className="b-body">{title ? <span className="b-title">{title}</span> : null}{children ? <span>{children}</span> : null}</div>
    {action ? <div style={{ marginLeft: 'auto' }}>{action}</div> : null}
  </div>;
}

export function PageHeader({ title, lead, actions }: { title: React.ReactNode; lead?: React.ReactNode; actions?: React.ReactNode }) {
  return <header className="page-h"><div><h1>{title}</h1>{lead ? <p className="lead">{lead}</p> : null}</div>{actions ? <div className="row-flex">{actions}</div> : null}</header>;
}
export function SectionHeader({ title, count, actions }: { title: React.ReactNode; count?: React.ReactNode; actions?: React.ReactNode }) {
  return <div className="section-h"><h2>{title}{count != null ? <span className="count"> {count}</span> : null}</h2>{actions}</div>;
}

export function Kpi({ label, value, hint, tone, size, badge }: { label: React.ReactNode; value: React.ReactNode; hint?: React.ReactNode; tone?: 'value' | 'watch' | 'avoid'; size?: 'md'; badge?: React.ReactNode }) {
  return <div className={`kpi ${tone ? `tone-${tone}` : ''}`}>
    <span className="k">{label}{badge}</span>
    <span className={`v ${size ?? ''}`}>{value}</span>
    {hint ? <span className="h">{hint}</span> : null}
  </div>;
}

export function Tiles({ items }: { items: [string, string, number?][] }) {
  return <div className="tiles">{items.map(([k, v, sg]) => <div className="tile" key={k}><span className={`v ${sg == null ? '' : sg > 0 ? 'pos' : sg < 0 ? 'neg' : ''}`}>{v}</span><span className="k">{k}</span></div>)}</div>;
}

export function Tabs<T extends string>({ value, onChange, items, label }: { value: T; onChange: (v: T) => void; items: [T, string][]; label: string }) {
  return <div className="tabs" role="tablist" aria-label={label}>{items.map(([k, l]) => <button key={k} className="tab" role="tab" aria-selected={value === k} onClick={() => onChange(k)}>{l}</button>)}</div>;
}
export function Segmented<T extends string>({ value, onChange, items, label }: { value: T; onChange: (v: T) => void; items: [T, string][]; label: string }) {
  return <div className="seg" role="group" aria-label={label}>{items.map(([k, l]) => <button key={k} aria-pressed={value === k} onClick={() => onChange(k)}>{l}</button>)}</div>;
}

export function Field({ label, hint, children, htmlFor }: { label: React.ReactNode; hint?: React.ReactNode; children: React.ReactNode; htmlFor?: string }) {
  return <label className="field" htmlFor={htmlFor}>{label}{children}{hint ? <span className="hint">{hint}</span> : null}</label>;
}
export function Check({ checked, onChange, label, hint, disabled, id }: { checked: boolean; onChange: (v: boolean) => void; label: React.ReactNode; hint?: React.ReactNode; disabled?: boolean; id?: string }) {
  return <label className="check" style={disabled ? { opacity: .6, cursor: 'default' } : undefined}><input id={id} type="checkbox" checked={checked} disabled={disabled} onChange={e => onChange(e.target.checked)} /><span>{label}{hint ? <span className="hint">{hint}</span> : null}</span></label>;
}

export function EmptyState({ title, text, code, action, icon = 'empty' }: { title: React.ReactNode; text?: React.ReactNode; code?: string; action?: React.ReactNode; icon?: string }) {
  return <div className="empty"><Icon name={icon} className="e-icon" />{code ? <span className="e-code">{code}</span> : null}<span className="e-title">{title}</span>{text ? <span className="e-text">{text}</span> : null}{action}</div>;
}
export function Skeleton({ lines = 3, height = 14 }: { lines?: number; height?: number }) {
  return <div className="loading-block" aria-busy="true" aria-live="polite">{Array.from({ length: lines }, (_, i) => <div key={i} className="skel" style={{ height, width: `${100 - i * 12}%` }} />)}</div>;
}
export function Loading({ lines = 3 }: { lines?: number }) { const { t } = useApp(); return <div><span className="sr-only" style={{ position: 'absolute', left: -9999 }}>{t.loading}</span><Skeleton lines={lines} /></div>; }
export function ErrorBox({ e, onRetry }: { e: unknown; onRetry?: () => void }) {
  const { u } = useApp();
  return <Banner tone="error" title={u.loadFailed} action={onRetry ? <Button variant="secondary" size="sm" onClick={onRetry}>{u.retry}</Button> : undefined}>{(e as Error)?.message ?? String(e)}</Banner>;
}

/** Wahrscheinlichkeitsbalken 1/X/2 bzw. Ja/Nein. */
export function ProbBar({ parts }: { parts: { label: string; p: number | null | undefined; color: string }[] }) {
  const valid = parts.filter(x => x.p != null && Number.isFinite(x.p));
  if (!valid.length) return <span className="t-3 small">–</span>;
  return <div>
    <div className="pbar" role="img" aria-label={valid.map(x => `${x.label} ${pct(x.p)}`).join(', ')}>{valid.map(x => <span key={x.label} style={{ width: `${(x.p ?? 0) * 100}%`, background: x.color }} />)}</div>
    <div className="pbar-legend" style={{ gridTemplateColumns: `repeat(${valid.length}, minmax(0, 1fr))` }}>{valid.map(x => <div key={x.label}><span>{x.label}</span><b>{pct(x.p)}</b></div>)}</div>
  </div>;
}

/**
 * Edge-Meter: Leitmotiv der Oberfläche. Zeigt auf einer 0–100-%-Skala
 *  – die in der Quote enthaltene Wahrscheinlichkeit (1/Quote, weißer Strich),
 *  – den fairen Marktpreis ohne Marge (Türkis),
 *  – die Entscheidungswahrscheinlichkeit (Balken) und den Abstand zur Quote (grün = positiver Edge).
 * Reine Darstellung vorhandener Werte; nichts wird neu berechnet außer 1/Quote.
 */
export function EdgeMeter({ decision, fair, odds, compact }: { decision: number | null | undefined; fair: number | null | undefined; odds: number | null | undefined; compact?: boolean }) {
  const { u } = useApp();
  if (decision == null || !odds) return null;
  const implied = 1 / odds;
  const lo = Math.min(implied, decision), hi = Math.max(implied, decision);
  const w = (v: number) => `${Math.max(0, Math.min(100, v * 100))}%`;
  return <div className="edge">
    <div className="track" role="img" aria-label={`${u.decision} ${pct(decision)}, ${u.implied} ${pct(implied)}${fair != null ? `, ${u.fair} ${pct(fair)}` : ''}`}>
      <div className="fill" style={{ width: w(lo) }} />
      <div className={`gap ${decision < implied ? 'neg' : ''}`} style={{ left: w(lo), width: `calc(${w(hi)} - ${w(lo)})` }} />
      {fair != null ? <span className="tick fair" style={{ left: w(fair) }} /> : null}
      <span className="tick implied" style={{ left: w(implied) }} />
    </div>
    {compact ? null : <div className="legend">
      <span><i style={{ background: 'var(--text)' }} /><em>{u.implied}</em><b>{pct(implied)}</b></span>
      {fair != null ? <span><i style={{ background: 'var(--teal)' }} /><em>{u.fair}</em><b>{pct(fair)}</b></span> : null}
      <span><i style={{ background: decision >= implied ? 'var(--value)' : 'var(--avoid)' }} /><em>{u.decision}</em><b>{pct(decision)}</b></span>
    </div>}
  </div>;
}
