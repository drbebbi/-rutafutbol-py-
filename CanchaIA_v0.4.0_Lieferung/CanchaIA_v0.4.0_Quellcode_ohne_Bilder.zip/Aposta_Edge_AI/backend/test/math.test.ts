import { test } from 'node:test';
import assert from 'node:assert/strict';
import { scoreMatrix, marketsFromMatrix, poissonPmf, dcTau, probsFromLambdas } from '../src/engines/prediction/poisson.js';
import { noVig, overround, validateQuote, consensusNoVig, type MarketBookView } from '../src/engines/odds.js';
import { selectionWon, calibrationBins, ece } from '../src/engines/performance.js';
import { combine } from '../src/engines/prediction/ensemble.js';
import type { ProviderOddsQuote } from '../src/providers/types.js';

const close = (a: number, b: number, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} ≉ ${b}`);

test('Poisson-PMF summiert sich zu 1 und stimmt für bekannte Werte', () => {
  let s = 0; for (let k = 0; k < 40; k++) s += poissonPmf(k, 1.7);
  close(s, 1, 1e-12);
  close(poissonPmf(0, 1), Math.exp(-1));
  close(poissonPmf(2, 3), Math.exp(-3) * 4.5);
});

test('Ergebnismatrix ist normiert; Märkte ergänzen sich zu 1', () => {
  const M = scoreMatrix(1.45, 1.1, 10, -0.1);
  close(M.flat().reduce((a, b) => a + b, 0), 1, 1e-12);
  const p = marketsFromMatrix(M);
  close(p['1X2'].HOME + p['1X2'].DRAW + p['1X2'].AWAY, 1, 1e-12);
  close(p.OU.OVER + p.OU.UNDER, 1, 1e-12);
  close(p.BTTS.YES + p.BTTS.NO, 1, 1e-12);
});

test('Dixon-Coles mit ρ = 0 entspricht unabhängigem Poisson; negatives ρ erhöht Remis 0:0/1:1', () => {
  assert.equal(dcTau(0, 0, 1.2, 1.1, 0), 1);
  const a = probsFromLambdas(1.3, 1.3, 0), b = probsFromLambdas(1.3, 1.3, -0.12);
  assert.ok(b['1X2'].DRAW > a['1X2'].DRAW);
});

test('Symmetrische Torerwartung ergibt symmetrische 1X2-Wahrscheinlichkeiten', () => {
  const p = probsFromLambdas(1.2, 1.2);
  close(p['1X2'].HOME, p['1X2'].AWAY, 1e-12);
});

test('EV-Beispiel aus dem Auftrag: 0,55 × 2,10 − 1 = +15,5 %', () => {
  close(0.55 * 2.10 - 1, 0.155, 1e-12);
});

test('No-Vig proportional und Marge', () => {
  const pr = { HOME: 2.30, DRAW: 3.10, AWAY: 3.45 };
  const nv = noVig(pr, '1X2');
  close(nv.HOME! + nv.DRAW! + nv.AWAY!, 1, 1e-12);
  close(overround(pr, '1X2'), 1 / 2.3 + 1 / 3.1 + 1 / 3.45 - 1, 1e-12);
  close(nv.HOME!, (1 / 2.3) / (1 / 2.3 + 1 / 3.1 + 1 / 3.45), 1e-12);
});

const baseQuote = (over: Partial<ProviderOddsQuote> = {}): ProviderOddsQuote => ({
  provider: 't', providerEventId: '1', bookmakerProviderId: 'b', bookmakerName: 'B', market: '1X2', line: null, marketStatus: 'open',
  prices: { HOME: 2.3, DRAW: 3.1, AWAY: 3.45 }, retrievedAt: '2026-10-12T11:50:00.000Z', sourceTimestamp: null, ...over,
});
const ctx = { now: new Date('2026-10-12T12:00:00Z'), maxAgeMinutes: 90, kickoffUtc: '2026-10-12T20:00:00Z', mappingConfidence: 1 };

test('Quotenvalidierung: gültiger Markt', () => assert.deepEqual(validateQuote(baseQuote(), ctx), []));
test('Quotenvalidierung: unvollständiger Markt', () => assert.ok(validateQuote(baseQuote({ prices: { HOME: 2.3, AWAY: 3.4 } }), ctx).some(e => e.includes('DRAW'))));
test('Quotenvalidierung: falsche Torlinie', () => assert.ok(validateQuote(baseQuote({ market: 'OU', line: 3.5, prices: { OVER: 2, UNDER: 1.8 } }), ctx).some(e => e.includes('Torlinie'))));
test('Quotenvalidierung: OU ohne Linie', () => assert.ok(validateQuote(baseQuote({ market: 'OU', line: null, prices: { OVER: 2, UNDER: 1.8 } }), ctx).some(e => e.includes('Torlinie fehlt'))));
test('Quotenvalidierung: negative Marge (vermischte Preise)', () => assert.ok(validateQuote(baseQuote({ prices: { HOME: 3, DRAW: 4, AWAY: 4 } }), ctx).some(e => e.includes('negative Marge'))));
test('Quotenvalidierung: veraltet', () => assert.ok(validateQuote(baseQuote({ retrievedAt: '2026-10-12T09:00:00.000Z' }), ctx).some(e => /min alt, erlaubt/.test(e))));
test('Quotenvalidierung: Spiel begonnen', () => assert.ok(validateQuote(baseQuote(), { ...ctx, kickoffUtc: '2026-10-12T11:00:00Z' }).some(e => e.includes('begonnen'))));
test('Quotenvalidierung: unsichere Spielzuordnung', () => assert.ok(validateQuote(baseQuote(), { ...ctx, mappingConfidence: 0.8 }).some(e => /zuordnung/i.test(e))));
test('Quotenvalidierung: Markt ausgesetzt', () => assert.ok(validateQuote(baseQuote({ marketStatus: 'suspended' }), ctx).some(e => e.includes('suspended'))));

test('Konsens: scharfer Buchmacher hat Vorrang, sonst Median', () => {
  const view = (id: string, sharp: boolean, h: number, d: number, a: number): MarketBookView => ({ snapshotId: id, bookmakerId: id, bookmakerName: id, isSharp: sharp, retrievedAt: '', sourceTimestamp: null, status: 'open', errors: [], valid: true, prices: { HOME: h, DRAW: d, AWAY: a }, overround: 0, noVig: noVig({ HOME: h, DRAW: d, AWAY: a }, '1X2') });
  const c1 = consensusNoVig([view('a', false, 2, 3.4, 4), view('p', true, 2.1, 3.5, 3.9)], '1X2')!;
  assert.equal(c1.source, 'sharp:p');
  const c2 = consensusNoVig([view('a', false, 2, 3.4, 4), view('b', false, 2.1, 3.3, 3.8), view('c', false, 2.05, 3.5, 3.7)], '1X2')!;
  assert.match(c2.source, /^median:3/);
  close(c2.probs.HOME! + c2.probs.DRAW! + c2.probs.AWAY!, 1, 1e-12);
});

test('Abrechnung der Auswahlen', () => {
  assert.equal(selectionWon('1X2', 'HOME', null, 2, 1), true);
  assert.equal(selectionWon('1X2', 'DRAW', null, 1, 1), true);
  assert.equal(selectionWon('OU', 'OVER', 2.5, 2, 1), true);
  assert.equal(selectionWon('OU', 'UNDER', 2.5, 2, 1), false);
  assert.equal(selectionWon('BTTS', 'YES', null, 1, 0), false);
  assert.equal(selectionWon('BTTS', 'NO', null, 0, 0), true);
});

test('Kalibrierung: perfekt kalibrierte Daten haben ECE nahe 0', () => {
  const items = [...Array(10)].flatMap((_, b) => { const p = b / 10 + 0.05; return [...Array(100)].map((__, k) => ({ p, y: k < Math.round(p * 100) ? 1 : 0 })); });
  assert.ok(ece(items) < 0.05);
  assert.ok(calibrationBins(items).length === 10);
});

test('Ensemble: gleiche Gewichte ohne Validierung, Unsicherheit wächst mit Modellstreuung', () => {
  const agree = combine([
    { model: 'poisson', available: true, lambdaHome: 1.4, lambdaAway: 1.1, probs: probsFromLambdas(1.4, 1.1) },
    { model: 'dixon_coles', available: true, lambdaHome: 1.4, lambdaAway: 1.1, probs: probsFromLambdas(1.4, 1.1) },
  ], null, 30);
  const disagree = combine([
    { model: 'poisson', available: true, lambdaHome: 1.8, lambdaAway: 0.9, probs: probsFromLambdas(1.8, 0.9) },
    { model: 'dixon_coles', available: true, lambdaHome: 1.0, lambdaAway: 1.3, probs: probsFromLambdas(1.0, 1.3) },
  ], null, 30);
  assert.ok(disagree.sd['1X2']!.HOME! > agree.sd['1X2']!.HOME!);
  assert.ok(agree.agreement > disagree.agreement);
  const s = agree.probs['1X2']!;
  close(s.HOME! + s.DRAW! + s.AWAY!, 1, 1e-9);
});
