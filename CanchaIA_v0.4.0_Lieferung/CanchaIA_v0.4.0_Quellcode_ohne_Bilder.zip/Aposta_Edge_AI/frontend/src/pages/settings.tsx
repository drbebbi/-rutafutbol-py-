/** Einstellungen: Profil, Sprache/Zeitzone, Benachrichtigungen, Tarif, Sicherheit, Analyse (nur Admin). Endpunkte wie v0.3.0. */
import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { useApp } from '../components';
import { useLoad } from '../hooks';
import { Badge, Banner, Button, Card, Check, ErrorBox, Field, Loading, PageHeader } from '../ui';
import { PersonalAlertsSection, PlanSection } from '../v030';

const TZS = ['America/Asuncion', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'Europe/Zurich', 'Europe/Berlin', 'Europe/Madrid', 'Europe/London', 'America/New_York', 'UTC'];

export function Settings({ onLang, onLogout }: { onLang: (l: 'es' | 'de' | 'en') => void; onLogout: () => void }) {
  const { t, u, role, email, plan, go } = useApp();
  const s = useLoad<any>('/api/settings');
  const [form, setForm] = useState<any>(null), [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (s.data) setForm({ ...s.data }); }, [s.data]);
  const save = async (fields: string[]) => {
    setMsg(null);
    try {
      const body: Record<string, unknown> = {};
      for (const f of fields) body[f] = f.startsWith('notify_') ? !!form[f] : form[f];
      const r = await api<any>('/api/settings', { method: 'PUT', body: JSON.stringify(body) });
      if (fields.includes('language')) onLang(r.language);
      setMsg({ ok: true, text: t.saved });
    } catch (e) { setMsg({ ok: false, text: `${t.error}: ${(e as Error).message}` }); }
  };
  const sections: [string, string][] = [['profile', u.sProfile], ['lang', u.sLang], ['alerts', u.sAlerts], ['plan', u.sPlan], ['security', u.sSecurity], ...(role === 'admin' ? [['analysis', u.sAnalysis] as [string, string]] : [])];
  const jump = (id: string) => document.getElementById(`set-${id}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  return (
    <>
      <PageHeader title={t.settings} actions={role === 'admin' ? <Button variant="secondary" icon="admin" onClick={() => go('/admin')}>{u.openAdmin}</Button> : null} />
      <div className="settings">
        <nav className="toc" aria-label={t.settings}>{sections.map(([id, l]) => <a key={id} href={`#/settings`} onClick={e => { e.preventDefault(); jump(id); }}>{l}</a>)}</nav>
        <div className="stack lg" style={{ maxWidth: 820 }}>
          {msg ? <Banner tone={msg.ok ? 'info' : 'error'}>{msg.text}</Banner> : null}

          <Card id="set-profile" title={u.sProfile} sub={u.sProfileText}>
            <dl className="kv"><dt>{u.email}</dt><dd>{email ?? '–'}</dd><dt>{u.roleK}</dt><dd><Badge tone={role === 'admin' ? 'info' : 'outline'}>{role}</Badge></dd><dt>{u.plan}</dt><dd><Badge tone="outline">{plan ?? 'FREE'}</Badge></dd></dl>
          </Card>

          {s.err ? <ErrorBox e={s.err} onRetry={s.reload} /> : !form ? <Loading /> : <>
            <Card id="set-lang" title={u.sLang}>
              <div className="form-grid two">
                <Field label={t.language}><select id="s-lang" value={form.language} onChange={e => setForm({ ...form, language: e.target.value })}><option value="es">Español (Paraguay)</option><option value="de">Deutsch</option><option value="en">English</option></select></Field>
                <Field label={t.timezone}><select id="s-tz" value={form.timezone} onChange={e => setForm({ ...form, timezone: e.target.value })}>{[...new Set([form.timezone, ...TZS])].map(z => <option key={z}>{z}</option>)}</select></Field>
              </div>
              <div className="row-flex" style={{ marginTop: 14 }}><Button onClick={() => save(['language', 'timezone'])}>{t.save}</Button></div>
            </Card>

            <Card id="set-alerts" title={u.sAlerts}>
              <div className="stack lg">
                <fieldset className="stack"><legend>{u.systemAlerts}</legend>
                  <Check checked={!!form.notify_new_value} onChange={v => setForm({ ...form, notify_new_value: v ? 1 : 0 })} label={t.nNew} />
                  <Check checked={!!form.notify_odds_change} onChange={v => setForm({ ...form, notify_odds_change: v ? 1 : 0 })} label={t.nOdds} />
                  <Check checked={!!form.notify_removed} onChange={v => setForm({ ...form, notify_removed: v ? 1 : 0 })} label={t.nRemoved} />
                  <div><Button variant="secondary" onClick={() => save(['notify_new_value', 'notify_odds_change', 'notify_removed'])}>{t.save}</Button></div>
                </fieldset>
                <div className="divider" />
                <PersonalAlertsSection />
              </div>
            </Card>
          </>}

          <Card id="set-plan" title={u.sPlan}><PlanSection /></Card>

          <Card id="set-security" title={u.sSecurity}>
            <div className="stack">
              <p className="t-2 small">{u.sSecurityText}</p>
              <p className="t-3 small">{u.sessionEnds}</p>
              <div><Button variant="danger" icon="logout" onClick={onLogout}>{t.logout}</Button></div>
            </div>
          </Card>

          {role === 'admin' ? <SystemSettings /> : null}
        </div>
      </div>
    </>
  );
}

function SystemSettings() {
  const { t, u } = useApp();
  const s = useLoad<any>('/api/system-settings'), books = useLoad<any[]>('/api/bookmakers');
  const [form, setForm] = useState<any>(null), [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => { if (s.data) setForm({ ...s.data, min_ev_pct: Math.round(s.data.min_ev * 1000) / 10, mw_pct: s.data.model_weight == null ? '' : Math.round(s.data.model_weight * 100) }); }, [s.data]);
  const save = async () => {
    setMsg(null);
    try {
      await api('/api/system-settings', { method: 'PUT', body: JSON.stringify({ min_ev: Number(form.min_ev_pct) / 100, strategy: form.strategy, model_weight: form.mw_pct === '' || form.mw_pct == null ? null : Number(form.mw_pct) / 100, preferred_bookmakers: form.preferred_bookmakers, max_fixtures_per_run: Number(form.max_fixtures_per_run) }) });
      setMsg({ ok: true, text: t.saved });
    } catch (e) { setMsg({ ok: false, text: `${t.error}: ${(e as Error).message}` }); }
  };
  return (
    <Card id="set-analysis" title={u.sAnalysis} sub={t.systemSettings}>
      {s.err ? <ErrorBox e={s.err} onRetry={s.reload} /> : !form ? <Loading /> : <div className="stack lg">
        <div className="form-grid two">
          <Field label={t.minEv}><input id="s-ev" type="number" min="1" max="50" step="0.5" value={form.min_ev_pct} onChange={e => setForm({ ...form, min_ev_pct: e.target.value })} /></Field>
          <Field label={t.strategy}><select id="s-strat" value={form.strategy} onChange={e => setForm({ ...form, strategy: e.target.value })}>{Object.entries(t.strategies).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>
          <Field label={t.modelWeight} hint={t.weightHint}><input id="s-mw" type="number" min="0" max="100" step="5" value={form.mw_pct} placeholder="auto" onChange={e => setForm({ ...form, mw_pct: e.target.value })} /></Field>
          <Field label="Max. fixtures / run"><input id="s-maxf" type="number" min="1" max="500" value={form.max_fixtures_per_run} onChange={e => setForm({ ...form, max_fixtures_per_run: e.target.value })} /></Field>
        </div>
        <fieldset><legend>{t.prefBooks}</legend>
          <div className="row-flex">{(books.data ?? []).map(b => <label key={b.id} className="chipbtn" aria-pressed={form.preferred_bookmakers.includes(b.id)} style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
            <input type="checkbox" checked={form.preferred_bookmakers.includes(b.id)} onChange={e => setForm({ ...form, preferred_bookmakers: e.target.checked ? [...form.preferred_bookmakers, b.id] : form.preferred_bookmakers.filter((x: string) => x !== b.id) })} /> {b.name}</label>)}</div>
        </fieldset>
        <div className="row-flex"><Button onClick={save}>{t.save}</Button>{msg ? <span className={`small ${msg.ok ? 'pos' : 'neg'}`}>{msg.text}</span> : null}</div>
      </div>}
    </Card>
  );
}
