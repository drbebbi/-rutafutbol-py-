# Zahlungsintegration (v0.3.0)

**Status**
- Manuelle Banküberweisung (SIPAP / Bank-Alias): IMPLEMENTED · TESTED, Prüfablauf im Testmodus
- uPay: nur Schnittstelle + Testmodus. Echte Integration NOT IMPLEMENTED (keine Händlerfreigabe)

Die App löst **keine** Zahlung, keine Belastung und keine wiederkehrende Abbuchung aus. Sie platziert auch weiterhin keine Wetten.

## Ablauf: Überweisung über SIPAP / Bank-Alias

```
Benutzer: Tarif wählen ─► Bestellung (Abo PENDING, Zahlung AWAITING_PAYMENT, Verwendungszweck AEA-XXXXXX)
Benutzer: überweist in seiner Bank-App an den Alias, mit Verwendungszweck
Benutzer: lädt optional einen Beleg hoch ─► Zahlung PROOF_SUBMITTED  (KEINE Freischaltung)
Admin:    prüft den Kontoauszug ─► "Bestätigen" mit Bankreferenz, Betrag, Eingangsdatum, Häkchen
          ─► Zahlung VERIFIED, Abo ACTIVE (Start, Ablauf)   oder   "Ablehnen" mit Begründung
```

Sicherungen (alle mit Tests):

- **Beleg ≠ Zahlung:** Ein Upload ändert nur den Zahlungsstatus. Das Abo bleibt `PENDING`, die Rechte bleiben FREE.
- **Pflichtangaben beim Bestätigen:**
  - Bankreferenz aus dem Kontoauszug
  - erhaltener Betrag, der **exakt** dem erwarteten Betrag entspricht (sonst 400 und Klärung)
  - Eingangsdatum, nicht in der Zukunft
  - ausdrückliches `confirmReceived: true`
- **Bankreferenz:** dieselbe Referenz kann nicht für zwei Zahlungen verwendet werden (409).
- **Mindestregel für zwei Personen:** Ein Admin kann die eigene Zahlung nicht freigeben (403). Bei nur einem Admin muss für dessen eigenes Konto ein zweiter Admin freigeben.
- **Fremde Zahlungen:** Benutzer sehen und bearbeiten nur ihre eigenen Zahlungen. Fremde IDs liefern 404.
- **Beleg-Dateien:**
  - Erlaubt sind nur PDF, PNG und JPEG, höchstens 2 MB, Dateiinhalt passend zum Typ (Magic Bytes).
  - Speicherung in `payment_proofs`, Abruf nur durch Admins. Jeder Abruf landet im Sicherheitsprotokoll.
  - Nach `PAYMENT_PROOF_RETENTION_DAYS` (Standard 180) ab der Entscheidung wird der Inhalt gelöscht. Die SHA-256-Prüfsumme bleibt.

## Bankdaten

- `PAYMENT_BANK_NAME`, `PAYMENT_BANK_ALIAS` und `PAYMENT_ACCOUNT_HOLDER` stehen **nur in der Umgebung** (`.env`).
- Im Code, in Tests und in Beispielen stehen keine echten Bankdaten und keine C.I.-Nummer. Die Tests verwenden „alias-de-prueba“.
- Fehlt der Alias, sehen Benutzer den Hinweis „Überweisungsdaten noch nicht hinterlegt“.

## uPay (vorbereitet)

Schnittstelle `PaymentProvider` in `backend/src/subscriptions.ts`:

```ts
interface PaymentProvider {
  method: 'bank_transfer' | 'upay';
  mode: 'manual' | 'test';
  start(p): { providerRef: string | null; instructions: Record<string, …> }   // keine Belastung
}
```

- `UPAY_MODE=test`:
  - `UpayTestProvider` erzeugt nur eine Test-Referenz `UPAY-TEST-<Verwendungszweck>`.
  - Es gibt keinen Netzwerkzugriff und keine Belastung.
  - Die Freischaltung erfolgt auch hier **nur** durch die manuelle Admin-Prüfung.
- `UPAY_MODE=live` wird ignoriert und als Konfigurationsproblem gemeldet.
- Für eine echte Integration nach Händlerfreigabe fehlen (NOT IMPLEMENTED):
  - Checkout-URL gemäß uPay-Dokumentation
  - signierte Webhooks mit Signaturprüfung und Idempotenz
  - Abgleich von Betrag und Referenz
  - Rückbuchungen und Erstattungen
  - Tests gegen die uPay-Sandbox

  Auch dann sollte ein Webhook nur „Zahlung bestätigt“ melden. Die Freischaltung bleibt an eine serverseitige Prüfung gebunden.

## Vor dem kommerziellen Start zu klären (nicht Teil der Software)

- Steuerliche Pflichten in Paraguay: Rechnungsstellung/Timbrado, RUC, ggf. IVA auf digitale Dienstleistungen
- AGB, Widerruf und Kündigung
- Datenschutzerklärung (Belege können personenbezogene Daten enthalten)
- Rechtliche Einordnung eines Dienstes mit Wettanalysen in den Zielmärkten
- Nutzungsrechte der Datenquellen für ein kostenpflichtiges Produkt (siehe [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md#kommerzieller-start))

Ich bin weder Anwalt noch Steuerberater. Diese Punkte bitte mit einer Fachperson klären.
