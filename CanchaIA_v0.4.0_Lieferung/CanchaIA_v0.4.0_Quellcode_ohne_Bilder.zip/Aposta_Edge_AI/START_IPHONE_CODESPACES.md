# CanchaIA v0.3.4 – Start auf einem iPhone mit GitHub Codespaces

Das ist die **originale CanchaIA-v0.3.4-Anwendung**, ergänzt um ein Startskript. Es wird keine neue App erstellt.

## Was vorab nötig ist

1. Ein **privates** GitHub-Repository erstellen (z. B. `canchaia-test`).
2. Die Datei `CanchaIA_v0.3.4_iPhone_Codespaces_Ready.zip` ins Repository hochladen (als ZIP belassen).
3. Im Repository `Settings > Secrets and variables > Codespaces` drei Secrets hinterlegen:
   - `THE_ODDS_API_KEY`: **erneuerter** API-Schlüssel, nicht den schon im Chat veröffentlichten nutzen.
   - `ADMIN_EMAIL`: E-Mail für dein erstes Admin-Konto.
   - `ADMIN_PASSWORD`: sicheres Passwort mit >=12 Zeichen, Buchstaben und Zahlen.
4. Codespace erstellen: `Code > Codespaces > Create codespace on main` (2-Core-Maschine nur innerhalb des Freikontingents nutzen).
5. Codespaces-Terminal öffnen und ausführen:

```bash
unzip -q CanchaIA_v0.3.4_iPhone_Codespaces_Ready.zip
bash Aposta_Edge_AI/start-codespaces.sh
```

6. Bei Bedarf nach dem Eintragen neuer Codespaces-Secrets den Codespace vollständig neu starten, damit die Env-Variablen übernommen werden.
7. Unter **PORTS** Port 8080 öffnen, **Sichtbarkeit PRIVATE** beibehalten. In der App mit `ADMIN_EMAIL` und `ADMIN_PASSWORD` anmelden.

## Technische Grenzen

- Das Startskript führt **genau einen kostenlosen** authentifizierten GET `/v4/sports` aus.
- **Keine** kostenpflichtigen `/odds`-, `/scores`- oder BTTS-Aufrufe und **kein** Scheduler werden gestartet.
- Der neue Schlüssel wird nie in die Projektdatei geschrieben; er bleibt ein Codespaces-Secret.
- Ohne erfolgreiche API-Antwort sind weder HTTP 200 noch Credits noch Live-Daten nachgewiesen.
- Bei laufendem Codespace kann GitHub Nutzungsgebühren nach Verbrauch des Freikontingents berechnen. Codespace nach Tests stoppen.
- Der Client ist keine dauerhaft bereitgestellte App. SQLite-Datenbank liegt im Codespace unter `Aposta_Edge_AI/data/`.
- The Odds API liefert Quoten, aber keine validierten unabhängigen Champions-League-Wahrscheinlichkeiten.

## Späterer optionaler bezahlter Test

**NICHT Teil des Starts.** Erst nach erfolgreichem kostenlosen Test und Prüfung von echten Restcredits/Budgets: `npm --prefix backend run odds:check -- --paid-test` im Ordner `Aposta_Edge_AI`. Die Anwendung vorher beenden; der Befehl kann kostenpflichtige API-Credits verbrauchen. BTTS bleibt deaktiviert.
