/**
 * The Odds API – Verbindungstest, Verbindungsstatus und Kostenvoranschlag (v0.3.3).
 *
 * Grundsätze:
 *  - Der Verbindungstest nutzt nur den KOSTENLOSEN Endpunkt GET /v4/sports, genau EIN Versuch (keine Wiederholung).
 *  - CONNECTED nur nach erfolgreichem, authentifiziertem Test (HTTP 200 mit echten Sportdaten) und ohne spätere
 *    Zugangs-/Netzwerkfehler. Ohne Test oder ohne Schlüssel: DISCONNECTED. Einschränkungen: DEGRADED.
 *  - Kostenpflichtige Abrufe (odds, event odds, scores) sind gesperrt, solange kein bestandener Test vorliegt
 *    (paidGateReason). So startet keine automatische Abfrage, bevor Zugang und Budgetkontrolle geprüft sind.
 *  - Der Schlüssel erscheint nirgends: weder im Ergebnis noch im Protokoll, in der DB oder in Fehlermeldungen.
 */
import type { App } from '../app.js';
import { effectiveSportKeys } from '../config.js';
import { ApiError } from '../api/apiQueue.js';
import { oddsApiUrl, normalizeOddsApiBase, ODDS_MARKETS, OU_LINE } from '../providers/theOddsApi.js';
import { QuotaExhaustedError } from '../providers/types.js';
import { redact } from '../util/log.js';
import { nowIso } from '../util/core.js';

export const ODDS_PROVIDER = 'theoddsapi';
export const UCL_SPORT_KEY = 'soccer_uefa_champs_league';
/** Ohne bestätigten Abruf innerhalb dieser Zeit gilt die Verbindung nur noch als DEGRADED. */
export const CONFIRM_MAX_AGE_H = 24;

export type OddsApiConnection = 'CONNECTED' | 'DEGRADED' | 'DISCONNECTED';
export type SportKeyStatus = 'ACTIVE' | 'INACTIVE' | 'UNKNOWN_KEY' | 'NOT_CHECKED';

export interface ConnectionTestResult {
  id: number | null; testedAt: string; ok: boolean; httpStatus: number | null; error: string | null;
  sportsTotal: number | null; soccerActive: number | null;
  targetSportKey: string; targetSportStatus: SportKeyStatus;
  sportKeys: { key: string; status: SportKeyStatus }[];
  requestsRemaining: number | null; requestsUsed: number | null; requestsLast: number | null;
  triggeredBy: string; creditsCharged: 0;
}

interface SportRow { key: string; group?: string; title?: string; active: boolean; has_outrights?: boolean }

const keysToCheck = (app: App) => [...new Set([UCL_SPORT_KEY, ...effectiveSportKeys(app.cfg)])];

/**
 * Kostenloser Verbindungstest (GET /v4/sports). Ein Versuch, kein Cache, 0 Credits.
 * Ergebnis wird in provider_connection_tests gespeichert (ohne Schlüssel).
 */
export async function testOddsApiConnection(app: App, opts: { triggeredBy: string; now?: Date } = { triggeredBy: 'unknown' }): Promise<ConnectionTestResult> {
  const testedAt = nowIso(opts.now);
  const res: ConnectionTestResult = {
    id: null, testedAt, ok: false, httpStatus: null, error: null, sportsTotal: null, soccerActive: null,
    targetSportKey: UCL_SPORT_KEY, targetSportStatus: 'NOT_CHECKED', sportKeys: keysToCheck(app).map(key => ({ key, status: 'NOT_CHECKED' as SportKeyStatus })),
    requestsRemaining: null, requestsUsed: null, requestsLast: null, triggeredBy: opts.triggeredBy, creditsCharged: 0,
  };
  const key = app.cfg.theOddsApi.apiKey;
  if (app.cfg.dataMode === 'mock') res.error = 'DATA_MODE=mock: The Odds API wird im Mock-Modus nicht verwendet. Kein Abruf.';
  else if (!key) res.error = 'Secret fehlt in dieser Umgebung (THE_ODDS_API_KEY). Kein Abruf.';
  else {
    try {
      const r = await app.queue.requestMeta<SportRow[]>({
        provider: ODDS_PROVIDER, url: oddsApiUrl(app.cfg.theOddsApi.baseUrl, key, '/v4/sports', {}),
        ttlSeconds: 0, cost: 0, priority: 9, noRetry: true, note: 'Verbindungstest /v4/sports (kostenlos)',
      });
      res.httpStatus = r.status ?? 200;
      res.requestsRemaining = r.quota?.remaining ?? null; res.requestsUsed = r.quota?.used ?? null; res.requestsLast = r.quota?.last ?? null;
      const list = Array.isArray(r.data) ? r.data.filter(s => s && typeof s.key === 'string') : [];
      res.sportsTotal = list.length;
      res.soccerActive = list.filter(s => s.key.startsWith('soccer_') && s.active).length;
      const by = new Map(list.map(s => [s.key, s]));
      const st = (k: string): SportKeyStatus => !by.has(k) ? 'UNKNOWN_KEY' : by.get(k)!.active ? 'ACTIVE' : 'INACTIVE';
      res.sportKeys = res.sportKeys.map(x => ({ key: x.key, status: st(x.key) }));
      res.targetSportStatus = st(UCL_SPORT_KEY);
      if (!list.length) res.error = 'Antwort ohne Sportdaten (unerwartetes Format): nicht als verbunden gewertet.';
      else res.ok = true;
    } catch (e) {
      if (e instanceof ApiError) {
        res.httpStatus = e.status || null;
        res.error = e.status === 401 ? 'Authentifizierung fehlgeschlagen (HTTP 401): Schlüssel ungültig, abgelaufen oder falsch eingetragen.'
          : e.status === 429 ? 'Rate-Limit (HTTP 429): Test nicht wiederholt.'
          : e.status === 0 ? `Keine Verbindung zum Anbieter: ${redact(e.message)}`
          : `HTTP ${e.status}: ${redact(e.message)}`;
      } else if (e instanceof QuotaExhaustedError) res.error = `Gesperrt: ${redact(e.message)}`;
      else res.error = `Fehler: ${redact((e as Error).message)}`;
    }
  }
  if (res.error) res.error = redact(res.error).slice(0, 400);
  res.id = Number(app.db.run(`INSERT INTO provider_connection_tests (provider, tested_at, ok, http_status, error, sports_total, soccer_active, target_sport_key, target_sport_status, sport_keys_status, requests_remaining, requests_used, requests_last, triggered_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, ODDS_PROVIDER, testedAt, res.ok ? 1 : 0, res.httpStatus, res.error, res.sportsTotal, res.soccerActive, res.targetSportKey, res.targetSportStatus,
    JSON.stringify(res.sportKeys), res.requestsRemaining, res.requestsUsed, res.requestsLast, opts.triggeredBy).lastInsertRowid);
  if (res.ok) app.queue.setHealth(ODDS_PROVIDER, 'ok', null);
  else if (res.httpStatus === 401 || res.httpStatus === 403) app.queue.setHealth(ODDS_PROVIDER, 'blocked', res.error);
  return res;
}

interface TestRow { id: number; tested_at: string; ok: number; http_status: number | null; error: string | null; sports_total: number | null; soccer_active: number | null; target_sport_key: string; target_sport_status: SportKeyStatus; sport_keys_status: string | null; requests_remaining: number | null; requests_used: number | null; requests_last: number | null; triggered_by: string | null }

function rowToResult(r: TestRow | undefined): ConnectionTestResult | null {
  if (!r) return null;
  let keys: { key: string; status: SportKeyStatus }[] = [];
  try { keys = JSON.parse(r.sport_keys_status ?? '[]'); } catch { /* alt/leer */ }
  return { id: r.id, testedAt: r.tested_at, ok: !!r.ok, httpStatus: r.http_status, error: r.error, sportsTotal: r.sports_total, soccerActive: r.soccer_active,
    targetSportKey: r.target_sport_key, targetSportStatus: r.target_sport_status, sportKeys: keys, requestsRemaining: r.requests_remaining, requestsUsed: r.requests_used,
    requestsLast: r.requests_last, triggeredBy: r.triggered_by ?? 'unknown', creditsCharged: 0 };
}

export function lastConnectionTest(app: App, onlyOk = false): ConnectionTestResult | null {
  return rowToResult(app.db.get<TestRow>(`SELECT * FROM provider_connection_tests WHERE provider = ? ${onlyOk ? 'AND ok = 1' : ''} ORDER BY id DESC LIMIT 1`, ODDS_PROVIDER));
}

/**
 * Zugangssperre über die monotonen Request-IDs statt volatilem Provider-Health-Status.
 * Ein nachfolgender kostenloser /events-Erfolg darf einen HTTP-401/403-Abruf NICHT freigeben.
 * Freigabe erst durch einen NEUEN erfolgreichen expliziten /sports-Verbindungstest.
 */
export function accessDeniedAfterVerifiedTest(app: App): boolean {
  const t = app.db.get<{ id: number }>(`SELECT id FROM api_requests
    WHERE provider = ? AND endpoint = '/v4/sports' AND status = 200
      AND note LIKE 'Verbindungstest /v4/sports%'
    ORDER BY id DESC LIMIT 1`, ODDS_PROVIDER);
  if (!t) return false;
  return !!app.db.get<{ id: number }>(`SELECT id FROM api_requests
    WHERE provider = ? AND id > ? AND from_cache = 0 AND status IN (401,403)
    LIMIT 1`, ODDS_PROVIDER, t.id);
}

/**
 * Sperrgrund für kostenpflichtige Abrufe oder null (frei).
 * Frei nur, wenn der letzte Test bestanden ist und danach kein Zugangsfehler (401/403) auftrat.
 */
export function paidGateReason(app: App): string | null {
  const last = lastConnectionTest(app);
  if (!last) return 'Kostenpflichtige Abrufe gesperrt: zuerst den kostenlosen Verbindungstest ausführen (Admin → The Odds API oder npm run odds:check).';
  if (!last.ok) return `Kostenpflichtige Abrufe gesperrt: letzter Verbindungstest fehlgeschlagen (${last.error ?? 'unbekannt'}).`;
  const h = app.db.get<{ status: string; last_error_at: string | null }>('SELECT status, last_error_at FROM provider_health WHERE provider = ?', ODDS_PROVIDER);
  if (accessDeniedAfterVerifiedTest(app)) return 'Kostenpflichtige Abrufe gesperrt: Zugang nach dem letzten Test verweigert (401/403). Neuen Verbindungstest ausführen.';
  if (h && h.status === 'blocked' && h.last_error_at && h.last_error_at > last.testedAt) return 'Kostenpflichtige Abrufe gesperrt: Provider meldet gesperrten Zugang. Neuen Verbindungstest ausführen.';
  return null;
}

/** Credits eines Laufs schätzen: Märkte × Regionen je Wettbewerb (+ BTTS je Spiel, + Ergebnisse). */
export function estimateRunCost(app: App): { credits: number | null; detail: string } {
  const c = app.cfg.theOddsApi, keys = effectiveSportKeys(app.cfg);
  const regions = Math.max(1, c.regions.split(',').filter(Boolean).length);
  const markets = ODDS_MARKETS.split(',').length;
  if (!keys.length) return { credits: null, detail: 'THE_ODDS_API_SPORT_KEYS leer: alle aktiven Fußball-Wettbewerbe würden abgefragt (Kosten unbekannt, je Wettbewerb ' + markets * regions + ' Credits).' };
  const odds = keys.length * markets * regions;
  const btts = c.includeBtts ? c.bttsMaxEventsPerRun * regions : 0;
  // v0.4.0: Ergebnisse gebündelt – 2 Credits je Wettbewerb mit offenen Spielen der letzten 3 Tage
  const staleSports = app.db.get<{ n: number }>(`SELECT COUNT(DISTINCT ca.provider_id) AS n FROM events e JOIN event_mappings m ON m.event_id = e.id AND m.provider = ?
      JOIN competition_aliases ca ON ca.competition_id = e.competition_id AND ca.provider = ?
      WHERE e.status IN ('scheduled','live','unknown') AND e.kickoff_utc < ? AND e.kickoff_utc > ?`, ODDS_PROVIDER, ODDS_PROVIDER, new Date(Date.now() - 2 * 3_600_000).toISOString(), new Date(Date.now() - 3 * 86_400_000).toISOString())!.n;
  const scores = c.resultsEnabled ? Math.min(keys.length, staleSports) * 2 : 0;
  return { credits: odds + btts + scores, detail: `${keys.length} Wettbewerb(e) × ${markets} Märkte (${ODDS_MARKETS}) × ${regions} Region(en) = ${odds}` + (btts ? ` + BTTS bis ${btts}` : '') + (scores ? ` + Ergebnisse ${scores}` : '') };
}

/** Kostenvoranschlag gegen internes Tages-/Monatsbudget und vom Anbieter gemeldete Restcredits. null = ok. */
export function budgetBlockReason(app: App): string | null {
  const est = estimateRunCost(app);
  if (est.credits == null) return est.detail;
  const b = app.queue.budgetStatus(ODDS_PROVIDER);
  if (b.paused) return `Anbieter gesperrt bis ${b.pausedUntil} (${b.pauseReason ?? 'Kontingent'}).`;
  if (b.remainingBudget < est.credits) return `Tagesbudget reicht nicht: geschätzt ${est.credits} Credits, frei ${b.remainingBudget} von ${b.budget}.`;
  if (b.monthlyBudget != null && b.monthlyBudget - b.usedMonth < est.credits) return `Monatsbudget reicht nicht: geschätzt ${est.credits} Credits, frei ${b.monthlyBudget - b.usedMonth} von ${b.monthlyBudget}.`;
  const prov = app.queue.providerReportedRemaining(ODDS_PROVIDER);
  if (prov != null && prov < est.credits) return `Laut Anbieter nur ${prov} Credits übrig, geschätzt ${est.credits}.`;
  return null;
}

export interface OddsApiStatusReport {
  provider: 'THE ODDS API'; connection: OddsApiConnection; reasons: string[]; mode: 'LIVE' | 'MOCK';
  configured: boolean; baseUrl: string; regions: string[]; sportKeys: string[]; markets: { odds: string; ouLine: number; btts: boolean; bttsMaxEventsPerRun: number };
  requireConnectionTest: boolean; paidAllowed: boolean; paidBlockedReason: string | null;
  lastTest: ConnectionTestResult | null; lastSuccessfulTest: ConnectionTestResult | null;
  lastSuccessfulFetchAt: string | null; lastRequestAt: string | null;
  credits: {
    providerRemaining: number | null; providerUsed: number | null; providerLast: number | null; providerReportedAt: string | null;
    dailyUsed: number; dailyBudget: number; monthlyUsed: number; monthlyBudget: number | null; paused: boolean; pausedUntil: string | null; pauseReason: string | null;
    nextRunEstimate: number | null; nextRunEstimateDetail: string;
  };
  errors: { at: string; endpoint: string; status: number; note: string | null }[];
  lastError: { at: string | null; message: string | null };
  data: { events: number; upcomingEvents: number; bookmakers: number; markets: string[]; validSnapshots: number; newestRetrievedAt: string | null; ageMinutes: number | null };
  /**
   * v0.4.0: Was ist tatsächlich belegt? Getrennt nach Verbindung (kostenlos), Spielsuche (kostenlos), Quoten (kostenpflichtig)
   * und Prognosen auf Basis echter Quoten. Ein bestandener Verbindungstest belegt NICHT, dass Quoten oder Prognosen funktionieren.
   */
  verification: {
    connection: { verified: boolean; at: string | null; note: string };
    discovery: { verified: boolean; at: string | null; httpStatus: number | null; note: string };
    odds: { verified: boolean; at: string | null; httpStatus: number | null; note: string };
    predictions: { verified: boolean; count: number; at: string | null; note: string };
  };
  /** Letzter echter (nicht gecachter) Abruf: Endpunkt und HTTP-Status */
  lastHttp: { at: string; endpoint: string; status: number; costCredits: number } | null;
  /** Nächste geplante Läufe laut Scheduler (null = Scheduler aus) */
  schedule: { discovery: { intervalMin: number; nextDue: string | null; lastSuccess: string | null } | null; odds: { intervalMin: number; nextDue: string | null; lastSuccess: string | null } | null } | null;
}

type SchedStatus = { name: string; intervalMin: number; nextDue: string; lastSuccess: string | null }[];

/** Status für Admin und Diagnose. Ausschließlich aus Konfiguration und Datenbank, nichts erfunden. */
export function oddsApiStatus(app: App, now: Date = new Date(), sched?: SchedStatus): OddsApiStatusReport {
  const cfg = app.cfg, db = app.db;
  const isMock = cfg.dataMode === 'mock' || app.providers.isMock;
  const last = lastConnectionTest(app), lastOk = lastConnectionTest(app, true);
  const b = app.queue.budgetStatus(ODDS_PROVIDER);
  const h = db.get<{ status: string; last_error_at: string | null; last_error: string | null; updated_at: string | null }>('SELECT status, last_error_at, last_error, updated_at FROM provider_health WHERE provider = ?', ODDS_PROVIDER);
  const paidRe = "(endpoint LIKE '%/odds' OR endpoint LIKE '%/scores')";
  const lastFetch = db.get<{ t: string | null }>(`SELECT MAX(created_at) AS t FROM api_requests WHERE provider = ? AND from_cache = 0 AND status BETWEEN 200 AND 299 AND ${paidRe}`, ODDS_PROVIDER)!.t;
  const lastReq = db.get<{ t: string | null }>('SELECT MAX(created_at) AS t FROM api_requests WHERE provider = ? AND from_cache = 0', ODDS_PROVIDER)!.t;
  const lastAnyOk = db.get<{ t: string | null }>('SELECT MAX(created_at) AS t FROM api_requests WHERE provider = ? AND from_cache = 0 AND status BETWEEN 200 AND 299', ODDS_PROVIDER)!.t;
  const errors = db.all<{ created_at: string; endpoint: string; status: number; note: string | null }>(
    'SELECT created_at, endpoint, status, note FROM api_requests WHERE provider = ? AND from_cache = 0 AND (status < 200 OR status > 299) ORDER BY id DESC LIMIT 10', ODDS_PROVIDER)
    .map(r => ({ at: r.created_at, endpoint: r.endpoint, status: r.status, note: r.note }));
  const lastPaidErr = errors.find(e => /\/(odds|scores)$/.test(e.endpoint));

  // Echte Daten: nur über The-Odds-API-Zuordnung und nie Mock
  const ev = db.get<{ n: number; up: number }>(`SELECT COUNT(DISTINCT e.id) AS n, COUNT(DISTINCT CASE WHEN e.kickoff_utc > ? AND e.status = 'scheduled' THEN e.id END) AS up
      FROM events e JOIN event_mappings m ON m.event_id = e.id AND m.provider = ? WHERE e.is_mock = 0`, now.toISOString(), ODDS_PROVIDER)!;
  const snap = db.get<{ books: number; n: number; newest: string | null }>(`SELECT COUNT(DISTINCT s.bookmaker_id) AS books, COUNT(*) AS n, MAX(s.retrieved_at) AS newest
      FROM odds_snapshots s JOIN events e ON e.id = s.event_id WHERE s.provider = ? AND e.is_mock = 0 AND s.snapshot_kind = 'live' AND s.validation_errors = '[]'`, ODDS_PROVIDER)!;
  const markets = db.all<{ m: string }>(`SELECT DISTINCT s.market_id AS m FROM odds_snapshots s JOIN events e ON e.id = s.event_id
      WHERE s.provider = ? AND e.is_mock = 0 AND s.snapshot_kind = 'live' AND s.validation_errors = '[]' AND (s.market_id != 'OU' OR s.line = ?) ORDER BY s.market_id`, ODDS_PROVIDER, OU_LINE).map(r => r.m);

  const reasons: string[] = [];
  let connection = 'CONNECTED' as OddsApiConnection;
  const down = (r: string) => { connection = 'DISCONNECTED'; reasons.push(r); };
  const degrade = (r: string) => { if (connection === 'CONNECTED') connection = 'DEGRADED'; reasons.push(r); };
  if (isMock) down('MOCK-Modus (DATA_MODE=mock): The Odds API wird nicht verwendet, alle Daten sind fiktiv.');
  else if (!cfg.theOddsApi.apiKey) down('Secret fehlt in dieser Umgebung (THE_ODDS_API_KEY).');
  else if (!last) down('Noch kein Verbindungstest ausgeführt.');
  else if (!last.ok) down(`Letzter Verbindungstest fehlgeschlagen: ${last.error ?? 'unbekannt'}`);
  else if (accessDeniedAfterVerifiedTest(app)) down('Nach dem letzten erfolgreichen Test hat der Anbieter den Zugriff verweigert (401/403).');
  else if (h && (h.status === 'blocked' || h.status === 'down') && h.last_error_at && h.last_error_at > last.testedAt) down(`Nach dem Test: ${h.last_error ?? h.status}`);
  if (connection !== 'DISCONNECTED') {
    if (b.paused) degrade(`Gesperrt bis ${b.pausedUntil} (${b.pauseReason ?? 'Kontingent'}).`);
    if (b.remainingBudget <= 0) degrade(`Internes Tagesbudget aufgebraucht (${b.used}/${b.budget} Credits).`);
    if (b.monthlyBudget != null && b.usedMonth >= b.monthlyBudget) degrade(`Internes Monatsbudget aufgebraucht (${b.usedMonth}/${b.monthlyBudget} Credits).`);
    const prov = app.queue.providerReportedRemaining(ODDS_PROVIDER);
    if (prov != null && prov <= 0) degrade('Laut Anbieter keine Credits mehr übrig.');
    if (last!.targetSportStatus !== 'ACTIVE') degrade(`${UCL_SPORT_KEY}: ${last!.targetSportStatus} (laut /v4/sports).`);
    for (const k of last!.sportKeys) if (k.key !== UCL_SPORT_KEY && k.status !== 'ACTIVE') degrade(`Konfigurierter Sport-Key ${k.key}: ${k.status}.`);
    if (lastPaidErr && lastPaidErr.at > last!.testedAt) degrade(`Letzter Quotenabruf fehlerhaft: HTTP ${lastPaidErr.status} (${lastPaidErr.endpoint}).`);
    if (lastAnyOk && Date.parse(lastAnyOk) < now.getTime() - CONFIRM_MAX_AGE_H * 3_600_000) degrade(`Seit über ${CONFIRM_MAX_AGE_H} h kein erfolgreicher Abruf: Verbindungstest wiederholen.`);
  }
  // v0.4.0: Belege getrennt ausweisen
  const lastOkOf = (re: string) => db.get<{ created_at: string; status: number } | undefined>(`SELECT created_at, status FROM api_requests WHERE provider = ? AND from_cache = 0 AND status BETWEEN 200 AND 299 AND ${re} ORDER BY id DESC LIMIT 1`, ODDS_PROVIDER) ?? null;
  const disc = lastOkOf("endpoint LIKE '/v4/sports/%/events'");
  const oddsOk = lastOkOf("endpoint LIKE '/v4/sports/%/odds' AND endpoint NOT LIKE '%/events/%'");
  const pred = db.get<{ n: number; t: string | null }>(`SELECT COUNT(DISTINCT p.id) AS n, MAX(p.created_at) AS t FROM predictions p JOIN events e ON e.id = p.event_id AND e.is_mock = 0
      JOIN event_mappings m ON m.event_id = e.id AND m.provider = ? WHERE EXISTS (SELECT 1 FROM value_signals v JOIN odds_snapshots s ON s.id = v.best_snapshot_id
        WHERE v.prediction_id = p.id AND s.provider = ? AND s.snapshot_kind = 'live')`, ODDS_PROVIDER, ODDS_PROVIDER)!;
  const lastHttpRow = db.get<{ created_at: string; endpoint: string; status: number; cost: number }>('SELECT created_at, endpoint, status, cost FROM api_requests WHERE provider = ? AND from_cache = 0 ORDER BY id DESC LIMIT 1', ODDS_PROVIDER);
  const oddsVerified = !isMock && !!oddsOk && snap.n > 0;
  const verification: OddsApiStatusReport['verification'] = {
    connection: { verified: !isMock && !!lastOk, at: lastOk?.testedAt ?? null, note: 'Kostenloser Test GET /v4/sports: belegt nur Erreichbarkeit und gültigen Schlüssel – KEINE Quoten, KEINE Prognosen.' },
    discovery: { verified: !isMock && !!disc, at: disc?.created_at ?? null, httpStatus: disc?.status ?? null, note: 'Kostenlose Spielsuche GET /v4/sports/{sport}/events: belegt Spielplan, keine Quoten.' },
    odds: { verified: oddsVerified, at: oddsOk?.created_at ?? null, httpStatus: oddsOk?.status ?? null,
      note: oddsVerified ? `Kostenpflichtiger Quotenabruf erfolgreich; ${snap.n} gültige Live-Snapshots gespeichert.` : 'Noch kein erfolgreicher kostenpflichtiger Quotenabruf mit gültigen Quoten (NOT VERIFIED).' },
    predictions: { verified: !isMock && pred.n > 0, count: pred.n, at: pred.t,
      note: pred.n > 0 ? 'Prognosen mit Value-Bewertung auf Basis echter The-Odds-API-Quoten vorhanden (ohne Validierungsnachweis des Modells).' : 'Keine Prognose auf Basis echter Quoten (NOT VERIFIED). Ohne Historie (CSV-Import) ist keine Prognose möglich.' },
  };
  const js = (n: string) => { const j = sched?.find(x => x.name === n); return j ? { intervalMin: j.intervalMin, nextDue: j.nextDue === 'sofort' ? nowIso(now) : j.nextDue, lastSuccess: j.lastSuccess } : null; };
  const paidReason = app.requireOddsConnectionTest ? paidGateReason(app) : null;
  const est = estimateRunCost(app);
  return {
    provider: 'THE ODDS API', connection, reasons, mode: isMock ? 'MOCK' : 'LIVE',
    configured: !!cfg.theOddsApi.apiKey, baseUrl: normalizeOddsApiBase(cfg.theOddsApi.baseUrl) + '/v4',
    regions: cfg.theOddsApi.regions.split(',').map(s => s.trim()).filter(Boolean), sportKeys: effectiveSportKeys(cfg),
    markets: { odds: ODDS_MARKETS, ouLine: OU_LINE, btts: cfg.theOddsApi.includeBtts, bttsMaxEventsPerRun: cfg.theOddsApi.bttsMaxEventsPerRun },
    requireConnectionTest: app.requireOddsConnectionTest, paidAllowed: !isMock && !!cfg.theOddsApi.apiKey && !paidReason, paidBlockedReason: isMock ? 'MOCK-Modus' : !cfg.theOddsApi.apiKey ? 'kein Schlüssel' : paidReason,
    lastTest: last, lastSuccessfulTest: lastOk, lastSuccessfulFetchAt: lastFetch, lastRequestAt: lastReq,
    credits: {
      providerRemaining: b.providerRemaining, providerUsed: b.providerUsed, providerLast: b.lastCost, providerReportedAt: b.providerRemaining != null ? lastReq : null,
      dailyUsed: b.used, dailyBudget: b.budget, monthlyUsed: b.usedMonth, monthlyBudget: b.monthlyBudget, paused: b.paused, pausedUntil: b.pausedUntil, pauseReason: b.pauseReason,
      nextRunEstimate: est.credits, nextRunEstimateDetail: est.detail,
    },
    errors, lastError: { at: h?.last_error_at ?? null, message: h?.last_error ?? null },
    data: { events: ev.n, upcomingEvents: ev.up, bookmakers: snap.books, markets, validSnapshots: snap.n, newestRetrievedAt: snap.newest, ageMinutes: snap.newest ? Math.round((now.getTime() - Date.parse(snap.newest)) / 60_000) : null },
    verification, lastHttp: lastHttpRow ? { at: lastHttpRow.created_at, endpoint: lastHttpRow.endpoint, status: lastHttpRow.status, costCredits: lastHttpRow.cost } : null,
    schedule: sched ? { discovery: js('discovery'), odds: js('hourly_sync') } : null,
  };
}
