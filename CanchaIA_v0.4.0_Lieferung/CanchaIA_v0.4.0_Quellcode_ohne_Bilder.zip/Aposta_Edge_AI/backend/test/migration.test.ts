import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { Db, migrate } from '../src/db/db.js';

const dir = path.resolve('src/db/migrations');

test('Upgrade v0.1.0 → v0.2.0: Daten bleiben erhalten, CSV-Kurse werden als Schlusskurse klassifiziert, Trigger aktiv, idempotent', () => {
  const db = new Db(':memory:');
  db.exec('CREATE TABLE schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  for (const f of ['001_init.sql', '002_decision_prob.sql']) { db.exec(fs.readFileSync(path.join(dir, f), 'utf8')); db.run('INSERT INTO schema_migrations VALUES (?, ?)', f, 'x'); }
  // Stand v0.1.0: ein Event mit einem CSV-Snapshot und alten Einstellungen
  db.run("INSERT INTO competitions (id, name) VALUES (1, 'L')");
  db.run("INSERT INTO teams (id, name, norm_name) VALUES (1, 'A', 'a'), (2, 'B', 'b')");
  db.run("INSERT INTO events (id, competition_id, home_team_id, away_team_id, kickoff_utc, status) VALUES (1, 1, 1, 2, '2024-08-16T19:00:00Z', 'finished')");
  db.run("INSERT INTO bookmakers (id, name) VALUES ('pinnacle', 'Pinnacle')");
  db.run("INSERT INTO odds_snapshots (id, event_id, provider, bookmaker_id, market_id, retrieved_at, is_complete) VALUES ('s1', 1, 'football-data-csv', 'pinnacle', '1X2', '2024-08-16T18:59:00Z', 1)");
  db.run("UPDATE user_settings SET min_ev = 0.07, strategy = 'CONSERVATIVE' WHERE user_id = 1");
  const applied = migrate(db);
  // v0.3.0: weitere Migrationen folgen; 003 muss als erste der neuen laufen
  assert.equal(applied[0], '003_v020_lifecycle_security.sql');
  assert.ok(applied.every(f => f > '002'), 'nur neue Migrationen');
  assert.equal(db.get<{ k: string }>("SELECT snapshot_kind AS k FROM odds_snapshots WHERE id = 's1'")!.k, 'closing');
  const sys = db.get<{ min_ev: number; strategy: string }>('SELECT min_ev, strategy FROM system_settings WHERE id = 1')!;
  assert.equal(sys.min_ev, 0.07); assert.equal(sys.strategy, 'CONSERVATIVE');
  assert.throws(() => db.run("UPDATE odds_snapshots SET market_status = 'x'"), /unveraenderlich/);
  assert.equal(db.get<{ role: string }>('SELECT role FROM users WHERE id = 1')!.role, 'system', 'Platzhalter ohne Login');
  assert.deepEqual(migrate(db), [], 'zweiter Lauf ändert nichts');
});

test('Upgrade v0.2.0 → v0.3.0: 004–006 ergänzend, alte Meldungen und Lesestatus erhalten, idempotent', () => {
  const db = new Db(':memory:');
  db.exec('CREATE TABLE schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  for (const f of ['001_init.sql', '002_decision_prob.sql', '003_v020_lifecycle_security.sql']) { db.exec(fs.readFileSync(path.join(dir, f), 'utf8')); db.run('INSERT INTO schema_migrations VALUES (?, ?)', f, 'x'); }
  // Stand v0.2.0: Benutzer, Einstellungen, Systemmeldungen (eine gelesen), Abrufprotokoll, Modellversion
  db.run("INSERT INTO users (id, name, email, password_hash, role, active) VALUES (2, 'a', 'a@example.test', 'x', 'admin', 1), (3, 'b', 'b@example.test', 'x', 'user', 1)");
  db.run('INSERT OR IGNORE INTO user_settings (user_id, notify_new_value) VALUES (2, 0), (3, 1)');
  db.run("INSERT INTO alerts_sent (id, dedupe_key, kind, title, body, channels, created_at, read_at) VALUES (1, 'k1', 'new_value', 't', 'b', '[]', '2026-10-01T00:00:00Z', '2026-10-01T01:00:00Z'), (2, 'k2', 'removed', 't', 'b', '[]', '2026-10-02T00:00:00Z', NULL)");
  db.run("INSERT INTO api_requests (provider, day, month, endpoint, status, duration_ms, from_cache, cost, created_at) VALUES ('theoddsapi', '2026-10-01', '2026-10', '/v4/sports/soccer_epl/odds', 200, 10, 0, 4, '2026-10-01T00:00:00Z')");
  db.run("INSERT INTO model_versions (id, description, weights, validation_status) VALUES ('ensemble-1.1.0+bt1', 'x', '{}', 'UNVALIDATED')");
  const applied = migrate(db);
  // v0.3.3: weitere Migrationen (007 …) folgen; 004–006 müssen in dieser Reihenfolge als erste laufen
  assert.deepEqual(applied.slice(0, 3), ['004_v030_api_log_pilot.sql', '005_v030_subscriptions.sql', '006_v030_user_alerts.sql']);
  assert.ok(applied.slice(3).every(f => f > '006'), 'nur spätere Migrationen danach');
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM alerts_sent')!.n, 2, 'alte Meldungen erhalten');
  assert.equal(db.get<{ r: string }>('SELECT read_at AS r FROM alerts_sent WHERE id = 1')!.r, '2026-10-01T01:00:00Z', 'alter Wert unverändert');
  assert.deepEqual(db.all<{ user_id: number }>('SELECT user_id FROM alert_reads WHERE alert_id = 1 ORDER BY user_id').map(r => r.user_id), [2, 3], 'bisheriger Lesestatus für alle Konten übernommen');
  assert.equal(db.get('SELECT 1 FROM alert_reads WHERE alert_id = 2'), undefined);
  const s = db.get<{ notify_new_value: number; personal_alerts_enabled: number; alert_min_ev: number | null }>('SELECT notify_new_value, personal_alerts_enabled, alert_min_ev FROM user_settings WHERE user_id = 2')!;
  assert.equal(s.notify_new_value, 0, 'Einstellungen erhalten'); assert.equal(s.personal_alerts_enabled, 0, 'persönliche Meldungen standardmäßig aus'); assert.equal(s.alert_min_ev, null);
  assert.equal(db.get<{ c: number }>('SELECT cost AS c FROM api_requests')!.c, 4);
  assert.deepEqual(db.all<{ id: string }>('SELECT id FROM plans ORDER BY price_monthly_pyg').map(p => p.id), ['FREE', 'PRO', 'PREMIUM']);
  assert.equal(db.get<{ role: string }>('SELECT role FROM users WHERE id = 3')!.role, 'user', 'Rollen unverändert');
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM subscriptions')!.n, 0, 'niemand bekommt automatisch einen Tarif');
  assert.throws(() => db.run("UPDATE model_versions SET validation_status = 'VALIDATED'"), /unveraenderlich/);
  assert.deepEqual(migrate(db), [], 'zweiter Lauf ändert nichts');
});
