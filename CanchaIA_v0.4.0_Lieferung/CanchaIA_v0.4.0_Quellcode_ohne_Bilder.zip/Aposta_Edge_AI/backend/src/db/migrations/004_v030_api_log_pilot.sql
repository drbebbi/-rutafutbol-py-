-- v0.3.0 (1/3): Abrufprotokoll und Pilotbetrieb. Nur ergänzend, keine Daten werden gelöscht oder überschrieben.

-- Jeder API-Abruf: bereinigte Parameter (ohne Schlüssel) und Zweck
ALTER TABLE api_requests ADD COLUMN query TEXT;
ALTER TABLE api_requests ADD COLUMN note TEXT;
CREATE INDEX IF NOT EXISTS idx_api_requests_time ON api_requests(created_at);

-- Kontrollierte Diagnose-Läufe (Admin): Bericht bleibt nachvollziehbar gespeichert
CREATE TABLE IF NOT EXISTS diagnostic_runs (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,                 -- controlled_sync | data_quality | validation
  started_at TEXT NOT NULL,
  finished_at TEXT,
  started_by INTEGER,                 -- users.id (NULL = CLI/Service)
  status TEXT NOT NULL DEFAULT 'running',
  report TEXT                         -- JSON
);
CREATE INDEX IF NOT EXISTS idx_diag_kind ON diagnostic_runs(kind, started_at);

-- Unveränderliche Modellversionen: einmal gespeicherte Gewichte und Validierungsstatus lassen sich nicht nachträglich ändern.
-- (Ein neuer Backtest erzeugt immer eine neue Version mit eigener ID.)
CREATE TRIGGER IF NOT EXISTS model_versions_immutable BEFORE UPDATE ON model_versions
BEGIN SELECT RAISE(ABORT, 'model_versions sind unveraenderlich'); END;
CREATE TRIGGER IF NOT EXISTS model_versions_no_delete BEFORE DELETE ON model_versions
BEGIN SELECT RAISE(ABORT, 'model_versions sind unveraenderlich'); END;
