/**
 * HTTP-API (node:http, keine Framework-Abhängigkeit) + Auslieferung des Frontends.
 *
 * Sicherheit (v0.2.0)
 * - Benutzer-Login mit Session-Cookie (HttpOnly, SameSite=Strict, Secure) statt gemeinsamem Token im Browser
 * - Rollen je Endpunkt: public | user | admin; optionales Service-Token (Bearer) mit Admin-Rechten für Server-zu-Server
 * - CSRF: x-csrf-token Pflicht bei schreibenden Anfragen mit Cookie-Auth; Origin-Prüfung (kein CORS, nur gleiche Herkunft)
 * - Rate-Limits (allgemein, Login, Analyst, Jobs), Eingabevalidierung, Größenlimits, Sicherheits-Header
 * - X-Forwarded-For nur mit TRUST_PROXY=true
 * - Keine API-Schlüssel in Antworten; Live-Modus zeigt nie Mock-Daten
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import type { App } from './app.js';
import type { Scheduler } from './scheduler.js';
import { configIssues, providerStates } from './config.js';
import { controlledSync } from './engines/diagnostic.js';
import { oddsApiStatus, testOddsApiConnection } from './engines/oddsApiStatus.js';
import { historicalDataQuality } from './engines/dataQuality.js';
import { runValidation } from './engines/validation.js';
import { validationSettings } from './scheduler.js';
import { competitionCoverage } from './engines/coverage.js';
import { SubscriptionService } from './subscriptions.js';
import { json } from './db/db.js';
import { EdgeAnalyst } from './engines/analyst.js';
import { PerformanceRepository } from './engines/performance.js';
import { BacktestingEngine } from './engines/backtest.js';
import { OddsStore } from './engines/odds.js';
import { Repository } from './engines/repository.js';
import { RecommendationEngine } from './engines/recommendation.js';
import { checkFreshness } from './engines/freshness.js';
import { importFootballDataCsv } from './providers/footballDataCsv.js';
import { teamForm } from './engines/prediction/history.js';
import { AppError, nowIso, addHours } from './util/core.js';
import { logError } from './util/log.js';
import { AuthService, parseCookies, sessionCookie, SESSION_COOKIE, SESSION_ABSOLUTE_H, type Principal, type Role } from './auth.js';
import type { MarketId } from './providers/types.js';

type Access = 'public' | 'user' | 'admin';
interface Ctx { req: http.IncomingMessage; res: http.ServerResponse; url: URL; params: Record<string, string>; body: any; ip: string; me: Principal | null; now: Date }
type Handler = (ctx: Ctx) => Promise<unknown> | unknown;

const MIME: Record<string, string> = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2' };

/** Host aus dem Origin-Header; "null" oder unlesbar → null (wird als fremde Herkunft abgelehnt). */
function originHost(o: string): string | null { try { return new URL(o).host || null; } catch { return null; } }

class RateLimiter {
  private buckets = new Map<string, { tokens: number; at: number }>();
  constructor(private perMinute: number) {}
  take(key: string): boolean {
    const now = Date.now(), b = this.buckets.get(key) ?? { tokens: this.perMinute, at: now };
    b.tokens = Math.min(this.perMinute, b.tokens + ((now - b.at) / 60_000) * this.perMinute); b.at = now;
    if (b.tokens < 1) { this.buckets.set(key, b); return false; }
    b.tokens -= 1; this.buckets.set(key, b);
    if (this.buckets.size > 5000) this.buckets.clear();
    return true;
  }
}

// --------------------------------------------------------------- Validierung
const v = {
  str(x: unknown, name: string, max = 500): string { if (typeof x !== 'string' || !x.trim() || x.length > max) throw new AppError('invalid_input', `${name}: Text (1–${max} Zeichen) erwartet`); return x.trim(); },
  int(x: unknown, name: string, min = 1, max = Number.MAX_SAFE_INTEGER): number { const n = Number(x); if (!Number.isInteger(n) || n < min || n > max) throw new AppError('invalid_input', `${name}: ganze Zahl ${min}–${max} erwartet`); return n; },
  num(x: unknown, name: string, min: number, max: number): number { const n = Number(x); if (!Number.isFinite(n) || n < min || n > max) throw new AppError('invalid_input', `${name}: Zahl ${min}–${max} erwartet`); return n; },
  oneOf<T extends string>(x: unknown, name: string, opts: readonly T[]): T { if (!opts.includes(x as T)) throw new AppError('invalid_input', `${name}: einer von ${opts.join(', ')}`); return x as T; },
};
const STATUSES = ['STRONG_VALUE', 'VALUE', 'WATCH', 'NO_VALUE', 'INSUFFICIENT_DATA', 'STALE', 'AVOID', 'MARKET_SUSPENDED'] as const;

export interface ServerOptions { clock?: () => Date }

export function createServer(app: App, scheduler: Scheduler | null, opts: ServerOptions = {}) {
  const clock = opts.clock ?? (() => new Date());
  const routes: { method: string; re: RegExp; keys: string[]; h: Handler; access: Access; limit?: RateLimiter; maxBody?: number }[] = [];
  const route = (method: string, p: string, access: Access, h: Handler, o: { limit?: RateLimiter; maxBody?: number } = {}) => {
    const keys: string[] = [];
    const re = new RegExp('^' + p.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, h, access, limit: o.limit, maxBody: o.maxBody });
  };
  const general = new RateLimiter(240), analystLimit = new RateLimiter(12), jobLimit = new RateLimiter(6), loginLimit = new RateLimiter(10), oddsTestLimit = new RateLimiter(2);
  const auth = new AuthService(app.db, app.cfg.adminToken, app.cfg.readToken);
  const subs = new SubscriptionService(app.db, app.cfg, () => clock());
  const analyst = new EdgeAnalyst(app.db, app.cfg);
  const perf = new PerformanceRepository(app.db), bt = new BacktestingEngine(app.db), odds = new OddsStore(app.db), repo = new Repository(app.db);
  const recs = new RecommendationEngine(app.db, { oddsMaxAgeMinutes: app.cfg.analysis.oddsMaxAgeMinutes, allowMock: app.providers.isMock });
  const db = app.db;
  const live = !app.providers.isMock;
  const mockFilter = (alias = 'e') => (live ? `AND ${alias}.is_mock = 0` : '');

  const lastSync = () => db.get<{ id: number; started_at: string; finished_at: string | null; status: string; summary: string | null }>("SELECT id, started_at, finished_at, status, summary FROM sync_runs WHERE job IN ('hourly_sync', 'controlled_sync') ORDER BY id DESC LIMIT 1");
  const modelStatus = () => db.all('SELECT id, validation_status, validated_by_backtest, created_at FROM model_versions ORDER BY created_at DESC LIMIT 5');
  const issues = () => [...configIssues(app.cfg), ...(auth.hasAdmin() ? [] : ['Kein Admin-Konto: ADMIN_EMAIL und ADMIN_PASSWORD setzen oder "npm run user:create" ausführen.'])];

  // ---------------------------------------------------------------- Öffentlich
  route('GET', '/api/health', 'public', () => ({ ok: true, time: nowIso() }));

  route('POST', '/api/auth/login', 'public', ({ body, ip, req, res, now }) => {
    const r = auth.login(String(body?.email ?? ''), String(body?.password ?? ''), ip, String(req.headers['user-agent'] ?? ''), now);
    res.setHeader('set-cookie', sessionCookie(r.token, SESSION_ABSOLUTE_H * 3600, app.cfg.cookieSecure));
    return { user: r.user, csrfToken: r.csrf, expiresAt: r.expiresAt };
  }, { limit: loginLimit });

  route('POST', '/api/auth/register', 'public', ({ body, ip }) => {
    if (!app.cfg.allowRegistration) throw new AppError('forbidden', 'Registrierung ist deaktiviert. Ein Admin legt Konten an.', 403);
    const u = auth.createUser(String(body?.email ?? ''), String(body?.password ?? ''), 'user');
    auth.event('registered', { userId: u.id, email: u.email, ip });
    return { user: u };
  }, { limit: loginLimit });

  // ---------------------------------------------------------------- Benutzer
  route('GET', '/api/auth/me', 'user', ({ me }) => ({ user: { id: me!.userId, email: me!.email, role: me!.role, kind: me!.kind }, csrfToken: me!.csrf }));
  route('POST', '/api/auth/logout', 'user', ({ me, res }) => {
    auth.logout(me!);
    res.setHeader('set-cookie', sessionCookie('', 0, app.cfg.cookieSecure));
    return { ok: true };
  });

  route('GET', '/api/status', 'user', ({ me, now }) => {
    const ls = lastSync();
    const sys = app.sync.systemSettings();
    const latestBt = bt.latest();
    return {
      dataMode: app.cfg.dataMode, isMock: app.providers.isMock, timezone: app.cfg.timezone,
      configIssues: me!.role === 'admin' ? issues() : [],
      lastSync: ls ? { ...ls, summary: json.parse(ls.summary, null) } : null,
      lastOddsUpdate: db.get<{ t: string | null }>(`SELECT MAX(s.retrieved_at) AS t FROM odds_snapshots s JOIN events e ON e.id = s.event_id WHERE s.snapshot_kind = 'live' ${mockFilter()}`)?.t ?? null,
      providers: db.all('SELECT provider, status, last_success_at, last_error_at, last_error, quota_remaining, quota_limit, paused_until, pause_reason, updated_at FROM provider_health WHERE provider != \'app\' ORDER BY provider'),
      blocked: app.providers.blocked, providerStates: providerStates(app.cfg), pilot: app.cfg.pilot.enabled ? { sportKeys: app.cfg.pilot.sportKeys, maxEvents: app.cfg.pilot.maxEventsPerRun } : null, models: modelStatus(),
      modelValidation: latestBt?.metrics ? { status: latestBt.metrics.validation.status, dataSource: latestBt.data_source, backtestId: latestBt.id, at: latestBt.finished_at } : { status: 'UNVALIDATED', dataSource: null, backtestId: null, at: null },
      scheduler: scheduler?.status(now) ?? null, minEv: sys.min_ev, strategy: sys.strategy,
      upcoming: db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM events e WHERE e.status = 'scheduled' AND e.kickoff_utc > ? AND e.kickoff_utc <= ? ${mockFilter()}`, nowIso(now), addHours(now, app.cfg.analysis.horizonHours).toISOString())!.n,
      unreadAlerts: db.get<{ n: number }>('SELECT COUNT(*) AS n FROM alerts_sent a WHERE NOT EXISTS (SELECT 1 FROM alert_reads r WHERE r.alert_id = a.id AND r.user_id = ?)', me!.userId ?? -1)!.n,
      unreadPersonalAlerts: me!.userId == null ? 0 : db.get<{ n: number }>('SELECT COUNT(*) AS n FROM user_alerts WHERE user_id = ? AND read_at IS NULL', me!.userId)!.n,
    };
  });

  // Jede Empfehlung wird hier gegen die aktuelle Uhr revalidiert – auch ohne neuen Sync-Lauf
  route('GET', '/api/recommendations', 'user', ({ now, me }) => {
    const all = recs.current(now);
    // Tarif: bei aktiver Durchsetzung nur so viele Empfehlungen wie im Tarif enthalten (die übrigen werden gezählt, nicht gezeigt)
    const ent = subs.entitlements(me!.userId, me!.role);
    const r = all.slice(0, ent.effective.maxRecommendations);
    return { recommendations: r, message: all.length ? null : 'NO QUALIFIED VALUE BETS', checkedAt: nowIso(now), recentlyDeactivated: recs.recentlyDeactivated(10),
      plan: { id: ent.plan, enforced: ent.enforced, hidden: all.length - r.length } };
  });

  route('GET', '/api/competitions', 'user', ({ now }) => db.all(`SELECT c.id, c.name, c.country_name, c.region, c.is_mock,
      (SELECT COUNT(*) FROM events e WHERE e.competition_id = c.id AND e.status = 'scheduled' AND e.kickoff_utc > ?) AS upcoming FROM competitions c WHERE ${live ? 'c.is_mock = 0' : '1=1'} ORDER BY c.region, c.name`, nowIso(now)));

  route('GET', '/api/matches', 'user', ({ url, now }) => {
    const hours = url.searchParams.get('hours') ? v.int(url.searchParams.get('hours'), 'hours', 1, 336) : app.cfg.analysis.horizonHours;
    const q = (url.searchParams.get('q') ?? '').slice(0, 60).toLowerCase();
    const region = url.searchParams.get('region'); const comp = url.searchParams.get('competition');
    const rows = db.all<Record<string, any>>(`SELECT e.id, e.kickoff_utc, e.status, e.analysis_status, e.is_mock, e.round, th.name AS home, ta.name AS away, c.id AS competition_id, c.name AS competition, c.region, c.country_name,
        (SELECT COUNT(DISTINCT bookmaker_id) FROM odds_snapshots s WHERE s.event_id = e.id AND s.snapshot_kind = 'live') AS bookmakers,
        (SELECT MAX(s.retrieved_at) FROM odds_snapshots s WHERE s.event_id = e.id AND s.snapshot_kind = 'live') AS last_odds_at,
        (SELECT json_object('status', s.status, 'market', s.market_id, 'selection', s.selection_id, 'ev', s.ev, 'ev_low', s.ev_low, 'odds', s.best_odds, 'valid_until', s.valid_until) FROM value_signals s WHERE s.event_id = e.id AND s.active = 1
           ORDER BY CASE s.status WHEN 'STRONG_VALUE' THEN 0 WHEN 'VALUE' THEN 1 WHEN 'WATCH' THEN 2 ELSE 3 END, s.ev_low DESC LIMIT 1) AS top_signal
       FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id
      WHERE e.status = 'scheduled' AND e.kickoff_utc > ? AND e.kickoff_utc <= ? ${mockFilter()} ${region ? 'AND c.region = ?' : ''} ${comp ? 'AND c.id = ?' : ''}
      ORDER BY e.kickoff_utc LIMIT 500`, ...([nowIso(now), addHours(now, hours).toISOString(), ...(region ? [region] : []), ...(comp ? [Number(comp)] : [])] as (string | number)[]));
    return rows.filter(r => !q || `${r.home} ${r.away} ${r.competition}`.toLowerCase().includes(q)).map(r => {
      const sig = json.parse<Record<string, any> | null>(r.top_signal, null);
      // Signale mit abgelaufener Gültigkeit nicht als aktuell zeigen
      if (sig && ['VALUE', 'STRONG_VALUE', 'WATCH'].includes(sig.status) && (!sig.valid_until || sig.valid_until <= nowIso(now))) sig.status = 'STALE';
      return { ...r, top_signal: sig };
    });
  });

  route('GET', '/api/matches/:id', 'user', ({ params, now }) => {
    const id = v.int(params.id, 'id');
    const ev = repo.event(id);
    if (!ev || (live && ev.is_mock)) throw new AppError('not_found', 'Spiel nicht gefunden', 404);
    const a = analyst.eventAnalysis(id, now) as any;
    const markets = (['1X2', 'OU', 'BTTS'] as MarketId[]).map(m => ({ market: m, line: m === 'OU' ? 2.5 : null,
      books: odds.latestPerBookmaker(id, m, m === 'OU' ? 2.5 : null).map(b => {
        const f = checkFreshness({ retrievedAt: b.retrievedAt, sourceTimestamp: b.sourceTimestamp, kickoffUtc: ev.kickoff_utc, snapshotKind: b.kind }, now, app.cfg.analysis.oddsMaxAgeMinutes);
        return { ...b, fresh: f.ok, ageMinutes: f.ageMinutes, limitMinutes: f.limitMinutes, freshnessReasons: f.reasons };
      }) }));
    // Verfügbarkeit je Markt: geliefert / ausgesetzt / nicht verfügbar (mit Grund aus dem letzten Lauf)
    const reports = json.parse<{ providerReports?: { provider: string; markets: Record<string, { requested: boolean; reason: string | null }> }[] }>(lastSync()?.summary ?? null, {}).providerReports ?? [];
    const evProviders = db.all<{ provider: string }>('SELECT provider FROM event_mappings WHERE event_id = ?', id).map(r => r.provider);
    for (const m of markets as any[]) {
      const live = m.books.filter((b: any) => b.kind === 'live' || b.kind == null);
      if (live.some((b: any) => b.status === 'open')) { m.availability = { status: 'AVAILABLE', reason: null }; continue; }
      if (live.length) { m.availability = { status: 'MARKET SUSPENDED', reason: 'Markt laut Provider ausgesetzt oder geschlossen' }; continue; }
      const why = reports.filter(r => evProviders.includes(r.provider)).map(r => r.markets?.[m.market]).find(x => x && x.reason)?.reason;
      m.availability = { status: 'NOT AVAILABLE', reason: why ?? 'keine Quoten für diesen Markt vorhanden' };
    }
    const hist = repo.competitionHistory(ev.competition_id, ev.kickoff_utc);
    const name = (tid: number) => db.get<{ name: string }>('SELECT name FROM teams WHERE id = ?', tid)?.name ?? '?';
    const lastOf = (tid: number) => hist.filter(m => m.home === tid || m.away === tid).slice(-10).reverse().map(m => ({ kickoff: m.kickoff, home: name(m.home), away: name(m.away), hg: m.hg, ag: m.ag, xgH: m.xgH, xgA: m.xgA }));
    const h2h = db.all<Record<string, any>>(`SELECT e.kickoff_utc, th.name AS home, ta.name AS away, e.home_goals, e.away_goals FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
      WHERE e.status = 'finished' AND ((e.home_team_id = ? AND e.away_team_id = ?) OR (e.home_team_id = ? AND e.away_team_id = ?)) ORDER BY e.kickoff_utc DESC LIMIT 10`, ev.home_team_id, ev.away_team_id, ev.away_team_id, ev.home_team_id);
    const snapshotsHistory = db.all(`SELECT s.market_id, s.bookmaker_id, b.name, s.retrieved_at, s.source_timestamp, s.provider, s.from_cache, s.snapshot_kind, p.selection_id, p.odds FROM odds_snapshots s JOIN bookmakers b ON b.id = s.bookmaker_id JOIN odds_prices p ON p.snapshot_id = s.id
      WHERE s.event_id = ? ORDER BY s.retrieved_at`, id);
    const provenance = db.all('SELECT provider, provider_event_id, confidence, method, created_at FROM event_mappings WHERE event_id = ?', id);
    return { ...a, odds: markets, oddsHistory: snapshotsHistory, provenance,
      statistics: { home: { form: teamForm(hist, ev.home_team_id, ev.kickoff_utc, 10), last: lastOf(ev.home_team_id) }, away: { form: teamForm(hist, ev.away_team_id, ev.kickoff_utc, 10), last: lastOf(ev.away_team_id) },
        teamStats: db.all('SELECT * FROM team_statistics WHERE team_id IN (?, ?)', ev.home_team_id, ev.away_team_id), leagueMatches: hist.length },
      h2h };
  });

  route('GET', '/api/signals', 'user', ({ url }) => {
    const status = url.searchParams.get('status');
    return db.all(`SELECT s.id, s.event_id, s.market_id, s.selection_id, s.line, s.status, s.model_prob, s.decision_prob, s.prob_low, s.novig_prob, s.best_odds, s.ev, s.ev_low, s.quality_score, s.created_at, s.validated_at, s.valid_until, s.odds_retrieved_at,
      th.name AS home, ta.name AS away, e.kickoff_utc FROM value_signals s JOIN events e ON e.id = s.event_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
      WHERE s.active = 1 ${mockFilter()} ${status ? 'AND s.status = ?' : ''} ORDER BY s.ev_low DESC LIMIT 200`, ...(status ? [v.oneOf(status, 'status', STATUSES)] : []));
  });

  route('GET', '/api/performance', 'user', () => ({ real: perf.metrics('real'), mock: live ? null : perf.metrics('mock'), backtest: bt.latest(), models: modelStatus() }));

  route('POST', '/api/analyst', 'user', async ({ body, now, me }) => {
    const question = v.str(body?.question, 'question', 1000);
    const lang = v.oneOf(body?.lang ?? 'es', 'lang', ['es', 'de', 'en'] as const);
    const history = Array.isArray(body?.history) ? body.history.slice(-6).filter((h: any) => (h?.role === 'user' || h?.role === 'assistant') && typeof h?.content === 'string').map((h: any) => ({ role: h.role, content: String(h.content).slice(0, 2000) })) : [];
    subs.consume(me!.userId, me!.role, 'edgeAnalyst');
    return analyst.ask(question, lang, history, now);
  }, { limit: analystLimit });

  // Persönliche Einstellungen (jeder Benutzer für sich)
  const userId = (me: Principal) => { if (me.userId == null) throw new AppError('forbidden', 'Service-Token hat keine persönlichen Einstellungen', 403); return me.userId; };
  route('GET', '/api/settings', 'user', ({ me }) => {
    const id = userId(me!);
    db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', id);
    const s = db.get<Record<string, any>>('SELECT language, timezone, notify_new_value, notify_odds_change, notify_removed, notify_ev_change, personal_alerts_enabled, alert_min_ev FROM user_settings WHERE user_id = ?', id)!;
    const ent = subs.entitlements(id, me!.role);
    return { ...s, entitlements: { personalAlerts: ent.effective.personalAlerts, customAlertMinEv: ent.effective.customAlertMinEv, plan: ent.plan, enforced: ent.enforced } };
  });
  route('PUT', '/api/settings', 'user', ({ body, me }) => {
    const id = userId(me!);
    db.run('INSERT OR IGNORE INTO user_settings (user_id) VALUES (?)', id);
    const cur = db.get<Record<string, any>>('SELECT * FROM user_settings WHERE user_id = ?', id)!;
    const next = {
      language: body.language !== undefined ? v.oneOf(body.language, 'language', ['es', 'de', 'en'] as const) : cur.language,
      timezone: body.timezone !== undefined ? validTz(v.str(body.timezone, 'timezone', 64)) : cur.timezone,
      notify_new_value: body.notify_new_value !== undefined ? (body.notify_new_value ? 1 : 0) : cur.notify_new_value,
      notify_odds_change: body.notify_odds_change !== undefined ? (body.notify_odds_change ? 1 : 0) : cur.notify_odds_change,
      notify_removed: body.notify_removed !== undefined ? (body.notify_removed ? 1 : 0) : cur.notify_removed,
      notify_ev_change: body.notify_ev_change !== undefined ? (body.notify_ev_change ? 1 : 0) : cur.notify_ev_change,
      personal_alerts_enabled: body.personal_alerts_enabled !== undefined ? (body.personal_alerts_enabled ? 1 : 0) : cur.personal_alerts_enabled,
      alert_min_ev: body.alert_min_ev === undefined ? cur.alert_min_ev : body.alert_min_ev === null ? null : v.num(body.alert_min_ev, 'alert_min_ev', 0.01, 0.5),
    };
    // Tarif (nur bei aktiver Durchsetzung): persönliche Meldungen / eigener Mindest-EV
    if (next.personal_alerts_enabled && !cur.personal_alerts_enabled) subs.require(id, me!.role, 'personalAlerts');
    if (next.alert_min_ev != null && next.alert_min_ev !== cur.alert_min_ev) subs.require(id, me!.role, 'customAlertMinEv');
    db.run('UPDATE user_settings SET language = ?, timezone = ?, notify_new_value = ?, notify_odds_change = ?, notify_removed = ?, notify_ev_change = ?, personal_alerts_enabled = ?, alert_min_ev = ?, updated_at = ? WHERE user_id = ?',
      next.language, next.timezone, next.notify_new_value, next.notify_odds_change, next.notify_removed, next.notify_ev_change, next.personal_alerts_enabled, next.alert_min_ev, nowIso(), id);
    return next;
  });
  const validTz = (tz: string) => { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return tz; } catch { throw new AppError('invalid_input', 'timezone: ungültige IANA-Zeitzone'); } };
  const validBooks = (x: unknown) => {
    if (!Array.isArray(x) || x.length > 50) throw new AppError('invalid_input', 'preferred_bookmakers: Liste erwartet');
    const known = new Set(db.all<{ id: string }>('SELECT id FROM bookmakers').map(b => b.id));
    return x.map(s => String(s)).filter(s => known.has(s));
  };

  route('GET', '/api/bookmakers', 'user', () => db.all(`SELECT id, name, is_sharp, is_mock FROM bookmakers WHERE ${live ? 'is_mock = 0' : '1=1'} ORDER BY is_sharp DESC, name`));
  // Systemweite Meldungen: Lesestatus je Benutzer (v0.3.0; vorher global – Benutzer A konnte für B "gelesen" setzen)
  route('GET', '/api/alerts', 'user', ({ me }) => db.all(`SELECT a.id, a.kind, a.title, a.body, a.channels, a.created_at, r.read_at FROM alerts_sent a
      LEFT JOIN alert_reads r ON r.alert_id = a.id AND r.user_id = ? ORDER BY a.id DESC LIMIT 100`, me!.userId ?? -1));
  route('POST', '/api/alerts/:id/read', 'user', ({ params, me }) => {
    const aid = v.int(params.id, 'id');
    if (!db.get('SELECT 1 FROM alerts_sent WHERE id = ?', aid)) throw new AppError('not_found', 'Meldung nicht gefunden', 404);
    return { changed: db.run('INSERT OR IGNORE INTO alert_reads (alert_id, user_id, read_at) VALUES (?, ?, ?)', aid, userId(me!), nowIso()).changes };
  });
  // Persönliche Meldungen: ausschließlich die eigenen
  route('GET', '/api/me/alerts', 'user', ({ me }) => db.all('SELECT id, kind, title, body, ev, channels, created_at, read_at FROM user_alerts WHERE user_id = ? ORDER BY id DESC LIMIT 200', userId(me!)));
  route('POST', '/api/me/alerts/:id/read', 'user', ({ params, me }) => {
    const r = db.run('UPDATE user_alerts SET read_at = ? WHERE id = ? AND user_id = ? AND read_at IS NULL', nowIso(), v.int(params.id, 'id'), userId(me!));
    if (!r.changes && !db.get('SELECT 1 FROM user_alerts WHERE id = ? AND user_id = ?', v.int(params.id, 'id'), userId(me!))) throw new AppError('not_found', 'Meldung nicht gefunden', 404);
    return { changed: r.changes };
  });
  route('POST', '/api/me/alerts/read-all', 'user', ({ me }) => ({ changed: db.run('UPDATE user_alerts SET read_at = ? WHERE user_id = ? AND read_at IS NULL', nowIso(), userId(me!)).changes }));

  // ---------------------------------------------------------------- Admin
  route('GET', '/api/system-settings', 'user', () => {
    const s = app.sync.systemSettings();
    return { ...s, preferred_bookmakers: json.parse(s.preferred_bookmakers, []), enabled_competitions: json.parse(s.enabled_competitions, []) };
  });
  route('PUT', '/api/system-settings', 'admin', ({ body, me }) => {
    const cur = app.sync.systemSettings();
    const next = {
      min_ev: body.min_ev !== undefined ? v.num(body.min_ev, 'min_ev', 0.01, 0.5) : cur.min_ev,
      strategy: body.strategy !== undefined ? v.oneOf(body.strategy, 'strategy', ['CONSERVATIVE', 'BALANCED', 'AGGRESSIVE'] as const) : cur.strategy,
      model_weight: body.model_weight !== undefined ? (body.model_weight === null ? null : v.num(body.model_weight, 'model_weight', 0, 1)) : cur.model_weight,
      preferred_bookmakers: body.preferred_bookmakers !== undefined ? JSON.stringify(validBooks(body.preferred_bookmakers)) : cur.preferred_bookmakers,
      enabled_competitions: body.enabled_competitions !== undefined ? JSON.stringify(validComps(body.enabled_competitions)) : cur.enabled_competitions,
      max_fixtures_per_run: body.max_fixtures_per_run !== undefined ? v.int(body.max_fixtures_per_run, 'max_fixtures_per_run', 1, 500) : cur.max_fixtures_per_run,
    };
    db.run('UPDATE system_settings SET min_ev = ?, strategy = ?, model_weight = ?, preferred_bookmakers = ?, enabled_competitions = ?, max_fixtures_per_run = ?, updated_at = ? WHERE id = 1',
      next.min_ev, next.strategy, next.model_weight, next.preferred_bookmakers, next.enabled_competitions, next.max_fixtures_per_run, nowIso());
    auth.event('system_settings_changed', { userId: me!.userId, email: me!.email, detail: JSON.stringify({ min_ev: next.min_ev, strategy: next.strategy, model_weight: next.model_weight }) });
    return { ...next, preferred_bookmakers: JSON.parse(next.preferred_bookmakers), enabled_competitions: JSON.parse(next.enabled_competitions) };
  });
  const validComps = (x: unknown) => {
    if (!Array.isArray(x) || x.length > 500) throw new AppError('invalid_input', 'enabled_competitions: Liste erwartet');
    const known = new Set(db.all<{ id: number }>('SELECT id FROM competitions').map(c => c.id));
    return x.map(Number).filter(n => known.has(n));
  };

  // v0.4.0: auch ohne Scheduler über den Validierungsablauf (Datenqualitätsprüfung), nie direkt über die Backtest-Engine
  route('POST', '/api/backtest/run', 'admin', async () => (scheduler ? scheduler.runJob('backtest') : (r => ({ validationId: r.id, status: r.status, backtestRunId: r.backtestRunId }))(runValidation(db, { includeMock: app.providers.isMock, ...validationSettings(app) }))), { limit: jobLimit });

  route('GET', '/api/admin/diagnostics', 'admin', ({ now }) => {
    const today = now.toISOString().slice(0, 10);
    return {
      configIssues: issues(), dataMode: app.cfg.dataMode, blocked: app.providers.blocked, providerStates: providerStates(app.cfg), pilot: app.cfg.pilot,
      apiRequestLog: app.queue.recentRequests({ limit: 100 }),
      providerHealth: db.all('SELECT * FROM provider_health ORDER BY provider'),
      quota: ['highlightly', 'theoddsapi', 'mock'].map(p => app.queue.budgetStatus(p)),
      requestsToday: db.all('SELECT provider, endpoint, COUNT(*) AS n, SUM(from_cache) AS cached, SUM(cost) AS credits, AVG(duration_ms) AS avg_ms FROM api_requests WHERE day = ? GROUP BY provider, endpoint ORDER BY n DESC LIMIT 50', today),
      freshness: db.get(`SELECT MAX(retrieved_at) AS last_odds, (SELECT MAX(updated_at) FROM events) AS last_event_update, (SELECT MAX(created_at) FROM predictions) AS last_prediction FROM odds_snapshots WHERE snapshot_kind = 'live'`),
      scheduler: scheduler?.status(now) ?? null,
      syncRuns: db.all('SELECT id, job, started_at, finished_at, heartbeat_at, status, error, summary FROM sync_runs ORDER BY id DESC LIMIT 30').map((r: any) => ({ ...r, summary: json.parse(r.summary, null) })),
      missingData: db.all('SELECT kind, ref, detail, count, last_seen FROM missing_data ORDER BY last_seen DESC LIMIT 100'),
      modelValidation: { models: modelStatus(), latestBacktest: bt.latest() },
      recentlyDeactivated: recs.recentlyDeactivated(30),
      errorLogs: db.all('SELECT id, source, message, created_at FROM error_logs ORDER BY id DESC LIMIT 50'),
      securityEvents: db.all('SELECT id, kind, email, ip, detail, created_at FROM security_events ORDER BY id DESC LIMIT 50'),
    };
  });
  route('GET', '/api/admin/api-requests', 'admin', ({ url }) => app.queue.recentRequests({
    provider: url.searchParams.get('provider') ? v.oneOf(url.searchParams.get('provider'), 'provider', ['theoddsapi', 'highlightly', 'mock'] as const) : undefined,
    limit: url.searchParams.get('limit') ? v.int(url.searchParams.get('limit'), 'limit') : 100,
  }));
  // Kontrollierte Diagnose: genau ein begrenzter Sync, vollständiger Bericht (unter dem Sync-Lock, nie parallel zum stündlichen Lauf)
  route('POST', '/api/admin/diagnostics/controlled-sync', 'admin', async ({ body, me, now }) => {
    const maxEvents = body?.maxEvents === undefined ? 10 : v.int(body.maxEvents, 'maxEvents');
    if (maxEvents < 1 || maxEvents > 60) throw new AppError('invalid_input', 'maxEvents: 1–60');
    return controlledSync(app, { now, maxEvents, userId: me!.userId, withLock: scheduler ? (fn) => scheduler.withLock('hourly_sync', fn, now) : undefined });
  }, { limit: jobLimit });
  // v0.3.3 – The Odds API: Status (nur aus Konfiguration und DB) und kostenloser Verbindungstest (GET /v4/sports, ein Versuch)
  // v0.4.0: Datengrundlage je Wettbewerb (Spielplan, Quoten, Historie, Teams, Modelle, Validierung je Markt)
  route('GET', '/api/admin/coverage', 'admin', ({ now }) => competitionCoverage(db, app.cfg, now));
  route('GET', '/api/admin/providers/theoddsapi', 'admin', ({ now }) => oddsApiStatus(app, now, scheduler?.status(now)));
  route('POST', '/api/admin/providers/theoddsapi/test', 'admin', async ({ me, now }) => {
    const result = await testOddsApiConnection(app, { triggeredBy: `admin:${me!.userId}`, now });
    return { result, status: oddsApiStatus(app, now, scheduler?.status(now)) };
  }, { limit: oddsTestLimit });
  route('GET', '/api/admin/diagnostics/runs', 'admin', () => db.all("SELECT id, kind, started_at, finished_at, status FROM diagnostic_runs ORDER BY id DESC LIMIT 30"));
  route('GET', '/api/admin/diagnostics/runs/:id', 'admin', ({ params }) => {
    const r = db.get<{ report: string | null }>('SELECT report FROM diagnostic_runs WHERE id = ?', v.int(params.id, 'id'));
    if (!r) throw new AppError('not_found', 'Diagnose nicht gefunden', 404);
    return json.parse(r.report, null);
  });
  // ---------------------------------------------------------------- Tarife und Zahlungen (V4, Testmodus)
  route('GET', '/api/plans', 'public', () => ({ plans: subs.plans(), methods: subs.methods(), enforced: app.cfg.subscriptions.enforce, currency: 'PYG' }));
  route('GET', '/api/subscription', 'user', ({ me }) => subs.overview(userId(me!)));
  route('POST', '/api/subscription/checkout', 'user', ({ body, me }) => subs.checkout(userId(me!), String(body?.planId ?? ''), String(body?.period ?? ''), String(body?.method ?? 'bank_transfer')));
  route('POST', '/api/subscription/cancel', 'user', ({ me }) => subs.cancel(userId(me!), userId(me!)));
  route('POST', '/api/payments/:id/proof', 'user', ({ params, body, me }) => subs.submitProof(userId(me!), v.int(params.id, 'id'), {
    fileName: String(body?.fileName ?? ''), mime: String(body?.mime ?? ''), dataBase64: String(body?.dataBase64 ?? ''), note: typeof body?.note === 'string' ? body.note : null,
  }), { maxBody: 3_000_000 });
  route('GET', '/api/admin/subscriptions', 'admin', () => subs.adminSubscriptions());
  route('GET', '/api/admin/payments', 'admin', ({ url }) => subs.adminPayments(url.searchParams.get('status') ? v.oneOf(url.searchParams.get('status'), 'status', ['AWAITING_PAYMENT', 'PROOF_SUBMITTED', 'VERIFIED', 'REJECTED', 'CANCELLED'] as const) : undefined));
  route('GET', '/api/admin/payments/:id/proof', 'admin', ({ params, me }) => {
    const id = v.int(params.id, 'id');
    auth.event('payment_proof_viewed', { userId: me!.userId, email: me!.email, detail: `payment ${id}` });
    return subs.adminProof(id);
  });
  route('POST', '/api/admin/payments/:id/verify', 'admin', ({ params, body, me }) => subs.verifyPayment(userId(me!), v.int(params.id, 'id'), body ?? {}));
  route('POST', '/api/admin/payments/:id/reject', 'admin', ({ params, body, me }) => subs.rejectPayment(userId(me!), v.int(params.id, 'id'), body?.reason));
  route('POST', '/api/admin/subscriptions/grant', 'admin', ({ body, me }) => subs.grant(userId(me!), body ?? {}));
  route('POST', '/api/admin/subscriptions/:id/cancel', 'admin', ({ params, body, me }) => subs.adminCancel(userId(me!), v.int(params.id, 'id'), body?.reason));
  route('GET', '/api/admin/subscription-events', 'admin', ({ url }) => subs.events(url.searchParams.get('userId') ? v.int(url.searchParams.get('userId'), 'userId') : undefined));

  // Historische Validierung (V3)
  route('GET', '/api/admin/data-quality', 'admin', () => historicalDataQuality(db, { includeMock: app.providers.isMock }));
  route('POST', '/api/admin/validation/run', 'admin', async () => {
    const run = async () => { const r = runValidation(db, { includeMock: app.providers.isMock, ...validationSettings(app) }); return { id: r.id, status: r.status, reasons: r.reasons, backtestRunId: r.backtestRunId }; };
    if (!scheduler) return run();
    const r = await scheduler.withLock('backtest', run);
    if (!r.started) throw new AppError('busy', 'Ein Backtest läuft bereits', 409);
    if (r.error) throw new AppError('failed', r.error, 500);
    return r.result;
  }, { limit: jobLimit });
  route('GET', '/api/admin/validation/latest', 'admin', () => {
    const r = db.get<{ report: string | null }>("SELECT report FROM diagnostic_runs WHERE kind = 'validation' AND report IS NOT NULL ORDER BY id DESC LIMIT 1");
    return r ? json.parse(r.report, null) : null;
  });
  route('POST', '/api/admin/jobs/:name/run', 'admin', async ({ params }) => {
    if (!scheduler) throw new AppError('unavailable', 'Scheduler deaktiviert', 409);
    const name = v.oneOf(params.name, 'job', ['discovery', 'hourly_sync', 'settlement', 'backtest', 'cleanup'] as const);
    return scheduler.runJob(name);
  }, { limit: jobLimit });
  route('POST', '/api/admin/providers/:name/resume', 'admin', ({ params, me }) => {
    const name = v.oneOf(params.name, 'provider', ['highlightly', 'theoddsapi'] as const);
    app.queue.resume(name);
    auth.event('provider_resumed', { userId: me!.userId, email: me!.email, detail: name });
    return { ok: true };
  });
  route('POST', '/api/admin/team-alias', 'admin', ({ body }) => {
    const teamId = v.int(body?.teamId, 'teamId');
    if (!db.get('SELECT 1 FROM teams WHERE id = ?', teamId)) throw new AppError('not_found', 'Team nicht gefunden', 404);
    repo.addTeamAlias(teamId, v.str(body?.provider, 'provider', 40), null, v.str(body?.name, 'name', 120));
    return { ok: true };
  });
  route('POST', '/api/admin/import-csv', 'admin', ({ body }) => {
    const text = typeof body === 'string' ? body : v.str(body?.csv, 'csv', 20_000_000);
    return importFootballDataCsv(db, text);
  }, { maxBody: 25_000_000 });
  route('GET', '/api/admin/users', 'admin', () => auth.listUsers());
  route('POST', '/api/admin/users', 'admin', ({ body, me }) => auth.createUser(String(body?.email ?? ''), String(body?.password ?? ''), v.oneOf(body?.role ?? 'user', 'role', ['admin', 'user'] as const) as Role, me));
  route('PUT', '/api/admin/users/:id', 'admin', ({ params, body, me }) => auth.updateUser(v.int(params.id, 'id'), { role: body?.role, active: body?.active }, me!));

  // ---------------------------------------------------------------- Server
  const server = http.createServer(async (req, res) => {
    const security: Record<string, string> = { 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer', 'x-frame-options': 'DENY', 'cross-origin-opener-policy': 'same-origin',
      'permissions-policy': 'camera=(), microphone=(), geolocation=()',
      'content-security-policy': "default-src 'self'; script-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" };
    if (app.cfg.cookieSecure) security['strict-transport-security'] = 'max-age=31536000';
    const send = (status: number, body: unknown) => {
      res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...security });
      res.end(JSON.stringify(body));
    };
    try {
      const url = new URL(req.url ?? '/', 'http://localhost');
      const ip = (app.cfg.trustProxy ? String(req.headers['x-forwarded-for'] ?? '').split(',')[0].trim() : '') || String(req.socket.remoteAddress ?? '');
      if (!url.pathname.startsWith('/api/')) return serveStatic(app.cfg.frontendDir, url.pathname, res, security);
      const r = routes.find(x => x.method === req.method && x.re.test(url.pathname));
      if (!r) return send(404, { error: 'not_found', message: 'Unbekannter Endpunkt' });
      if (!general.take(ip) || (r.limit && !r.limit.take(ip))) return send(429, { error: 'rate_limited', message: 'Zu viele Anfragen. Bitte kurz warten.' });
      const writing = ['POST', 'PUT', 'DELETE'].includes(req.method ?? '');
      // Kein CORS: schreibende Anfragen nur von der eigenen Herkunft
      const origin = req.headers.origin;
      if (writing && origin && originHost(origin) !== req.headers.host) { auth.event('forbidden', { ip, detail: `fremde Herkunft ${origin}` }); return send(403, { error: 'forbidden_origin', message: 'Anfragen von fremden Seiten sind nicht erlaubt.' }); }
      const now = clock();
      const bearer = String(req.headers.authorization ?? '').startsWith('Bearer ') ? String(req.headers.authorization).slice(7) : null;
      const me = auth.session(parseCookies(req.headers.cookie)[SESSION_COOKIE] ?? null, now) ?? auth.service(bearer);
      if (bearer && me?.kind === 'service') auth.event('token_auth', { ip, detail: `${req.method} ${url.pathname}` });
      if (r.access !== 'public') {
        if (!me) return send(401, { error: 'unauthorized', message: 'Bitte anmelden.' });
        if (me.readOnly && req.method !== 'GET') { auth.event('forbidden', { email: me.email, ip, detail: `${req.method} ${url.pathname} (Lese-Token)` }); return send(403, { error: 'forbidden', message: 'Lese-Token erlaubt nur GET.' }); }
        if (r.access === 'admin' && me.role !== 'admin') { auth.event('forbidden', { userId: me.userId, email: me.email, ip, detail: `${req.method} ${url.pathname}` }); return send(403, { error: 'forbidden', message: 'Nur für Administratoren.' }); }
        if (writing && me.kind === 'session' && req.headers['x-csrf-token'] !== me.csrf) { auth.event('csrf_failed', { userId: me.userId, email: me.email, ip, detail: url.pathname }); return send(403, { error: 'csrf', message: 'CSRF-Token fehlt oder ist ungültig. Seite neu laden.' }); }
      }
      const m = r.re.exec(url.pathname)!;
      const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
      const body = writing ? await readBody(req, r.maxBody ?? 1_000_000) : null;
      const out = await r.h({ req, res, url, params, body, ip, me, now });
      send(200, out);
    } catch (e) {
      if (e instanceof AppError) return send(e.httpStatus, { error: e.code, message: e.message });
      logError(app.db, 'http', e);
      send(500, { error: 'internal', message: 'Interner Fehler. Details im Admin-Fehlerprotokoll.' });
    }
  });
  return server;
}

function readBody(req: http.IncomingMessage, max: number): Promise<any> {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks: Buffer[] = [];
    req.on('data', (c: Buffer) => { size += c.length; if (size > max) { reject(new AppError('too_large', 'Anfrage zu groß', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      if (String(req.headers['content-type'] ?? '').includes('application/json')) { try { resolve(JSON.parse(raw)); } catch { reject(new AppError('invalid_json', 'Ungültiges JSON')); } }
      else resolve(raw);
    });
    req.on('error', reject);
  });
}

function serveStatic(dir: string, pathname: string, res: http.ServerResponse, security: Record<string, string>): void {
  const root = path.resolve(dir);
  let file = path.resolve(root, '.' + path.posix.normalize('/' + decodeURIComponent(pathname)));
  if (file !== root && !file.startsWith(root + path.sep)) { res.writeHead(403); res.end(); return; }
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) file = path.join(root, 'index.html');
  if (!fs.existsSync(file)) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', ...security }); res.end('Frontend nicht gebaut. Bitte "npm run build" im Ordner frontend ausführen.'); return; }
  const ext = path.extname(file);
  res.writeHead(200, { 'content-type': MIME[ext] ?? 'application/octet-stream', 'cache-control': ext === '.html' ? 'no-cache' : 'public, max-age=3600', ...security });
  fs.createReadStream(file).pipe(res);
}
