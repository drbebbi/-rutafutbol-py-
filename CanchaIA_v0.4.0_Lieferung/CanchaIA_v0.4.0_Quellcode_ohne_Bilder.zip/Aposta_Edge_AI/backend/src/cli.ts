/**
 * Kommandozeile: seed-mock | sync | backtest | import-csv <datei...> | report | data-quality | validate [verzeichnis] | user-create <email> [admin|user] | user-password <email>
 *               | odds-check [--paid-test]   (v0.3.3, The Odds API: kostenloser Verbindungstest, optional EIN kontrollierter Quotenabruf)
 * Passwort für user-create über die Umgebungsvariable NEW_USER_PASSWORD (nie als Argument, damit es nicht in der Shell-Historie landet).
 */
import { envLoad } from './env.js';
import fs from 'node:fs';
import { loadConfig, ConfigError } from './config.js';
import { buildApp, seedMock } from './app.js';
import { validationSettings } from './scheduler.js';
import { importFootballDataCsv } from './providers/footballDataCsv.js';
import { AuthService } from './auth.js';
import path from 'node:path';
import { historicalDataQuality } from './engines/dataQuality.js';
import { runValidation } from './engines/validation.js';
import { oddsApiStatus, testOddsApiConnection } from './engines/oddsApiStatus.js';
import { controlledSync } from './engines/diagnostic.js';

const [cmd, ...args] = process.argv.slice(2);
let cfg: ReturnType<typeof loadConfig>;
try { cfg = loadConfig(); }
catch (e) { if (e instanceof ConfigError) { console.error(`Konfigurationsfehler: ${e.message}`); process.exit(2); } throw e; }
if (envLoad.error) console.error(envLoad.error);
const app = buildApp(cfg);

switch (cmd) {
  case 'seed-mock': console.log(`Mock-Historie: ${await seedMock(app)} Spiele`); break;
  case 'sync': {
    if (cfg.dataMode === 'mock') await seedMock(app);
    const s = await app.sync.run();
    console.log(JSON.stringify(s, null, 2));
    const r = app.sync.report();
    console.log(r.message ?? r.recommendations.map(x => `${x.rank}. ${x.signal.home} – ${x.signal.away} ${x.signal.market_id} ${x.signal.selection_id} @ ${x.signal.best_odds} EV ${(x.signal.ev! * 100).toFixed(1)} %`).join('\n'));
    break;
  }
  case 'backtest': {
    if (cfg.dataMode === 'mock') await seedMock(app);
    // v0.4.0: immer über den Validierungsablauf (Datenqualität → Backtest), damit kein Weg die Prüfung umgeht
    const rep = runValidation(app.db, { includeMock: cfg.dataMode === 'mock', ...validationSettings(app) });
    const m = rep.metrics;
    console.log(JSON.stringify({ validationId: rep.id, status: rep.status, backtestRunId: rep.backtestRunId, scopes: m?.scopes, betting: m?.betting, reasons: rep.reasons,
      holdoutEnsemble: m ? Object.fromEntries(Object.entries(m.holdoutEnsemble).map(([k, x]) => [k, { ...x, calibration: undefined }])) : null }, null, 2));
    break;
  }
  case 'import-csv': {
    if (!args.length) { console.error('Aufruf: import-csv <datei.csv> [weitere.csv]'); process.exit(2); }
    for (const f of args) console.log(f, importFootballDataCsv(app.db, fs.readFileSync(f, 'utf8'), f));
    break;
  }
  case 'data-quality': {
    console.log(JSON.stringify(historicalDataQuality(app.db, { includeMock: cfg.dataMode === 'mock' }), null, 2));
    break;
  }
  case 'validate': {
    // Validierungsablauf: Datenqualität → Backtest → Bericht (Markdown + JSON) in data/validation/
    if (cfg.dataMode === 'mock') await seedMock(app);
    const rep = runValidation(app.db, { includeMock: cfg.dataMode === 'mock', ...validationSettings(app) });
    const dir = args[0] ?? path.resolve('data', 'validation');
    fs.mkdirSync(dir, { recursive: true });
    const base = path.join(dir, `validation-${rep.id}`);
    fs.writeFileSync(base + '.md', rep.markdown);
    fs.writeFileSync(base + '.json', JSON.stringify({ ...rep, markdown: undefined }, null, 2));
    console.log(rep.markdown);
    console.log(`\nGespeichert: ${base}.md / .json · Status ${rep.status}`);
    break;
  }
  case 'odds-check': {
    // 1) kostenloser Test GET /v4/sports (genau ein Versuch, 0 Credits). Der Schlüssel wird nie ausgegeben.
    const t = await testOddsApiConnection(app, { triggeredBy: 'cli' });
    const show = (o: unknown) => console.log(JSON.stringify(o, null, 2));
    show({ schritt: '1 Verbindungstest /v4/sports (kostenlos)', ok: t.ok, httpStatus: t.httpStatus, fehler: t.error, sportarten: t.sportsTotal, fussballAktiv: t.soccerActive,
      championsLeague: `${t.targetSportKey}: ${t.targetSportStatus}`, sportKeys: t.sportKeys, 'x-requests-remaining': t.requestsRemaining, 'x-requests-used': t.requestsUsed, 'x-requests-last': t.requestsLast });
    if (args.includes('--paid-test')) {
      // 2) höchstens EIN kontrollierter Lauf; Vorprüfung (Test bestanden, Kostenvoranschlag im Budget) passiert in controlledSync
      if (!t.ok) { console.log('Kostenpflichtiger Test NICHT ausgeführt: Verbindungstest nicht bestanden.'); process.exitCode = 2; break; }
      const r = await controlledSync(app, { maxEvents: Number(process.env.PILOT_MAX_EVENTS ?? 30) || 30 });
      show({ schritt: '2 kontrollierter Quotenabruf', status: r.status, liveVerification: r.liveVerification, kostenvoranschlag: r.costEstimate, creditsVerbraucht: r.creditsUsed,
        abrufe: r.apiRequests.map(x => `${x.status} ${x.endpoint} ${x.query ?? ''} cache=${x.fromCache} credits=${x.cost}`), spiele: r.events.length,
        maerkte: r.events.map(e => `${e.home} – ${e.away}: 1X2 ${e.markets['1X2'].valid}/${e.markets['1X2'].books}, OU2.5 ${e.markets.OU.valid}/${e.markets.OU.books}, BTTS ${e.markets.BTTS.valid}/${e.markets.BTTS.books} · ${e.prediction}`),
        hinweise: r.notes, pruefungen: r.checks });
    }
    const st = oddsApiStatus(app);
    show({ status: st.connection, gruende: st.reasons, modus: st.mode, credits: st.credits, daten: st.data, kostenpflichtigFrei: st.paidAllowed });
    if (!t.ok) process.exitCode = 1;
    break;
  }
  case 'report': { const r = app.sync.report(); console.log(r.message ?? JSON.stringify(r.recommendations, null, 2)); break; }
  case 'user-create': {
    const [email, role = 'user'] = args;
    const pw = process.env.NEW_USER_PASSWORD;
    if (!email || !pw || !['admin', 'user'].includes(role)) { console.error('Aufruf: NEW_USER_PASSWORD=… user-create <email> [admin|user]'); process.exit(2); }
    console.log(new AuthService(app.db, null).createUser(email, pw, role as 'admin' | 'user'));
    break;
  }
  case 'user-password': {
    const [email] = args;
    const pw = process.env.NEW_USER_PASSWORD;
    if (!email || !pw) { console.error('Aufruf: NEW_USER_PASSWORD=… user-password <email>'); process.exit(2); }
    console.log(new AuthService(app.db, null).setPassword(email, pw), '– alle Sessions dieses Kontos beendet');
    break;
  }
  default: console.log('Befehle: seed-mock | sync | backtest | import-csv <dateien> | report | data-quality | validate [verzeichnis] | user-create <email> [admin|user] | user-password <email>');
}
app.db.close();
