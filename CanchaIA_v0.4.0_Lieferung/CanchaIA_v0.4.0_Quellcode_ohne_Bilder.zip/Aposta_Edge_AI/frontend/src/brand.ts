/**
 * Öffentliche Marke (v0.3.2). Einzige Quelle für sichtbaren Namen, Slogan und Locale.
 *
 * HINWEIS: Verfügbarkeit des Namens „CanchaIA“ und Markenregistrierung (z. B. DINAPI Paraguay)
 * sind NOCH NICHT rechtlich bestätigt. Siehe BRANDING.md.
 *
 * Technische Kennungen (Paketnamen, DB-Pfad, Cookie `aea_session`, Event `aea:unauthorized`,
 * Sprachcodes 'es' | 'de' | 'en') bleiben bewusst unverändert.
 */
import type { Lang } from './i18n';

export const BRAND = {
  name: 'CanchaIA',
  /** Wortmarke in zwei Teilen: „Cancha“ + hervorgehobenes „IA“ */
  wordA: 'Cancha',
  wordB: 'IA',
  /** Slogan bleibt in allen Sprachen spanisch (Markenbestandteil). */
  slogan: 'Inteligencia Futbolística',
  market: 'PY',
  defaultLang: 'es' as Lang,
  defaultTz: 'America/Asuncion',
  currency: 'PYG',
} as const;

/** BCP-47-Locale je UI-Sprache. Spanisch = Spanisch (Paraguay). */
export const LOCALE: Record<Lang, string> = { es: 'es-PY', de: 'de-DE', en: 'en-GB' };

/** Name des Analyse-Assistenten (früher „EDGE ANALYST“). */
export const ANALYST: Record<Lang, string> = { es: 'Analista IA', de: 'KI-Analyst', en: 'AI Analyst' };

/** Dokumenttitel: „Seite · CanchaIA“ bzw. „CanchaIA · Inteligencia Futbolística“ */
export const docTitle = (page?: string) => page ? `${page} · ${BRAND.name}` : `${BRAND.name} · ${BRAND.slogan}`;
