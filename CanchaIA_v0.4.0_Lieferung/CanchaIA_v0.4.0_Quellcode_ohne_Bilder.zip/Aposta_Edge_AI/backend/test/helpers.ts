import { loadConfig, type Config } from '../src/config.js';
import { Db, migrate } from '../src/db/db.js';
import { buildApp, seedMock, type App } from '../src/app.js';
import type { HistMatch } from '../src/engines/prediction/history.js';
import { rng } from '../src/providers/mock.js';

export const ANCHOR = new Date('2026-10-12T12:00:00.000Z');
// Nur Testwerte – keine echten Zugangsdaten
export const TEST_ADMIN = { email: 'admin@example.test', password: 'test-admin-passwort-123' };
export const TEST_SERVICE_TOKEN = 'test-service-token-0123456789abcdef0123';

export function memDb(): Db { const db = new Db(':memory:'); migrate(db); return db; }

export function testConfig(over: Partial<NodeJS.ProcessEnv> = {}): Config {
  return loadConfig({ DATA_MODE: 'mock', ADMIN_EMAIL: TEST_ADMIN.email, ADMIN_PASSWORD: TEST_ADMIN.password, ADMIN_TOKEN: TEST_SERVICE_TOKEN, DB_PATH: ':memory:', SCHEDULER_ENABLED: 'false', ...over } as NodeJS.ProcessEnv);
}

export async function mockApp(over: Partial<NodeJS.ProcessEnv> = {}): Promise<App> {
  const cfg = testConfig(over);
  const app = buildApp(cfg, { db: memDb(), mockAnchor: ANCHOR });
  await seedMock(app);
  return app;
}

/** Simulierte Liga mit bekannten Stärken für Modelltests. */
export function simulateLeague(opts: { teams?: number; seasons?: number; home?: number; seed?: string } = {}): { matches: HistMatch[]; att: number[]; def: number[] } {
  const T = opts.teams ?? 12, seasons = opts.seasons ?? 3, home = opts.home ?? 1.3;
  const r = rng(opts.seed ?? 'sim');
  const att = Array.from({ length: T }, () => 0.7 + r() * 0.6), def = Array.from({ length: T }, () => 0.7 + r() * 0.6);
  const pois = (l: number) => { const L = Math.exp(-l); let k = 0, p = 1; do { k++; p *= r(); } while (p > L); return k - 1; };
  const matches: HistMatch[] = [];
  let id = 1; const start = Date.UTC(2023, 7, 1);
  let day = 0;
  for (let s = 0; s < seasons; s++) for (let a = 0; a < T; a++) for (let b = 0; b < T; b++) {
    if (a === b) continue;
    const lh = 1.1 * att[a] * def[b] * home, la = 1.1 * att[b] * def[a];
    matches.push({ eventId: id++, competitionId: 1, kickoff: new Date(start + day++ * 8 * 3_600_000).toISOString(), home: a + 1, away: b + 1, hg: pois(lh), ag: pois(la) });
  }
  return { matches, att, def };
}

import { EventMatchingEngine } from '../src/engines/matching.js';
import { OddsStore } from '../src/engines/odds.js';
import { probsFromLambdas } from '../src/engines/prediction/poisson.js';
import type { Db as DbT } from '../src/db/db.js';

/**
 * Synthetische (NICHT echte) Liga mit bekannter Wahrheit in der DB – nur um die Backtest-Logik zu prüfen.
 * Marktquoten: pre_closing = Wahrheit + Rauschen + Marge (24 h vor Anstoß), closing = optional manipulierbar.
 */
export function insertSyntheticLeague(db: DbT, opts: { teams?: number; seasons?: number; marketNoise?: number; withOdds?: boolean; closingOdds?: number | null; seed?: string; spacingHours?: number; providerId?: string; name?: string } = {}) {
  const T = opts.teams ?? 16, seasons = opts.seasons ?? 4;
  const r = rng(opts.seed ?? 'synthetic');
  const att = Array.from({ length: T }, () => 0.65 + r() * 0.7), def = Array.from({ length: T }, () => 0.65 + r() * 0.7);
  const pois = (l: number) => { const L = Math.exp(-l); let k = 0, p = 1; do { k++; p *= r(); } while (p > L); return k - 1; };
  const match = new EventMatchingEngine(db), store = new OddsStore(db);
  let day = 0; const start = Date.UTC(2021, 7, 1); let n = 0;
  db.tx(() => {
    for (let s = 0; s < seasons; s++) for (let a = 0; a < T; a++) for (let b = 0; b < T; b++) {
      if (a === b) continue;
      const lh = 1.15 * att[a] * def[b] * 1.25, la = 1.15 * att[b] * def[a];
      const kickoff = new Date(start + day++ * (opts.spacingHours ?? 6) * 3_600_000).toISOString();
      const hg = pois(lh), ag = pois(la);
      const id = `${opts.providerId ?? 'syn'}-${s}-${a}-${b}`;
      const m = match.upsertFixture({ provider: 'synthetic-test', providerEventId: id, competition: { providerId: opts.providerId ?? 'syn', name: opts.name ?? 'Synthetische Testliga', countryCode: 'XX', season: String(2021 + s) },
        home: { providerId: (opts.providerId ?? 'syn') + ':' + a, name: `${opts.name ?? 'Syn'} Team ${a}` }, away: { providerId: (opts.providerId ?? 'syn') + ':' + b, name: `${opts.name ?? 'Syn'} Team ${b}` }, kickoffUtc: kickoff, status: 'finished', homeGoals: hg, awayGoals: ag });
      n++;
      if (opts.withOdds === false) continue;
      const truth = probsFromLambdas(lh, la, -0.08);
      const noise = opts.marketNoise ?? 0.02;
      const price = (ps: number[], margin: number) => { const q = ps.map(p => Math.max(0.02, p * (1 + (r() - 0.5) * 2 * noise))); const sum = q.reduce((x, y) => x + y, 0); return q.map(p => +(1 / ((p / sum) * (1 + margin))).toFixed(2)); };
      const pre = new Date(new Date(kickoff).getTime() - 24 * 3_600_000).toISOString(), close = new Date(new Date(kickoff).getTime() - 60_000).toISOString();
      for (const [bk, margin] of [['pinnacle', 0.025], ['softbook', 0.06]] as [string, number][]) {
        const [h, d, aw] = price([truth['1X2'].HOME, truth['1X2'].DRAW, truth['1X2'].AWAY], margin);
        const [o, u] = price([truth.OU.OVER, truth.OU.UNDER], margin);
        const base = { provider: 'synthetic-test', providerEventId: id, bookmakerProviderId: bk, bookmakerName: bk, marketStatus: 'open' as const, sourceTimestamp: null, timeEstimated: true };
        store.save(m.eventId, { ...base, market: '1X2', line: null, prices: { HOME: h, DRAW: d, AWAY: aw }, retrievedAt: pre, snapshotKind: 'pre_closing' }, [], false);
        store.save(m.eventId, { ...base, market: 'OU', line: 2.5, prices: { OVER: o, UNDER: u }, retrievedAt: pre, snapshotKind: 'pre_closing' }, [], false);
        if (opts.closingOdds !== null) {
          const c = opts.closingOdds; // absichtlich unrealistische Schlusskurse, um Look-Ahead zu erkennen
          store.save(m.eventId, { ...base, market: '1X2', line: null, prices: c ? { HOME: c, DRAW: c, AWAY: c } : { HOME: h, DRAW: d, AWAY: aw }, retrievedAt: close, snapshotKind: 'closing' }, [], false);
        }
      }
    }
  });
  return { matches: n };
}
