import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mapHlMatch, mapHlMarket, parseScore, HighlightlyProvider } from '../src/providers/highlightly.js';
import { convertOaEvent } from '../src/providers/theOddsApi.js';
import { parseCsv, rowsToFixtures, importFootballDataCsv } from '../src/providers/footballDataCsv.js';
import { ApiQueue } from '../src/api/apiQueue.js';
import { ProviderBlockedError } from '../src/providers/types.js';
import { memDb } from './helpers.js';
import { normName, nameSimilarity } from '../src/util/core.js';

// Beispielobjekt exakt in der Form der OpenAPI-Spezifikation (FootballMatchResponseDto)
const hlMatch = {
  id: 1234, round: 'Regular Season - 10', date: '2026-10-13T19:00:00.000Z',
  country: { code: 'PY', name: 'Paraguay', logo: '' },
  homeTeam: { id: 11, name: 'Cerro Porteño', logo: '', type: 'club' as const }, awayTeam: { id: 22, name: 'Olimpia', logo: '', type: 'club' as const },
  league: { id: 99, season: 2026, name: 'Primera División', logo: '' },
  state: { description: 'Finished', clock: 90, score: { current: '2 - 1', penalties: '' } },
};

test('Highlightly: Match-Mapping inkl. Status und Ergebnis', () => {
  const f = mapHlMatch(hlMatch);
  assert.equal(f.providerEventId, '1234');
  assert.equal(f.status, 'finished');
  assert.equal(f.homeGoals, 2); assert.equal(f.awayGoals, 1);
  assert.equal(f.competition.season, '2026');
  assert.equal(mapHlMatch({ ...hlMatch, state: { description: 'Not started' } }).status, 'scheduled');
  assert.equal(mapHlMatch({ ...hlMatch, state: { description: 'Second half', score: { current: '0 - 0' } } }).homeGoals, null);
  assert.deepEqual(parseScore('3 : 0'), [3, 0]);
  assert.equal(parseScore(''), null);
});

test('Highlightly: Odds-Marktzuordnung', () => {
  const x = mapHlMarket('Full Time Result', [{ odd: 2.1, value: 'Home' }, { odd: 3.3, value: 'Draw' }, { odd: 3.6, value: 'Away' }])!;
  assert.deepEqual(x[0], { market: '1X2', line: null, prices: { HOME: 2.1, DRAW: 3.3, AWAY: 3.6 } });
  const ou = mapHlMarket('Over/Under', [{ odd: 1.9, value: 'Over 2.5' }, { odd: 1.95, value: 'Under 2.5' }, { odd: 1.4, value: 'Over 1.5' }, { odd: 2.9, value: 'Under 1.5' }])!;
  assert.equal(ou.length, 2);
  assert.deepEqual(ou.find(o => o.line === 2.5)!.prices, { OVER: 1.9, UNDER: 1.95 });
  assert.deepEqual(mapHlMarket('Both Teams To Score', [{ odd: 1.8, value: 'Yes' }, { odd: 2.0, value: 'No' }])![0].prices, { YES: 1.8, NO: 2.0 });
  assert.deepEqual(mapHlMarket('Over/Under 1st Half', []), [], 'Halbzeitmärkte ignorieren');
  assert.equal(mapHlMarket('Some Exotic Market', []), null, 'unbekannter Markt → null (wird protokolliert)');
});

test('Highlightly: ohne bestätigte Nutzungsrechte gesperrt', async () => {
  const p = new HighlightlyProvider(new ApiQueue(memDb()), { apiKey: 'x', baseUrl: 'https://soccer.highlightly.net', rapidApiHost: null, bettingUseConfirmed: false });
  await assert.rejects(() => p.upcomingFixtures(new Date(), new Date()), ProviderBlockedError);
});

test('Highlightly: Anfragen nutzen dokumentierte Pfade, Parameter und Header', async () => {
  const db = memDb(); const calls: { url: string; headers: Record<string, string> }[] = [];
  const q = new ApiQueue(db, async (url, init) => { calls.push({ url, headers: init.headers }); return { status: 200, headers: { get: () => null }, text: async () => JSON.stringify({ data: [hlMatch], pagination: { totalCount: 1, offset: 0, limit: 100 }, plan: { tier: 'PRO', message: '' } }) }; });
  q.register({ provider: 'highlightly', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0 });
  const p = new HighlightlyProvider(q, { apiKey: 'secret-key', baseUrl: 'https://soccer.highlightly.net', rapidApiHost: null, bettingUseConfirmed: true });
  await p.historicalResults({ providerId: '99', name: 'x' }, '2026');
  const u = new URL(calls[0].url);
  assert.equal(u.origin + u.pathname, 'https://soccer.highlightly.net/matches');
  assert.equal(u.searchParams.get('leagueId'), '99'); assert.equal(u.searchParams.get('season'), '2026'); assert.equal(u.searchParams.get('limit'), '100');
  assert.equal(calls[0].headers['x-rapidapi-key'], 'secret-key');
  assert.equal(calls[0].headers['x-rapidapi-host'], undefined, 'Host-Header nur bei RapidAPI');
  assert.ok(!calls[0].url.includes('secret-key'), 'Schlüssel nie in der URL');
  const cached = db.get<{ cache_key: string }>('SELECT cache_key FROM api_cache')!;
  assert.ok(!cached.cache_key.includes('secret'));
});

test('The Odds API: Umwandlung h2h/totals/btts mit korrekter Heim/Gast-Zuordnung', () => {
  const e = { id: 'abc', sport_key: 'soccer_epl', sport_title: 'EPL', commence_time: '2026-10-13T19:00:00Z', home_team: 'Arsenal', away_team: 'Lille',
    bookmakers: [{ key: 'pinnacle', title: 'Pinnacle', last_update: '2026-10-12T11:58:00Z', markets: [
      { key: 'h2h', outcomes: [{ name: 'Lille', price: 14 }, { name: 'Arsenal', price: 1.22 }, { name: 'Draw', price: 6.8 }] },
      { key: 'totals', outcomes: [{ name: 'Over', price: 1.6, point: 2.5 }, { name: 'Under', price: 2.4, point: 2.5 }, { name: 'Over', price: 2.3, point: 3.5 }, { name: 'Under', price: 1.65, point: 3.5 }] },
      { key: 'btts', outcomes: [{ name: 'Yes', price: 2.1 }, { name: 'No', price: 1.72 }] },
    ] }] };
  const q = convertOaEvent(e, '2026-10-12T12:00:00Z');
  assert.deepEqual(q.find(x => x.market === '1X2')!.prices, { HOME: 1.22, DRAW: 6.8, AWAY: 14 });
  assert.deepEqual(q.find(x => x.market === 'OU' && x.line === 2.5)!.prices, { OVER: 1.6, UNDER: 2.4 });
  assert.equal(q.filter(x => x.market === 'OU').length, 2, 'Linien werden nicht vermischt');
  assert.deepEqual(q.find(x => x.market === 'BTTS')!.prices, { YES: 2.1, NO: 1.72 });
  assert.equal(q[0].sourceTimestamp, '2026-10-12T11:58:00Z');
});

const CSV = `Div,Date,Time,HomeTeam,AwayTeam,FTHG,FTAG,FTR,PSCH,PSCD,PSCA,PC>2.5,PC<2.5
E0,16/08/2024,20:00,Man United,Fulham,1,0,H,1.60,4.33,5.50,1.90,1.98
E0,17/08/2024,12:30,Ipswich,Liverpool,0,2,A,7.80,5.10,1.40,1.60,2.40
E0,17/08/2024,15:00,Arsenal,Wolves,2,0,H,1.22,7.00,13.00,,`;

test('football-data.co.uk CSV: Parsing und Import inkl. Pinnacle-Schlusskursen', () => {
  const rows = parseCsv(CSV);
  assert.equal(rows.length, 3);
  const fx = rowsToFixtures(rows, 't');
  assert.equal(fx[0].fx.homeGoals, 1); assert.equal(fx[0].fx.competition.name, 'Premier League');
  assert.equal(fx[0].odds.length, 2); assert.ok(fx[0].odds.every(o => o.snapshotKind === "closing")); assert.equal(fx[2].odds.length, 1, "fehlende OU-Quoten werden ausgelassen");
  const db = memDb();
  const r = importFootballDataCsv(db, CSV);
  assert.equal(r.matches, 3);
  assert.equal(db.get<{ n: number }>("SELECT COUNT(*) AS n FROM events WHERE status = 'finished'")!.n, 3);
  assert.equal(db.get<{ n: number }>("SELECT COUNT(*) AS n FROM odds_snapshots WHERE validation_errors = '[]'")!.n, 5);
  // erneuter Import ist idempotent
  importFootballDataCsv(db, CSV);
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM events')!.n, 3);
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM odds_snapshots')!.n, 5);
});

test('Namensnormalisierung und Ähnlichkeit', () => {
  assert.equal(normName('Bodø/Glimt'), normName('Bodo Glimt'));
  assert.equal(normName('FC Bayern München'), normName('Bayern Munchen'));
  assert.ok(nameSimilarity('Manchester United', 'Manchester City') < 0.85);
  assert.ok(nameSimilarity('Real Madrid', 'Atlético Madrid') < 0.85);
  assert.ok(nameSimilarity('Cerro Porteño', 'Club Cerro Porteno') >= 0.85);
});
