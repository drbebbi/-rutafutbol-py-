/**
 * KI-Analyst (früher EDGE ANALYST) als Analyse-Konsole. Die Antwort (Text) kommt unverändert vom Backend.
 * Strukturierte Blöcke (MATCH, MARKET, MODEL, DATA, RISKS, VERDICT) werden NUR aus den Werkzeug-Daten
 * gebildet, die das Backend mitliefert (response.data). Fehlen Daten, fehlt der Block – es wird nichts ergänzt.
 */
import React, { useEffect, useRef, useState } from 'react';
import { api, fx, pct, signed, localTime } from '../api';
import { SEL, MKT } from '../i18n';
import { tr } from '../reasons';
import { ANALYST } from '../brand';
import { useApp } from '../components';
import { Badge, Button, EdgeMeter, MockChip, PageHeader, SignalBadge, Skeleton, StatusBadge } from '../ui';

interface Turn { q: string; a?: { answer: string; mode: string; toolsUsed: string[]; data: unknown[]; model?: string; fallbackReason?: string }; err?: string }

const isEventAnalysis = (d: any) => d && typeof d === 'object' && d.event && 'signals' in d;
const isSignalList = (d: any) => Array.isArray(d) && d.length > 0 && d.every((x: any) => x == null || (x && 'market' in x && 'selection' in x && 'match' in x));
const isOddsAges = (d: any) => Array.isArray(d) && d.length > 0 && d.every((x: any) => x && 'age_minutes' in x && 'bookmaker' in x);
const isModelStatus = (d: any) => d && typeof d === 'object' && 'modelVersions' in d;
const isPerformance = (d: any) => d && typeof d === 'object' && 'settled' in d && 'roi' in d;

function Block({ code, title, children, className = '' }: { code: string; title?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return <div className={`ablock ${className}`}><div className="bh"><h4>{code}</h4>{title}</div>{children}</div>;
}

function Answer({ a }: { a: NonNullable<Turn['a']> }) {
  const { t, u, lang, tz } = useApp();
  const blocks: React.ReactNode[] = [];
  const risks: string[] = [];
  let verdictBadge: React.ReactNode = null;
  for (const d of a.data ?? []) {
    if (isEventAnalysis(d)) {
      const x = d as any, p = x.prediction, dq = p?.data_quality;
      const sigs = (x.signals ?? []).filter(Boolean).sort((m: any, n: any) => (n.ev_low ?? -9) - (m.ev_low ?? -9));
      const best = sigs[0];
      verdictBadge = best ? <SignalBadge s={best.status} /> : null;
      blocks.push(<Block key="match" code={u.bMatch} title={x.event.mock ? <MockChip /> : null}>
        <b>{x.event.match}</b><span className="t-2 small">{x.event.competition} · {localTime(x.event.kickoff_utc, tz, lang)}</span></Block>);
      if (best) blocks.push(<Block key="market" code={u.bMarket} title={<SignalBadge s={best.status} />}>
        <div className="row-flex between"><b>{MKT[best.market]} · {SEL[lang][best.selection] ?? best.selection}</b><span className="small t-2">{best.bookmaker ?? ''} · <b className="cy">{fx(best.best_odds)}</b></span></div>
        <EdgeMeter decision={best.decision_prob ?? best.model_prob} fair={best.novig_prob} odds={best.best_odds} />
        <dl className="kv small"><dt>EV</dt><dd className={best.ev > 0 ? 'pos' : 'neg'}>{signed(best.ev)} ({t.evLow} {signed(best.ev_low)})</dd><dt>{t.fairOdds}</dt><dd>{fx(best.fair_odds)}</dd></dl>
      </Block>);
      if (p) blocks.push(<Block key="model" code={u.bModel} title={<span className="t-3 xs">{p.model_version}</span>}>
        <dl className="kv small">
          <dt>λ</dt><dd>{fx(p.lambda_home)} – {fx(p.lambda_away)}</dd>
          <dt>1 / X / 2</dt><dd>{pct(p.probs['1X2']?.HOME)} / {pct(p.probs['1X2']?.DRAW)} / {pct(p.probs['1X2']?.AWAY)}</dd>
          {best ? <><dt>{t.modelProb}</dt><dd>{pct(best.model_prob)}</dd><dt>{t.decisionProb}</dt><dd>{pct(best.decision_prob)}{best.model_weight != null ? ` · ${Math.round(best.model_weight * 100)} % / ${Math.round((1 - best.model_weight) * 100)} %` : ''}</dd></> : null}
        </dl></Block>);
      if (dq) {
        blocks.push(<Block key="data" code={u.bData} title={<Badge tone={dq.status === 'good' ? 'value' : dq.status === 'insufficient' ? 'avoid' : 'watch'}>{dq.score}/100</Badge>}>
          <dl className="kv small"><dt>{t.lineups}</dt><dd>{dq.lineups}</dd><dt>Home / Away</dt><dd>{dq.homeGames} / {dq.awayGames}</dd></dl></Block>);
        risks.push(...(dq.issues ?? []));
      }
      if (best?.reasons) risks.push(...best.reasons.filter((r: string) => /UNVALIDATED|MOCK|STALE|korrel|Untergrenze|negativ|unsicher|fehlt|keine/i.test(r)));
      if (best && best.ev_low != null && best.ev_low <= 0) risks.push(`${t.evLow} ${signed(best.ev_low)}`);
    } else if (isSignalList(d)) {
      const list = (d as any[]).filter(Boolean);
      blocks.push(<Block key={'sig' + blocks.length} code={u.bMarket} className="wide"><div className="siglist">{list.map((s: any, i: number) => <div key={i} className="sigitem">
        <div className="si-main"><b>{s.match}</b><span className="t-3 xs">{s.competition}{s.mock ? ' · MOCK' : ''}</span></div>
        <span className="small t-2">{MKT[s.market]} · {SEL[lang][s.selection] ?? s.selection}</span>
        <span className="si-num"><b className="cy">{fx(s.best_odds)}</b><span className={s.ev > 0 ? 'pos' : 'neg'}>{signed(s.ev)}</span><SignalBadge s={s.status} /></span>
      </div>)}</div></Block>);
      if (list.some((s: any) => s.mock)) risks.push('MOCK');
    } else if (isOddsAges(d)) {
      blocks.push(<Block key="ages" code={u.bData} className="wide"><div className="tablewrap"><table><tbody>{(d as any[]).map((x: any, i: number) => <tr key={i}>
        <td>{MKT[x.market] ?? x.market}</td><td className="small">{x.bookmaker} · {x.provider}{x.from_cache ? ' · cache' : ''}</td><td className="n">{x.age_minutes ?? '–'} / {x.limit_minutes} min</td>
        <td>{x.current ? <Badge tone="value">OK</Badge> : <Badge tone="avoid">STALE ODDS</Badge>}</td></tr>)}</tbody></table></div></Block>);
      if ((d as any[]).some((x: any) => !x.current)) risks.push('STALE ODDS');
    } else if (isModelStatus(d)) {
      const m = d as any;
      blocks.push(<Block key="ms" code={u.bModel}>{(m.modelVersions ?? []).map((v: any) => <div key={v.id} className="row-flex between small"><span className="t-2">{v.id}</span><StatusBadge s={v.validation_status} /></div>)}
        {m.latestBacktest ? <span className="t-3 xs">Backtest #{m.latestBacktest.id} · {m.latestBacktest.dataSource} · {m.latestBacktest.validation?.status}</span> : null}</Block>);
      if ((m.modelVersions ?? []).every((v: any) => v.validation_status !== 'VALIDATED')) risks.push(t.unvalidatedHint);
    } else if (isPerformance(d)) {
      const p = d as any;
      blocks.push(<Block key="perf" code={u.bData}><dl className="kv small"><dt>{t.settled}</dt><dd>{p.settled}</dd><dt>ROI</dt><dd>{signed(p.roi)}</dd><dt>{t.winRate}</dt><dd>{pct(p.winRate)}</dd><dt>{t.clv}</dt><dd>{signed(p.avgClv, 2)}</dd></dl>
        {p.settled < 30 ? <Badge tone="watch">{u.smallSample}</Badge> : null}</Block>);
    }
  }
  const uniq = [...new Set(risks)];
  return <div className="blocks">
    {blocks}
    {blocks.length ? <Block code={u.bRisks} className="risks">{uniq.length ? <ul className="reasons">{uniq.map(r => <li key={r}>{tr(r, lang)}</li>)}</ul> : <span className="t-2 small">{u.noRisks}</span>}</Block> : null}
    <Block code={u.bVerdict} className="verdict wide" title={verdictBadge}>
      <div className="text">{a.answer}</div>
      <span className="meta">{a.mode === 'llm' ? `${t.modeLlm}${a.model ? ` (${a.model})` : ''}` : t.modeRules}{a.mode === 'rules' && a.fallbackReason ? ` · ${tr(a.fallbackReason, lang)}` : ''}{a.toolsUsed?.length ? ` · ${u.toolsUsed}: ${a.toolsUsed.join(', ')}` : ''}{!blocks.length ? ` · ${u.noStructured}` : ''}</span>
    </Block>
  </div>;
}

export function Console({ eventQuery }: { eventQuery?: string }) {
  const { t, u, lang } = useApp();
  const [turns, setTurns] = useState<Turn[]>([]);
  const [q, setQ] = useState(''), [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }, [turns.length, busy]);
  const ask = async (question: string) => {
    if (!question.trim() || busy) return;
    const hist = turns.filter(x => x.a).flatMap(x => [{ role: 'user', content: x.q }, { role: 'assistant', content: x.a!.answer }]);
    setTurns(ts => [...ts, { q: question }]); setQ(''); setBusy(true);
    try { const r = await api<any>('/api/analyst', { method: 'POST', body: JSON.stringify({ question, lang, history: hist }) }); setTurns(ts => ts.map((x, i) => i === ts.length - 1 ? { ...x, a: r } : x)); }
    catch (e) { setTurns(ts => ts.map((x, i) => i === ts.length - 1 ? { ...x, err: (e as Error).message } : x)); }
    finally { setBusy(false); }
  };
  const sugg = eventQuery
    ? [`${eventQuery}: ${lang === 'de' ? 'Analyse' : lang === 'en' ? 'analysis' : 'análisis'}`, `${eventQuery}: ${lang === 'de' ? 'Warum empfiehlt das Modell diesen Markt?' : lang === 'en' ? 'why does the model recommend this market?' : '¿por qué recomienda el modelo este mercado?'}`, `${eventQuery}: ${lang === 'de' ? 'Wie alt sind die Quoten?' : lang === 'en' ? 'how old are the odds?' : '¿qué tan vieja es la cuota?'}`]
    : t.suggestions;
  return (
    <div className="console">
      <div className="card console-input">
        <form onSubmit={e => { e.preventDefault(); void ask(q); }}>
          <input id="chat-q" value={q} onChange={e => setQ(e.target.value)} placeholder={t.askPlaceholder} maxLength={1000} aria-label={t.askPlaceholder} autoComplete="off" />
          <Button disabled={busy || !q.trim()} icon="send">{u.ask}</Button>
        </form>
        <div className="suggest">{sugg.map(s => <button key={s} type="button" onClick={() => ask(s)} disabled={busy}>{s}</button>)}</div>
      </div>
      {turns.map((x, i) => <div key={i} className="qa">
        <div className="q"><span className="who">{u.asked}</span><span>{x.q}</span></div>
        {x.a ? <Answer a={x.a} /> : x.err ? <div className="banner error"><span>{t.error}: {x.err}</span></div> : <Skeleton lines={3} height={40} />}
      </div>)}
      {turns.length ? <div><Button variant="quiet" size="sm" onClick={() => setTurns([])} disabled={busy}>{u.clear}</Button></div> : null}
      <div ref={end} />
    </div>
  );
}

export function EdgeAI() {
  const { u, t, lang } = useApp();
  return <><PageHeader title={ANALYST[lang]} lead={<><b style={{ color: 'var(--text)', fontWeight: 500 }}>{u.console}.</b> {u.consoleLead} {t.disclaimer}</>} /><Console /></>;
}
