# The Odds API – Integration (v0.3.3)

Stand: 13.10.2026. Marke: CanchaIA (technischer Projektname `aposta-edge-ai`).

> **Ehrlicher Status:** Die Integration ist im Projekt umgesetzt und mit nachgebauten Antworten automatisiert getestet.
> Ein **Live-Test mit dem echten Schlüssel wurde NICHT ausgeführt**: In der Entwicklungsumgebung war das Secret
> `THE_ODDS_API_KEY` nicht gesetzt, und `api.the-odds-api.com` ist dort durch die Egress-Richtlinie gesperrt
> (CONNECT → HTTP 403). Die produktive Anwendung wurde **nicht** verändert. Die Schritte unten sind auf deinem Server nötig.

## 1. Was die Integration tut

| Bereich | Umsetzung |
|---|---|
| Secret | Nur `THE_ODDS_API_KEY` (bisheriger Name, kein Alias nötig). Wird ausschließlich serverseitig gelesen. |
| Basis-URL | `THE_ODDS_API_BASE_URL` mit oder ohne `/v4` (vorher führte `…/v4` zu `/v4/v4/…`). |
| Verbindungstest | `GET /v4/sports` (laut Anbieter kostenlos), **genau ein Versuch**, kein Cache, 0 Credits. Speichert HTTP-Status, Sportarten, Status von `soccer_uefa_champs_league`, `x-requests-remaining/-used/-last`. |
| Status | **CONNECTED** nur nach bestandenem, authentifiziertem Test ohne spätere Zugangsfehler. **DEGRADED** bei Sperre, aufgebrauchtem Budget, inaktivem Sport-Key, fehlerhaftem Quotenabruf oder > 24 h ohne erfolgreichen Abruf. Sonst **DISCONNECTED**. |
| Sperre | Kostenpflichtige Endpunkte (`/odds`, `/events/{id}/odds`, `/scores`) sind **gesperrt, bis ein Test bestanden ist**. Das gilt auch für den automatischen Scheduler. Ein 401/403 nach dem Test sperrt erneut. |
| Märkte | `/odds?markets=h2h,totals&regions=eu&oddsFormat=decimal`. 1X2 nur mit Heim/Unentschieden/Auswärts (`h2h_3_way` als Ersatz, keine Duplikate). Über/Unter nur Linie 2,5. BTTS nur über den Event-Endpunkt (`markets=btts`), standardmäßig aus. |
| Kosten | Standard eine Region (`eu`). Vor jedem kontrollierten Lauf gibt es einen Kostenvoranschlag (Wettbewerbe × Märkte × Regionen + BTTS + Ergebnisse) gegen Tagesbudget, Monatsbudget und die vom Anbieter gemeldeten Restcredits. Reicht es nicht, wird nichts abgerufen. Zusätzlich stoppt die Queue jeden Abruf, für den der Anbieter zu wenig Restcredits gemeldet hat. |
| Budgets | 500 Credits/Monat, 16/Tag (wie bisher; neu explizit `THE_ODDS_API_DAILY_BUDGET`). Tatsächliche Kosten aus `x-requests-last`. |
| LIVE/MOCK | Echte Daten nur im Live-Modus. Mock-Daten werden dort nie ausgeliefert. Im Mock-Modus wird The Odds API nie aufgerufen (Status DISCONNECTED/MOCK). |
| Admin | Karte **THE ODDS API**: Status, letzter Test, letzter erfolgreicher Quotenabruf, Restcredits/verbraucht/letzte Kosten, Budgets, API-Fehler, echte importierte Spiele, Buchmacher, Märkte, Datenaktualität, LIVE/MOCK, Kostenvoranschlag. Button „Verbindung testen (kostenlos)“. Alles kommt aus `GET /api/admin/providers/theoddsapi`. |
| Schlüsselschutz | Schlüssel nie im Frontend, in API-Antworten, im Abrufprotokoll, im Cache-Schlüssel oder in der DB. Die Log-Bereinigung wurde repariert: `authorization: Bearer …` wird jetzt wirklich geschwärzt, Hinweise wie „THE_ODDS_API_KEY fehlt“ bleiben lesbar. |

**Wichtig für die Champions League:** Die Quoten kommen dann echt an, aber die Prognosemodelle haben für `soccer_uefa_champs_league` **keine Historie**. football-data.co.uk liefert keine CSV für die Champions League, und die Historie wird je Wettbewerb geladen. Die Engine markiert diese Spiele deshalb als **INSUFFICIENT DATA** und erzeugt **keine** Value Bets. Das ist beabsichtigt: Es werden keine Modellwahrscheinlichkeiten erfunden. Eine erfolgreiche Quotenintegration bedeutet außerdem nicht, dass die Modelle kalibriert sind (Status weiterhin **UNVALIDATED**).

## 2. Deployment auf deinem Server (konkrete Schritte)

1. **Secret eintragen.** Nur in der Secret-Verwaltung der Ausführungsumgebung, nie in Git, ZIP oder Chat:
   - Docker Compose: `.env` neben `docker-compose.yml` (Rechte `600`), Zeile `THE_ODDS_API_KEY=…`, oder Docker-/Plattform-Secret
   - systemd: `EnvironmentFile=/etc/canchaia/env` (Rechte `600`, Eigentümer root)
   - PaaS: Secret-Einstellungen der Plattform
2. **Weitere Variablen** (siehe `.env.example`):
   ```
   DATA_MODE=live
   THE_ODDS_API_REGIONS=eu
   THE_ODDS_API_SPORT_KEYS=soccer_uefa_champs_league
   THE_ODDS_API_MONTHLY_BUDGET=500
   THE_ODDS_API_INCLUDE_BTTS=false
   ```
   Optional bis zur Prüfung: `SCHEDULER_ENABLED=false`. Nötig ist das nicht, weil kostenpflichtige Abrufe ohnehin bis zum bestandenen Test gesperrt sind.
3. **Neue Version einspielen** (Ordnername `Aposta_Edge_AI` beibehalten, sonst ändert sich der Docker-Volume-Name). Danach `npm run build` bzw. `docker compose up -d --build`. Migration `007` läuft automatisch und ist rein ergänzend.
4. **Kostenloser Verbindungstest** (0 Credits, ein Versuch). Alternativ Admin → THE ODDS API → „Verbindung testen“:
   ```
   docker compose exec aposta-edge-ai node dist/src/cli.js odds-check
   # ohne Docker: npm --prefix backend run odds:check
   ```
   Erwartet: `ok: true`, `httpStatus: 200`, `soccer_uefa_champs_league: ACTIVE`, Werte für `x-requests-remaining/-used`. Status → CONNECTED.
5. **Höchstens EIN kostenpflichtiger Testabruf** (geschätzt 2 Credits: 1 Wettbewerb × 2 Märkte × 1 Region). Im Admin unter „Sincronización controlada / Kontrollierter Sync“ (läuft unter dem Sync-Lock) oder per CLI bei gestopptem Server:
   ```
   node dist/src/cli.js odds-check --paid-test
   ```
   Der Lauf bricht ohne Abruf ab, wenn Test, Budget oder Restcredits nicht passen. Danach zeigt die Admin-Karte echte Spiele, Buchmacher, Märkte und Datenaktualität.
6. **BTTS erst danach** bewusst aktivieren: `THE_ODDS_API_INCLUDE_BTTS=true`, `THE_ODDS_API_BTTS_MAX_EVENTS=2`. Kosten: 1 Credit je Spiel und Region, nur wenn der Anbieter BTTS liefert.

### Credit-Planung (500/Monat, eine Region, nur Champions League)
- Ein Quotenabruf kostet 2 Credits. Das Tagesbudget 16 reicht für 8 Abrufe pro Tag. Bei stündlichem Sync ist das Tagesbudget nach 8 Läufen erreicht, danach stoppt die Queue bis zum nächsten UTC-Tag.
- Ergebnisse (`/scores`) kosten 2 Credits je Abruf, wenn begonnene Spiele offen sind (Cache 30 min).
- Empfehlung: `SYNC_INTERVAL_MINUTES=180` oder höher. An Champions-League-Abenden liegen die Kosten dann bei etwa 8 Abrufen pro Tag.

## 3. Geänderte und neue Dateien

- `backend/src/db/migrations/007_v033_odds_api_status.sql` (neu): `provider_health.quota_used`, Tabelle `provider_connection_tests`
- `backend/src/engines/oddsApiStatus.ts` (neu): Verbindungstest, Status, Sperre, Kostenvoranschlag
- `backend/src/api/apiQueue.ts`: `x-requests-used`, `noRetry`, Stopp bei zu wenig Anbieter-Restcredits, Status und Kontingent in der Antwort
- `backend/src/providers/theOddsApi.ts`: Basis-URL-Normalisierung, Linie 2,5, `h2h_3_way`, Sperre kostenpflichtiger Endpunkte
- `backend/src/app.ts`: Sperre verdrahtet (`requireOddsConnectionTest`, Standard an bei echtem Netzwerk), `x-requests-used` registriert
- `backend/src/config.ts`: Regionen-Standard `eu`, `THE_ODDS_API_DAILY_BUDGET`, Warnungen (mehrere Regionen, leere Sport-Keys, Schlüssel in URL)
- `backend/src/engines/diagnostic.ts`: Vorprüfung im kontrollierten Sync (`NOT CONNECTED`, `BUDGET`, Kostenvoranschlag)
- `backend/src/server.ts`: `GET /api/admin/providers/theoddsapi`, `POST /api/admin/providers/theoddsapi/test` (Admin, max. 2/min)
- `backend/src/cli.ts`, `backend/package.json`: `odds-check [--paid-test]`, `npm run odds:check`
- `backend/src/util/log.ts`: Log-Bereinigung repariert
- `backend/test/v033_odds_api.test.ts` (neu, 16 Tests); `backend/test/migration.test.ts`: für Migration 007 geöffnet
- `frontend/src/oddsapi.tsx` (neu), `frontend/src/pages/admin.tsx`, `frontend/src/ui.tsx`, `frontend/src/styles.css`
- `.env.example`, Versionen 0.3.3, Doku


### Nachtrag v0.3.4 – kostenfreie Spielsuche

Die Discovery verwendet jetzt `GET /v4/sports/soccer_uefa_champs_league/events`
mit `commenceTimeFrom` und `commenceTimeTo` (0 Credits). Erst für priorisierte
Spiele wird `GET /v4/sports/{sport}/odds` mit `h2h,totals` aufgerufen.
BTTS bleibt separat und standardmäßig deaktiviert. Der offizielle Endpunkt
`/events` liefert ausdrücklich **keine Quoten**. Es gibt keinen automatischen
kostenpflichtigen Abruf, wenn die Liste priorisierter Spiele leer ist.

Für einen einmaligen Produktionstest die Secrets **in der Laufzeitumgebung** setzen:
`THE_ODDS_API_KEY`, `DATA_MODE=live`, `THE_ODDS_API_SPORT_KEYS=soccer_uefa_champs_league`,
`THE_ODDS_API_REGIONS=eu`, `SCHEDULER_ENABLED=false`, `THE_ODDS_API_INCLUDE_BTTS=false`,
`THE_ODDS_API_RESULTS=false`. Danach den kostenlosen `odds:check` starten; erst
nach erfolgreichem HTTP 200 und bestätigtem Restbudget `odds:check -- --paid-test`.
Die Tests im ZIP sind ausschließlich lokal/simuliert, kein erfolgreicher Provider-Live-Test.


## v0.4.0 – Kostenkontrolle und Nachweise

- **Getrennte Jobs:** `discovery` (nur `GET /v4/sports` und `/v4/sports/{sport}/events`, laut offizieller V4-Doku kostenlos; Intervall `THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES`, Standard 30) und `hourly_sync` (Quoten, Ergebnisse, Analyse; `THE_ODDS_API_ODDS_INTERVAL_MINUTES`, Standard 60).
- **Budget vor dem ersten bezahlten Abruf:** verfügbar = Minimum aus Tagesbudget, Monatsbudget und Anbieter-Restcredits (`x-requests-remaining`). Kosten je `/odds`-Abruf = Märkte × Regionen. Wettbewerbe werden nach nächstem Anstoß abgerufen, solange das Budget reicht, der Rest wird mit Grund übersprungen.
- **Ergebnisse gebündelt:** ein `/scores?daysFrom=3` (2 Credits) je Wettbewerb mit offenen Spielen der letzten 3 Tage, sonst kein Abruf.
- **Cache-Schlüssel** mit stündlich gerundeten Zeitfenstern. Antworten werden exakt auf das angefragte Fenster gefiltert, begonnene Spiele verworfen.
- **Admin → THE ODDS API → Nachweise:** Verbindung (kostenlos) ≠ Spielsuche (kostenlos) ≠ Quoten (kostenpflichtig, nur mit gültigen gespeicherten Snapshots) ≠ Prognosen mit echten Quoten. Dazu letzter echter Abruf mit HTTP-Status und Credits sowie nächste geplante Läufe.
- **Live-Status v0.4.0:** nur `/v4/sports` mit absichtlich ungültigem Schlüssel echt geprüft (HTTP 401 korrekt). Alles andere ist NOT LIVE VERIFIED.
