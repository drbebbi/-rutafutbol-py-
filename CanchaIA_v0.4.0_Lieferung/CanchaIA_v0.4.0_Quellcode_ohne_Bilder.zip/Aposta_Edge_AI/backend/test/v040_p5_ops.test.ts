/**
 * v0.4.0 – Priorität 5: Konfiguration, .env-Verhalten, KI-Analyst-Fallback, Migration 008.
 * Der Analyst wird mit einem eingespielten Fetcher geprüft (kein Netzwerk, kein echter Schlüssel).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ConfigError, loadConfig } from '../src/config.js';
import { loadDotEnv } from '../src/env.js';
import { EdgeAnalyst } from '../src/engines/analyst.js';
import { Db, migrate } from '../src/db/db.js';
import { ValueBettingEngine } from '../src/engines/value.js';
import { PredictionEngine } from '../src/engines/prediction/index.js';
import { ANCHOR, mockApp } from './helpers.js';

test('P5: ungültiges DATA_MODE / STRATEGY wird nicht stillschweigend als Mock / BALANCED übernommen', () => {
  assert.throws(() => loadConfig({ DATA_MODE: 'Live ' } as NodeJS.ProcessEnv), ConfigError);
  assert.throws(() => loadConfig({ DATA_MODE: 'production' } as NodeJS.ProcessEnv), /DATA_MODE="production" ist ungültig/);
  assert.throws(() => loadConfig({ STRATEGY: 'YOLO' } as NodeJS.ProcessEnv), ConfigError);
  assert.equal(loadConfig({ DATA_MODE: 'live' } as NodeJS.ProcessEnv).dataMode, 'live');
  assert.equal(loadConfig({} as NodeJS.ProcessEnv).dataMode, 'mock', 'nicht gesetzt → Mock (mit Hinweis in configIssues)');
  assert.equal(loadConfig({ STRATEGY: 'conservative' } as NodeJS.ProcessEnv).analysis.strategy, 'CONSERVATIVE');
  const c = loadConfig({} as NodeJS.ProcessEnv);
  assert.equal(c.analysis.minEv, 0.05); assert.equal(c.analysis.strategy, 'BALANCED'); assert.equal(c.analysis.maxRecommendations, 5); assert.equal(c.timezone, 'America/Asuncion');
});

test('P5: .env – echte Umgebungsvariablen haben Vorrang, leere Platzhalter werden ignoriert, ENV_FILE=none lädt nichts', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'canchaia-env-'));
  fs.writeFileSync(path.join(dir, '.env'), 'DATA_MODE=live\nTHE_ODDS_API_KEY=from-file-NOT-REAL\nADMIN_EMAIL=\n# Kommentar\nMIN_EV=0.07\n');
  const env: NodeJS.ProcessEnv = { THE_ODDS_API_KEY: 'from-real-env-NOT-REAL' };
  const r = loadDotEnv(env, dir);
  assert.equal(r.file, path.join(dir, '.env'));
  assert.equal(env.THE_ODDS_API_KEY, 'from-real-env-NOT-REAL', 'Secret aus der echten Umgebung wird nicht überschrieben');
  assert.equal(env.DATA_MODE, 'live'); assert.equal(env.MIN_EV, '0.07');
  assert.equal(env.ADMIN_EMAIL, undefined, 'leerer Platzhalter gilt nicht als gesetzt');
  assert.equal(r.applied, 2); assert.equal(r.skippedExisting, 1);
  assert.ok(!JSON.stringify(r).includes('NOT-REAL'), 'Ergebnis enthält keine Werte');
  assert.equal(loadDotEnv({ ENV_FILE: 'none' }, dir).file, null);
  assert.match(loadDotEnv({ ENV_FILE: 'fehlt.env' }, dir).error ?? '', /nicht gefunden/);
});

function fakeAnthropic(reply: (body: any) => { status: number; json: unknown }) {
  const seen: { headers: Record<string, string>; body: any }[] = [];
  const f = (async (_url: string, init: { headers: Record<string, string>; body: string }) => {
    const body = JSON.parse(init.body); seen.push({ headers: init.headers, body });
    const r = reply(body);
    return { ok: r.status >= 200 && r.status < 300, status: r.status, json: async () => r.json } as Response;
  }) as unknown as typeof fetch;
  return { f, seen };
}

test('P5: KI-Analyst – ohne Schlüssel klar gekennzeichneter lokaler Regelmodus', async () => {
  const app = await mockApp();
  const a = await new EdgeAnalyst(app.db, app.cfg).ask('top', 'es', [], ANCHOR);
  assert.equal(a.mode, 'rules');
  assert.match(a.fallbackReason ?? '', /kein KI-Schlüssel konfiguriert: lokaler Regelmodus/);
});

test('P5: KI-Analyst – Modell konfigurierbar, effort und Server-Fallback nur für unterstützte Modelle; Fehler/Ablehnung → gekennzeichneter Fallback', async () => {
  const app = await mockApp({ ANTHROPIC_API_KEY: 'sk-test-NOT-REAL' });
  assert.equal(app.cfg.anthropic.model, 'claude-sonnet-5-5');
  const ok = fakeAnthropic(() => ({ status: 200, json: { model: 'claude-sonnet-5-5', stop_reason: 'end_turn', content: [{ type: 'thinking', thinking: '' }, { type: 'text', text: 'Respuesta' }] } }));
  const r1 = await new EdgeAnalyst(app.db, app.cfg, ok.f).ask('hola', 'es', [], ANCHOR);
  assert.equal(r1.mode, 'llm'); assert.equal(r1.answer, 'Respuesta'); assert.equal(r1.model, 'claude-sonnet-5-5');
  assert.equal(ok.seen[0].body.model, 'claude-sonnet-5-5');
  assert.deepEqual(ok.seen[0].body.output_config, { effort: 'low' });
  assert.equal(ok.seen[0].body.fallbacks, 'default');
  assert.equal(ok.seen[0].headers['anthropic-beta'], 'server-side-fallback-2026-07-01');
  assert.ok(!JSON.stringify(ok.seen[0].body).includes('sk-test'), 'Schlüssel nur im Header');
  // Anderes Modell per Konfiguration; ohne Server-Fallback-Unterstützung kein beta-Header
  const app2 = await mockApp({ ANTHROPIC_API_KEY: 'sk-test-NOT-REAL', ANTHROPIC_MODEL: 'claude-haiku-5-5', ANTHROPIC_EFFORT: 'none' });
  const ok2 = fakeAnthropic(() => ({ status: 200, json: { stop_reason: 'end_turn', content: [{ type: 'text', text: 'x' }] } }));
  await new EdgeAnalyst(app2.db, app2.cfg, ok2.f).ask('hola', 'es', [], ANCHOR);
  assert.equal(ok2.seen[0].body.model, 'claude-haiku-5-5');
  assert.equal(ok2.seen[0].body.fallbacks, undefined); assert.equal(ok2.seen[0].headers['anthropic-beta'], undefined); assert.equal(ok2.seen[0].body.output_config, undefined);
  // Unbekanntes Modell (HTTP 404) → Regelmodus mit Grund
  const nf = fakeAnthropic(() => ({ status: 404, json: { type: 'error' } }));
  const r3 = await new EdgeAnalyst(app.db, app.cfg, nf.f).ask('top', 'es', [], ANCHOR);
  assert.equal(r3.mode, 'rules'); assert.match(r3.fallbackReason ?? '', /HTTP 404/);
  // Ablehnung und abgeschnittene Antwort werden nicht als Analyse ausgegeben
  for (const stop of ['refusal', 'max_tokens']) {
    const x = fakeAnthropic(() => ({ status: 200, json: { stop_reason: stop, content: [] } }));
    const r = await new EdgeAnalyst(app.db, app.cfg, x.f).ask('top', 'es', [], ANCHOR);
    assert.equal(r.mode, 'rules', stop); assert.match(r.fallbackReason ?? '', new RegExp(stop));
  }
});

test('P5: Upgrade v0.3.4 → v0.4.0 (Migration 008) erhält Daten; alte Signale ohne Signatur werden genau einmal neu versioniert; Neustart idempotent', async () => {
  const dir = path.resolve('src/db/migrations');
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  // Den Stand von v0.3.4 nachbilden: eine DB mit 001–007 und denselben Daten
  const file = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'canchaia-up-')), 'db.sqlite');
  const old = new Db(file);
  old.exec('CREATE TABLE schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  for (const f of fs.readdirSync(dir).filter(f => f < '008').sort()) { old.exec(fs.readFileSync(path.join(dir, f), 'utf8')); old.run('INSERT INTO schema_migrations VALUES (?, ?)', f, 'x'); }
  old.run("INSERT INTO competitions (id, name) VALUES (1, 'L')");
  old.run("INSERT INTO teams (id, name, norm_name) VALUES (1, 'A', 'a'), (2, 'B', 'b')");
  old.run("INSERT INTO events (id, competition_id, home_team_id, away_team_id, kickoff_utc, status) VALUES (1, 1, 1, 2, '2030-01-01T19:00:00Z', 'scheduled')");
  old.run(`INSERT INTO predictions (id, event_id, model_version, created_at, probs, components, uncertainty, data_quality, inputs_hash) VALUES (1, 1, 'ensemble-1.0.0', '2026-10-01T00:00:00Z', '{}', '[]', '{}', '{"score":0,"status":"insufficient","issues":[]}', 'h')`);
  old.run(`INSERT INTO value_signals (id, event_id, prediction_id, market_id, selection_id, status, reasons, active, created_at) VALUES (1, 1, 1, '1X2', 'HOME', 'VALUE', '[]', 1, '2026-10-01T00:00:00Z')`);
  old.run("INSERT INTO model_versions (id, description, weights, validation_status) VALUES ('ensemble-1.1.0+bt7', 'alt', '{}', 'VALIDATED')");
  old.close();
  const db = new Db(file);
  assert.deepEqual(migrate(db), ['008_v040_pilot_consistency.sql']);
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM value_signals')!.n, 1, 'Signal erhalten');
  assert.equal(db.get<{ s: string | null }>('SELECT calc_signature AS s FROM value_signals WHERE id = 1')!.s, null);
  assert.equal(db.get<{ v: string }>("SELECT validation_status AS v FROM model_versions WHERE id = 'ensemble-1.1.0+bt7'")!.v, 'VALIDATED', 'alte Modellversion unverändert');
  assert.equal(new PredictionEngine(db).currentModelVersion(1).status, 'UNVALIDATED', 'alte globale Validierung gilt ohne Scope-Eintrag nicht mehr');
  db.run("INSERT INTO model_scope_validations (model_version_id, competition_id, market_id, status, market_evidence, holdout_n, market_n, reasons, created_at) VALUES ('ensemble-1.1.0+bt7', 1, 'OU', 'UNVALIDATED', 'NOT_TESTABLE', 1, 0, '[]', 'x')");
  assert.throws(() => db.run("UPDATE model_scope_validations SET status = 'VALIDATED'"), /unveraenderlich/, 'Scope-Validierungen sind unveränderlich');
  assert.throws(() => db.run('DELETE FROM model_scope_validations'), /unveraenderlich/);
  db.close();
  // Neustart: erneutes Öffnen ändert nichts
  const again = new Db(file);
  assert.deepEqual(migrate(again), []);
  again.close();
  // Neue Signale nach dem Upgrade tragen eine Signatur und werden bei identischer Neuberechnung nicht dupliziert
  const v = new ValueBettingEngine(app.db);
  const ev = app.db.get<{ event_id: number }>('SELECT event_id FROM value_signals WHERE active = 1 LIMIT 1')!;
  const pred = new PredictionEngine(app.db).predictEvent(ev.event_id, ANCHOR)!;
  const s = { minEv: 0.05, strategy: 'BALANCED' as const, oddsMaxAgeMinutes: 90, preferredBookmakers: [], modelValidated: false, isMock: true };
  app.db.run('UPDATE value_signals SET calc_signature = NULL WHERE event_id = ?', ev.event_id);   // Zustand direkt nach dem Upgrade
  assert.ok(v.persist(v.evaluate(pred, s, ANCHOR), ANCHOR).length > 0, 'einmalige Neuversionierung');
  assert.equal(v.persist(v.evaluate(pred, s, ANCHOR), ANCHOR).length, 0, 'danach stabil');
});
