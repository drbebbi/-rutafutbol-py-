/** Performance: KPI, Verlauf, Kalibrierung, je Markt, Backtest. Unvollständige Daten werden markiert, nichts wird geschönt. */
import React, { useState } from 'react';
import { api, fx, pct, signed, localTime } from '../api';
import { MKT } from '../i18n';
import { tr } from '../reasons';
import { useApp, LineChart, CalibrationChart } from '../components';
import { useLoad } from '../hooks';
import { Badge, Banner, Button, Card, EmptyState, ErrorBox, Kpi, Loading, PageHeader, Segmented, StatusBadge } from '../ui';

const SMALL = 30;

export function Performance() {
  const { t, u, lang, tz, role } = useApp();
  const d = useLoad<any>('/api/performance');
  const [scope, setScope] = useState<'real' | 'mock'>('real');
  const [busy, setBusy] = useState(false), [err, setErr] = useState('');
  const run = async () => { setBusy(true); setErr(''); try { await api('/api/backtest/run', { method: 'POST' }); d.reload(); } catch (e) { setErr((e as Error).message); } finally { setBusy(false); } };
  if (d.err) return <><PageHeader title={t.performance} /><ErrorBox e={d.err} onRetry={d.reload} /></>;
  if (!d.data) return <><PageHeader title={t.performance} /><Loading lines={6} /></>;
  const m = d.data[scope] ?? d.data.real, bt = d.data.backtest, btm = bt?.metrics;
  const n = m.settled, small = n > 0 && n < SMALL;
  const tag = small ? <Badge tone="watch">{u.smallSample}</Badge> : undefined;
  const v = (x: string) => (n ? x : '–');

  return (
    <>
      <PageHeader title={t.performance} lead={u.perfLead}
        actions={d.data.mock ? <Segmented label="scope" value={scope} onChange={setScope} items={[['real', t.real], ['mock', t.mock]]} /> : null} />
      {scope === 'mock' ? <Banner tone="warn" title={u.mockTitle}>{t.mockBanner}</Banner> : null}
      {!n ? <Banner tone="info" title={u.noSettled}>{u.noSettledText}</Banner> : small ? <Banner tone="warn" title={`${u.smallSample} (n = ${n})`}>{u.perfLead}</Banner> : null}

      <div className="kpis six">
        <Kpi label={t.roi} value={v(signed(m.roi))} tone={n ? (m.roi >= 0 ? 'value' : 'avoid') : undefined} badge={tag} hint={`${t.settled}: ${n}`} />
        <Kpi label={u.yieldK} value={v(signed(m.yield))} hint="= ROI · 1u" />
        <Kpi label={u.hitRate} value={v(pct(m.winRate))} hint={n ? `${m.wins} / ${n}` : undefined} />
        <Kpi label={t.avgOdds} value={v(fx(m.avgOdds))} />
        <Kpi label={t.clv} value={m.clvCount ? signed(m.avgClv, 2) : '–'} hint={m.clvCount ? `${t.clvPos} ${pct(m.clvPositiveRate, 0)} · n = ${m.clvCount}` : u.incomplete} tone={m.clvCount ? (m.avgClv >= 0 ? 'value' : 'avoid') : undefined} />
        <Kpi label={t.drawdown} value={v(`${fx(m.maxDrawdown)}u`)} hint={n ? `Profit ${fx(m.profit)}u` : undefined} />
        <Kpi label={t.predictions} value={m.predictions} size="md" hint={`${m.open} open`} />
        <Kpi label={t.brier} value={n ? fx(m.brier, 4) : '–'} size="md" />
        <Kpi label={t.logLoss} value={n ? fx(m.logLoss, 4) : '–'} size="md" />
        <Kpi label="Model" value={m.modelVersions.join(', ') || '–'} size="md" />
      </div>

      <div className="grid two">
        <Card title={t.cumProfit}>{m.series.length ? <LineChart data={m.series.map((s: any) => ({ t: s.t, y: s.cumProfit }))} /> : <div className="chart-empty">{u.noSettled}</div>}</Card>
        <Card title={t.calibration} sub={n ? `n = ${n}` : undefined}>{m.calibration.length ? <CalibrationChart bins={m.calibration} /> : <div className="chart-empty">{u.noSettled}</div>}</Card>
      </div>
      {Object.keys(m.byMarket ?? {}).length ? <Card title={t.market}><div className="tablewrap"><table><thead><tr><th>{t.market}</th><th className="n">n</th><th className="n">Profit</th><th className="n">ROI</th></tr></thead>
        <tbody>{Object.entries(m.byMarket).map(([k, x]: any) => <tr key={k}><td>{MKT[k] ?? k}{x.n < SMALL ? <span className="t-3 xs"> · {u.smallSample}</span> : null}</td><td className="n">{x.n}</td><td className="n">{fx(x.profit)}u</td><td className={`n ${x.roi >= 0 ? 'pos' : 'neg'}`}>{signed(x.roi)}</td></tr>)}</tbody></table></div></Card> : null}

      <Card title={t.backtest} sub={bt ? `#${bt.id} · ${bt.data_source} · ${localTime(bt.started_at, tz, lang)}` : undefined}
        actions={role === 'admin' ? <Button variant="secondary" size="sm" icon="refresh" onClick={run} disabled={busy}>{busy ? t.loading : t.runBacktest}</Button> : null}>
        {err ? <Banner tone="error" title={t.error}>{err}</Banner> : null}
        {btm ? <div className="grid two">
          <div className="stack">
            <div className="row-flex"><StatusBadge s={btm.validation.status} /><span className="t-3 small">Walk-forward {btm.matches.walkForward} · Holdout {btm.matches.holdout}</span></div>
            {btm.scopes?.length ? <div className="tablewrap"><table><thead><tr><th>{lang === 'de' ? 'Bereich' : lang === 'en' ? 'Scope' : 'Ámbito'}</th><th>{t.status}</th><th>{lang === 'de' ? 'vs. Markt' : lang === 'en' ? 'vs market' : 'vs mercado'}</th><th className="n">n</th></tr></thead>
              <tbody>{btm.scopes.map((x: any) => <tr key={`${x.competitionId}-${x.market}`}><td className="small">{x.competition} · {MKT[x.market] ?? x.market}</td><td><StatusBadge s={x.status} /></td>
                <td className="small">{x.marketEvidence === 'BETTER' ? (lang === 'de' ? 'Mehrwert belegt' : lang === 'en' ? 'edge shown' : 'ventaja mostrada') : x.marketEvidence === 'NOT_WORSE' ? (lang === 'de' ? 'nicht schlechter – kein Mehrwert-Nachweis' : lang === 'en' ? 'not worse – no edge shown' : 'no peor – sin ventaja demostrada') : x.marketEvidence === 'WORSE' ? (lang === 'de' ? 'schlechter' : lang === 'en' ? 'worse' : 'peor') : (lang === 'de' ? 'nicht prüfbar' : lang === 'en' ? 'not testable' : 'no comprobable')}{x.oddsTimesEstimated ? ' · *' : ''}</td>
                <td className="n">{x.n}</td></tr>)}</tbody></table>
              <p className="t-3 xs" style={{ marginTop: 6 }}>{lang === 'de' ? 'Nur Bereiche mit VALIDATED gelten live als validiert. * Quotenzeitpunkte geschätzt.' : lang === 'en' ? 'Only VALIDATED scopes count as validated live. * Odds times estimated.' : 'Solo los ámbitos VALIDATED cuentan como validados. * Hora de cuotas estimada.'}</p></div> : null}
            <ul className="reasons">{btm.validation.reasons.slice(0, 8).map((r: string) => <li key={r}>{tr(r, lang)}</li>)}{btm.validation.reasons.length > 8 ? <li className="t-3">… +{btm.validation.reasons.length - 8}</li> : null}</ul>
            <div className="tablewrap"><table><thead><tr><th>Holdout</th><th className="n">Log Loss</th><th className="n">Baseline</th><th className="n">Brier</th><th className="n">ECE</th></tr></thead>
              <tbody>{Object.entries(btm.holdoutEnsemble).map(([k, x]: any) => <tr key={k}><td>{MKT[k]}</td><td className={`n ${x.logLoss < btm.baseline[k]?.logLoss ? 'pos' : 'neg'}`}>{fx(x.logLoss, 4)}</td><td className="n">{fx(btm.baseline[k]?.logLoss, 4)}</td><td className="n">{fx(x.brier, 4)}</td><td className="n">{fx(x.ece, 3)}</td></tr>)}</tbody></table></div>
            {btm.betting ? <Banner tone="warn" title={t.simulated}>{btm.betting.bets} bets · ROI {signed(btm.betting.roi)} · Ø {fx(btm.betting.avgOdds)} · CLV {signed(btm.betting.avgClv, 2)} · DD {btm.betting.maxDrawdown}u. {btm.betting.note}</Banner>
              : <Banner tone="warn" title={u.incomplete}>{tr(btm.bettingIncompleteReason ?? '–', lang)}</Banner>}
          </div>
          <div className="stack">
            {btm.comparisons ? <div className="tablewrap"><table><thead><tr><th>ΔLogLoss (95 %)</th><th className="n">vs base</th><th className="n">vs market</th><th className="n">mix vs market</th><th className="n">w*</th></tr></thead>
              <tbody>{Object.entries(btm.comparisons).map(([k, c]: any) => <tr key={k}><td>{MKT[k]}</td>
                {[c.ensembleVsBaseline, c.ensembleVsMarket, c.blendVsMarket].map((x: any, i: number) => <td key={i} className={`n ${x ? (x.hi < 0 ? 'pos' : x.lo > 0 ? 'neg' : '') : ''}`}>{x ? `${x.diff.toFixed(4)} [${x.lo.toFixed(3)}; ${x.hi.toFixed(3)}]` : '–'}</td>)}
                <td className="n">{btm.blend?.[k]?.chosenWeight ?? '–'}</td></tr>)}</tbody></table>
              <p className="t-3 xs" style={{ marginTop: 6 }}>{lang === 'de' ? 'Negativ = besser. Grün = signifikant besser, rot = signifikant schlechter.' : lang === 'en' ? 'Negative = better. Green = significantly better, red = significantly worse.' : 'Negativo = mejor. Verde = significativamente mejor, rojo = significativamente peor.'}</p></div> : null}
            {btm.holdoutEnsemble['1X2']?.calibration ? <><h3>{t.calibration} 1X2</h3><CalibrationChart bins={btm.holdoutEnsemble['1X2'].calibration} /></> : null}
          </div>
        </div> : <EmptyState title={t.noData} icon="perf" />}
      </Card>
    </>
  );
}
