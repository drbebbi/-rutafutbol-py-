/**
 * v0.4.0 – Priorität 4: Datengrundlage je Wettbewerb; Champions League ohne Historie → INSUFFICIENT DATA.
 * Provider-Antworten nach der offiziellen v4-Doku NACHGEBAUT; CSV synthetisch. Kein Live-Nachweis.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildApp } from '../src/app.js';
import { testOddsApiConnection, UCL_SPORT_KEY } from '../src/engines/oddsApiStatus.js';
import { competitionCoverage } from '../src/engines/coverage.js';
import { importFootballDataCsv } from '../src/providers/footballDataCsv.js';
import { memDb, testConfig } from './helpers.js';
import { e0Csv, fakeFetcher, oddsEvent } from './fixtures/theOddsApiSamples.js';

const H = 3_600_000, MIN = 60_000;
const TEAMS = ['Arsenal', 'Chelsea', 'Everton', 'Fulham', 'Liverpool', 'Brentford', 'Burnley', 'Wolves'];

async function scenario() {
  const now = Date.now();
  const epl = oddsEvent({ id: 'epl-1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now - 2 * MIN });
  const ucl = oddsEvent({ id: 'ucl-1', sport: UCL_SPORT_KEY, title: 'UEFA Champions League', home: 'Arsenal', away: 'Paris Saint Germain', kickoff: now + 22 * H, updatedAt: now - 2 * MIN });
  const f = fakeFetcher((p) => {
    if (p === '/v4/sports') return { body: [{ key: 'soccer_epl', active: true, has_outrights: false }, { key: UCL_SPORT_KEY, active: true, has_outrights: false }, { key: 'soccer_spain_la_liga', active: true, has_outrights: false }] };
    if (p === '/v4/sports/soccer_epl/events') return { body: [epl].map(({ bookmakers, ...e }) => e) };
    if (p === `/v4/sports/${UCL_SPORT_KEY}/events`) return { body: [ucl].map(({ bookmakers, ...e }) => e) };
    if (p === '/v4/sports/soccer_epl/odds') return { body: [epl], headers: { 'x-requests-last': '2' } };
    if (p === `/v4/sports/${UCL_SPORT_KEY}/odds`) return { body: [ucl], headers: { 'x-requests-last': '2' } };
    if (p.endsWith('/events') || p.endsWith('/odds')) return { body: [] };
    return null;
  });
  const cfg = testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: 'test-key-NOT-REAL-p4', THE_ODDS_API_SPORT_KEYS: `soccer_epl,${UCL_SPORT_KEY},soccer_spain_la_liga` });
  const app = buildApp(cfg, { db: memDb(), fetcher: f.fetcher, requireOddsConnectionTest: true });
  importFootballDataCsv(app.db, e0Csv(TEAMS, 4, Date.UTC(2025, 0, 5)), 'E0.csv');
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const sum = await app.sync.run(new Date(now));
  return { app, now, sum };
}

test('P4: Übersicht je Wettbewerb – EPL mit Historie berechenbar, Champions League INSUFFICIENT DATA mit Erklärung', async () => {
  const { app, now } = await scenario();
  const cov = competitionCoverage(app.db, app.cfg, new Date(now));
  const epl = cov.competitions.find(c => c.sportKey === 'soccer_epl')!;
  const ucl = cov.competitions.find(c => c.sportKey === UCL_SPORT_KEY)!;
  const liga = cov.competitions.find(c => c.sportKey === 'soccer_spain_la_liga')!;
  assert.ok(epl && ucl && liga, cov.competitions.map(c => c.name).join(', '));
  assert.equal(epl.fixtures.available, true); assert.equal(epl.odds.available, true);
  assert.equal(epl.history.available, true, `Historie ${epl.history.finishedMatches}`);
  assert.equal(epl.models.computable, true);
  assert.deepEqual(Object.values(epl.validation).map(v => v.status), ['UNVALIDATED', 'UNVALIDATED', 'UNVALIDATED']);
  assert.ok(epl.explanation.some(e => /experimentell/.test(e)));
  assert.equal(ucl.status, 'INSUFFICIENT DATA');
  assert.equal(ucl.fixtures.available, true); assert.equal(ucl.odds.available, true, 'Quoten vorhanden – trotzdem keine Prognose');
  assert.equal(ucl.history.finishedMatches, 0);
  assert.equal(ucl.models.computable, false);
  assert.ok(ucl.explanation.some(e => /keine geeignete Historie/.test(e) && /nicht ungeprüft übertragen/.test(e)), ucl.explanation.join(' | '));
  assert.equal(liga.competitionId, null, 'konfigurierter Sport-Key ohne Spiele wird dennoch gelistet');
  assert.equal(liga.status, 'INSUFFICIENT DATA');
});

test('P4: Champions League – keine Ersatzwahrscheinlichkeiten, keine Übertragung des EPL-Modells, keine Empfehlung', async () => {
  const { app } = await scenario();
  const ev = app.db.get<{ event_id: number }>("SELECT event_id FROM event_mappings WHERE provider = 'theoddsapi' AND provider_event_id = 'ucl-1'")!;
  const pred = app.db.get<{ probs: string; data_quality: string }>('SELECT probs, data_quality FROM predictions WHERE event_id = ? ORDER BY id DESC LIMIT 1', ev.event_id)!;
  assert.deepEqual(JSON.parse(pred.probs), {}, 'keine Wahrscheinlichkeiten');
  const dq = JSON.parse(pred.data_quality);
  assert.equal(dq.status, 'insufficient');
  assert.ok(dq.issues.some((i: string) => /keine Historie für diesen Wettbewerb/.test(i)));
  const sig = app.db.all<{ status: string; model_prob: number | null }>('SELECT status, model_prob FROM value_signals WHERE event_id = ? AND active = 1', ev.event_id);
  assert.ok(sig.length && sig.every(s => ['INSUFFICIENT_DATA', 'MARKET_SUSPENDED'].includes(s.status) && s.model_prob == null), JSON.stringify(sig));
  assert.ok(sig.some(s => s.status === 'INSUFFICIENT_DATA'));
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM recommendations WHERE event_id = ? AND active = 1', ev.event_id)!.n, 0);
  // Das EPL-Spiel desselben Teams hat dagegen eine Prognose aus der EPL-Historie
  const eplEv = app.db.get<{ event_id: number }>("SELECT event_id FROM event_mappings WHERE provider = 'theoddsapi' AND provider_event_id = 'epl-1'")!;
  const p2 = app.db.get<{ probs: string }>('SELECT probs FROM predictions WHERE event_id = ? ORDER BY id DESC LIMIT 1', eplEv.event_id)!;
  assert.ok(JSON.parse(p2.probs)['1X2'], 'EPL-Prognose vorhanden');
});
