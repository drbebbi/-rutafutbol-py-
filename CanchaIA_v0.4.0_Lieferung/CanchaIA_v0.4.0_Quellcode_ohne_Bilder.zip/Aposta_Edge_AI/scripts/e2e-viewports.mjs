// v0.4.0 – Layoutprüfung der echten React-App (Mock-Modus) bei 375, 390, 430 px und Desktop (1440 px).
// Prüft je Seite: kein horizontales Scrollen, keine JS-Fehler, Marke sichtbar, Spanisch als Standard. Speichert Screenshots.
// Voraussetzung: laufender Server (Mock) mit Admin-Konto. Zugangsdaten NUR über Umgebung: E2E_EMAIL, E2E_PASSWORD.
// Aufruf: E2E_EMAIL=… E2E_PASSWORD=… node scripts/e2e-viewports.mjs <pfad-zu-playwright> <ausgabeordner> [basis-url]
import { createRequire } from 'node:module';
import fs from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require(process.argv[2]);
const OUT = process.argv[3];
const BASE = process.argv[4] ?? 'http://localhost:8080';
const CRED = [process.env.E2E_EMAIL, process.env.E2E_PASSWORD];
if (!CRED[0] || !CRED[1]) { console.error('E2E_EMAIL und E2E_PASSWORD setzen.'); process.exit(2); }
fs.mkdirSync(OUT, { recursive: true });
const WIDTHS = [[375, 812, true], [390, 844, true], [430, 932, true], [1440, 900, false]];
const ROUTES = [['home', '/'], ['matches', '/matches'], ['edge', '/edge'], ['performance', '/performance'], ['settings', '/settings'], ['admin', '/admin']];
const results = []; let failed = 0;
const check = (name, ok, info = '') => { results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? ' – ' + info : ''}`); if (!ok) failed++; };
const browser = await chromium.launch();
for (const [w, h, mobile] of WIDTHS) {
  const c = await browser.newContext({ viewport: { width: w, height: h }, deviceScaleFactor: 2, isMobile: mobile, hasTouch: mobile, locale: 'es-PY', timezoneId: 'America/Asuncion' });
  const p = await c.newPage(); const errors = [];
  p.on('pageerror', e => errors.push(String(e)));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g|Failed to load resource/.test(m.text())) errors.push(m.text()); });
  await p.goto(BASE + '/'); await p.waitForSelector('#email');
  check(`[${w}] Login: Spanisch als Standard`, (await p.evaluate(() => document.body.innerText)).includes('Iniciar sesión'));
  await p.fill('#email', CRED[0]); await p.fill('#password', CRED[1]);
  await p.click('form button.btn.block'); await p.waitForSelector('main.main', { timeout: 15000 });
  for (const [name, hash] of ROUTES) {
    await p.goto(BASE + '/#' + hash); await p.waitForLoadState('networkidle').catch(() => {}); await p.waitForTimeout(900);
    const m = await p.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, t: document.body.innerText,
      wide: [...document.querySelectorAll('body *')].filter(e => { const r = e.getBoundingClientRect(); return r.width > 0 && r.right > window.innerWidth + 1 && getComputedStyle(e).position !== 'fixed' && !e.closest('.tablewrap, pre, .code'); }).slice(0, 3).map(e => `${e.tagName.toLowerCase()}.${String(e.className).split(' ')[0]}`) }));
    check(`[${w}] ${name}: kein horizontales Scrollen`, m.sw <= m.iw, `scrollWidth ${m.sw} / innerWidth ${m.iw}${m.wide.length ? ' · ' + m.wide.join(', ') : ''}`);
    check(`[${w}] ${name}: Marke CanchaIA sichtbar`, m.t.includes('CanchaIA') || (await p.locator('.brand').count()) > 0);
    check(`[${w}] ${name}: keine Behauptung „verifiziert/nachgewiesen“ für experimentelle Signale`, !/ventaja (verificada|demostrada)(?! frente)|verified edge|proven edge(?! over)|nachgewiesener Vorteil/i.test(m.t.replace(/sin ventaja demostrada|no proven edge|kein nachgewiesener Vorteil/gi, '')));
    await p.screenshot({ path: `${OUT}/${w}-${name}.png`, fullPage: false });
  }
  check(`[${w}] keine JS-Fehler`, errors.length === 0, errors.slice(0, 3).join(' | '));
  await c.close();
}
await browser.close();
fs.writeFileSync(`${OUT}/RESULTS.txt`, results.join('\n') + `\n\n${results.length - failed} PASS, ${failed} FAIL\n`);
console.log(results.join('\n')); console.log(`\n${results.length - failed} PASS, ${failed} FAIL`);
process.exit(failed ? 1 : 0);
