# Live-API-Testbericht

## v0.3.3 (13.10.2026, 21:19 Asunción)

| Prüfung | Ergebnis |
|---|---|
| Secret `THE_ODDS_API_KEY` in der Entwicklungsumgebung | **nicht gesetzt** |
| Netzwerk zu `api.the-odds-api.com` | **gesperrt** (Egress-Richtlinie, CONNECT → HTTP 403) |
| `npm run odds:check` (tatsächlich ausgeführt, Live-Modus) | `ok: false`, kein Abruf, Status **DISCONNECTED** („Secret fehlt in dieser Umgebung“) |
| Echte Abrufe / verbrauchte Credits | **0 / 0** |
| Echte Champions-League-Spiele geladen | **0** |
| Restcredits laut Anbieter | **unbekannt** (kein Abruf) |

Der Live-Test erfolgt auf dem Server mit dem Secret: Schritte 4 und 5 in [THE_ODDS_API_INTEGRATION.md](THE_ODDS_API_INTEGRATION.md).

---

## v0.3.0

Stand: 13.10.2026, 14:56 UTC.

## Ergebnis

| Provider | Live-Test | Grund |
|---|---|---|
| The Odds API | **NOT VERIFIED** | Kein API-Schlüssel übergeben, und kein Netzwerkzugang aus der Entwicklungsumgebung (`curl https://api.the-odds-api.com/v4/sports` → Verbindung abgewiesen, HTTP 000) |
| football-data.co.uk (CSV) | **NOT VERIFIED** | Download aus der Umgebung nicht möglich (HTTP 000). Format mit Beispieldateien im Originalformat getestet |
| Highlightly | **BLOCKED** | Nutzungsrechte für Wettanalysen nicht schriftlich bestätigt. Außerdem kein Netzwerkzugang |

Es wurde **kein** echter API-Abruf durchgeführt. Es wurden keine Live-Daten erzeugt und keine Quoten oder Spiele erfunden.

## Was stattdessen getestet wurde (TESTED)

Mit Antworten, die nach der offiziellen v4-Dokumentation nachgebaut sind (`backend/test/fixtures/theOddsApiSamples.ts`). Das sind **keine** aufgezeichneten echten Antworten.

- Pilotmodus: Sport-Keys werden gegen `/v4/sports` (kostenlos) geprüft. Inaktive und unbekannte Keys werden übersprungen und gemeldet.
- Kontrollierter Sync, vollständig im Live-Modus mit eingespieltem Test-Fetcher:
  - Spieltermine, eindeutige Event-IDs, Teamzuordnung zur CSV-Historie
  - vollständige Marktsnapshots, Zeitstempel
  - Credits (4 je `/odds`-Abruf bei 2 Märkten × 2 Regionen)
  - ein bereits begonnenes Spiel wird nicht als Pre-Match angelegt
- Der Bericht kennzeichnet einen solchen Lauf selbst als **NOT VERIFIED**: Mit eingespieltem Fetcher kann der Status „LIVE VERIFIED“ technisch nicht vergeben werden.
- Weitere getestete Punkte:
  - BTTS: aus/an, Limit je Lauf, Budget-Reserve
  - dynamischer Cache, Monatsbudget
  - Abrufprotokoll ohne Schlüssel
  - Ergebnisse über `/scores`
  - Fehlender Schlüssel: Status NOT CONFIGURED, **0** Abrufe

## So führst du den Live-Test selbst durch

1. In `.env` setzen:
   ```
   DATA_MODE=live
   THE_ODDS_API_KEY=<dein Schlüssel>
   PILOT_MODE=true
   PILOT_SPORT_KEYS=soccer_epl,soccer_spain_la_liga,soccer_uefa_champs_league
   PILOT_MAX_EVENTS=10
   THE_ODDS_API_MONTHLY_BUDGET=500
   THE_ODDS_API_INCLUDE_BTTS=false
   ```
2. Historie importieren (Admin → CSV-Import oder `npm run import:csv -- E0.csv SP1.csv`), am besten 2–3 Saisons Premier League (E0) und La Liga (SP1). Für die Champions League gibt es bei football-data.co.uk keine CSV, dort bleiben die Modelle bei INSUFFICIENT DATA.
3. Admin → **Kontrollierter Sync** → Max. Spiele 10 → „Einmal ausführen“.
4. Bericht prüfen:
   - Status `DONE` und `LIVE VERIFIED` (nur wenn echte Antworten verarbeitet wurden)
   - alle Prüfungen OK
   - Credits (erwartet: 4 je aktivem Wettbewerb, `/sports` kostenlos)
   - Teamzuordnung: Teams ohne Verknüpfung erscheinen als `unlinked_team` → Admin → Team-Aliase
   - Stichprobe von 3 Spielen: Anstoßzeit und Quoten mit einer Buchmacher-Website vergleichen
5. Ergebnis hier eintragen:
   - Datum, Credits, Abweichungen, offene Zuordnungen
   - **Prognosequalität ist damit nicht geprüft.** Dafür gibt es die Validierung (`npm run validate`).

Kosten des Tests: etwa 8–12 Credits (2–3 aktive Wettbewerbe × 4, dazu ggf. `/scores` mit 2 je Wettbewerb).
