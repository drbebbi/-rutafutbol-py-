import { envLoad } from './env.js';
import { loadConfig, configIssues, ConfigError } from './config.js';
import { buildApp, seedMock } from './app.js';
import { Scheduler } from './scheduler.js';
import { createServer } from './server.js';
import { log } from './util/log.js';

let cfg: ReturnType<typeof loadConfig>;
try { cfg = loadConfig(); }
catch (e) { if (e instanceof ConfigError) { console.error(`Konfigurationsfehler: ${e.message}`); process.exit(2); } throw e; }
if (envLoad.error) log.warn(envLoad.error);
log.info(envLoad.file ? `Umgebung: ${envLoad.file} geladen (${envLoad.applied} Variablen übernommen; ${envLoad.skippedExisting} bereits in der Umgebung gesetzt – Umgebung hat Vorrang). Werte werden nicht ausgegeben.` : 'Umgebung: keine .env-Datei geladen (nur echte Umgebungsvariablen).');
const app = buildApp(cfg);
for (const i of configIssues(cfg)) log.warn(i);
if (cfg.dataMode === 'mock') {
  const n = await seedMock(app);
  log.info(`Mock-Modus: ${n} historische Mock-Spiele bereitgestellt. Alle Daten sind fiktiv.`);
}
const scheduler = cfg.schedulerEnabled ? new Scheduler(app) : null;
const server = createServer(app, scheduler);
server.listen(cfg.port, cfg.host, () => log.info(`CanchaIA läuft auf http://${cfg.host}:${cfg.port} (Modus: ${cfg.dataMode})`));
scheduler?.start();

const shutdown = (sig: string) => {
  log.info(`${sig}: fahre herunter`);
  scheduler?.stop();
  server.close(() => { app.db.close(); process.exit(0); });
  setTimeout(() => process.exit(0), 5000).unref();
};
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
