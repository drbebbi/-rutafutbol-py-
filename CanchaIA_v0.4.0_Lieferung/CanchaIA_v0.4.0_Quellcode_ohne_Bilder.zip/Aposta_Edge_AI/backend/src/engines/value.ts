/**
 * ValueBettingEngine: vergleicht Modellwahrscheinlichkeiten mit verifizierten Quoten.
 * - p_model: unabhängige Modellwahrscheinlichkeit (Ensemble)
 * - p_markt: fairer Marktpreis (No-Vig des scharfen Buchmachers, sonst Median der gültigen Buchmacher)
 * - p_dec = w · p_model + (1 − w) · p_markt  (w = Modellgewicht; Default je Risikoprofil)
 * EV = p_dec × Quote − 1 (einfache Märkte ohne Push). EV an der Untergrenze mit p_dec − z·σ_dec,
 * σ_dec = √((w·σ_model)² + ((1 − w)·σ_markt)²). Ohne Marktpreis zählt das Modell allein mit voller Unsicherheit.
 */
import type { Db } from '../db/db.js';
import type { MarketId, SelectionId } from '../providers/types.js';
import { MARKET_SELECTIONS } from '../providers/types.js';
import type { PredictionRecord } from './prediction/index.js';
import { OddsStore, consensusNoVig, type MarketBookView } from './odds.js';
import { clamp, nowIso, sha, stableStringify } from '../util/core.js';
import { checkFreshness } from './freshness.js';
import type { Strategy } from '../config.js';

export type SignalStatus = 'STRONG_VALUE' | 'VALUE' | 'WATCH' | 'NO_VALUE' | 'INSUFFICIENT_DATA' | 'STALE' | 'AVOID' | 'MARKET_SUSPENDED';
export const QUALIFIED: SignalStatus[] = ['STRONG_VALUE', 'VALUE'];

export interface ValueSettings {
  minEv: number; strategy: Strategy; oddsMaxAgeMinutes: number; preferredBookmakers: string[]; modelValidated: boolean; isMock: boolean; modelWeight?: number | null;
  /** v0.4.0: Validierung je Markt für den Wettbewerb dieses Spiels (überschreibt modelValidated, wenn gesetzt). */
  validatedMarkets?: MarketId[];
  /** v0.4.0: Märkte, in denen ein Mehrwert gegenüber dem Markt statistisch nachgewiesen ist (Voraussetzung für STRONG_VALUE). */
  marketEdgeMarkets?: MarketId[];
  /** v0.4.0: im Backtest gewähltes Mischgewicht je Markt (nur für validierte Märkte). */
  modelWeightByMarket?: Partial<Record<MarketId, number>>;
}

export interface Signal {
  eventId: number; predictionId: number; market: MarketId; selection: SelectionId; line: number | null;
  status: SignalStatus; modelProb: number | null; decisionProb: number | null; modelWeight: number | null; probLow: number | null; impliedProb: number | null; novigProb: number | null;
  fairOdds: number | null; bestOdds: number | null; bestBookmakerId: string | null; bestSnapshotId: string | null;
  edge: number | null; ev: number | null; evLow: number | null; qualityScore: number; reasons: string[]; bookCount: number;
  /** Datenstand der verwendeten Quote */
  oddsRetrievedAt: string | null; oddsSourceTimestamp: string | null;
  /** Zeitpunkt dieser Bewertung und spätester Zeitpunkt, bis zu dem sie ohne neue Quote gilt */
  validatedAt: string; validUntil: string | null;
  /** Herkunft des fairen Marktpreises (ohne den bewerteten Buchmacher) */
  marketRefSource: string | null;
  /**
   * v0.4.0: Signatur aller fachlich relevanten Berechnungswerte und Eingaben (Prognose, beste Quote, Marktreferenz,
   * Wahrscheinlichkeiten, EV, Status und Konfiguration). Ändert sich einer davon, entsteht eine neue Signalversion.
   */
  calcSignature: string;
}

/** Zahlen auf 9 Stellen runden, damit Gleitkomma-Rauschen keine Scheinänderung erzeugt. */
const r9 = (x: number | null) => x == null || !Number.isFinite(x) ? null : Math.round(x * 1e9) / 1e9;

export function signalSignature(s: Omit<Signal, 'calcSignature'>, cfg: ValueSettings): string {
  return sha(stableStringify({
    p: s.predictionId, st: s.status, ln: s.line, snap: s.bestSnapshotId, bk: s.bestBookmakerId, odds: r9(s.bestOdds), ref: s.marketRefSource, books: s.bookCount,
    pm: r9(s.modelProb), pd: r9(s.decisionProb), w: r9(s.modelWeight), lo: r9(s.probLow), nv: r9(s.novigProb), ev: r9(s.ev), evl: r9(s.evLow), edge: r9(s.edge),
    cfg: { minEv: r9(cfg.minEv), strategy: cfg.strategy, w: r9(cfg.modelWeight ?? null), validated: cfg.modelValidated, mock: cfg.isMock, pref: [...cfg.preferredBookmakers].sort(), maxAge: cfg.oddsMaxAgeMinutes,
      vm: cfg.validatedMarkets ?? null, em: cfg.marketEdgeMarkets ?? null, wm: cfg.modelWeightByMarket ?? null },
  }), 24);
}

const Z: Record<Strategy, number> = { CONSERVATIVE: 1.645, BALANCED: 1.0, AGGRESSIVE: 0.5 };
const MIN_DQ: Record<Strategy, number> = { CONSERVATIVE: 70, BALANCED: 55, AGGRESSIVE: 45 };
const AVOID_GAP = 0.12;
/** Modellgewicht in der Entscheidungswahrscheinlichkeit, solange kein Backtest ein anderes belegt. */
export const DEFAULT_MODEL_WEIGHT: Record<Strategy, number> = { CONSERVATIVE: 0.25, BALANCED: 0.35, AGGRESSIVE: 0.5 };
const MARKET_SD = 0.015;

export interface DecisionInput {
  p: number; sd: number | null; bestOdds: number; novig: number | null; strategy: Strategy; minEv: number; modelWeight?: number | null;
  dqScore: number; agreement: number; modelValidated: boolean; marketEdgeProven: boolean; isMock: boolean;
  /** 0..1 (1 = gerade abgerufen); im Backtest 0, weil historische Abrufzeitpunkte nur geschätzt sind */
  freshness: number; freshBooks: number; marketRefSource: string | null;
}
export interface Decision { status: Extract<SignalStatus, 'STRONG_VALUE' | 'VALUE' | 'WATCH' | 'NO_VALUE' | 'AVOID'>; modelWeight: number; decisionProb: number; probLow: number; ev: number; evLow: number; edge: number | null; qualityScore: number; reasons: string[] }

/**
 * v0.4.0: EINE Entscheidungsregel für Live-Betrieb und Backtest (vorher im Backtest nachgebaut, ohne Datenqualität,
 * AVOID-Regel und Strategie-z). Reine Funktion ohne Datenbankzugriff.
 */
export function decide(i: DecisionInput): Decision {
  const reasons: string[] = [];
  const z = Z[i.strategy];
  const sigma = i.sd ?? 0.05;
  const w = i.novig != null ? clamp(i.modelWeight ?? DEFAULT_MODEL_WEIGHT[i.strategy], 0, 1) : 1;
  const pDec = i.novig != null ? w * i.p + (1 - w) * i.novig : i.p;
  const sDec = i.novig != null ? Math.sqrt((w * sigma) ** 2 + ((1 - w) * MARKET_SD) ** 2) : sigma;
  const probLow = clamp(pDec - z * sDec, 0.001, 0.999);
  const ev = pDec * i.bestOdds - 1, evLow = probLow * i.bestOdds - 1;
  const edge = i.novig != null ? i.p - i.novig : null;
  if (i.novig == null) reasons.push('kein fairer Marktpreis ohne den bewerteten Buchmacher verfügbar: Entscheidung nur auf Modellbasis mit voller Unsicherheit');
  const qualityScore = Math.round(i.dqScore * 0.4 + i.freshness * 15 + i.agreement * 15 + (i.modelValidated ? 15 : 0) + Math.min(15, i.freshBooks * 3.75));
  const out = (status: Decision['status']): Decision => ({ status, modelWeight: w, decisionProb: pDec, probLow, ev, evLow, edge, qualityScore, reasons });
  if (edge != null && Math.abs(edge) > AVOID_GAP) {
    reasons.push(`Modell weicht ${(edge * 100).toFixed(1)} Prozentpunkte vom fairen Marktpreis ab (${i.marketRefSource}). Das deutet eher auf fehlende Informationen oder Datenfehler hin als auf Value.`);
    return out('AVOID');
  }
  if (ev < i.minEv) { reasons.push(`EV ${(ev * 100).toFixed(1)} % unter Mindest-EV ${(i.minEv * 100).toFixed(0)} %`); return out('NO_VALUE'); }
  const dqOk = i.dqScore >= MIN_DQ[i.strategy];
  if (evLow > 0 && dqOk) {
    reasons.push(`EV ${(ev * 100).toFixed(1)} %, auch an der Untergrenze positiv (${(evLow * 100).toFixed(1)} %)`);
    if (!i.modelValidated) reasons.push('Modell für diesen Markt/Wettbewerb UNVALIDATED: experimentelles Signal, kein nachgewiesener Vorteil');
    else if (!i.marketEdgeProven) reasons.push('Modell validiert, aber kein statistisch nachgewiesener Mehrwert gegenüber dem Markt: STRONG_VALUE gesperrt');
    return out(i.modelValidated && i.marketEdgeProven && !i.isMock && evLow >= 0.03 && i.dqScore >= 75 ? 'STRONG_VALUE' : 'VALUE');
  }
  if (evLow <= 0) reasons.push(`EV ${(ev * 100).toFixed(1)} %, aber an der Untergrenze ${(evLow * 100).toFixed(1)} %: Vorteil liegt innerhalb der Modellunsicherheit`);
  if (!dqOk) reasons.push(`Datenqualität ${i.dqScore} unter Mindestwert ${MIN_DQ[i.strategy]} (${i.strategy})`);
  return out('WATCH');
}

/** Mindest-Datenqualität je Strategie (gleich für Live und Backtest). */
export const MIN_DATA_QUALITY = MIN_DQ;

export class ValueBettingEngine {
  private odds: OddsStore;
  private kickoff = '';
  constructor(private db: Db) { this.odds = new OddsStore(db); }

  evaluate(pred: PredictionRecord, s: ValueSettings, now: Date = new Date()): Signal[] {
    const out: Signal[] = [];
    const ev = this.db.get<{ kickoff_utc: string; status: string }>('SELECT kickoff_utc, status FROM events WHERE id = ?', pred.eventId)!;
    const started = new Date(ev.kickoff_utc).getTime() <= now.getTime() || ev.status !== 'scheduled';
    this.kickoff = ev.kickoff_utc;
    for (const market of ['1X2', 'OU', 'BTTS'] as MarketId[]) {
      const line = market === 'OU' ? 2.5 : null;
      const views = this.odds.latestPerBookmaker(pred.eventId, market, line);
      const p = pred.ensemble.probs[market], sd = pred.ensemble.sd[market];
      for (const sel of MARKET_SELECTIONS[market]) {
        const sig = this.one(pred, market, sel, line, views, p?.[sel] ?? null, sd?.[sel] ?? null, s, now, started);
        sig.calcSignature = signalSignature(sig, s);
        out.push(sig);
      }
    }
    return out;
  }

  private one(pred: PredictionRecord, market: MarketId, sel: SelectionId, line: number | null, views: MarketBookView[], p: number | null, sd: number | null, s: ValueSettings, now: Date, started: boolean): Signal {
    const reasons: string[] = [];
    const base: Signal = { eventId: pred.eventId, predictionId: pred.id, market, selection: sel, line, status: 'NO_VALUE', modelProb: p, decisionProb: null, modelWeight: null, probLow: null, impliedProb: null, novigProb: null,
      fairOdds: p ? 1 / p : null, bestOdds: null, bestBookmakerId: null, bestSnapshotId: null, edge: null, ev: null, evLow: null, qualityScore: 0, reasons, bookCount: 0,
      oddsRetrievedAt: null, oddsSourceTimestamp: null, validatedAt: nowIso(now), validUntil: null, marketRefSource: null, calcSignature: '' };
    if (s.isMock) reasons.push('MOCK-Daten: nur Entwicklungsmodus');
    if (started) { base.status = 'STALE'; reasons.push('Spiel hat begonnen oder ist nicht mehr angesetzt'); return base; }
    // Frische je Buchmacher mit denselben Regeln wie bei der Aufnahme (strenger, je näher der Anstoß)
    const fr = new Map(views.map(v => [v.snapshotId, checkFreshness({ retrievedAt: v.retrievedAt, sourceTimestamp: v.sourceTimestamp, kickoffUtc: this.kickoff, snapshotKind: v.kind }, now, s.oddsMaxAgeMinutes)]));
    const fresh = views.filter(v => v.valid && v.status === 'open' && fr.get(v.snapshotId)!.ok);
    const pref = s.preferredBookmakers.length ? fresh.filter(v => s.preferredBookmakers.includes(v.bookmakerId)) : fresh;
    base.bookCount = fresh.length;
    if (!views.length) { base.status = 'MARKET_SUSPENDED'; reasons.push('keine Quoten für diesen Markt'); return base; }
    if (views.every(v => v.status !== 'open')) { base.status = 'MARKET_SUSPENDED'; reasons.push('Markt bei allen Buchmachern geschlossen/ausgesetzt'); return base; }
    if (!fresh.length) {
      base.status = views.some(v => v.valid) ? 'STALE' : 'INSUFFICIENT_DATA';
      reasons.push(views.some(v => v.valid) ? 'STALE ODDS: ' + [...new Set(views.flatMap(v => fr.get(v.snapshotId)!.reasons))].slice(0, 2).join('; ') : 'keine Quote hat die Validierung bestanden: ' + [...new Set(views.flatMap(v => v.errors))].slice(0, 3).join('; '));
      return base;
    }
    const best = (pref.length ? pref : fresh).reduce((a, b) => (b.prices[sel]! > a.prices[sel]! ? b : a));
    // Marktreferenz OHNE den bewerteten Buchmacher (sonst steckt sein eigener Preis doppelt in der Bewertung)
    const cons = consensusNoVig(fresh, market, best.bookmakerId);
    base.marketRefSource = cons?.source ?? null;
    base.bestOdds = best.prices[sel]!; base.bestBookmakerId = best.bookmakerId; base.bestSnapshotId = best.snapshotId;
    base.oddsRetrievedAt = best.retrievedAt; base.oddsSourceTimestamp = best.sourceTimestamp;
    base.validUntil = fr.get(best.snapshotId)!.expiresAt;
    base.impliedProb = 1 / base.bestOdds; base.novigProb = cons?.probs[sel] ?? null;
    if (s.preferredBookmakers.length && !pref.length) reasons.push('keiner der bevorzugten Buchmacher hat einen gültigen Preis');
    if (p == null || pred.dataQuality.status === 'insufficient') {
      base.status = 'INSUFFICIENT_DATA';
      reasons.push(p == null ? 'kein Modell für diesen Markt verfügbar' : 'Datenqualität unzureichend: ' + pred.dataQuality.issues.slice(0, 2).join('; '));
      return base;
    }
    const f = fr.get(best.snapshotId)!;
    const validated = s.validatedMarkets ? s.validatedMarkets.includes(market) : s.modelValidated;
    const d = decide({
      p, sd, bestOdds: base.bestOdds, novig: base.novigProb, strategy: s.strategy, minEv: s.minEv,
      modelWeight: s.modelWeightByMarket?.[market] ?? s.modelWeight, dqScore: pred.dataQuality.score, agreement: pred.ensemble.agreement,
      modelValidated: validated, marketEdgeProven: s.marketEdgeMarkets ? s.marketEdgeMarkets.includes(market) : validated, isMock: s.isMock,
      freshness: f.ageMinutes == null ? 0 : clamp(1 - f.ageMinutes / f.limitMinutes, 0, 1), freshBooks: fresh.length, marketRefSource: cons?.source ?? null,
    });
    base.modelWeight = d.modelWeight; base.decisionProb = d.decisionProb; base.fairOdds = 1 / d.decisionProb;
    base.probLow = d.probLow; base.ev = d.ev; base.evLow = d.evLow; base.edge = d.edge; base.qualityScore = d.qualityScore; base.status = d.status;
    reasons.push(...d.reasons);
    return base;
  }

  /** Persistiert Signale, deaktiviert ältere Versionen derselben Auswahl. Liefert alt/neu für Benachrichtigungen. */
  persist(signals: Signal[], now: Date = new Date()): { prev: StoredSignal | null; next: StoredSignal }[] {
    const changes: { prev: StoredSignal | null; next: StoredSignal }[] = [];
    this.db.tx(() => {
      for (const s of signals) {
        const prev = this.db.get<StoredSignal>(`SELECT * FROM value_signals WHERE event_id = ? AND market_id = ? AND selection_id = ? AND ${s.line == null ? 'line IS NULL' : 'line = ?'} AND active = 1`,
          ...([s.eventId, s.market, s.selection, ...(s.line == null ? [] : [s.line])] as (string | number)[])) ?? null;
        // v0.4.0: unverändert nur, wenn ALLE Berechnungswerte und Eingaben gleich sind (Signatur). Vorher genügten
        // prediction_id, status und best_snapshot_id – geänderte Marktreferenz, Gewichte oder Strategie gingen verloren.
        if (prev && prev.calc_signature && prev.calc_signature === s.calcSignature) {
          // Nur zeitabhängige Felder fortschreiben (Qualitätswert enthält die Quotenfrische); Berechnungswerte bleiben.
          this.db.run('UPDATE value_signals SET validated_at = ?, valid_until = ?, quality_score = ? WHERE id = ?', s.validatedAt, s.validUntil, s.qualityScore, prev.id);
          continue;
        }
        if (prev) this.db.run('UPDATE value_signals SET active = 0, deactivated_at = ?, deactivation_reason = ? WHERE id = ?', nowIso(now), changeReason(prev, s), prev.id);
        const id = this.db.run(`INSERT INTO value_signals (event_id, prediction_id, market_id, selection_id, line, status, model_prob, decision_prob, model_weight, prob_low, implied_prob, novig_prob, fair_odds, best_odds, best_bookmaker_id, best_snapshot_id, edge, ev, ev_low, quality_score, reasons, active, created_at,
                                  odds_retrieved_at, odds_source_timestamp, validated_at, valid_until, market_ref_source, calc_signature)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?)`,
          s.eventId, s.predictionId, s.market, s.selection, s.line, s.status, s.modelProb, s.decisionProb, s.modelWeight, s.probLow, s.impliedProb, s.novigProb, s.fairOdds, s.bestOdds, s.bestBookmakerId, s.bestSnapshotId, s.edge, s.ev, s.evLow, s.qualityScore, JSON.stringify(s.reasons), nowIso(now),
          s.oddsRetrievedAt, s.oddsSourceTimestamp, s.validatedAt, s.validUntil, s.marketRefSource, s.calcSignature).lastInsertRowid;
        changes.push({ prev, next: this.db.get<StoredSignal>('SELECT * FROM value_signals WHERE id = ?', id)! });
      }
    });
    return changes;
  }

  /** Signale deaktivieren, deren Spiel begonnen hat oder deren Quote über die Gültigkeit hinaus ist. */
  expire(now: Date = new Date()): number {
    const t = nowIso(now);
    const a = this.db.run(`UPDATE value_signals SET active = 0, deactivated_at = ?, deactivation_reason = 'Spiel begonnen'
                        WHERE active = 1 AND event_id IN (SELECT id FROM events WHERE kickoff_utc <= ? OR status != 'scheduled')`, t, t).changes;
    const b = this.db.run(`UPDATE value_signals SET active = 0, deactivated_at = ?, deactivation_reason = 'STALE ODDS: Gültigkeit abgelaufen'
                        WHERE active = 1 AND status IN ('STRONG_VALUE','VALUE','WATCH') AND (valid_until IS NULL OR valid_until <= ?)`, t, t).changes;
    return a + b;
  }
  /** @deprecated v0.1.0-Name */
  expireStarted(now: Date = new Date()): number { return this.expire(now); }
}

/** Nachvollziehbarer Grund für eine neue Signalversion (für Transparenz in der Historie). */
function changeReason(prev: StoredSignal, s: Signal): string {
  const d: string[] = [];
  const ne = (a: number | null, b: number | null) => r9(a) !== r9(b);
  if (prev.prediction_id !== s.predictionId) d.push('neue Prognose');
  if (prev.status !== s.status) d.push(`Status ${prev.status}→${s.status}`);
  if (prev.best_snapshot_id !== s.bestSnapshotId) d.push('neue beste Quote');
  if (ne(prev.novig_prob, s.novigProb) || prev.market_ref_source !== s.marketRefSource) d.push('Marktreferenz geändert');
  if (ne(prev.model_weight, s.modelWeight)) d.push('Modellgewicht geändert');
  if (ne(prev.prob_low, s.probLow) && !ne(prev.decision_prob, s.decisionProb)) d.push('Unsicherheit/Strategie geändert');
  if (ne(prev.decision_prob, s.decisionProb) || ne(prev.ev, s.ev)) d.push('Entscheidungswahrscheinlichkeit/EV geändert');
  return 'ersetzt durch neue Berechnung' + (d.length ? ': ' + d.join(', ') : ' (Konfiguration geändert)');
}

export interface StoredSignal {
  id: number; event_id: number; prediction_id: number; market_id: MarketId; selection_id: SelectionId; line: number | null; status: SignalStatus;
  model_prob: number | null; decision_prob: number | null; model_weight: number | null; prob_low: number | null; implied_prob: number | null; novig_prob: number | null; fair_odds: number | null; best_odds: number | null;
  best_bookmaker_id: string | null; best_snapshot_id: string | null; edge: number | null; ev: number | null; ev_low: number | null; quality_score: number;
  reasons: string; active: number; created_at: string;
  odds_retrieved_at: string | null; odds_source_timestamp: string | null; validated_at: string | null; valid_until: string | null; market_ref_source: string | null; calc_signature: string | null;
}
