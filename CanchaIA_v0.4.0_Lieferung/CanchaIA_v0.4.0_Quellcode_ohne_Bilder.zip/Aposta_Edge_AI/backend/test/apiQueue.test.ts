import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ApiQueue, ApiError, type Fetcher } from '../src/api/apiQueue.js';
import { QuotaExhaustedError } from '../src/providers/types.js';
import { memDb } from './helpers.js';

const res = (status: number, body: unknown, headers: Record<string, string> = {}) => ({ status, headers: { get: (n: string) => headers[n.toLowerCase()] ?? null }, text: async () => JSON.stringify(body) });

function q(fetcher: Fetcher, budget = 100) {
  const db = memDb();
  const queue = new ApiQueue(db, fetcher, () => new Date(), 0.001);
  queue.register({ provider: 'p', dailyBudget: budget, maxConcurrent: 2, minIntervalMs: 0 });
  return { db, queue };
}

test('Cache: zweiter Aufruf kommt aus der Datenbank, nicht vom Provider', async () => {
  let n = 0;
  const { queue } = q(async () => { n++; return res(200, { ok: 1 }); });
  await queue.request({ provider: 'p', url: 'https://x.test/a?b=1', ttlSeconds: 60 });
  await queue.request({ provider: 'p', url: 'https://x.test/a?b=1', ttlSeconds: 60 });
  assert.equal(n, 1);
  assert.equal(queue.usedToday('p'), 1, 'Cache-Treffer zählen nicht zum Budget');
});

test('Deduplizierung gleichzeitiger identischer Anfragen', async () => {
  let n = 0;
  const { queue } = q(async () => { n++; await new Promise(r => setTimeout(r, 20)); return res(200, { ok: 1 }); });
  await Promise.all([1, 2, 3].map(() => queue.request({ provider: 'p', url: 'https://x.test/same', ttlSeconds: 0 })));
  assert.equal(n, 1);
});

test('Tagesbudget: Anfragen über dem Budget werden abgelehnt', async () => {
  const { queue } = q(async () => res(200, {}), 2);
  await queue.request({ provider: 'p', url: 'https://x.test/1', ttlSeconds: 0 });
  await queue.request({ provider: 'p', url: 'https://x.test/2', ttlSeconds: 0 });
  await assert.rejects(() => queue.request({ provider: 'p', url: 'https://x.test/3', ttlSeconds: 0 }), QuotaExhaustedError);
});

test('429 mit Retry-After wird beachtet und danach erfolgreich wiederholt', async () => {
  let n = 0;
  const { queue } = q(async () => (++n === 1 ? res(429, {}, { 'retry-after': '1' }) : res(200, { ok: true })));
  const r = await queue.request<{ ok: boolean }>({ provider: 'p', url: 'https://x.test/r', ttlSeconds: 0 });
  assert.equal(r.ok, true); assert.equal(n, 2);
});

test('5xx: exponentielles Backoff, danach Fehler', async () => {
  let n = 0;
  const { queue } = q(async () => { n++; return res(503, {}); });
  await assert.rejects(() => queue.request({ provider: 'p', url: 'https://x.test/e', ttlSeconds: 0, maxRetries: 2 }), ApiError);
  assert.equal(n, 3);
});

test('Kontingent-Header 0 pausiert die Synchronisation', async () => {
  let n = 0;
  const { queue, db } = q(async () => { n++; return res(200, {}, { 'x-ratelimit-requests-remaining': '0', 'x-ratelimit-requests-limit': '7500' }); });
  await queue.request({ provider: 'p', url: 'https://x.test/h', ttlSeconds: 0 });
  await assert.rejects(() => queue.request({ provider: 'p', url: 'https://x.test/h2', ttlSeconds: 0 }), QuotaExhaustedError);
  assert.equal(n, 1);
  const h = db.get<{ quota_remaining: number; quota_limit: number }>("SELECT quota_remaining, quota_limit FROM provider_health WHERE provider = 'p'")!;
  assert.equal(h.quota_remaining, 0); assert.equal(h.quota_limit, 7500);
  assert.equal(queue.budgetStatus('p').paused, true);
});

test('401 markiert den Provider als blockiert und wird nicht wiederholt', async () => {
  let n = 0;
  const { queue, db } = q(async () => { n++; return res(401, { message: 'invalid key' }); });
  await assert.rejects(() => queue.request({ provider: 'p', url: 'https://x.test/k', ttlSeconds: 0 }), ApiError);
  assert.equal(n, 1);
  assert.equal(db.get<{ status: string }>("SELECT status FROM provider_health WHERE provider = 'p'")!.status, 'blocked');
});
