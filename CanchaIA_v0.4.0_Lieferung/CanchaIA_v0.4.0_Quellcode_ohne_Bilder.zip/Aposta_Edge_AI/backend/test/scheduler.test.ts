import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, mockApp } from './helpers.js';
import { Scheduler, LOCK_TTL_MIN } from '../src/scheduler.js';
import { ApiQueue } from '../src/api/apiQueue.js';
import { QuotaExhaustedError } from '../src/providers/types.js';

const M = 60_000;
const at = (min: number) => new Date(ANCHOR.getTime() + min * M);
const syncRuns = (app: any) => app.db.all("SELECT status, started_at FROM sync_runs WHERE job = 'hourly_sync' ORDER BY id");

test('Mehrere Scheduler-Ticks mit simulierter Uhr: genau ein Sync pro Intervall, keine doppelten Alerts', async () => {
  const app = await mockApp();
  const s = new Scheduler(app);
  await s.tick(at(0));
  await s.tick(at(10));
  await s.tick(at(30));
  assert.equal(syncRuns(app).length, 1, 'innerhalb des Intervalls kein zweiter Lauf');
  const alerts1 = app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM alerts_sent')!.n;
  await s.tick(at(61));
  await s.tick(at(65));
  await s.tick(at(122));
  assert.equal(syncRuns(app).length, 3);
  assert.ok(syncRuns(app).every((r: any) => r.status === 'done'));
  const dup = app.db.get<{ n: number }>('SELECT COUNT(*) - COUNT(DISTINCT dedupe_key) AS n FROM alerts_sent')!.n;
  assert.equal(dup, 0, 'keine doppelten Meldungen');
  assert.ok(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM alerts_sent')!.n >= alerts1);
});

test('Absturz: verwaister Lauf wird als interrupted markiert, Lock läuft ab, Sync wird kontrolliert nachgeholt', async () => {
  const app = await mockApp();
  // simulierter Absturz: Lauf "running" ohne Heartbeat + fremdes Lock
  app.db.run("INSERT INTO sync_runs (job, started_at, status) VALUES ('hourly_sync', ?, 'running')", at(-120).toISOString());
  app.db.run("INSERT INTO job_locks (name, holder, expires_at) VALUES ('hourly_sync', 'toter-prozess', ?)", at(-120 + LOCK_TTL_MIN).toISOString());
  const s = new Scheduler(app);
  assert.equal(s.recoverStaleRuns(at(0)), 1);
  // Fehler-Wartezeit: interrupted vor 120 min → sofort fällig; Lock des toten Prozesses ist abgelaufen
  await s.tick(at(0));
  const runs = syncRuns(app);
  assert.equal(runs[0].status, 'interrupted');
  assert.equal(runs[1].status, 'done', 'Nachholen nach Neustart');
  assert.equal(runs.length, 2, 'nur EIN Nachhol-Lauf, nicht einer je verpasster Stunde');
});

test('Gültiges fremdes Lock (anderer Prozess läuft noch) verhindert einen zweiten Lauf', async () => {
  const app = await mockApp();
  app.db.run("INSERT INTO job_locks (name, holder, expires_at) VALUES ('hourly_sync', 'anderer-prozess', ?)", at(5).toISOString());
  const s = new Scheduler(app);
  const r = await s.runJob('hourly_sync', at(0));
  assert.equal(r.started, false);
  assert.equal(syncRuns(app).length, 0);
});

test('Fehlgeschlagener Job: kurze Wartezeit statt Endlosschleife', async () => {
  const app = await mockApp();
  const s = new Scheduler(app);
  (app.sync as any).run = async () => { throw new Error('kaputt'); };
  await s.tick(at(0));
  await s.tick(at(1));
  await s.tick(at(5));
  const n = app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM error_logs WHERE source = 'job.hourly_sync'")!.n;
  assert.equal(n, 1, 'innerhalb von 10 min kein erneuter Versuch');
  await s.tick(at(11));
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM error_logs WHERE source = 'job.hourly_sync'")!.n, 2);
});

test('Heartbeat verlängert das eigene Lock', async () => {
  const app = await mockApp();
  const s = new Scheduler(app);
  app.db.run("INSERT INTO job_locks (name, holder, expires_at) VALUES ('x', ?, ?)", s.holder, at(1).toISOString());
  assert.equal(s.heartbeat('x', at(5)), true);
  assert.equal(app.db.get<{ expires_at: string }>("SELECT expires_at FROM job_locks WHERE name = 'x'")!.expires_at, at(5 + LOCK_TTL_MIN).toISOString());
  app.db.run("UPDATE job_locks SET holder = 'fremd' WHERE name = 'x'");
  assert.equal(s.heartbeat('x', at(6)), false, 'fremdes Lock wird nicht übernommen');
});

test('Kontingentsperre überlebt einen Neustart (neue Queue-Instanz, gleiche DB)', async () => {
  const app = await mockApp();
  let calls = 0;
  const f = async () => { calls++; return { status: 429, headers: { get: (n: string) => (n === 'retry-after' ? '3600' : null) }, text: async () => '{}' }; };
  const q1 = new ApiQueue(app.db, f, () => ANCHOR, 0.001);
  q1.register({ provider: 'p', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0 });
  await assert.rejects(() => q1.request({ provider: 'p', url: 'https://x.test/a', ttlSeconds: 0 }), QuotaExhaustedError);
  assert.equal(calls, 1, '429 mit Retry-After 1 h: keine Wiederholung');
  const q2 = new ApiQueue(app.db, f, () => at(30), 0.001); // "Neustart"
  q2.register({ provider: 'p', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0 });
  await assert.rejects(() => q2.request({ provider: 'p', url: 'https://x.test/b', ttlSeconds: 0 }), QuotaExhaustedError);
  assert.equal(calls, 1, 'nach Neustart wird der Provider NICHT erneut kontaktiert');
  const q3 = new ApiQueue(app.db, async () => { calls++; return { status: 200, headers: { get: () => null }, text: async () => '{"ok":1}' }; }, () => at(61), 0.001);
  q3.register({ provider: 'p', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0 });
  assert.deepEqual(await q3.request({ provider: 'p', url: 'https://x.test/c', ttlSeconds: 0 }), { ok: 1 }, 'nach Ablauf der Sperre wieder erlaubt');
});

test('Monatsbudget wird eingehalten', async () => {
  const app = await mockApp();
  const q = new ApiQueue(app.db, async () => ({ status: 200, headers: { get: () => null }, text: async () => '{}' }), () => ANCHOR, 0.001);
  q.register({ provider: 'm', dailyBudget: 1000, monthlyBudget: 5, maxConcurrent: 1, minIntervalMs: 0 });
  await q.request({ provider: 'm', url: 'https://x.test/1', ttlSeconds: 0, cost: 4 });
  await assert.rejects(() => q.request({ provider: 'm', url: 'https://x.test/2', ttlSeconds: 0, cost: 4 }), /Monatsbudget/);
});
