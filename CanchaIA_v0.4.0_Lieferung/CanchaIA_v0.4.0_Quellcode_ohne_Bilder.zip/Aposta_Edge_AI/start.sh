#!/usr/bin/env bash
# CanchaIA – Start unter Linux/macOS. Aufruf: ./start.sh [mock|live] [--no-install] [--no-build]
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
command -v node >/dev/null 2>&1 || { echo "Node.js >= 22.13 nicht gefunden (https://nodejs.org)."; exit 3; }
exec node scripts/start.mjs "$@"
