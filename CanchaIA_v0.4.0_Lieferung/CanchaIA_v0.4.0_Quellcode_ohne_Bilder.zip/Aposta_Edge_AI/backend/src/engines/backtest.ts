/**
 * BacktestingEngine v0.2.0 – Walk-Forward mit fixiertem Holdout.
 *
 * Zeitliche Korrektheit
 * - Modellparameter (DC, Elo-Logit, Regression) nur aus Spielen vor Fensterbeginn; Form/Elo bis vor den Anstoß.
 * - Keine Aufstellungen/Datenqualität aus der Zukunft (werden im Backtest nicht verwendet).
 * - Entscheidungszeitpunkt = Anstoß − DECISION_LEAD. Wettquoten nur aus Snapshots der Art live/pre_closing,
 *   die VOR dem Entscheidungszeitpunkt abgerufen wurden. Schlusskurse (closing) dienen ausschließlich für CLV
 *   und als Benchmark – nie als damals verfügbare Wettquote.
 * - Ohne zeitlich gültige Quoten: keine Rendite, Auswertung als UNVOLLSTÄNDIG gekennzeichnet.
 *
 * Vergleiche (Holdout, je Markt): Basisrate · jedes Einzelmodell · Ensemble · Markt zum Entscheidungszeitpunkt ·
 * Mischungen w·Modell + (1−w)·Markt (w aus Walk-Forward gewählt) · Schlusskurs (nur Referenz, nicht handelbar).
 * Unsicherheit: gepaarter Bootstrap (1000×, deterministisch) für Log-Loss-Differenzen.
 *
 * Validierung (v0.4.0) je WETTBEWERB × MARKT (Scope). Ein Scope ist VALIDATED nur wenn ALLE gelten:
 *   echte Daten (kein Mock) · keine Datenqualitäts-Blocker des Wettbewerbs · Holdout ≥ 300 im Scope ·
 *   Ensemble signifikant besser als Basisrate (95-%-KI < 0) · ECE < 0,05 · ≥ 300 Marktquoten zum Entscheidungszeitpunkt ·
 *   gewähltes Mischgewicht > 0 · Mischung NICHT signifikant schlechter als der Markt.
 *   "Nicht signifikant schlechter" ist KEIN Nachweis eines Mehrwerts: marketEvidence = NOT_WORSE.
 *   Nur wenn die Mischung signifikant besser ist als der Markt (95-%-KI < 0): marketEvidence = BETTER (Voraussetzung für STRONG_VALUE).
 *   Fehlende BTTS-Quoten machen nur die BTTS-Scopes UNVALIDATED, nicht 1X2/OU. Ungeprüfte Wettbewerbe bleiben UNVALIDATED.
 *
 * Live-Konsistenz (v0.4.0):
 *   - Informationsstand: ein Spiel zählt erst als bekannt, wenn sein Ergebnis zum Entscheidungszeitpunkt vorlag
 *     (Anstoß + RESULT_AVAILABLE_AFTER_MS ≤ Entscheidung) – "Anstoß vor Zielspiel" reicht bei laufenden Spielen nicht.
 *   - Ensemble mit λ-Werten und derselben Stichprobengröße wie live (vorher gingen λ verloren → zu kleine Unsicherheit).
 *   - Entscheidung über value.ts/decide() (Datenqualität, AVOID, Strategie-z) und Auswahl über recommendation.ts/selectTop()
 *     (höchstens eine je Spiel, höchstens maxRecommendations je Auswahlfenster = Kalendertag des Entscheidungszeitpunkts in APP_TIMEZONE).
 *   - CSV-Quotenzeitpunkte sind GESCHÄTZT (Anstoß − 24 h); das wird im Ergebnis ausgewiesen und ist kein exakter Verfügbarkeitsnachweis.
 */
import type { Db } from '../db/db.js';
import { Repository } from './repository.js';
import type { HistMatch } from './prediction/history.js';
import { buildElo, dixonColes, elo, featureModel, fitDixonColes, fitFeatureModel, poissonStrength, type ModelOutput } from './prediction/models.js';
import { combine, type Weights } from './prediction/ensemble.js';
import { computeDataQuality, type DataQuality } from './prediction/index.js';
import { calibrationBins, ece } from './performance.js';
import { OddsStore, consensusNoVig, type MarketBookView } from './odds.js';
import { DEFAULT_MODEL_WEIGHT, decide } from './value.js';
import { selectTop } from './recommendation.js';
import type { Strategy } from '../config.js';
import { nowIso } from '../util/core.js';
import { rng } from '../providers/mock.js';
import type { MarketId, SelectionId } from '../providers/types.js';
import { MARKET_SELECTIONS } from '../providers/types.js';

export const DECISION_LEAD_MS = 60 * 60_000;
/** Ein Ergebnis gilt erst 150 min nach Anstoß als bekannt (90 min + Pause + Nachspielzeit + Puffer für die Datenlieferung). */
export const RESULT_AVAILABLE_AFTER_MS = 150 * 60_000;
/** Spiele, deren Ergebnis zum Zeitpunkt `at` bereits vorlag (all aufsteigend nach Anstoß sortiert). */
export function knownAt(all: HistMatch[], at: string): HistMatch[] {
  const t = Date.parse(at) - RESULT_AVAILABLE_AFTER_MS;
  let n = 0; while (n < all.length && Date.parse(all[n].kickoff) <= t) n++;
  return all.slice(0, n);
}
export const MIN_SCOPE_HOLDOUT = 300;
const MARKETS: MarketId[] = ['1X2', 'OU', 'BTTS'];
const W_GRID = [0, 0.1, 0.2, 0.3, 0.35, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1];

type Outcome = Record<MarketId, SelectionId>;
type P = Record<string, number>;
export interface Row {
  eventId: number; competitionId: number; kickoff: string; decisionAt: string; segment: 'walk_forward' | 'holdout'; outcome: Outcome;
  /** Verfügbare Modellausgaben inkl. λ (für dieselbe Ensemble-Unsicherheit wie live) */
  outputs: ModelOutput[];
  models: Record<string, Partial<Record<MarketId, P>>>;
  dq: DataQuality;
  ens: Partial<Record<MarketId, P>>; ensSd: Partial<Record<MarketId, P>>; agreement: number;
  market: Partial<Record<MarketId, { probs: P; views: MarketBookView[] }>>;  // Entscheidungszeitpunkt
  closing: Partial<Record<MarketId, P>>;                                       // nur Referenz
}

export type ScopeStatus = 'VALIDATED' | 'UNVALIDATED' | 'FAILED';
export type MarketEvidence = 'BETTER' | 'NOT_WORSE' | 'WORSE' | 'NOT_TESTABLE';
export interface ScopeValidation {
  competitionId: number; competition: string; market: MarketId; status: ScopeStatus; marketEvidence: MarketEvidence;
  n: number; marketN: number; ece: number | null; vsBaseline: Cmp | null; blendVsMarket: Cmp | null; blendWeight: number | null;
  oddsTimesEstimated: boolean; reasons: string[];
}
export interface BacktestOptions {
  includeMock?: boolean; refitDays?: number; minEv?: number; now?: Date; minMatches?: number;
  /** Blocker für ALLE Scopes (Altverhalten) */
  blockers?: string[];
  /** v0.4.0: Blocker je Wettbewerb (z. B. Duplikate, Data Leakage) – betreffen nur diesen Wettbewerb */
  blockersByCompetition?: Record<number, string[]>;
  strategy?: Strategy; modelWeight?: number | null; maxRecommendations?: number; timezone?: string;
}

interface Score { n: number; logLoss: number; brier: number }
interface Cmp { diff: number; lo: number; hi: number; n: number }

export interface BacktestMetrics {
  version: '0.2.0' | '0.3.0';
  dataSource: string; competitions: number; matches: { walkForward: number; holdout: number };
  decisionLeadMinutes: number;
  byModel: Record<string, Partial<Record<MarketId, Score>>>;
  baseline: Partial<Record<MarketId, Score>>;
  weights: Weights;
  holdoutEnsemble: Partial<Record<MarketId, Score & { ece: number; calibration: ReturnType<typeof calibrationBins> }>>;
  holdoutModels: Record<string, Partial<Record<MarketId, Score>>>;
  market: Partial<Record<MarketId, { n: number; decision: Score | null; closing: Score | null; coverage: number }>>;
  blend: Partial<Record<MarketId, { chosenWeight: number | null; walkForwardByWeight: { w: number; logLoss: number }[]; holdout: Score | null; vsMarket: Cmp | null }>>;
  comparisons: Partial<Record<MarketId, { ensembleVsBaseline: Cmp | null; ensembleVsMarket: Cmp | null; blendVsMarket: Cmp | null }>>;
  byCompetition: { competitionId: number; name: string; holdout: number; ensemble1x2: number | null; baseline1x2: number | null; market1x2: number | null;
    /** v0.3.0: je Markt Stichprobe, Log Loss, Brier und Kalibrierung für Ensemble, Basisrate und Markt (Entscheidungszeitpunkt). */
    markets?: Partial<Record<MarketId, { n: number; ensemble: Score | null; baseline: Score | null; market: Score | null; marketCoverage: number; ece: number | null }>> }[];
  betting: null | {
    simulated: true; complete: boolean; decisionRule: string; bets: number; qualifiedSignals: number; wins: number; profit: number; roi: number | null; yield: number | null;
    avgOdds: number | null; maxDrawdown: number; avgClv: number | null; clvCount: number; byMarket: Record<string, { bets: number; profit: number; roi: number | null }>; note: string;
    /** v0.4.0: Auswahl wie live */
    selection?: { rule: string; windows: number; maxPerWindow: number; maxBetsInAWindow: number; maxBetsPerEvent: number;
      excluded: { insufficientData: number; avoid: number; watchOrNoValue: number; correlatedSameEvent: number; beyondWindowLimit: number } };
    oddsTimes?: { estimatedShare: number; note: string };
  };
  bettingIncompleteReason: string | null;
  recommendedModelWeight: number | null;
  /** Gesamtstatus: VALIDATED nur wenn ALLE Scopes validiert; PARTIAL wenn mindestens einer. Live zählt nur der Scope. */
  validation: { status: 'VALIDATED' | 'PARTIAL' | 'UNVALIDATED' | 'FAILED'; reasons: string[] };
  /** v0.4.0 */
  scopes?: ScopeValidation[];
  blendWeightByMarket?: Partial<Record<MarketId, number | null>>;
  informationCutoffMinutes?: number;
}

const outcomeOf = (m: HistMatch): Outcome => ({
  '1X2': m.hg > m.ag ? 'HOME' : m.hg === m.ag ? 'DRAW' : 'AWAY',
  OU: m.hg + m.ag > 2.5 ? 'OVER' : 'UNDER',
  BTTS: m.hg > 0 && m.ag > 0 ? 'YES' : 'NO',
});
const ll1 = (p: P | undefined, y: string) => -Math.log(Math.max(1e-6, p?.[y] ?? 0));
const br1 = (p: P, y: string, sels: string[]) => sels.reduce((a, s) => a + ((p[s] ?? 0) - (s === y ? 1 : 0)) ** 2, 0);
const blendP = (m: P, k: P, w: number, sels: string[]): P => Object.fromEntries(sels.map(s => [s, w * (m[s] ?? 0) + (1 - w) * (k[s] ?? 0)]));

export class BacktestingEngine {
  private repo: Repository; private odds: OddsStore;
  /** Zeilen des letzten Laufs (nur für Tests und Diagnose; nicht persistiert). */
  lastRows: Row[] = [];
  constructor(private db: Db) { this.repo = new Repository(db); this.odds = new OddsStore(db); }

  run(opts: BacktestOptions = {}): { runId: number; metrics: BacktestMetrics } {
    const now = opts.now ?? new Date();
    const minM = opts.minMatches ?? 200;
    const comps = this.db.all<{ id: number; is_mock: number; name: string }>(`SELECT c.id, c.is_mock, c.name FROM competitions c WHERE ${opts.includeMock ? '1=1' : 'c.is_mock = 0'}
      AND (SELECT COUNT(*) FROM events e WHERE e.competition_id = c.id AND e.status = 'finished' AND e.home_goals IS NOT NULL) >= ?`, minM);
    const dataSource = comps.length && comps.every(c => c.is_mock) ? 'mock' : comps.some(c => c.is_mock) ? 'mixed' : this.sourceOfReal();
    const runId = this.db.run('INSERT INTO backtest_runs (started_at, status, data_source, config) VALUES (?, ?, ?, ?)', nowIso(now), 'running', dataSource, JSON.stringify(opts)).lastInsertRowid;
    try {
      const rows: Row[] = [];
      for (const c of comps) rows.push(...this.walkForward(c.id, opts.refitDays ?? 14, minM));
      this.lastRows = rows;
      const metrics = this.evaluate(rows, dataSource, comps, opts);
      this.db.run('UPDATE backtest_runs SET status = ?, finished_at = ?, metrics = ? WHERE id = ?', 'done', nowIso(), JSON.stringify(metrics), runId);
      this.storeModelVersion(runId, metrics);
      return { runId, metrics };
    } catch (e) {
      this.db.run('UPDATE backtest_runs SET status = ?, finished_at = ?, error = ? WHERE id = ?', 'failed', nowIso(), (e as Error).message, runId);
      throw e;
    }
  }

  private sourceOfReal(): string {
    const csv = this.db.get("SELECT 1 FROM competition_aliases WHERE provider = 'football-data-csv' LIMIT 1");
    return csv ? 'csv' : 'provider';
  }

  /** Marktsicht zum Entscheidungszeitpunkt (nur live/pre_closing, abgerufen vor decisionAt). */
  private marketAt(eventId: number, m: MarketId, decisionAt: string) {
    const views = this.odds.latestPerBookmaker(eventId, m, m === 'OU' ? 2.5 : null, decisionAt, ['live', 'pre_closing']).filter(v => v.valid && v.status === 'open');
    const c = consensusNoVig(views, m);
    return c ? { probs: c.probs as P, views } : undefined;
  }
  private closingAt(eventId: number, m: MarketId, kickoff: string) {
    const views = this.odds.latestPerBookmaker(eventId, m, m === 'OU' ? 2.5 : null, kickoff, ['closing']).filter(v => v.valid);
    return consensusNoVig(views, m)?.probs as P | undefined;
  }

  private walkForward(competitionId: number, refitDays: number, minM: number): Row[] {
    const all = this.repo.competitionHistory(competitionId);
    if (all.length < minM) return [];
    const burnIn = Math.max(120, Math.floor(all.length * 0.3));
    const holdoutStart = all[Math.floor(all.length * 0.75)].kickoff;
    const rows: Row[] = [];
    let i = burnIn;
    const lead = (k: string) => new Date(Date.parse(k) - DECISION_LEAD_MS).toISOString();
    while (i < all.length) {
      const windowStart = all[i].kickoff;
      const windowEnd = new Date(new Date(windowStart).getTime() + refitDays * 86_400_000).toISOString();
      // Parameter nur aus Spielen, deren Ergebnis zum FRÜHESTEN Entscheidungszeitpunkt des Fensters bekannt war
      const fitAt = lead(windowStart);
      const train = knownAt(all, fitAt);
      const dc = fitDixonColes(train, fitAt), el = buildElo(train, fitAt), ft = fitFeatureModel(train, fitAt);
      for (; i < all.length && all[i].kickoff < windowEnd; i++) {
        const m = all[i];
        const decisionAt = lead(m.kickoff);
        const seen = knownAt(all, decisionAt);
        const outs: ModelOutput[] = [
          poissonStrength(seen, m.home, m.away, decisionAt, !!m.neutral),
          dixonColes(dc, train, m.home, m.away, fitAt, !!m.neutral),
          elo(el, m.home, m.away, !!m.neutral),
          featureModel(ft, seen, m.home, m.away, decisionAt, !!m.neutral),
        ];
        const avail = outs.filter(o => o.available && o.probs);
        if (!avail.length) continue;
        const models: Row['models'] = {};
        for (const o of avail) models[o.model] = Object.fromEntries(Object.entries(o.probs!).map(([k, v]) => [k, v as P]));
        // Historische Aufstellungen sind unbekannt → wie ein Live-Spiel ohne Aufstellung bewertet (konservativ)
        const dq = computeDataQuality(seen, m.home, m.away, decisionAt, outs, 'none');
        const market: Row['market'] = {}, closing: Row['closing'] = {};
        for (const mk of MARKETS) {
          const a = this.marketAt(m.eventId, mk, decisionAt); if (a) market[mk] = a;
          const c = this.closingAt(m.eventId, mk, m.kickoff); if (c) closing[mk] = c;
        }
        rows.push({ eventId: m.eventId, competitionId, kickoff: m.kickoff, decisionAt, segment: m.kickoff >= holdoutStart ? 'holdout' : 'walk_forward', outcome: outcomeOf(m),
          outputs: avail, models, dq, ens: {}, ensSd: {}, agreement: 0, market, closing });
      }
    }
    return rows;
  }

  private evaluate(rows: Row[], dataSource: string, comps: { id: number; name: string }[], opts: BacktestOptions): BacktestMetrics {
    const minEv = opts.minEv ?? 0.05;
    const wf = rows.filter(r => r.segment === 'walk_forward'), ho = rows.filter(r => r.segment === 'holdout');
    const modelNames = ['poisson', 'dixon_coles', 'elo', 'feature'];
    const score = (set: Row[], get: (r: Row) => P | undefined, m: MarketId): Score | null => {
      let ll = 0, br = 0, n = 0;
      for (const r of set) { const p = get(r); if (!p) continue; ll += ll1(p, r.outcome[m]); br += br1(p, r.outcome[m], MARKET_SELECTIONS[m]); n++; }
      return n ? { n, logLoss: ll / n, brier: br / n } : null;
    };
    const byModel: BacktestMetrics['byModel'] = {}, holdoutModels: BacktestMetrics['holdoutModels'] = {};
    const weights: Weights = {}, baseline: BacktestMetrics['baseline'] = {}, baseP: Partial<Record<MarketId, P>> = {};
    for (const m of MARKETS) {
      const freq: Record<string, number> = {};
      for (const r of wf) freq[r.outcome[m]] = (freq[r.outcome[m]] ?? 0) + 1;
      baseP[m] = Object.fromEntries(MARKET_SELECTIONS[m].map(s => [s, ((freq[s] ?? 0) + 1) / (wf.length + MARKET_SELECTIONS[m].length)]));
      const b = score(ho, () => baseP[m], m); if (b) baseline[m] = b;
      const ll: Record<string, number> = {};
      for (const name of modelNames) {
        const s = score(wf, r => r.models[name]?.[m], m);
        if (s) { (byModel[name] ??= {})[m] = s; ll[name] = s.logLoss; }
        const h = score(ho, r => r.models[name]?.[m], m);
        if (h) (holdoutModels[name] ??= {})[m] = h;
      }
      const minLL = Math.min(...Object.values(ll));
      if (Number.isFinite(minLL)) {
        const raw = Object.fromEntries(Object.entries(ll).map(([k, v]) => [k, Math.exp(-(v - minLL) * 40)]));
        const sum = Object.values(raw).reduce((a, x) => a + x, 0);
        weights[m] = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k, +(v / sum).toFixed(4)]));
      }
    }
    // Ensemble je Zeile wie live: vollständige Modellausgaben (inkl. λ) und Stichprobe = kleinere Teamhistorie
    for (const r of rows) {
      const c = combine(r.outputs, weights, Math.min(r.dq.homeGames, r.dq.awayGames));
      r.ens = c.probs as Row['ens']; r.ensSd = c.sd as Row['ensSd']; r.agreement = c.agreement;
    }
    const holdoutEnsemble: BacktestMetrics['holdoutEnsemble'] = {}, market: BacktestMetrics['market'] = {}, blend: BacktestMetrics['blend'] = {}, comparisons: BacktestMetrics['comparisons'] = {};
    let seed = 0;
    const blendWeightByMarket: Partial<Record<MarketId, number | null>> = {};
    for (const m of MARKETS) {
      const sels = MARKET_SELECTIONS[m];
      const s = score(ho, r => r.ens[m], m);
      if (s) {
        const items = ho.flatMap(r => r.ens[m] ? sels.map(sel => ({ p: r.ens[m]![sel], y: r.outcome[m] === sel ? 1 : 0 })) : []);
        holdoutEnsemble[m] = { ...s, ece: ece(items), calibration: calibrationBins(items) };
      }
      const withMkt = ho.filter(r => r.market[m] && r.ens[m]);
      market[m] = { n: withMkt.length, decision: score(withMkt, r => r.market[m]?.probs, m), closing: score(ho.filter(r => r.closing[m]), r => r.closing[m], m), coverage: ho.length ? withMkt.length / ho.length : 0 };
      // Mischgewicht nur auf dem Walk-Forward-Teil wählen (kein Blick in den Holdout)
      const wfM = wf.filter(r => r.market[m] && r.ens[m]);
      const byW = wfM.length >= 50 ? W_GRID.map(w => ({ w, logLoss: wfM.reduce((a, r) => a + ll1(blendP(r.ens[m]!, r.market[m]!.probs, w, sels), r.outcome[m]), 0) / wfM.length })) : [];
      const chosen = byW.length ? byW.reduce((a, b) => (b.logLoss < a.logLoss - 1e-9 ? b : a)).w : null;
      blendWeightByMarket[m] = chosen;
      const blendHo = chosen != null ? score(withMkt, r => blendP(r.ens[m]!, r.market[m]!.probs, chosen, sels), m) : null;
      blend[m] = { chosenWeight: chosen, walkForwardByWeight: byW.map(x => ({ w: x.w, logLoss: +x.logLoss.toFixed(5) })), holdout: blendHo,
        vsMarket: chosen != null ? pairedBootstrap(withMkt.map(r => ll1(blendP(r.ens[m]!, r.market[m]!.probs, chosen, sels), r.outcome[m]) - ll1(r.market[m]!.probs, r.outcome[m])), `b${m}${seed++}`) : null };
      const withEns = ho.filter(r => r.ens[m]);
      comparisons[m] = {
        ensembleVsBaseline: withEns.length ? pairedBootstrap(withEns.map(r => ll1(r.ens[m], r.outcome[m]) - ll1(baseP[m], r.outcome[m])), `e${m}${seed++}`) : null,
        ensembleVsMarket: withMkt.length ? pairedBootstrap(withMkt.map(r => ll1(r.ens[m], r.outcome[m]) - ll1(r.market[m]!.probs, r.outcome[m])), `m${m}${seed++}`) : null,
        blendVsMarket: blend[m]!.vsMarket,
      };
    }
    const byCompetition = comps.map(c => {
      const h = ho.filter(r => r.competitionId === c.id);
      return { competitionId: c.id, name: c.name, holdout: h.length, ensemble1x2: score(h, r => r.ens['1X2'], '1X2')?.logLoss ?? null,
        baseline1x2: score(h, () => baseP['1X2'], '1X2')?.logLoss ?? null, market1x2: score(h.filter(r => r.market['1X2']), r => r.market['1X2']?.probs, '1X2')?.logLoss ?? null,
        markets: Object.fromEntries(MARKETS.map(m => {
          const he = h.filter(r => r.ens[m]), hm = he.filter(r => r.market[m]);
          const items = he.flatMap(r => MARKET_SELECTIONS[m].map(sel => ({ p: r.ens[m]![sel], y: r.outcome[m] === sel ? 1 : 0 })));
          return [m, { n: he.length, ensemble: score(he, r => r.ens[m], m), baseline: score(he, () => baseP[m], m), market: score(hm, r => r.market[m]?.probs, m), marketCoverage: he.length ? hm.length / he.length : 0, ece: items.length ? ece(items) : null }];
        })) };
    }).filter(c => c.holdout > 0);

    // Wettsimulation: nur mit zeitlich gültigen Quoten, gleiche Entscheidungs- UND Auswahlregel wie live
    const anyDecisionOdds = ho.some(r => MARKETS.some(m => r.market[m]));
    const strategy = opts.strategy ?? 'BALANCED';
    const betting = anyDecisionOdds ? this.simulateBets(ho, { strategy, modelWeight: opts.modelWeight ?? DEFAULT_MODEL_WEIGHT[strategy], minEv, max: opts.maxRecommendations ?? 5, timezone: opts.timezone ?? 'America/Asuncion' }) : null;
    const bettingIncompleteReason = anyDecisionOdds ? null : 'UNVOLLSTÄNDIG: keine zeitlich gültigen Quoten zum Entscheidungszeitpunkt – keine historische Rendite berechnet';

    // Validierung je Wettbewerb × Markt
    const mock = dataSource === 'mock' || dataSource === 'mixed';
    const scopes: ScopeValidation[] = [];
    for (const c of comps) for (const m of MARKETS) scopes.push(this.validateScope(c, m, ho, baseP[m]!, blendWeightByMarket[m] ?? null, mock, [...(opts.blockers ?? []), ...(opts.blockersByCompetition?.[c.id] ?? [])], seed++));
    const nVal = scopes.filter(x => x.status === 'VALIDATED').length;
    const status: BacktestMetrics['validation']['status'] = mock || !scopes.length ? 'UNVALIDATED' : nVal === scopes.length ? 'VALIDATED' : nVal > 0 ? 'PARTIAL'
      : scopes.some(x => x.status === 'FAILED') ? 'FAILED' : 'UNVALIDATED';
    const reasons: string[] = [];
    if (mock) reasons.push('Mock-Daten: keine gültige historische Validierung möglich');
    if (!scopes.length) reasons.push('Kein Wettbewerb mit ausreichender Historie: nichts validiert');
    for (const b of opts.blockers ?? []) reasons.push(`Datenqualität: ${b}`);
    for (const x of scopes) for (const r of x.reasons) reasons.push(`${x.competition} · ${x.market}: ${r}`);
    if (status === 'VALIDATED' || status === 'PARTIAL') reasons.push(`${nVal} von ${scopes.length} Bereichen (Wettbewerb × Markt) validiert. Nur diese Bereiche gelten live als validiert; alle anderen bleiben UNVALIDATED.`);
    const ws = MARKETS.map(m => blendWeightByMarket[m]).filter((x): x is number => x != null);
    const recommendedModelWeight = ws.length ? Math.min(...ws) : null; // Altfeld: konservativ kleinstes Gewicht
    return {
      version: '0.3.0', dataSource, competitions: comps.length, matches: { walkForward: wf.length, holdout: ho.length }, decisionLeadMinutes: DECISION_LEAD_MS / 60_000,
      byModel, baseline, weights, holdoutEnsemble, holdoutModels, market, blend, comparisons, byCompetition, betting, bettingIncompleteReason, recommendedModelWeight,
      validation: { status, reasons: [...new Set(reasons)] }, scopes, blendWeightByMarket, informationCutoffMinutes: RESULT_AVAILABLE_AFTER_MS / 60_000,
    };
  }

  /** Validierung eines Bereichs (Wettbewerb × Markt). Ohne ausreichenden Nachweis: UNVALIDATED. */
  private validateScope(c: { id: number; name: string }, m: MarketId, ho: Row[], baseP: P, w: number | null, mock: boolean, blockers: string[], seed: number): ScopeValidation {
    const sels = MARKET_SELECTIONS[m];
    const h = ho.filter(r => r.competitionId === c.id && r.ens[m]);
    const hm = h.filter(r => r.market[m]);
    const items = h.flatMap(r => sels.map(sel => ({ p: r.ens[m]![sel], y: r.outcome[m] === sel ? 1 : 0 })));
    const e = items.length ? ece(items) : null;
    const vsBaseline = h.length ? pairedBootstrap(h.map(r => ll1(r.ens[m], r.outcome[m]) - ll1(baseP, r.outcome[m])), `s${c.id}${m}b${seed}`) : null;
    const blendVsMarket = w != null && hm.length ? pairedBootstrap(hm.map(r => ll1(blendP(r.ens[m]!, r.market[m]!.probs, w, sels), r.outcome[m]) - ll1(r.market[m]!.probs, r.outcome[m])), `s${c.id}${m}m${seed}`) : null;
    const estimated = hm.length > 0 && hm.some(r => r.market[m]!.views.some(v => v.timeEstimated));
    const reasons: string[] = [];
    let failed = false, unval = false;
    const no = (why: string) => { reasons.push(why); unval = true; };
    const fail = (why: string) => { reasons.push(why); failed = true; };
    if (mock) no('Mock-Daten');
    for (const b of blockers) no(`Datenqualität: ${b}`);
    if (h.length < MIN_SCOPE_HOLDOUT) no(`zu kleiner Holdout (${h.length} Spiele, mindestens ${MIN_SCOPE_HOLDOUT})`);
    else {
      if (!vsBaseline || vsBaseline.hi >= 0) fail(`Ensemble nicht signifikant besser als die Basisrate (ΔLogLoss ${fmtCmp(vsBaseline)})`);
      if (e != null && e >= 0.05) fail(`Kalibrierungsfehler ECE ${e.toFixed(3)} ≥ 0,05`);
    }
    let evidence: MarketEvidence = 'NOT_TESTABLE';
    if (hm.length < MIN_SCOPE_HOLDOUT) no(`zu wenige Marktquoten zum Entscheidungszeitpunkt (${hm.length}) – Vergleich mit dem Markt nicht prüfbar`);
    else if (w === 0) no('Modell liefert keinen Mehrwert gegenüber dem Markt (optimales Gewicht 0)');
    else if (blendVsMarket) {
      evidence = blendVsMarket.lo > 0 ? 'WORSE' : blendVsMarket.hi < 0 ? 'BETTER' : 'NOT_WORSE';
      if (evidence === 'WORSE') fail(`Mischung signifikant schlechter als der Markt (${fmtCmp(blendVsMarket)})`);
    }
    if (estimated) reasons.push('Quotenzeitpunkte geschätzt (CSV: Anstoß − 24 h) – kein exakter Nachweis der historischen Verfügbarkeit');
    const status: ScopeStatus = mock || unval ? (failed && !mock ? 'FAILED' : 'UNVALIDATED') : failed ? 'FAILED' : 'VALIDATED';
    if (status === 'VALIDATED') reasons.push(evidence === 'BETTER'
      ? 'signifikant besser als Basisrate, kalibriert und Mischung signifikant besser als der Markt (Mehrwert im Holdout belegt)'
      : 'signifikant besser als Basisrate und kalibriert; Mischung NICHT signifikant schlechter als der Markt – das ist KEIN Nachweis eines Mehrwerts gegenüber dem Markt');
    return { competitionId: c.id, competition: c.name, market: m, status, marketEvidence: evidence, n: h.length, marketN: hm.length, ece: e, vsBaseline, blendVsMarket, blendWeight: w, oddsTimesEstimated: estimated, reasons };
  }

  /**
   * Flat 1u, Entscheidung wie live (value.ts/decide) und Auswahl wie live (recommendation.ts/selectTop):
   * Datenqualität, Unsicherheit (Strategie-z), AVOID-Regel, höchstens eine Wette je Spiel und höchstens `max` je Auswahlfenster.
   * Auswahlfenster = Kalendertag des Entscheidungszeitpunkts in der App-Zeitzone (live: jeder Lauf zeigt höchstens 5 aktive Empfehlungen).
   * Unterschiede zu live (ausgewiesen): Quotenfrische fließt mit 0 in den Qualitätswert ein (Zeitpunkte geschätzt), keine Aufstellungen.
   */
  private simulateBets(ho: Row[], o: { strategy: Strategy; modelWeight: number; minEv: number; max: number; timezone: string }): NonNullable<BacktestMetrics['betting']> {
    type Cand = { id: number; event_id: number; ev_low: number | null; quality_score: number; row: Row; m: MarketId; sel: SelectionId; odds: number; window: string };
    const ex = { insufficientData: 0, avoid: 0, watchOrNoValue: 0, correlatedSameEvent: 0, beyondWindowLimit: 0 };
    const dayOf = new Intl.DateTimeFormat('en-CA', { timeZone: o.timezone, year: 'numeric', month: '2-digit', day: '2-digit' });
    const cands: Cand[] = [];
    let complete = true, seq = 0, viewsUsed = 0, viewsEstimated = 0;
    for (const r of ho) for (const m of MARKETS) {
      const mk = r.market[m], pm = r.ens[m], sd = r.ensSd[m];
      if (!pm) continue;
      if (!mk) { complete = false; continue; }
      if (r.dq.status === 'insufficient') { ex.insufficientData += MARKET_SELECTIONS[m].length; continue; }
      for (const sel of MARKET_SELECTIONS[m]) {
        const best = mk.views.reduce<MarketBookView | null>((a, v) => (v.prices[sel] ?? 0) > (a?.prices[sel] ?? 0) ? v : a, null);
        if (!best) continue;
        const ref = consensusNoVig(mk.views, m, best.bookmakerId);
        const d = decide({ p: pm[sel], sd: sd?.[sel] ?? null, bestOdds: best.prices[sel]!, novig: ref?.probs[sel] ?? null, strategy: o.strategy, minEv: o.minEv, modelWeight: o.modelWeight,
          dqScore: r.dq.score, agreement: r.agreement, modelValidated: false, marketEdgeProven: false, isMock: false, freshness: 0, freshBooks: mk.views.length, marketRefSource: ref?.source ?? null });
        if (d.status === 'AVOID') { ex.avoid++; continue; }
        if (d.status !== 'VALUE' && d.status !== 'STRONG_VALUE') { ex.watchOrNoValue++; continue; }
        viewsUsed++; if (best.timeEstimated) viewsEstimated++;
        cands.push({ id: seq++, event_id: r.eventId, ev_low: d.evLow, quality_score: d.qualityScore, row: r, m, sel, odds: best.prices[sel]!, window: dayOf.format(new Date(r.decisionAt)) });
      }
    }
    const byWindow = new Map<string, Cand[]>();
    for (const c of cands) byWindow.set(c.window, [...(byWindow.get(c.window) ?? []), c]);
    const bets: Cand[] = [];
    let maxInWindow = 0;
    for (const list of [...byWindow.entries()].sort((a, b) => a[0].localeCompare(b[0])).map(e => e[1])) {
      const all = selectTop(list, Number.MAX_SAFE_INTEGER), top = all.slice(0, o.max);
      ex.correlatedSameEvent += all.reduce((a, t) => a + t.correlated.length, 0);
      ex.beyondWindowLimit += all.length - top.length;
      bets.push(...top.map(t => t.pick)); maxInWindow = Math.max(maxInWindow, top.length);
    }
    bets.sort((a, b) => a.row.kickoff.localeCompare(b.row.kickoff) || a.id - b.id);
    let wins = 0, profit = 0, peak = 0, dd = 0, oddsSum = 0, clvSum = 0, clvN = 0;
    const byMarket: Record<string, { bets: number; profit: number; roi: number | null }> = {};
    const perEvent = new Map<number, number>();
    for (const b of bets) {
      perEvent.set(b.event_id, (perEvent.get(b.event_id) ?? 0) + 1);
      oddsSum += b.odds;
      const won = b.row.outcome[b.m] === b.sel;
      if (won) wins++;
      const pl = won ? b.odds - 1 : -1;
      profit += pl; peak = Math.max(peak, profit); dd = Math.max(dd, peak - profit);
      const bm = (byMarket[b.m] ??= { bets: 0, profit: 0, roi: null }); bm.bets++; bm.profit += pl; bm.roi = bm.profit / bm.bets;
      const close = b.row.closing[b.m]?.[b.sel];
      if (close) { clvSum += b.odds * close - 1; clvN++; } // erwarteter Wert zum fairen Schlusskurs
    }
    const n = bets.length;
    const estShare = viewsUsed ? viewsEstimated / viewsUsed : 0;
    return {
      simulated: true, complete,
      decisionRule: `wie live (decide): Strategie ${o.strategy}, p_dec = ${o.modelWeight}·Modell + ${+(1 - o.modelWeight).toFixed(2)}·Markt (ohne bewerteten Buchmacher); EV ≥ ${(o.minEv * 100).toFixed(0)} %; EV-Untergrenze > 0; Datenqualität ≥ Mindestwert; AVOID bei > 12 Pp. Abweichung; Entscheidung ${DECISION_LEAD_MS / 60_000} min vor Anstoß`,
      bets: n, qualifiedSignals: cands.length, wins, profit: +profit.toFixed(2), roi: n ? profit / n : null, yield: n ? profit / n : null, avgOdds: n ? oddsSum / n : null,
      maxDrawdown: +dd.toFixed(2), avgClv: clvN ? clvSum / clvN : null, clvCount: clvN, byMarket,
      note: 'SIMULIERT im Holdout gegen zum Entscheidungszeitpunkt verfügbare (Pre-Closing-)Quoten. Keine echte Performance.'
        + (estShare > 0 ? ` Quotenzeitpunkte zu ${(estShare * 100).toFixed(0)} % GESCHÄTZT (kein exakter Verfügbarkeitsnachweis).` : '')
        + (complete ? '' : ' Nicht für alle Spiele lagen Quoten vor (UNVOLLSTÄNDIG).'),
      selection: { rule: `höchstens 1 je Spiel, höchstens ${o.max} je Auswahlfenster (Kalendertag des Entscheidungszeitpunkts, ${o.timezone}); Rang = EV-Untergrenze × Qualität`,
        windows: byWindow.size, maxPerWindow: o.max, maxBetsInAWindow: maxInWindow, maxBetsPerEvent: Math.max(0, ...perEvent.values()), excluded: ex },
      oddsTimes: { estimatedShare: estShare, note: estShare > 0 ? 'Geschätzte Erfassungszeitpunkte (football-data.co.uk: Anstoß − 24 h). Belegen keine exakte historische Verfügbarkeit.' : 'Erfassungszeitpunkte aus echten Abrufen.' },
    };
  }

  private storeModelVersion(runId: number, m: BacktestMetrics) {
    const id = `ensemble-1.1.0+bt${runId}`;
    // v0.3.0: Modellversionen sind unveränderlich (Trigger); jede Backtest-Version bekommt eine eigene ID
    this.db.run('INSERT INTO model_versions (id, description, weights, validation_status, validated_by_backtest) VALUES (?, ?, ?, ?, ?)',
      id, `Gewichte aus Backtest #${runId} (${m.dataSource})`, JSON.stringify({ ...m.weights, blendWeight: m.recommendedModelWeight, blendWeightByMarket: m.blendWeightByMarket ?? {} }), m.validation.status, runId);
    // v0.4.0: Status je Wettbewerb × Markt (unveränderlich, append-only)
    for (const s of m.scopes ?? [])
      this.db.run(`INSERT INTO model_scope_validations (model_version_id, backtest_run_id, competition_id, market_id, status, market_evidence, holdout_n, market_n, blend_weight, odds_times_estimated, reasons, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, id, runId, s.competitionId, s.market, s.status, s.marketEvidence, s.n, s.marketN, s.blendWeight, s.oddsTimesEstimated ? 1 : 0, JSON.stringify(s.reasons), nowIso());
  }

  latest(): { id: number; started_at: string; finished_at: string | null; status: string; data_source: string; metrics: BacktestMetrics | null } | null {
    const r = this.db.get<{ id: number; started_at: string; finished_at: string | null; status: string; data_source: string; metrics: string | null }>('SELECT * FROM backtest_runs ORDER BY id DESC LIMIT 1');
    return r ? { ...r, metrics: r.metrics ? JSON.parse(r.metrics) : null } : null;
  }
}

/** Gepaarter Bootstrap der mittleren Differenz (negativ = erstes besser). 95-%-Perzentil-Intervall, deterministisch. */
export function pairedBootstrap(d: number[], seed: string, B = 1000): Cmp | null {
  if (!d.length) return null;
  const mean = d.reduce((a, b) => a + b, 0) / d.length;
  const r = rng('bootstrap:' + seed), ms: number[] = [];
  for (let b = 0; b < B; b++) { let s = 0; for (let i = 0; i < d.length; i++) s += d[Math.floor(r() * d.length)]; ms.push(s / d.length); }
  ms.sort((a, b) => a - b);
  return { diff: mean, lo: ms[Math.floor(0.025 * B)], hi: ms[Math.floor(0.975 * B)], n: d.length };
}
const fmtCmp = (c: Cmp | null | undefined) => c ? `${c.diff.toFixed(4)} [${c.lo.toFixed(4)}; ${c.hi.toFixed(4)}]` : '–';
