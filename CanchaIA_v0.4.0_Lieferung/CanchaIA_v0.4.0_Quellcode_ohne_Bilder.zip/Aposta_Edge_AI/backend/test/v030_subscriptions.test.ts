/**
 * v0.3.0 – Verbesserung 4: Tarifverwaltung, Zahlungsprüfung (Testmodus), Berechtigungen, Sicherheit.
 * Keine echten Zahlungen, keine echten Bankdaten (nur Platzhalter aus der Testkonfiguration).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { ANCHOR, mockApp, TEST_ADMIN } from './helpers.js';
import { createServer } from '../src/server.js';
import { AuthService } from '../src/auth.js';
import { addPeriod, SubscriptionService } from '../src/subscriptions.js';
import { configIssues, loadConfig } from '../src/config.js';

const PDF = Buffer.from('%PDF-1.4\n% Testbeleg ohne echte Daten\n').toString('base64');
const PNG_HEADER = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]).toString('base64');
const BANK = { PAYMENT_BANK_ALIAS: 'alias-de-prueba', PAYMENT_BANK_NAME: 'Banco de Prueba', PAYMENT_ACCOUNT_HOLDER: 'Titular de Prueba' };

async function start(over: Record<string, string> = {}) {
  const app = await mockApp({ ...BANK, ...over });
  await app.sync.run(ANCHOR);
  let clock = new Date(ANCHOR.getTime() + 60_000);
  const server = createServer(app, null, { clock: () => clock });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const auth = new AuthService(app.db, null);
  const users = {
    a: auth.createUser('kunde-a@example.test', 'kunde-a-passwort-123', 'user'),
    b: auth.createUser('kunde-b@example.test', 'kunde-b-passwort-123', 'user'),
    admin2: auth.createUser('admin2@example.test', 'admin-zwei-passwort-1', 'admin'),
  };
  async function login(email: string, password: string) {
    const r = await fetch(base + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ email, password }) });
    const cookie = (r.headers.get('set-cookie') ?? '').split(';')[0];
    const csrf = (await r.json() as any).csrfToken;
    const call = async (p: string, init: { method?: string; body?: unknown } = {}) => {
      const res = await fetch(base + p, { method: init.method ?? 'GET', headers: { 'content-type': 'application/json', cookie, 'x-csrf-token': csrf }, body: init.body === undefined ? undefined : JSON.stringify(init.body) });
      return { status: res.status, body: await res.json().catch(() => null) as any };
    };
    return call;
  }
  return {
    app, server, users, login, setClock: (d: Date) => { clock = d; },
    A: await login('kunde-a@example.test', 'kunde-a-passwort-123'),
    B: await login('kunde-b@example.test', 'kunde-b-passwort-123'),
    ADMIN: await login(TEST_ADMIN.email, TEST_ADMIN.password),
    ADMIN2: await login('admin2@example.test', 'admin-zwei-passwort-1'),
  };
}

test('V4: Ohne Durchsetzung bleiben alle bisherigen Funktionen frei (keine Regression)', async () => {
  const t = await start();
  try {
    const recs = await t.A('/api/recommendations');
    assert.equal(recs.status, 200);
    const total = (await t.ADMIN('/api/recommendations')).body.recommendations.length;
    assert.equal(recs.body.recommendations.length, total, 'FREE-Benutzer sieht ohne Durchsetzung alles wie bisher');
    assert.equal(recs.body.plan.enforced, false);
    assert.equal((await t.A('/api/analyst', { method: 'POST', body: { question: '¿Qué tan vieja es la cuota?' } })).status, 200);
    const ov = await t.A('/api/subscription');
    assert.equal(ov.body.plan, 'FREE'); assert.equal(ov.body.status, 'NONE');
    assert.deepEqual(ov.body.plans.map((p: any) => [p.id, p.price_monthly_pyg, p.price_yearly_pyg]), [['FREE', 0, 0], ['PRO', 79000, 790000], ['PREMIUM', 139000, 1200000]]);
  } finally { t.server.close(); }
});

test('V4: Bestellung → Beleg → KEINE automatische Freischaltung → Admin prüft Zahlungseingang → ACTIVE', async () => {
  const t = await start();
  try {
    const co = await t.A('/api/subscription/checkout', { method: 'POST', body: { planId: 'PRO', period: 'monthly', method: 'bank_transfer' } });
    assert.equal(co.status, 200, JSON.stringify(co.body));
    assert.equal(co.body.amountPyg, 79000);
    assert.match(co.body.reference, /^AEA-[A-Z2-9]{6}$/);
    assert.equal(co.body.instructions.alias, 'alias-de-prueba', 'Bankdaten nur aus der Konfiguration');
    // Beleg mit falschem Inhalt / falschem Typ wird abgelehnt
    assert.equal((await t.A(`/api/payments/${co.body.paymentId}/proof`, { method: 'POST', body: { fileName: 'x.pdf', mime: 'application/pdf', dataBase64: PNG_HEADER } })).status, 400);
    assert.equal((await t.A(`/api/payments/${co.body.paymentId}/proof`, { method: 'POST', body: { fileName: 'x.exe', mime: 'application/x-msdownload', dataBase64: PDF } })).status, 400);
    const up = await t.A(`/api/payments/${co.body.paymentId}/proof`, { method: 'POST', body: { fileName: 'comprobante.pdf', mime: 'application/pdf', dataBase64: PDF } });
    assert.equal(up.body.status, 'PROOF_SUBMITTED');
    let ov = await t.A('/api/subscription');
    assert.equal(ov.body.plan, 'FREE', 'Beleg allein schaltet NICHT frei');
    assert.equal(ov.body.pendingPayments[0].status, 'PROOF_SUBMITTED');
    // Prüfregeln des Admins
    const v = (body: object) => t.ADMIN(`/api/admin/payments/${co.body.paymentId}/verify`, { method: 'POST', body });
    const ok = { bankReference: 'SIPAP-TEST-0001', receivedAmountPyg: 79000, receivedAt: new Date(ANCHOR.getTime() + 30_000).toISOString(), confirmReceived: true };
    assert.equal((await v({ ...ok, confirmReceived: undefined })).status, 400, 'ohne ausdrückliche Bestätigung');
    assert.equal((await v({ ...ok, receivedAmountPyg: 70000 })).status, 400, 'falscher Betrag');
    assert.equal((await v({ ...ok, bankReference: '' })).status, 400, 'ohne Bankreferenz');
    assert.equal((await v({ ...ok, receivedAt: '2030-01-01T00:00:00Z' })).status, 400, 'Eingang in der Zukunft');
    const done = await v(ok);
    assert.equal(done.status, 200, JSON.stringify(done.body));
    assert.equal(done.body.status, 'ACTIVE');
    assert.equal(done.body.expiresAt, addPeriod(done.body.startedAt, 'monthly'));
    ov = await t.A('/api/subscription');
    assert.equal(ov.body.plan, 'PRO'); assert.equal(ov.body.status, 'ACTIVE');
    assert.equal((await v(ok)).status, 409, 'nicht doppelt freigeben');
    const ev = (await t.ADMIN('/api/admin/subscription-events')).body.map((e: any) => e.action);
    for (const a of ['checkout', 'proof_submitted', 'payment_verified', 'activated']) assert.ok(ev.includes(a), a);
  } finally { t.server.close(); }
});

test('V4: Sicherheit – fremde Zahlungen, Admin-Endpunkte, eigene Freigabe, doppelte Bankreferenz', async () => {
  const t = await start();
  try {
    const coA = await t.A('/api/subscription/checkout', { method: 'POST', body: { planId: 'PREMIUM', period: 'yearly', method: 'bank_transfer' } });
    assert.equal(coA.body.amountPyg, 1200000);
    assert.equal((await t.B(`/api/payments/${coA.body.paymentId}/proof`, { method: 'POST', body: { fileName: 'b.pdf', mime: 'application/pdf', dataBase64: PDF } })).status, 404, 'B kann A nicht anfassen');
    for (const p of ['/api/admin/payments', '/api/admin/subscriptions', `/api/admin/payments/${coA.body.paymentId}/proof`]) assert.equal((await t.B(p)).status, 403, p);
    assert.equal((await t.B(`/api/admin/payments/${coA.body.paymentId}/verify`, { method: 'POST', body: {} })).status, 403);
    assert.equal((await t.B('/api/admin/subscriptions/grant', { method: 'POST', body: { userId: t.users.b.id, planId: 'PREMIUM', reason: 'selbst freischalten' } })).status, 403);
    // Admin bestellt selbst → darf die eigene Zahlung nicht freigeben, ein zweiter Admin schon
    const own = await t.ADMIN2('/api/subscription/checkout', { method: 'POST', body: { planId: 'PRO', period: 'monthly', method: 'bank_transfer' } });
    const body = { bankReference: 'SIPAP-TEST-7777', receivedAmountPyg: 79000, receivedAt: new Date(ANCHOR.getTime() + 30_000).toISOString(), confirmReceived: true };
    assert.equal((await t.ADMIN2(`/api/admin/payments/${own.body.paymentId}/verify`, { method: 'POST', body })).status, 403);
    assert.equal((await t.ADMIN(`/api/admin/payments/${own.body.paymentId}/verify`, { method: 'POST', body })).status, 200);
    // gleiche Bankreferenz für eine andere Zahlung → abgelehnt
    assert.equal((await t.ADMIN(`/api/admin/payments/${coA.body.paymentId}/verify`, { method: 'POST', body: { ...body, receivedAmountPyg: 1200000 } })).status, 409);
    // Rolle bleibt unabhängig vom Tarif
    const me = await t.ADMIN2('/api/auth/me');
    assert.equal(me.body.user.role, 'admin');
    // Protokoll ist unveränderlich
    assert.throws(() => t.app.db.run("UPDATE subscription_events SET action = 'x'"), /unveraenderlich/);
    assert.throws(() => t.app.db.run('DELETE FROM subscription_events'), /unveraenderlich/);
  } finally { t.server.close(); }
});

test('V4: Durchsetzung aktiv – FREE begrenzt, PRO nach Freischaltung, Ablauf → EXPIRED', async () => {
  const t = await start({ SUBSCRIPTIONS_ENFORCE: 'true' });
  try {
    const all = (await t.ADMIN('/api/recommendations')).body.recommendations.length;
    assert.ok(all >= 2, 'Mock-Lauf liefert mehrere Empfehlungen');
    const free = await t.A('/api/recommendations');
    assert.equal(free.body.recommendations.length, 1, 'FREE: 1 Empfehlung');
    assert.equal(free.body.plan.hidden, all - 1);
    assert.equal((await t.A('/api/analyst', { method: 'POST', body: { question: 'hola' } })).status, 402, 'FREE: kein EDGE ANALYST');
    assert.equal((await t.ADMIN('/api/analyst', { method: 'POST', body: { question: 'hola' } })).status, 200, 'Admin immer voller Zugriff');
    // Manuelle Freischaltung (ohne Zahlung) nur mit Begründung, im Protokoll sichtbar
    assert.equal((await t.ADMIN('/api/admin/subscriptions/grant', { method: 'POST', body: { userId: t.users.a.id, planId: 'PRO', months: 1 } })).status, 400);
    const g = await t.ADMIN('/api/admin/subscriptions/grant', { method: 'POST', body: { userId: t.users.a.id, planId: 'PRO', months: 1, reason: 'Testkonto Pilotphase' } });
    assert.equal(g.body.status, 'ACTIVE');
    assert.equal((await t.A('/api/recommendations')).body.recommendations.length, Math.min(5, all));
    assert.equal((await t.A('/api/analyst', { method: 'POST', body: { question: 'hola' } })).status, 200);
    assert.equal((await t.B('/api/analyst', { method: 'POST', body: { question: 'hola' } })).status, 402, 'B bleibt FREE');
    // Ablauf
    t.setClock(new Date(ANCHOR.getTime() + 40 * 86_400_000));
    // Sessions laufen nach 12 h ab → neu anmelden (gleiche Server-Uhr)
    const A2 = await t.login('kunde-a@example.test', 'kunde-a-passwort-123'), ADM = await t.login(TEST_ADMIN.email, TEST_ADMIN.password);
    const ov = await A2('/api/subscription');
    assert.equal(ov.body.plan, 'FREE');
    assert.ok(ov.body.history.some((h: any) => h.status === 'EXPIRED'));
    assert.ok((await ADM('/api/admin/subscription-events')).body.some((e: any) => e.action === 'expired' && e.user_id === t.users.a.id));
    assert.equal((await A2('/api/analyst', { method: 'POST', body: { question: 'hola' } })).status, 402, 'nach Ablauf wieder FREE');
  } finally { t.server.close(); }
});

test('V4: uPay nur Testmodus ohne Belastung; UPAY_MODE=live wird abgelehnt', async () => {
  const live = loadConfig({ UPAY_MODE: 'live' } as NodeJS.ProcessEnv);
  assert.equal(live.subscriptions.upayMode, 'disabled');
  assert.ok(configIssues(live).some(i => /UPAY_MODE=live wird ignoriert/.test(i)));
  const app = await mockApp({ UPAY_MODE: 'test' });
  const svc = new SubscriptionService(app.db, app.cfg, () => ANCHOR);
  assert.deepEqual(svc.methods().map(m => `${m.method}:${m.mode}`), ['bank_transfer:manual', 'upay:test']);
  const u = new AuthService(app.db, null).createUser('upay@example.test', 'upay-test-passwort-1', 'user');
  const co = svc.checkout(u.id, 'PRO', 'monthly', 'upay');
  assert.equal(co.instructions.procedure, 'upay_test_mode_no_charge');
  assert.equal(app.db.get<{ provider_ref: string }>('SELECT provider_ref FROM payments WHERE id = ?', co.paymentId)!.provider_ref, `UPAY-TEST-${co.reference}`);
  assert.equal(svc.entitlements(u.id, 'user').plan, 'FREE', 'auch uPay-Test schaltet nicht selbst frei');
  // ohne UPAY_MODE ist uPay nicht wählbar
  const off = new SubscriptionService(app.db, (await mockApp()).cfg, () => ANCHOR);
  assert.throws(() => off.checkout(u.id, 'PRO', 'monthly', 'upay'), /nicht verfügbar/);
});

test('V4: Laufzeiten – Monatsende, Jahr, Verlängerung ab Ablauf des laufenden Abos', () => {
  assert.equal(addPeriod('2026-01-31T10:00:00.000Z', 'monthly'), '2026-02-28T10:00:00.000Z');
  assert.equal(addPeriod('2028-01-31T10:00:00.000Z', 'monthly'), '2028-02-29T10:00:00.000Z');
  assert.equal(addPeriod('2026-10-13T00:00:00.000Z', 'yearly'), '2027-10-13T00:00:00.000Z');
});
