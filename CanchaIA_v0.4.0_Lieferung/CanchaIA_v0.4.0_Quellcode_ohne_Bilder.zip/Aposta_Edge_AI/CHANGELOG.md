## v0.4.0 – Konsistenz für den kontrollierten Live-Pilot (26.10.2026)

Details: [CHANGES_v0.4.0.md](CHANGES_v0.4.0.md) · Tests: [TEST_REPORT_v0.4.0.md](TEST_REPORT_v0.4.0.md) · Start: [START.md](START.md) · Blocker: [OPEN_BLOCKERS.md](OPEN_BLOCKERS.md)

> Nicht produktionsreif, nicht als profitabel nachgewiesen. Es gab keinen echten Quotenabruf, weil kein Schlüssel verfügbar war, und keine Validierung mit echten Daten.

- Signalpersistenz: Änderungserkennung über alle Berechnungswerte und die Konfiguration (vorher gingen geänderte EV, Marktreferenz, Gewicht und Strategie verloren).
- Prognose-Cache: Inhalts-Hash der Historie (korrigierte Ergebnisse und xG führen zu neuem Fit, gespeicherte = zurückgegebene Prognose).
- Backtest wie live: λ-Unsicherheit, Informationsstand zum Entscheidungszeitpunkt, gemeinsame Entscheidungs- und Auswahlregel (höchstens 1 je Spiel, 5 je Fenster), geschätzte CSV-Zeitpunkte gekennzeichnet.
- Validierung je Wettbewerb × Markt. „Nicht schlechter als der Markt“ ist kein Mehrwert, STRONG_VALUE nur mit belegtem Mehrwert. Scheduler, API und CLI laufen über die Datenqualitätsprüfung.
- The Odds API: kostenloser Discovery-Job getrennt vom kostenpflichtigen Quotenjob, Budget-Vorabprüfung, Ergebnisse je Wettbewerb gebündelt, stabile Cache-Schlüssel, getrennte Nachweise im Admin.
- Datengrundlage je Wettbewerb (Admin); Champions League ohne Historie → INSUFFICIENT DATA mit Erklärung.
- Lockfiles, Frontend-Typprüfung, Start für Windows und Linux, `.env` wird geladen (Umgebung hat Vorrang), strikte Prüfung von DATA_MODE und STRATEGY, KI-Analyst mit gekennzeichnetem lokalem Fallback.
- Migration 008 (rein ergänzend). Tests: 169/169 (vorher 139).

## v0.3.4 – The Odds API: kostenlose Fixture-Discovery und stabile Zugriffssperre (13.10.2026)

- `TheOddsApiProvider.upcomingFixtures()` nutzt den kostenlosen, authentifizierten `/v4/sports/{sport}/events`-Endpunkt mit Datumsfiltern statt des kostenpflichtigen `/odds`-Endpunkts.
- 1X2 und Über/Unter 2,5 werden danach ausschließlich über den kostenpflichtigen `/odds`-Endpunkt geladen; BTTS bleibt optional über Event-Odds und standardmäßig deaktiviert.
- Wenn keine priorisierten Spiele vorhanden sind, wird kein kostenpflichtiger Odds-Abruf ausgelöst.
- Nach einem HTTP 401/403 verhindert nun die persistente Request-Historie erneute kostenpflichtige Abrufe, auch wenn später ein kostenloser Event-Abruf die Provider-Health-Anzeige verändert. Ein erneuter erfolgreicher Verbindungstest hebt die Sperre auf.
- Alte Testfälle an die Aufteilung `/events` (kostenlos) und `/odds` (kostenpflichtig) angepasst und zwei neue Free-Discovery-Tests hinzugefügt.
- Backend-Build (TypeScript): erfolgreich. Backend-Suite: **139/139 bestanden** mit lokal eingebundenen Node-Typdefinitionen. Tests mit nachgebauten Provider-Antworten; **kein echter Provider-Live-Test**, da `THE_ODDS_API_KEY` nicht in dieser Umgebung gesetzt und kein produktiver Deployment-Zugriff vorhanden ist.
- Keine echten API-Aufrufe, keine Änderungen an Produktivdaten, keine Änderungen an API-Budgets, keine neuen Abonnements.

# Changelog

## 0.3.3 – 13.10.2026: The Odds API integriert (Champions League)

Details, Deployment-Schritte und ehrlicher Status in [THE_ODDS_API_INTEGRATION.md](THE_ODDS_API_INTEGRATION.md).

> **Live nicht verifiziert:** In der Entwicklungsumgebung war das Secret nicht gesetzt und `api.the-odds-api.com` gesperrt. Es gab keinen echten Abruf (0 Credits verbraucht). Die produktive Anwendung wurde nicht verändert.

- **Verbindungstest** über den kostenlosen Endpunkt `GET /v4/sports`: ein Versuch, 0 Credits, gespeichert inkl. `x-requests-remaining/-used/-last` und Status von `soccer_uefa_champs_league`. Admin-Button und `npm run odds:check`.
- **Status CONNECTED / DEGRADED / DISCONNECTED**: Admin-Karte „THE ODDS API“, alle Werte aus dem Backend.
- **Sperre**: Kostenpflichtige Abrufe (auch automatisch) erst nach bestandenem Test; ein 401/403 danach sperrt erneut.
- **Kostenkontrolle**: Standard eine Region (`eu`). Kostenvoranschlag vor dem kontrollierten Lauf. Der Abruf wird verweigert, wenn Tages-/Monatsbudget oder die vom Anbieter gemeldeten Restcredits nicht reichen. `THE_ODDS_API_DAILY_BUDGET` (Standard weiterhin 16).
- **Märkte**: Über/Unter nur Linie 2,5; `h2h_3_way` als 1X2-Ersatz ohne Duplikate. Fehlendes Unentschieden oder halbe Märkte werden weiterhin abgelehnt.
- **Behoben**:
  - `THE_ODDS_API_BASE_URL=…/v4` führte zu `/v4/v4/…`.
  - Die Log-Bereinigung schwärzte Hinweistexte („THE_ODDS_API_KEY [REDACTED]“), aber bei `authorization: Bearer …` nicht den Token.
- Migration `007` (rein ergänzend). Tests: 137 (vorher 121). Der Migrationstest wurde für 007 geöffnet, alle übrigen Tests sind unverändert.
- Champions League: echte Quoten, aber **keine Modellhistorie**. Prognosen bleiben INSUFFICIENT DATA, es gibt keine Value Bets. Modelle weiterhin UNVALIDATED.

## 0.3.2 – 13.10.2026: Rebranding „CanchaIA – Inteligencia Futbolística“

Öffentliche Marke für den paraguayischen Markt. Reines Branding, kein Funktionsumbau. Details in [BRANDING.md](BRANDING.md).

> ⚠️ Namensverfügbarkeit und Markenregistrierung von „CanchaIA“ sind **noch nicht rechtlich bestätigt**.

- Sichtbarer Name **CanchaIA** mit Slogan **Inteligencia Futbolística** (Seitenleiste, Kopfzeile Start, Anmeldung, Seitentitel, Meta-Daten).
- Neues Logo und Favicon (Spielfeld, Mittelkreis in Cyan, grüner Strafraum) in den Farben des bestehenden Design-Systems. Neu: `apple-touch-icon.png`.
- Assistent „EDGE ANALYST“/„Edge AI“ heißt jetzt **Analista IA** / **AI Analyst** / **KI-Analyst** (Navigation, Konsole, Schnellzugriff, Tarifliste).
- Standardsprache Español (Paraguay): `lang="es-PY"`, Auswahl „Español (Paraguay)“. Locale zentral in `frontend/src/brand.ts`.
- Guaraní immer im Format `es-PY` (`79.000 Gs.`), Zeitzone weiterhin `America/Asuncion`.
- Dokumenttitel je Seite (`Partidos · CanchaIA`); bei unbekannten Routen gilt der Starttitel.
- Backend: nur Texte (Identität im KI-Prompt, Startmeldung). DB, APIs, Modelle, EV, Auth und Abos unverändert.
- Technische Kennungen (Pakete, DB-Pfad, Cookie, Zahlungsreferenz `AEA-`) bewusst unverändert, siehe BRANDING.md.
- Tests: 121/121 Backend-Tests grün; neuer E2E-Branding-/Regressionstest `scripts/e2e-branding.mjs` (88/88), Screenshots in `docs/screenshots/`.

## 0.3.1 – 13.10.2026: Frontend-Redesign „Professional Analytics“

Reines Frontend-Redesign. Backend, API, Datenmodell, Scheduler, Tarif-Logik und Modelle sind unverändert (keine Datei unter `backend/` geändert, 121/121 Tests grün). Details, Konflikte und offene Risiken stehen in [FRONTEND_REDESIGN.md](FRONTEND_REDESIGN.md).

- Neues Design-System: Tokens (Navy/Schiefer, Cyan für Interaktion, Grün/Bernstein/Rot nur für Bedeutung), IBM Plex Sans / Condensed, UI-Kit `ui.tsx` mit Button, Card, Badge, Banner, KPI, Tabs, Feldern, Leer-/Lade-/Fehlerzuständen, ProbBar und **Edge-Meter**.
- Shell: Seitenleiste (Desktop) und Tab-Leiste (Handy); Kopfzeile mit Beta, Mock/Live, Tarif, letzter Sync.
- Überarbeitete Seiten:
  - Übersicht (KPI-Leiste, Value-Karten, Systemzustand, Schnellzugriff)
  - Spiele (Filterleiste mit Signal und Mindest-EV, Tabelle ab 900 px)
  - Spieldetail (Kopf, 6 Kennzahlen, Tabs)
  - EDGE ANALYST als Analyse-Konsole mit Blöcken MATCH, MARKET, MODEL, DATA, RISKS, VERDICT, gebildet nur aus mitgelieferten Werkzeug-Daten
  - Performance (Kennzeichnung kleiner/unvollständiger Stichproben)
  - Einstellungen (Profil, Sprache, Benachrichtigungen, Tarif, Sicherheit, Analyse nur für Admins)
  - Anmeldung/Registrierung (Beta-Hinweis bei gesperrter Registrierung)
  - Admin
- `pages.tsx` aufgeteilt in `pages/*`; `useLoad` nach `hooks.ts`.

## 0.3.0 – 13.10.2026: gezielte, risikoarme Weiterentwicklung

Weiterentwicklung von 0.2.0, keine neue App, gleiche Architektur. Migrationen `004`–`006` sind nur ergänzend. Die Prognosemodelle sind mathematisch unverändert.

### Behoben (mit Regressionstest)
- **Provider-Diagnose:** Mit nur `THE_ODDS_API_KEY` meldete die Konfigurationsprüfung fälschlich „kein Fixture-Provider“. Ein nicht konfiguriertes Highlightly galt im Sync als Fehler, wodurch ein Lauf ohne Prognosen als `failed` endete.
- **BTTS:** In der App-Verdrahtung wurde `includeBtts` nie gesetzt. BTTS-Quoten waren über The Odds API daher nicht abrufbar. Jetzt per Option, mit Limit und Budget-Reserve.
- **Cache vs. Frische:** Ein fester 20-min-Quoten-Cache konnte in der letzten Stunde vor Anstoß (Grenze 10 min) Kopien liefern, die sofort verworfen werden mussten. Jetzt dynamische Regel nach dem nächsten Anstoß.
- **„MARKET SUSPENDED“ für fehlende Märkte:** Nicht gelieferte oder nicht angefragte Märkte wurden als ausgesetzt angezeigt. Jetzt `NOT AVAILABLE` mit Grund.
- **Live-Pilot ohne Historie:** Teams und Wettbewerbe von The Odds API wurden nie mit der CSV-Historie verknüpft („Manchester United“ ≠ „Man United“, `soccer_epl` ≠ `E0`). Live-Spiele bekamen deshalb immer INSUFFICIENT DATA, und CSV-Ergebnisse landeten nicht beim Live-Spiel.
- **Keine Ergebnisse im Odds-API-Betrieb:** The Odds API hatte keine Ergebnisabfrage, Pilot-Empfehlungen konnten nicht abgerechnet werden. Jetzt `/scores?daysFrom=3`.
- **Begonnene Spiele aus dem Provider-Feed** wurden als `scheduled` angelegt. Jetzt beim Abruf ausgeschlossen.
- **CSV-Anstoßzeiten:** pauschal UTC−1 h, im Winter 1 h zu früh. Jetzt korrekte GMT/BST-Umrechnung.
- **Lesestatus von Meldungen** war global: Benutzer A konnte Meldungen für alle als gelesen markieren. Jetzt je Benutzer.
- **Modellversionen** waren per `INSERT OR REPLACE` überschreibbar. Jetzt unveränderlich (Trigger).

### Hinzugefügt
1. **API/Konfiguration:** `providerStates` (READY, NOT CONFIGURED, BLOCKED, MOCK MODE), Abrufprotokoll (Endpunkt, bereinigte Parameter, Zweck, Credits) mit Admin-Ansicht, dynamische Cache-Regel auch für Highlightly.
2. **Pilotbetrieb:**
   - `PILOT_MODE` mit Prüfung der Sport-Keys gegen `/v4/sports`
   - kontrollierter Diagnose-Sync (`POST /api/admin/diagnostics/controlled-sync`) mit Bericht, Abrufliste, Credits und 8 automatischen Prüfungen, gespeichert in `diagnostic_runs`
   - LIVE VERIFIED nur mit echtem Netzwerk-Fetcher
3. **Historische Validierung:**
   - Datenqualitätsprüfung: Duplikate, mögliche Doppel-Teams, fehlende Ergebnisse, unplausible Ergebnisse, Heim/Auswärts, Quotenabdeckung, Stichprobe zur zeitlichen Trennung
   - Validierungsablauf (`npm run validate`, Admin) mit Markdown/JSON-Bericht, Kennzahlen je Liga **und** Markt, Datenquellen und Nutzungsbedingungen
   - Datenqualitäts-Befunde verhindern VALIDATED
4. **Tarifverwaltung (Testmodus):**
   - FREE, PRO und PREMIUM mit den vorgegebenen Preisen in Gs.
   - Abo-Status ACTIVE, PENDING, EXPIRED, CANCELLED; monatliche oder jährliche Laufzeit
   - Bestellung, Beleg-Upload, Admin-Prüfung (Bankreferenz, exakter Betrag, Datum, Bestätigung, keine Selbstfreigabe), begründete Freischaltung ohne Zahlung
   - unveränderliches Änderungsprotokoll; Berechtigungen serverseitig (402); Tageskontingent für EDGE ANALYST
   - uPay-Schnittstelle nur als Test
   - `SUBSCRIPTIONS_ENFORCE` standardmäßig aus
5. **Persönliche Benachrichtigungen:**
   - `user_alerts`, `alert_reads`, Opt-in, Meldungstypen inkl. EV-Änderung, optionaler Mindest-EV
   - Deduplizierung je Benutzer, nur In-App, serverseitige Zugriffskontrolle
   - bestehende AlertEngine und Event-Erkennung unverändert
- Frontend: Provider-Bereitschaft, kontrollierter Sync, Abrufprotokoll, Validierung, Zahlungsprüfung (Admin); Tarif, Bestellung, Beleg, persönliche Meldungen (Einstellungen). Keine Umgestaltung der bestehenden Oberfläche.
- CLI: `data-quality`, `validate`. Dokumente: SUBSCRIPTION_SYSTEM, PAYMENT_INTEGRATION, LIVE_API_TEST_REPORT.
- 121 automatisierte Tests (vorher 93). Bestehende Tests sind unverändert; nur der v0.1.0-Migrationstest wurde für weitere Migrationen geöffnet.

### Unverändert ehrlich
- Modelle **UNVALIDATED**, STRONG_VALUE wird nicht vergeben. The Odds API **nicht live verifiziert**. Keine Rendite behauptet. Keine echten Zahlungen.

## 0.2.0 – 13.10.2026: Härtung

Weiterentwicklung von 0.1.0, keine neue App. Die Datenbank wird automatisch migriert (`003_v020_lifecycle_security.sql`, nur ergänzend).

### Behoben (Befunde des Audits, Details in TEST_REPORT.md)
- **Veraltete Empfehlungen:** Empfehlungen blieben aktiv, bis der nächste erfolgreiche Sync sie ersetzte. Fiel der Sync aus, blieben sie stundenlang sichtbar. Jetzt hat jede Empfehlung `valid_until` und wird bei jedem Abruf revalidiert.
- **Cache-Zeitstempel:** Quoten aus dem Cache bekamen den aktuellen Zeitpunkt als Abrufzeit, alte Quoten wirkten dadurch frisch. Jetzt bleibt der ursprüngliche Abrufzeitpunkt erhalten.
- **Freshness:** Eine feste Grenze galt unabhängig von der Zeit bis zum Anstoß. Quellzeitstempel wurden nur grob (4× Grenze) geprüft, Zukunftszeitstempel gar nicht. Jetzt gestaffelt (90/60/30/10 min) mit halber Grenze ohne Quellzeit und Ablehnung von Zukunftszeitstempeln.
- **Doppelte Marktinformation:** Der bewertete Buchmacher floss in seinen eigenen fairen Referenzpreis ein. Jetzt gilt die Leave-one-out-Referenz.
- **Backtest-Look-Ahead:** Die simulierte Wettstrategie nutzte Snapshots bis zum Anstoß, bei CSV-Daten also den Schlusskurs, als Wettquote. Jetzt nur Quoten vor dem Entscheidungszeitpunkt (Anstoß − 60 min). Schlusskurse dienen nur als Benchmark und für CLV.
- **Validierung ohne Marktvergleich:** VALIDATED war möglich, ohne dass das Modell gegen den Markt geprüft wurde. Jetzt nötig: signifikant besser als die Basisrate (Bootstrap-KI), ECE < 0,05 und ein Marktvergleich.
- **Credits:** The Odds API wurde mit 1 je Anfrage gezählt (tatsächlich Märkte × Regionen), ein Monatsbudget gab es nicht. Jetzt Credits aus `x-requests-last` sowie Tages- und Monatsbudget.
- **429:** Es gab mehrere Wiederholungen, und die Sperre lag nur im Arbeitsspeicher und war nach einem Neustart vergessen. Jetzt höchstens eine kurze Wiederholung, danach eine persistente Sperre.
- **Scheduler:** Locks hatten keinen Heartbeat, abgestürzte Läufe blieben auf `running`, ein fehlgeschlagener Sync ohne eigenen Eintrag war unsichtbar. Alles behoben.
- **Sicherheit:** Ein gemeinsames Admin-Token galt für alle und lag im `localStorage`. Ersetzt durch Benutzer, Rollen und Session-Cookies (siehe SECURITY_REVIEW.md).
- **Mock im Live-Modus:** Mock-Daten in der Datenbank konnten im Live-Modus ausgeliefert werden. Jetzt gefiltert.
- **Alerts:** Der Dedupe-Schlüssel für „neue Value Bet“ enthielt die Quote nicht. Ein Signal, das zurückgezogen wurde und später zu einer anderen Quote wieder qualifiziert war, erzeugte deshalb keine neue Meldung.
- Während der Abschlussprüfung gefunden: Monatsbudget und Kosten-Header von The Odds API waren nur im Test, nicht in der App-Verdrahtung registriert. Ein unlesbarer `Origin`-Header (`null`) wurde nicht als fremd behandelt.

### Hinzugefügt
- Freshness-Modul als einzige Quelle der Wahrheit. Getrennte Zeitstempel (Abruf, Quelle, Cache, Verarbeitung, Validierung, Gültigkeit) bis in die Oberfläche.
- Snapshot-Arten `live`/`pre_closing`/`closing`. CSV-Import speichert Pre-Closing (geschätzt, Anstoß − 24 h) und Closing getrennt.
- Backtest 0.2.0: Vergleich mit Basisrate, Einzelmodellen, Ensemble, Markt zum Entscheidungszeitpunkt, Mischgewichten (aus Walk-Forward gewählt) und Schlusskurs. Gepaarte Bootstrap-Konfidenzintervalle, Auswertung je Wettbewerb, empfohlenes Modellgewicht, Kennzeichnung „unvollständig“.
- Benutzerkonten (`user`/`admin`), scrypt, Sessions, CSRF, Origin-Prüfung, Kontosperre, Sicherheitsprotokoll, Benutzerverwaltung, CLI `user:create` und `user:password`, Service-Token (`ADMIN_TOKEN`, ≥ 32 Zeichen) und Lese-Token (`READ_TOKEN`, nur GET).
- Systemweite Analyse-Einstellungen (nur Admin), getrennt von persönlichen Einstellungen. Wettbewerbe lassen sich auswählen.
- Scheduler mit Heartbeat, Wiederaufnahme nach Absturz, Wartezeit nach Fehler und einmaligem Nachholen.
- Frontend: Statusleiste, Banner UNVALIDATED MODEL / PROVIDER UNAVAILABLE, Odds-Alter und Herkunft, Chip STALE ODDS, „Kürzlich zurückgezogen“, Anmeldung mit E-Mail und Passwort, Admin-Bereiche Credits, Provider-Freigabe, Benutzer und Sicherheit.
- EDGE ANALYST: Werkzeug `get_odds_age`, Antworten mit Datenstand. Keine Empfehlung ohne gültige, frische Quote.
- Dokumente: API_INTEGRATION, SECURITY_REVIEW, BASE44_INTEGRATION (nur Leitfaden), KNOWN_LIMITATIONS, TEST_REPORT.
- 93 automatisierte Tests (vorher 51).

### Geändert
- Cache für Quoten 45 → 20 min (Highlightly, The Odds API).
- `ADMIN_TOKEN` ist kein Browser-Login mehr. Anmeldung mit `ADMIN_EMAIL`/`ADMIN_PASSWORD`.
- Ensemble-Version `ensemble-1.1.0`.

### Unverändert ehrlich
- Modelle **UNVALIDATED**, STRONG_VALUE wird nicht vergeben. Live-Provider **nicht live verifiziert**. Keine historische Rendite behauptet.

## 0.1.0 – 13.10.2026

Erste Version. Neu aufgebaut, weil kein Base44-Export vorlag.

### Hinzugefügt
- Backend (Node 22, TypeScript, ohne Laufzeit-Abhängigkeiten): REST-API, SQLite-Schema mit Migrationen (33 Tabellen), unveränderliche Quoten-Snapshots per Trigger
- Provider: Highlightly (OpenAPI 8.2.7, gesperrt bis zur Rechte-Bestätigung), The Odds API v4, CSV-Import football-data.co.uk, Mock-Provider für den Entwicklungsmodus
- Zentrale ApiQueue mit Tagesbudget, DB-Cache, Deduplizierung, Retry-After, exponentiellem Backoff, Kontingent-Synchronisation und Pause
- EventMatchingEngine (IDs, Aliase, Fuzzy mit Anstoßfenster, Ablehnung vertauschter und mehrdeutiger Zuordnungen)
- Quotenvalidierung (Zuordnung, Vollständigkeit, Torlinie, Status, Alter, Marge), BookmakerRegistry, No-Vig, Marktkonsens
- Prognosen: Poisson-Stärke, Dixon-Coles (ML + ρ), Elo mit geordnetem Logit, Poisson-Regression (IRLS) auf Merkmalen, Ensemble mit Unsicherheit, Datenqualität
- Value-Engine mit Entscheidungswahrscheinlichkeit (Modell + fairer Marktpreis), EV und EV-Untergrenze, 8 Signalstatus, AVOID-Schutz
- RecommendationEngine: max. 5, eine je Spiel, Korrelationshinweis, „NO QUALIFIED VALUE BETS“
- Scheduler (stündlicher Sync, Abrechnung, täglicher Backtest, Bereinigung) mit DB-Lock
- Benachrichtigungen (In-App, Telegram, Webhook) mit Deduplizierung
- Backtesting: Walk-Forward, fixer Holdout, Brier, Log Loss, Kalibrierung, Gewichte, Validierungsregeln, simulierte Wettstrategie gegen Schlusskurse
- Performance: Trefferquote, ROI, Yield, Brier, Log Loss, Kalibrierung, CLV, Drawdown, getrennt echt/Mock
- EDGE ANALYST: Tool-Use mit Sprachmodell (optional), Regelmodus ohne Schlüssel
- Frontend (React 19): Home, Matches, Match-Detail (6 Tabs), Edge AI, Performance, Settings, Admin; Spanisch/Deutsch/Englisch; mobile-first
- Docker, Compose, `.env.example`, 51 automatisierte Tests

### Behoben während der Entwicklung
- 429 ohne Kontingent-Header pausierte den Provider fälschlich
- zu grobe Unsicherheitsschätzung
- Entscheidungsregel ohne Marktreferenz bevorzugte Datenrauschen
- horizontales Überlaufen der mobilen Kopfzeile
