/**
 * MatchStatisticsRepository + Stammdaten-Upserts.
 */
import type { Db } from '../db/db.js';
import type { HistMatch } from './prediction/history.js';
import { normName, nowIso } from '../util/core.js';
import { linkedCompetitionIds, pickTeamLink } from './linking.js';
import { noteMissing } from '../util/log.js';
import type { ProviderCompetition, ProviderTeam, ProviderMatchStat, ProviderLineup, ProviderTeamStats } from '../providers/types.js';

export interface EventRow {
  id: number; competition_id: number; season: string | null; round: string | null; home_team_id: number; away_team_id: number;
  kickoff_utc: string; status: string; home_goals: number | null; away_goals: number | null; neutral_venue: number; venue: string | null;
  analysis_status: string; last_analysed_at: string | null; is_mock: number;
}

const REGION_BY_CC: Record<string, string> = {
  PY: 'paraguay', AR: 'south_america', BR: 'south_america', UY: 'south_america', CL: 'south_america', CO: 'south_america', PE: 'south_america', EC: 'south_america', BO: 'south_america', VE: 'south_america',
  US: 'north_america', CA: 'north_america', MX: 'north_america',
  JP: 'asia', KR: 'asia', CN: 'asia', SA: 'asia', AE: 'asia', QA: 'asia', AU: 'asia', IN: 'asia', TH: 'asia',
};
const EUROPE = new Set(['GB', 'EN', 'ES', 'DE', 'IT', 'FR', 'PT', 'NL', 'BE', 'TR', 'GR', 'AT', 'CH', 'DK', 'SE', 'NO', 'PL', 'CZ', 'SC', 'HR', 'RS', 'UA', 'RU', 'RO', 'HU', 'IE', 'FI', 'SK', 'SI', 'BG', 'CY', 'IS']);
export function regionOf(cc: string | null | undefined, name: string): string {
  const c = (cc || '').toUpperCase();
  if (REGION_BY_CC[c]) return REGION_BY_CC[c];
  if (EUROPE.has(c)) return 'europe';
  if (/world|international|friendl|nations|qualif|copa am|euro\b|afc|caf|concacaf|conmebol/i.test(name)) return 'international';
  if (/uefa|champions league|europa/i.test(name)) return 'europe';
  return 'other';
}

export class Repository {
  constructor(private db: Db) {}

  upsertCompetition(provider: string, c: ProviderCompetition, isMock = false): number {
    const a = this.db.get<{ competition_id: number }>('SELECT competition_id FROM competition_aliases WHERE provider = ? AND provider_id = ?', provider, c.providerId);
    if (a) return a.competition_id;
    // v0.3.0: dokumentierte Verknüpfung (z. B. soccer_epl ↔ div:E0) → gleicher interner Wettbewerb
    for (const l of linkedCompetitionIds(provider, c.providerId)) {
      const linked = this.db.get<{ competition_id: number }>('SELECT competition_id FROM competition_aliases WHERE provider = ? AND provider_id = ?', l.provider, l.providerId);
      if (linked) {
        this.db.run('INSERT OR IGNORE INTO competition_aliases (competition_id, provider, provider_id, alias_name) VALUES (?, ?, ?, ?)', linked.competition_id, provider, c.providerId, c.name);
        return linked.competition_id;
      }
    }
    const id = this.db.run('INSERT INTO competitions (name, country_code, country_name, region, is_mock) VALUES (?, ?, ?, ?, ?)',
      c.name, c.countryCode ?? null, c.countryName ?? null, regionOf(c.countryCode, c.name), isMock ? 1 : 0).lastInsertRowid;
    this.db.run('INSERT INTO competition_aliases (competition_id, provider, provider_id, alias_name) VALUES (?, ?, ?, ?)', id, provider, c.providerId, c.name);
    return id;
  }

  findTeamByProviderId(provider: string, providerId: string): number | null {
    return this.db.get<{ team_id: number }>('SELECT team_id FROM team_aliases WHERE provider = ? AND provider_id = ?', provider, providerId)?.team_id ?? null;
  }

  /**
   * Legt ein Team an, falls es über Provider-ID oder exakten Alias nicht gefunden wird.
   * v0.3.0: mit competitionId wird zuerst ein bestehendes Team eines ANDEREN Providers im selben Wettbewerb gesucht
   * (konservative Regeln in linking.ts). Gefundene Verknüpfungen werden als Alias gespeichert.
   */
  upsertTeam(provider: string, t: ProviderTeam, isMock = false, competitionId?: number): number {
    const byId = this.findTeamByProviderId(provider, t.providerId);
    if (byId) return byId;
    const norm = normName(t.name);
    const byAlias = this.db.get<{ team_id: number }>('SELECT team_id FROM team_aliases WHERE provider = ? AND alias_norm = ?', provider, norm);
    if (byAlias) return byAlias.team_id;
    if (competitionId != null && !isMock) {
      const cands = this.db.all<{ id: number; name: string }>(
        `SELECT DISTINCT t.id, t.name FROM teams t JOIN events e ON (e.home_team_id = t.id OR e.away_team_id = t.id)
          WHERE e.competition_id = ? AND t.is_mock = 0 AND NOT EXISTS (SELECT 1 FROM team_aliases a WHERE a.team_id = t.id AND a.provider = ?)`, competitionId, provider);
      if (cands.length) {
        const pick = pickTeamLink(t.name, cands);
        if (pick.team) {
          this.db.run('INSERT OR IGNORE INTO team_aliases (team_id, provider, provider_id, alias_norm) VALUES (?, ?, ?, ?)', pick.team.id, provider, t.providerId, norm);
          return pick.team.id;
        }
        noteMissing(this.db, 'unlinked_team', `${provider}:${t.providerId}`, `${t.name} (Wettbewerb ${competitionId}): ${pick.reason}${pick.best ? `; bester Kandidat ${pick.best} ${pick.score?.toFixed(2)}` : ''}`);
      }
    }
    const id = this.db.run('INSERT INTO teams (name, norm_name, country_code, team_type, is_mock) VALUES (?, ?, ?, ?, ?)',
      t.name, norm, t.countryCode ?? null, t.type ?? 'club', isMock ? 1 : 0).lastInsertRowid;
    this.db.run('INSERT OR IGNORE INTO team_aliases (team_id, provider, provider_id, alias_norm) VALUES (?, ?, ?, ?)', id, provider, t.providerId, norm);
    return id;
  }

  addTeamAlias(teamId: number, provider: string, providerId: string | null, name: string): void {
    this.db.run('INSERT OR REPLACE INTO team_aliases (team_id, provider, provider_id, alias_norm) VALUES (?, ?, ?, ?)', teamId, provider, providerId, normName(name));
  }

  event(id: number): EventRow | undefined { return this.db.get<EventRow>('SELECT * FROM events WHERE id = ?', id); }

  /** Abgeschlossene Spiele eines Wettbewerbs, chronologisch, inkl. xG falls vorhanden. */
  competitionHistory(competitionId: number, before?: string): HistMatch[] {
    const rows = this.db.all<{ id: number; competition_id: number; kickoff_utc: string; home_team_id: number; away_team_id: number; home_goals: number; away_goals: number; neutral_venue: number; xg_h: number | null; xg_a: number | null }>(
      `SELECT e.id, e.competition_id, e.kickoff_utc, e.home_team_id, e.away_team_id, e.home_goals, e.away_goals, e.neutral_venue,
              (SELECT value FROM match_statistics s WHERE s.event_id = e.id AND s.team_id = e.home_team_id AND s.stat_key = 'xg') AS xg_h,
              (SELECT value FROM match_statistics s WHERE s.event_id = e.id AND s.team_id = e.away_team_id AND s.stat_key = 'xg') AS xg_a
         FROM events e
        WHERE e.competition_id = ? AND e.status = 'finished' AND e.home_goals IS NOT NULL AND e.away_goals IS NOT NULL ${before ? 'AND e.kickoff_utc < ?' : ''}
        ORDER BY e.kickoff_utc, e.id`, ...(before ? [competitionId, before] : [competitionId]));
    return rows.map(r => ({ eventId: r.id, competitionId: r.competition_id, kickoff: r.kickoff_utc, home: r.home_team_id, away: r.away_team_id, hg: r.home_goals, ag: r.away_goals, neutral: !!r.neutral_venue, xgH: r.xg_h, xgA: r.xg_a }));
  }

  saveMatchStats(eventId: number, provider: string, stats: ProviderMatchStat[], teamIdOf: (pid: string) => number | null): number {
    let n = 0;
    for (const s of stats) {
      const tid = teamIdOf(s.teamProviderId); if (!tid) continue;
      this.db.run('INSERT OR REPLACE INTO match_statistics (event_id, team_id, stat_key, value, provider) VALUES (?, ?, ?, ?, ?)', eventId, tid, s.key, s.value, provider);
      n++;
    }
    return n;
  }

  saveLineups(eventId: number, provider: string, ls: ProviderLineup[], teamIdOf: (pid: string) => number | null): number {
    let n = 0;
    for (const l of ls) {
      const tid = teamIdOf(l.teamProviderId); if (!tid) continue;
      this.db.run('INSERT OR REPLACE INTO lineups (event_id, team_id, status, formation, players, provider, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        eventId, tid, l.status, l.formation, JSON.stringify(l.players), provider, nowIso());
      n++;
    }
    return n;
  }

  saveTeamStats(provider: string, rows: ProviderTeamStats[], teamIdOf: (pid: string) => number | null, compIdOf: (pid: string | null) => number | null): void {
    for (const r of rows) {
      const tid = teamIdOf(r.teamProviderId); if (!tid) continue;
      this.db.run(`INSERT OR REPLACE INTO team_statistics (team_id, competition_id, season, scope, played, wins, draws, losses, goals_for, goals_against, provider, fetched_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, tid, compIdOf(r.competitionProviderId), r.season, r.scope, r.played, r.wins, r.draws, r.losses, r.goalsFor, r.goalsAgainst, provider, nowIso());
    }
  }

  lineupStatus(eventId: number): 'confirmed' | 'expected' | 'none' {
    const rows = this.db.all<{ status: string }>('SELECT status FROM lineups WHERE event_id = ?', eventId);
    if (rows.length >= 2 && rows.every(r => r.status === 'confirmed')) return 'confirmed';
    return rows.length ? 'expected' : 'none';
  }
}
