/**
 * v0.3.3 – Admin-Karte „THE ODDS API“. Alle Werte stammen aus GET /api/admin/providers/theoddsapi (Backend, DB);
 * hier wird nichts berechnet oder ergänzt. Der Schlüssel ist dem Frontend nie bekannt.
 * „Verbindung testen“ ruft POST …/test auf: kostenloser Endpunkt /v4/sports, genau ein Versuch, 0 Credits.
 */
import React, { useState } from 'react';
import { api, localTime } from './api';
import { useApp } from './components';
import { useLoad } from './hooks';
import { Badge, Banner, Button, Card, ErrorBox, Kpi, Loading, StatusBadge } from './ui';

const L = {
  es: { title: 'The Odds API', sub: 'Cuotas reales · estado calculado en el servidor', test: 'Probar conexión (gratis)', testing: 'Probando…', testHint: 'GET /v4/sports · 1 intento · 0 créditos',
    lastTest: 'Última prueba', lastFetch: 'Última consulta de cuotas OK', remaining: 'Créditos restantes (proveedor)', used: 'Usados (proveedor)', last: 'Costo última consulta',
    daily: 'Presupuesto diario interno', monthly: 'Presupuesto mensual interno', events: 'Partidos reales importados', upcoming: 'próximos', books: 'Casas disponibles', markets: 'Mercados disponibles',
    fresh: 'Actualidad de datos', ago: 'hace {m} min', errors: 'Errores de API', none: 'Ninguno', paid: 'Consultas de pago', allowed: 'permitidas', blocked: 'bloqueadas', estimate: 'Estimación próxima ejecución',
    ucl: 'Champions League', keys: 'Sport keys', regions: 'Regiones', never: 'nunca', reasons: 'Motivos', noKey: 'La clave nunca se muestra aquí ni se envía al navegador.',
    evidence: 'Evidencia (qué está realmente comprobado)', conn: 'Conexión (gratis)', disc: 'Búsqueda de partidos (gratis)', odds: 'Cuotas (de pago)', preds: 'Pronósticos con cuotas reales', verified: 'VERIFICADO', notVerified: 'NO VERIFICADO', lastHttp: 'Última llamada real', next: 'Próxima ejecución', nextDisc: 'búsqueda', nextOdds: 'cuotas', off: 'planificador desactivado' },
  de: { title: 'The Odds API', sub: 'Echte Quoten · Status vom Server berechnet', test: 'Verbindung testen (kostenlos)', testing: 'Teste …', testHint: 'GET /v4/sports · 1 Versuch · 0 Credits',
    lastTest: 'Letzter Test', lastFetch: 'Letzter erfolgreicher Quotenabruf', remaining: 'Restcredits (Anbieter)', used: 'Verbraucht (Anbieter)', last: 'Kosten letzter Abruf',
    daily: 'Internes Tagesbudget', monthly: 'Internes Monatsbudget', events: 'Echte importierte Spiele', upcoming: 'anstehend', books: 'Verfügbare Buchmacher', markets: 'Verfügbare Märkte',
    fresh: 'Datenaktualität', ago: 'vor {m} min', errors: 'API-Fehler', none: 'Keine', paid: 'Kostenpflichtige Abrufe', allowed: 'freigegeben', blocked: 'gesperrt', estimate: 'Schätzung nächster Lauf',
    ucl: 'Champions League', keys: 'Sport-Keys', regions: 'Regionen', never: 'nie', reasons: 'Gründe', noKey: 'Der Schlüssel wird hier nie angezeigt und nie an den Browser gesendet.',
    evidence: 'Nachweise (was tatsächlich belegt ist)', conn: 'Verbindung (kostenlos)', disc: 'Spielsuche (kostenlos)', odds: 'Quoten (kostenpflichtig)', preds: 'Prognosen mit echten Quoten', verified: 'VERIFIZIERT', notVerified: 'NICHT VERIFIZIERT', lastHttp: 'Letzter echter Abruf', next: 'Nächster Lauf', nextDisc: 'Spielsuche', nextOdds: 'Quoten', off: 'Scheduler aus' },
  en: { title: 'The Odds API', sub: 'Real odds · status computed on the server', test: 'Test connection (free)', testing: 'Testing…', testHint: 'GET /v4/sports · 1 attempt · 0 credits',
    lastTest: 'Last test', lastFetch: 'Last successful odds fetch', remaining: 'Remaining credits (provider)', used: 'Used (provider)', last: 'Cost of last request',
    daily: 'Internal daily budget', monthly: 'Internal monthly budget', events: 'Real imported matches', upcoming: 'upcoming', books: 'Bookmakers available', markets: 'Markets available',
    fresh: 'Data freshness', ago: '{m} min ago', errors: 'API errors', none: 'None', paid: 'Paid requests', allowed: 'allowed', blocked: 'blocked', estimate: 'Next run estimate',
    ucl: 'Champions League', keys: 'Sport keys', regions: 'Regions', never: 'never', reasons: 'Reasons', noKey: 'The key is never shown here and never sent to the browser.',
    evidence: 'Evidence (what is actually proven)', conn: 'Connection (free)', disc: 'Fixture discovery (free)', odds: 'Odds (paid)', preds: 'Predictions with real odds', verified: 'VERIFIED', notVerified: 'NOT VERIFIED', lastHttp: 'Last real request', next: 'Next run', nextDisc: 'discovery', nextOdds: 'odds', off: 'scheduler off' },
};

const n = (v: number | null | undefined) => v == null ? '–' : new Intl.NumberFormat('es-PY').format(v);

export function OddsApiPanel() {
  const { lang, tz } = useApp();
  const T = L[lang] ?? L.es;
  const s = useLoad<any>('/api/admin/providers/theoddsapi');
  const [busy, setBusy] = useState(false), [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const test = async () => {
    setBusy(true); setMsg(null);
    try {
      const r = await api<any>('/api/admin/providers/theoddsapi/test', { method: 'POST' });
      setMsg({ ok: !!r.result.ok, text: r.result.ok ? `HTTP ${r.result.httpStatus} · ${r.result.sportsTotal} sports · ${r.result.targetSportKey}: ${r.result.targetSportStatus}` : (r.result.error ?? 'Error') });
      s.reload();
    } catch (e) { setMsg({ ok: false, text: (e as Error).message }); } finally { setBusy(false); }
  };
  if (s.err) return <Card title={T.title}><ErrorBox e={s.err} onRetry={s.reload} /></Card>;
  if (!s.data) return <Card title={T.title}><Loading lines={4} /></Card>;
  const x = s.data, c = x.credits, d = x.data, lt = x.lastTest;
  const tone = x.connection === 'CONNECTED' ? 'value' : x.connection === 'DEGRADED' ? 'watch' : 'avoid';
  const when = (iso: string | null) => iso ? localTime(iso, tz, lang) : T.never;
  return (
    <Card id="oddsapi" title={<span className="row-flex">THE ODDS API <Badge tone={tone} dot>{x.connection}</Badge> <Badge tone={x.mode === 'LIVE' ? 'info' : 'watch'}>{x.mode}</Badge></span>} sub={T.sub}
      actions={<Button variant="secondary" size="sm" icon="refresh" onClick={test} disabled={busy || x.mode !== 'LIVE' || !x.configured} title={T.testHint}>{busy ? T.testing : T.test}</Button>}>
      <div className="stack lg">
        {x.reasons.length ? <Banner tone={x.connection === 'DISCONNECTED' ? 'error' : 'warn'} title={T.reasons}>{x.reasons.map((r: string) => <div key={r}>{r}</div>)}</Banner> : null}
        {msg ? <Banner tone={msg.ok ? 'info' : 'error'}>{msg.text}</Banner> : null}
        <div className="kpis four">
          <Kpi label={T.remaining} value={n(c.providerRemaining)} hint={`${T.used}: ${n(c.providerUsed)} · ${T.last}: ${n(c.providerLast)}`} />
          <Kpi label={T.daily} value={`${n(c.dailyUsed)} / ${n(c.dailyBudget)}`} hint={`${T.monthly}: ${n(c.monthlyUsed)} / ${n(c.monthlyBudget)}`} tone={c.dailyUsed >= c.dailyBudget ? 'avoid' : undefined} />
          <Kpi label={T.events} value={n(d.events)} hint={`${n(d.upcomingEvents)} ${T.upcoming}`} />
          <Kpi label={T.fresh} value={d.ageMinutes == null ? '–' : T.ago.replace('{m}', String(d.ageMinutes))} hint={d.newestRetrievedAt ? when(d.newestRetrievedAt) : undefined} />
        </div>
        {x.verification ? <div className="stack" style={{ gap: 6 }}>
          <div className="small t-2">{T.evidence}</div>
          {([['conn', x.verification.connection], ['disc', x.verification.discovery], ['odds', x.verification.odds], ['preds', x.verification.predictions]] as [keyof typeof T, any][]).map(([k, v]) =>
            <div key={k} className="row-flex between small" style={{ flexWrap: 'wrap', gap: 6 }}>
              <span>{T[k]}</span>
              <span className="row-flex"><Badge tone={v.verified ? 'value' : 'watch'} dot>{v.verified ? T.verified : T.notVerified}</Badge>{v.at ? <span className="t-3">{when(v.at)}</span> : null}</span>
              <span className="xs t-3" style={{ flexBasis: '100%' }}>{v.note}</span>
            </div>)}
        </div> : null}
        <dl className="kv small">
          <dt>{T.lastHttp}</dt><dd>{x.lastHttp ? `${when(x.lastHttp.at)} · HTTP ${x.lastHttp.status} · ${x.lastHttp.endpoint} · ${x.lastHttp.costCredits} credits` : T.never}</dd>
          <dt>{T.next}</dt><dd>{x.schedule ? `${T.nextDisc}: ${x.schedule.discovery?.nextDue ? when(x.schedule.discovery.nextDue) : '–'} (${x.schedule.discovery?.intervalMin ?? '–'} min) · ${T.nextOdds}: ${x.schedule.odds?.nextDue ? when(x.schedule.odds.nextDue) : '–'} (${x.schedule.odds?.intervalMin ?? '–'} min)` : T.off}</dd>
          <dt>{T.lastTest}</dt><dd>{lt ? <span className="row-flex"><StatusBadge s={lt.ok ? 'OK' : 'FAILED'} /> {when(lt.testedAt)} · HTTP {lt.httpStatus ?? '–'} {lt.error ? <span className="t-2">· {lt.error}</span> : null}</span> : T.never}</dd>
          <dt>{T.lastFetch}</dt><dd>{when(x.lastSuccessfulFetchAt)}</dd>
          <dt>{T.ucl}</dt><dd>{lt ? <StatusBadge s={lt.targetSportStatus === 'ACTIVE' ? 'ACTIVE' : lt.targetSportStatus === 'NOT_CHECKED' ? null : 'DEGRADED'} label={`${lt.targetSportKey}: ${lt.targetSportStatus}`} /> : '–'}</dd>
          <dt>{T.keys}</dt><dd>{x.sportKeys.length ? x.sportKeys.join(', ') : '–'} · {T.regions}: {x.regions.join(', ')}</dd>
          <dt>{T.books}</dt><dd>{n(d.bookmakers)}</dd>
          <dt>{T.markets}</dt><dd>{d.markets.length ? d.markets.map((m: string) => m === 'OU' ? `OU ${x.markets.ouLine}` : m).join(', ') : '–'} <span className="t-3">(odds: {x.markets.odds}{x.markets.btts ? `, btts ≤ ${x.markets.bttsMaxEventsPerRun}/run` : ', btts off'})</span></dd>
          <dt>{T.paid}</dt><dd>{x.paidAllowed ? <Badge tone="value">{T.allowed}</Badge> : <span className="row-flex"><Badge tone="watch">{T.blocked}</Badge><span className="t-2">{x.paidBlockedReason}</span></span>}</dd>
          <dt>{T.estimate}</dt><dd>{c.nextRunEstimate == null ? '–' : `${c.nextRunEstimate} credits`} <span className="t-3">{c.nextRunEstimateDetail}</span></dd>
          <dt>{T.errors}</dt><dd>{x.errors.length ? x.errors.slice(0, 5).map((e: any) => <div key={e.at + e.endpoint}>{when(e.at)} · HTTP {e.status} · {e.endpoint}</div>) : T.none}{x.lastError?.message ? <div className="t-2">{x.lastError.message}</div> : null}</dd>
        </dl>
        <p className="xs t-3">{T.noKey}</p>
      </div>
    </Card>
  );
}
