import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { DICTS, UI, type Lang } from './i18n';
import { api, setCsrf, ago, localTime } from './api';
import { AppCtx, BrandMark, BrandWord, Icon } from './components';
import { ANALYST, BRAND, LOCALE, docTitle } from './brand';
import { Badge, Banner } from './ui';
import { Auth } from './auth';
import { Home } from './pages/home';
import { Matches } from './pages/matches';
import { MatchDetail } from './pages/match';
import { EdgeAI } from './pages/edge';
import { Performance } from './pages/performance';
import { Settings } from './pages/settings';
import { Admin } from './pages/admin';

function useRoute(): [string, (p: string) => void] {
  const read = () => (location.hash.replace(/^#/, '') || '/');
  const [r, setR] = useState(read());
  useEffect(() => { const f = () => { setR(read()); window.scrollTo(0, 0); }; addEventListener('hashchange', f); return () => removeEventListener('hashchange', f); }, []);
  return [r, (p: string) => { location.hash = p; }];
}

function App() {
  const [route, go] = useRoute();
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [lang, setLang] = useState<Lang>(BRAND.defaultLang);
  const [tz, setTz] = useState<string>(BRAND.defaultTz);
  const [status, setStatus] = useState<any>(null);
  const [role, setRole] = useState<'admin' | 'user'>('user');
  const [email, setEmail] = useState<string | null>(null);
  const [plan, setPlan] = useState<string | null>(null);
  useEffect(() => {
    if (authed !== null) return;
    api<any>('/api/auth/me').then(async me => {
      setCsrf(me.csrfToken); setRole(me.user.role); setEmail(me.user.email);
      const [s, st, sub] = await Promise.all([api<any>('/api/status'), api<any>('/api/settings').catch(() => ({ language: BRAND.defaultLang, timezone: BRAND.defaultTz })), api<any>('/api/subscription').catch(() => null)]);
      setStatus(s); setLang(st.language); setTz(st.timezone); setPlan(me.user.role === 'admin' ? 'ADMIN' : sub?.plan ?? 'FREE'); setAuthed(true);
    }).catch(() => setAuthed(false));
  }, [authed]);
  // Kopfzeilen-Status (Modus, letzter Sync) alle 5 min aktualisieren
  useEffect(() => { if (!authed) return; const id = setInterval(() => { api<any>('/api/status').then(setStatus).catch(() => {}); }, 5 * 60_000); return () => clearInterval(id); }, [authed]);
  useEffect(() => { const f = () => setAuthed(false); addEventListener('aea:unauthorized', f); return () => removeEventListener('aea:unauthorized', f); }, []);
  // Spanisch = es-PY (Paraguay); die gespeicherten Sprachcodes bleiben 'es' | 'de' | 'en'
  useEffect(() => { document.documentElement.lang = LOCALE[lang]; }, [lang]);
  const t = DICTS[lang], u = UI[lang];
  if (authed === null) return null;
  if (!authed) { document.title = docTitle(); return <Auth lang={lang} setLang={setLang} onOk={() => setAuthed(null)} />; }

  const isMock = !!status?.isMock, dataMode: 'mock' | 'live' = status?.dataMode === 'live' ? 'live' : 'mock';
  const logout = async () => { try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* Session ohnehin ungültig */ } setCsrf(null); setAuthed(false); };
  const changeLang = async (l: Lang) => { setLang(l); try { await api('/api/settings', { method: 'PUT', body: JSON.stringify({ language: l }) }); } catch { /* bleibt lokal */ } };
  const nav: [string, string, string][] = [['/', 'home', t.home], ['/matches', 'matches', t.matches], ['/edge', 'edge', t.edge], ['/performance', 'perf', t.performance], ['/settings', 'settings', t.settings]];
  const railNav = role === 'admin' ? [...nav, ['/admin', 'admin', t.admin] as [string, string, string]] : nav;
  const active = (p: string) => p === '/' ? route === '/' : route.startsWith(p) || (p === '/matches' && route.startsWith('/match/'));

  let page: React.ReactNode, title = t.home, isHome = false;
  const m = /^\/match\/(\d+)$/.exec(route);
  if (m) { page = <MatchDetail id={Number(m[1])} />; title = t.matches; }
  else if (route === '/matches') { page = <Matches />; title = t.matches; }
  else if (route === '/edge') { page = <EdgeAI />; title = ANALYST[lang]; }
  else if (route === '/performance') { page = <Performance />; title = t.performance; }
  else if (route === '/settings') { page = <Settings onLang={changeLang} onLogout={logout} />; title = t.settings; }
  else if (route === '/admin' && role === 'admin') { page = <Admin />; title = t.admin; }
  else { page = <Home />; isHome = true; }

  document.title = isHome ? docTitle() : docTitle(title);
  const modeBadge = isMock ? <Badge tone="watch" dot title={t.mockBanner}>{u.mockMode}</Badge> : <Badge tone="info" dot title="DATA_MODE=live">{u.live}</Badge>;
  const lastSync = status?.lastSync;
  return (
    <AppCtx.Provider value={{ lang, t, u, tz, isMock, dataMode, go, role, email, plan }}>
      <div className="app">
        <aside className="rail">
          <a className="brand" href="#/" aria-label={`${BRAND.name} – ${BRAND.slogan}`}><BrandMark /><BrandWord slogan /></a>
          <nav aria-label="main">{railNav.map(([p, ic, label]) => <a key={p} className="navlink" href={`#${p}`} aria-current={active(p) ? 'page' : undefined}><Icon name={ic} />{label}</a>)}</nav>
          <div className="railfoot">
            <div className="row-flex"><Badge tone="outline">{u.beta}</Badge>{modeBadge}</div>
            <div>{t.lastSync}<br /><span style={{ color: 'var(--text-2)' }}>{lastSync ? `${lastSync.status} · ${ago(lastSync.started_at, lang)}` : '–'}</span></div>
            <div>{u.signedInAs}<br /><span style={{ color: 'var(--text-2)', overflowWrap: 'anywhere' }}>{email}</span></div>
            <button className="btn quiet sm" style={{ justifySelf: 'start', padding: '4px 0' }} onClick={logout}><Icon name="logout" />{t.logout}</button>
          </div>
        </aside>
        <div style={{ minWidth: 0 }}>
          <header className="topbar">
            <a className="brand" href="#/" aria-label={BRAND.name}><BrandMark /></a>
            <span className="page-title grow">{isHome ? <BrandWord /> : title}</span>
            <div className="pills">
              <span className="hide-sm"><Badge tone="outline">{u.beta}</Badge></span>
              {modeBadge}
              <span className="hide-sm"><Badge tone="info">{u.plan}: {plan ?? 'FREE'}</Badge></span>
              {lastSync ? <span className="hide-sm t-3 xs" title={localTime(lastSync.started_at, tz, lang)}>{t.lastSync}: {ago(lastSync.started_at, lang)}</span> : null}
            </div>
            <div className="langsel" role="group" aria-label={t.language}>{(['es', 'de', 'en'] as Lang[]).map(l => <button key={l} aria-pressed={lang === l} onClick={() => changeLang(l)}>{l.toUpperCase()}</button>)}</div>
          </header>
          <main className="main">
            {isMock ? <Banner tone="warn" title={u.mockTitle}>{t.mockBanner}</Banner> : null}
            {page}
          </main>
        </div>
        <nav className="tabbar" aria-label="main">{nav.map(([p, ic, label]) => <a key={p} href={`#${p}`} aria-current={active(p) || (p === '/settings' && route === '/admin') ? 'page' : undefined}><Icon name={ic} />{label}</a>)}</nav>
      </div>
    </AppCtx.Provider>
  );
}

createRoot(document.getElementById('root')!).render(<App />);
