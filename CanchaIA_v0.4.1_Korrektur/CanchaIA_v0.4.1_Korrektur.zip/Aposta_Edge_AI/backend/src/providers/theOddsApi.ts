/**
 * The Odds API v4 Adapter (https://the-odds-api.com/liveapi/guides/v4/).
 * Lizenzierter Quotenanbieter und – ohne Highlightly – auch Fixture-Provider.
 * - GET /v4/sports                          kostenlos → aktive soccer_* Wettbewerbe (Pilot: Prüfung der Keys)
 * - GET /v4/sports/{sport}/events           kostenlos → kommende Spiele (ohne Quoten)
 * - GET /v4/sports/{sport}/odds             markets=h2h,totals → Kosten = Märkte × Regionen
 * - GET /v4/sports/{sport}/events/{id}/odds markets=btts → Kosten = gelieferte Märkte × Regionen (leere Antwort kostenlos)
 * - GET /v4/sports/{sport}/scores?daysFrom=3 → 2 Credits; Ergebnisse für die Abrechnung
 * Antwort-Header: x-requests-remaining, x-requests-used, x-requests-last (Kosten der letzten Anfrage).
 *
 * Zeitstempel: retrievedAt = echter Abrufzeitpunkt der (ggf. gecachten) Antwort, sourceTimestamp = markets[].last_update.
 * Cache: dynamisch nach dem nächsten Anstoß im gecachten Inhalt (oddsCacheMaxAgeSeconds), höchstens 20 min.
 *
 * Status: NOT LIVE VERIFIED (kein Netzwerkzugang in der Entwicklungsumgebung). Getestet mit nach der Doku nachgebauten Antworten.
 *
 * v0.3.3:
 *  - Basis-URL mit oder ohne "/v4" (THE_ODDS_API_BASE_URL=https://api.the-odds-api.com/v4 führte zu /v4/v4/…)
 *  - Über/Unter nur Linie 2,5 (andere Linien werden gar nicht erst als Snapshot angelegt)
 *  - h2h_3_way wird wie h2h behandelt, falls ein Buchmacher nur diesen Markt liefert (Unentschieden Pflicht)
 *  - paidGate: kostenpflichtige Abrufe erst nach erfolgreichem, authentifiziertem Verbindungstest (siehe oddsApiStatus.ts)
 *
 * v0.4.0:
 *  - Zeitfenster für /events und /odds auf volle Stunden gerundet → stabiler Cache-Schlüssel (vorher sekundengenau:
 *    jeder Lauf erzeugte einen neuen Schlüssel, Cache-Treffer waren praktisch unmöglich). Ergebnis wird exakt nachgefiltert.
 *  - Quotenabruf budgetgesteuert: VOR dem ersten kostenpflichtigen Abruf wird geprüft, wie viele Wettbewerbe Tages-,
 *    Monatsbudget und Anbieter-Restcredits zulassen (nächste Anstöße zuerst). Der Rest wird mit Grund übersprungen.
 *  - lastEvents enthält nur Spiele des angefragten Fensters, die noch nicht begonnen haben, und wird nach dem Lauf geleert.
 *  - Ergebnisse gebündelt je Wettbewerb (resultsFor): ein /scores-Abruf nur für Wettbewerbe mit offenen Spielen ≤ 3 Tage.
 */
import type { ApiQueue } from '../api/apiQueue.js';
import type { FootballDataProvider, MarketId, OddsProvider, ProviderCapabilities, ProviderCompetition, ProviderFixture, ProviderOddsQuote, ProviderRunReport, SelectionId } from './types.js';
import { ProviderBlockedError, QuotaExhaustedError } from './types.js';
import { ODDS_CACHE_MAX_SECONDS, minutesToNextKickoff, oddsCacheMaxAgeSeconds } from '../engines/freshness.js';

interface OaOutcome { name: string; price: number; point?: number }
interface OaEvent {
  id: string; sport_key: string; sport_title: string; commence_time: string; home_team: string; away_team: string;
  bookmakers?: { key: string; title: string; last_update: string; markets: { key: string; last_update?: string; outcomes: OaOutcome[] }[] }[];
}
interface OaScore { id: string; sport_key: string; sport_title?: string; commence_time: string; completed: boolean; home_team: string; away_team: string; scores: { name: string; score: string }[] | null; last_update: string | null }

export interface TheOddsApiOptions {
  apiKey: string | null; baseUrl: string; regions: string; sportKeys: string[];
  includeBtts?: boolean;
  /** Höchstens so viele BTTS-Event-Abrufe je Lauf (Default 5). */
  bttsMaxEventsPerRun?: number;
  /** BTTS nur, solange mindestens dieser Prozentsatz des Monatsbudgets frei ist (Default 25). */
  bttsReservePct?: number;
  /** Ergebnisse über /scores (Default true). */
  resultsEnabled?: boolean;
  /** Pilotmodus: sportKeys werden gegen /v4/sports geprüft; inaktive Keys werden übersprungen und gemeldet. */
  pilot?: boolean;
  /** Basis der Frische-Grenze (ODDS_MAX_AGE_MINUTES) für die dynamische Cache-Regel. */
  oddsMaxAgeMinutes?: number;
  /**
   * Sperre für kostenpflichtige Endpunkte (odds, event odds, scores). Liefert einen Grund, solange gesperrt, sonst null.
   * Die kostenlosen Endpunkte /v4/sports und /v4/sports/{sport}/events sind nie gesperrt.
   */
  paidGate?: () => string | null;
}

/** Basis-URL ohne abschließendes "/" und ohne "/v4" (die Pfade enthalten /v4 selbst). */
export function normalizeOddsApiBase(base: string): string { return base.trim().replace(/\/+$/, '').replace(/\/v4$/i, ''); }

/** Vollständige Anfrage-URL. Der Schlüssel steht nur hier in der URL; Protokoll, Cache-Schlüssel und Logs entfernen ihn. */
export function oddsApiUrl(baseUrl: string, apiKey: string, path: string, params: Record<string, string>): string {
  const u = new URL(normalizeOddsApiBase(baseUrl) + path);
  for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
  u.searchParams.set('apiKey', apiKey);
  return u.toString();
}

const HOUR = 3_600_000;
/** Fenster auf volle Stunden runden (from abwärts, to aufwärts) – stabiler Cache-Schlüssel, Ergebnis wird exakt gefiltert. */
export function hourWindow(from: Date, to: Date): { from: Date; to: Date } {
  return { from: new Date(Math.floor(from.getTime() / HOUR) * HOUR), to: new Date(Math.ceil(to.getTime() / HOUR) * HOUR) };
}
const isoS = (d: Date) => d.toISOString().replace(/\.\d{3}Z$/, 'Z');
/** /scores?daysFrom=3 liefert nur Spiele der letzten 3 Tage. */
export const SCORES_DAYS = 3;

/** Märkte von /odds (je Region 1 Credit pro gelieferter Markt). */
export const ODDS_MARKETS = 'h2h,totals';
export const OU_LINE = 2.5;

const emptyReport = (keys: string[]): ProviderRunReport => ({
  provider: 'theoddsapi', sportKeys: keys, skippedSportKeys: [], notes: [],
  markets: {
    '1X2': { requested: true, events: 0, reason: null },
    OU: { requested: true, events: 0, reason: null },
    BTTS: { requested: false, events: 0, reason: 'nicht aktiviert (THE_ODDS_API_INCLUDE_BTTS=false)' },
  },
});

export class TheOddsApiProvider implements OddsProvider, FootballDataProvider {
  readonly name = 'theoddsapi';
  readonly sharesEventIdsWith = 'theoddsapi';
  readonly capabilities: ProviderCapabilities = {
    fixtures: true, history: false, teamStats: false, standings: false, lineups: false, matchStats: false, injuries: false, odds: true, liveScores: false,
  };
  private lastEvents = new Map<string, { e: OaEvent; fetchedAt: string; fromCache: boolean }>();
  private report: ProviderRunReport;
  private resolvedKeys: string[] | null = null;
  private clock: Date | null = null;
  /** Uhr des Laufs (Discovery setzt sie); ohne Angabe die Uhr der API-Queue. */
  setNow(now: Date): void { this.clock = now; }
  private now(): Date { return this.clock ?? this.q.currentTime(); }

  constructor(private q: ApiQueue, private o: TheOddsApiOptions) { this.report = emptyReport(o.sportKeys); }

  lastRunReport(): ProviderRunReport { return JSON.parse(JSON.stringify(this.report)); }

  private url(path: string, params: Record<string, string>): string {
    if (!this.o.apiKey) throw new ProviderBlockedError(this.name, 'THE_ODDS_API_KEY ist nicht gesetzt (NOT CONFIGURED).');
    return oddsApiUrl(this.o.baseUrl, this.o.apiKey, path, params);
  }

  /** Kostenpflichtige Endpunkte erst nach bestandenem Verbindungstest. */
  private paidUrl(path: string, params: Record<string, string>): string {
    const reason = this.o.paidGate?.() ?? null;
    if (reason) throw new ProviderBlockedError(this.name, reason);
    return this.url(path, params);
  }

  private async activeSports(): Promise<{ key: string; title: string; active: boolean; has_outrights: boolean }[]> {
    return (await this.q.request<{ key: string; title: string; group: string; active: boolean; has_outrights: boolean }[]>({
      provider: this.name, url: this.url('/v4/sports', {}), ttlSeconds: 6 * 3600, priority: 5, cost: 0, note: 'sports (kostenlos)',
    })) ?? [];
  }

  async sportKeys(): Promise<string[]> {
    if (this.resolvedKeys) return this.resolvedKeys;
    if (this.o.sportKeys.length && !this.o.pilot) return (this.resolvedKeys = this.o.sportKeys);
    const sports = await this.activeSports();
    if (!this.o.sportKeys.length) return (this.resolvedKeys = sports.filter(s => s.active && !s.has_outrights && s.key.startsWith('soccer_')).map(s => s.key));
    // Pilot: nur Keys verwenden, die der Provider tatsächlich als aktiv meldet
    const byKey = new Map(sports.map(s => [s.key, s]));
    const ok: string[] = [];
    for (const k of this.o.sportKeys) {
      const s = byKey.get(k);
      if (!s) this.report.skippedSportKeys.push({ key: k, reason: 'unbekannter Sport-Key (nicht in /v4/sports)' });
      else if (!s.active) this.report.skippedSportKeys.push({ key: k, reason: 'derzeit nicht aktiv (keine Spiele angeboten)' });
      else ok.push(k);
    }
    return (this.resolvedKeys = ok);
  }

  /** Dynamische Cache-Regel: Alter eines Cache-Eintrags höchstens halbe Frische-Grenze des nächsten Anstoßes im Inhalt. */
  private cacheRule = (data: OaEvent[] | OaEvent | null, now: Date): number | null => {
    const list = Array.isArray(data) ? data : data ? [data] : [];
    const m = minutesToNextKickoff(list.map(e => e.commence_time), now);
    return m == null ? null : oddsCacheMaxAgeSeconds(m, this.o.oddsMaxAgeMinutes ?? 90, true);
  };

  /** Reine Spielsuche: /events ist laut offizieller V4-Doku kostenlos (0 Credits). */
  private async upcomingEvents(sport: string, from: Date, to: Date): Promise<OaEvent[]> {
    const w = hourWindow(from, to);
    const data = await this.q.request<OaEvent[]>({
      provider: this.name,
      url: this.url(`/v4/sports/${encodeURIComponent(sport)}/events`, { dateFormat: 'iso', commenceTimeFrom: isoS(w.from), commenceTimeTo: isoS(w.to) }),
      ttlSeconds: 300, priority: 5, cost: 0, noRetry: true,
      note: `events (kostenlos) ${sport}`,
    });
    if (!Array.isArray(data)) throw new Error(`Ungültige /events-Antwort für ${sport}: Liste erwartet`);
    return data.filter(e => e && typeof e.id === 'string' && e.id.length > 0
      && typeof e.home_team === 'string' && typeof e.away_team === 'string'
      && e.home_team.length > 0 && e.away_team.length > 0
      && Number.isFinite(Date.parse(e.commence_time))
      && Date.parse(e.commence_time) >= from.getTime()
      && Date.parse(e.commence_time) <= to.getTime());
  }

  /** Kostenpflichtiger Quotenabruf erst nach kontrollierter Spielsuche. */
  private async eventsWithOdds(sport: string, from: Date, to: Date): Promise<OaEvent[]> {
    const w = hourWindow(from, to);
    const r = await this.q.requestMeta<OaEvent[]>({
      provider: this.name,
      url: this.paidUrl(`/v4/sports/${encodeURIComponent(sport)}/odds`, {
        regions: this.o.regions, markets: ODDS_MARKETS, oddsFormat: 'decimal', dateFormat: 'iso',
        commenceTimeFrom: isoS(w.from), commenceTimeTo: isoS(w.to),
      }),
      ttlSeconds: ODDS_CACHE_MAX_SECONDS, maxCacheAgeSeconds: this.cacheRule, priority: 2, cost: this.oddsCost(),
      note: `odds h2h,totals ${sport}`,
    });
    const now = this.now().getTime();
    const list = (r.data ?? []).filter(e => { const t = Date.parse(e.commence_time); return Number.isFinite(t) && t >= from.getTime() && t <= to.getTime() && t > now; });
    for (const e of list) this.lastEvents.set(e.id, { e, fetchedAt: r.fetchedAt, fromCache: r.fromCache });
    return list;
  }

  private regionCount(): number { return Math.max(1, this.o.regions.split(',').filter(Boolean).length); }
  /** Kosten eines /odds-Abrufs: Märkte × Regionen (offizielle V4-Doku). */
  oddsCost(): number { return ODDS_MARKETS.split(',').length * this.regionCount(); }

  /** Frei verfügbare Credits: Minimum aus internem Tages-/Monatsbudget und vom Anbieter gemeldeten Restcredits. */
  private creditsAvailable(): { credits: number; limitedBy: string } {
    const b = this.q.budgetStatus(this.name);
    const c: [number, string][] = [[b.remainingBudget, `Tagesbudget (${b.used}/${b.budget})`]];
    if (b.monthlyBudget != null) c.push([Math.max(0, b.monthlyBudget - b.usedMonth), `Monatsbudget (${b.usedMonth}/${b.monthlyBudget})`]);
    const prov = this.q.providerReportedRemaining(this.name);
    if (prov != null) c.push([prov, `Anbieter-Restcredits (${prov})`]);
    if (b.paused) c.push([0, `gesperrt bis ${b.pausedUntil}`]);
    const min = c.reduce((a, x) => (x[0] < a[0] ? x : a));
    return { credits: Math.max(0, min[0]), limitedBy: min[1] };
  }

  async upcomingFixtures(fromUtc: Date, toUtc: Date): Promise<ProviderFixture[]> {
    this.report = emptyReport(this.o.sportKeys); this.resolvedKeys = null;
    this.lastEvents.clear(); // Nur Quoten des aktuellen Laufs verwenden.
    const out: ProviderFixture[] = [];
    const keys = await this.sportKeys();
    this.report.sportKeys = keys;
    for (const sport of keys) {
      for (const e of await this.upcomingEvents(sport, fromUtc, toUtc)) out.push(toFixture(e, 'scheduled'));
    }
    return out;
  }

  async historicalResults(_c: ProviderCompetition, _s: string | null): Promise<ProviderFixture[]> { return []; }

  private async scores(sport: string): Promise<OaScore[]> {
    return (await this.q.request<OaScore[]>({
      provider: this.name, url: this.paidUrl(`/v4/sports/${encodeURIComponent(sport)}/scores`, { daysFrom: String(SCORES_DAYS), dateFormat: 'iso' }),
      ttlSeconds: 30 * 60, priority: 1, cost: 2, note: `scores daysFrom=${SCORES_DAYS} ${sport}`,
    })) ?? [];
  }

  /** Ergebnis eines Spiels über /scores (Altweg; bevorzugt resultsFor). */
  async matchDetails(providerEventId: string): Promise<ProviderFixture | null> {
    if (this.o.resultsEnabled === false) return null;
    for (const sport of await this.sportKeys()) {
      const s = (await this.scores(sport)).find(r => r.id === providerEventId);
      if (s) return scoreToFixture(s, this.now());
    }
    return null;
  }

  /**
   * v0.4.0: Ergebnisse gebündelt – genau ein /scores-Abruf (2 Credits) je Wettbewerb, der offene Spiele der letzten
   * SCORES_DAYS Tage hat. Spiele ohne bekannten Wettbewerb oder älter als SCORES_DAYS lösen keinen Abruf aus.
   */
  async resultsFor(items: { providerEventId: string; competitionProviderId: string | null; kickoffUtc: string }[]): Promise<ProviderFixture[]> {
    if (this.o.resultsEnabled === false) return [];
    const minKick = this.now().getTime() - SCORES_DAYS * 86_400_000;
    const allowed = new Set(await this.sportKeys());
    const bySport = new Map<string, Set<string>>();
    for (const it of items) {
      if (!it.competitionProviderId || !allowed.has(it.competitionProviderId) || Date.parse(it.kickoffUtc) < minKick) continue;
      (bySport.get(it.competitionProviderId) ?? bySport.set(it.competitionProviderId, new Set()).get(it.competitionProviderId)!).add(it.providerEventId);
    }
    const out: ProviderFixture[] = [];
    for (const [sport, ids] of bySport) for (const s of await this.scores(sport)) if (ids.has(s.id)) out.push(scoreToFixture(s, this.now()));
    return out;
  }

  async oddsForFixtures(fixtures: ProviderFixture[]): Promise<ProviderOddsQuote[]> {
    const out: ProviderOddsQuote[] = [];
    // Ohne priorisierte Spiele keine kostenpflichtige Quotenabfrage.
    if (!fixtures.length) {
      for (const m of ['1X2', 'OU'] as MarketId[]) this.report.markets[m].reason = 'keine priorisierten Spiele';
      return out;
    }
    // /events hat KEINE Quoten geliefert. Quoten erst hier, einmal je Sport und Fenster abrufen.
    this.lastEvents.clear();
    try {
      const nowMs = this.now().getTime();
      const upcoming = fixtures.filter(f => Number.isFinite(Date.parse(f.kickoffUtc)) && Date.parse(f.kickoffUtc) > nowMs);
      // v0.4.1: Quoten nur für Wettbewerbe der tatsächlich priorisierten Spiele. Ohne eindeutige Wettbewerbs-ID (Sport-Key)
      // wird nichts geraten und NICHT auf alle konfigurierten Wettbewerbe ausgewichen – das Spiel wird mit Grund übersprungen.
      const allowed = new Set(await this.sportKeys());
      const valid = upcoming.filter(f => {
        const k = f.competition.providerId;
        if (!k) { this.report.notes.push(`${f.home.name} – ${f.away.name} (${f.provider}:${f.providerEventId}): keine eindeutige Wettbewerbszuordnung für The Odds API – kein Quotenabruf`); return false; }
        if (!allowed.has(k)) { this.report.notes.push(`${f.home.name} – ${f.away.name}: Sport-Key ${k} nicht freigegeben/aktiv – kein Quotenabruf`); return false; }
        return true;
      });
      if (!valid.length) {
        for (const m of ['1X2', 'OU'] as MarketId[]) this.report.markets[m].reason = upcoming.length ? 'keine Spiele mit eindeutiger Wettbewerbszuordnung' : 'keine priorisierten Spiele';
        return out;
      }
      const from = new Date(Math.min(...valid.map(f => Date.parse(f.kickoffUtc))) - 3_600_000);
      const to = new Date(Math.max(...valid.map(f => Date.parse(f.kickoffUtc))) + 3_600_000);
      // Nächste Anstöße zuerst; Budget VOR dem ersten kostenpflichtigen Abruf prüfen
      const firstKick = (sp: string) => Math.min(...valid.filter(f => f.competition.providerId === sp).map(f => Date.parse(f.kickoffUtc)));
      const sports = [...new Set(valid.map(f => f.competition.providerId))].sort((a, b) => firstKick(a) - firstKick(b) || a.localeCompare(b));
      const cost = this.oddsCost();
      const avail = this.creditsAvailable();
      const affordable = Math.max(0, Math.floor(avail.credits / cost));
      for (const sp of sports.slice(affordable)) this.report.skippedSportKeys.push({ key: sp, reason: `Budget: ${cost} Credits je Abruf, verfügbar ${avail.credits} (${avail.limitedBy})` });
      if (!affordable && sports.length) throw new QuotaExhaustedError(this.name, `${this.name}: kein Quotenabruf – ${cost} Credits nötig, verfügbar ${avail.credits} (${avail.limitedBy})`);
      for (const sport of sports.slice(0, affordable)) await this.eventsWithOdds(sport, from, to);
      const wanted = new Set(valid.filter(f => f.provider === this.name).map(f => f.providerEventId));
      const all = valid.some(f => f.provider !== this.name);
      const selected = [...this.lastEvents.values()].filter(({ e }) => all || wanted.has(e.id));
      for (const { e, fetchedAt, fromCache } of selected) {
        const qs = convertOaEvent(e, fetchedAt, { onlyOuLine: OU_LINE }).map(q => ({ ...q, fromCache }));
        if (qs.some(q => q.market === '1X2')) this.report.markets['1X2'].events++;
        if (qs.some(q => q.market === 'OU')) this.report.markets.OU.events++;
        out.push(...qs);
      }
      if (this.o.includeBtts) out.push(...await this.bttsLimited(selected.map(s => s.e)));
      for (const m of ['1X2', 'OU'] as MarketId[]) if (!this.report.markets[m].events) this.report.markets[m].reason = selected.length ? 'vom Provider für diese Spiele nicht geliefert' : 'keine Spiele';
      return out;
    } finally {
      // Keine Quoten über den Lauf hinaus im Speicher halten (nie als "aktuell" wiederverwenden)
      this.lastEvents.clear();
    }
  }

  /**
   * BTTS kontrolliert: nur die nächsten N Anstöße (bttsMaxEventsPerRun), nur solange das Monatsbudget eine Reserve hat,
   * Budgetfehler beenden nur BTTS, nicht den Lauf. Nicht angefragte Spiele bleiben ohne BTTS ("nicht verfügbar").
   */
  private async bttsLimited(events: OaEvent[]): Promise<ProviderOddsQuote[]> {
    const rep = this.report.markets.BTTS;
    rep.requested = true; rep.reason = null;
    const max = this.o.bttsMaxEventsPerRun ?? 5;
    const now = this.now().getTime();
    const upcoming = events.filter(e => Date.parse(e.commence_time) > now).sort((a, b) => a.commence_time.localeCompare(b.commence_time));
    const out: ProviderOddsQuote[] = [];
    let asked = 0;
    for (const e of upcoming) {
      if (asked >= max) { rep.reason = `Limit ${max} BTTS-Abrufe je Lauf erreicht; ${upcoming.length - asked} Spiele ohne BTTS`; break; }
      const st = this.q.budgetStatus(this.name);
      if (st.monthlyBudget != null) {
        const freePct = 100 * (st.monthlyBudget - st.usedMonth) / st.monthlyBudget;
        if (freePct < (this.o.bttsReservePct ?? 25)) { rep.reason = `Monatsbudget-Reserve unterschritten (${freePct.toFixed(0)} % frei, mindestens ${this.o.bttsReservePct ?? 25} %): BTTS ausgesetzt`; break; }
      }
      asked++;
      try {
        const qs = await this.btts(e);
        if (qs.length) rep.events++;
        out.push(...qs);
      } catch (err) {
        if (err instanceof QuotaExhaustedError) { rep.reason = `BTTS abgebrochen: ${err.message}`; break; }
        throw err;
      }
    }
    if (!rep.reason && asked && !rep.events) rep.reason = 'vom Provider für die angefragten Spiele nicht geliefert';
    return out;
  }

  private async btts(e: OaEvent): Promise<ProviderOddsQuote[]> {
    const r = await this.q.requestMeta<OaEvent>({
      provider: this.name,
      url: this.paidUrl(`/v4/sports/${encodeURIComponent(e.sport_key)}/events/${encodeURIComponent(e.id)}/odds`, { regions: this.o.regions, markets: 'btts', oddsFormat: 'decimal', dateFormat: 'iso' }),
      ttlSeconds: ODDS_CACHE_MAX_SECONDS, maxCacheAgeSeconds: this.cacheRule, priority: 1, cost: this.regionCount(), note: `event odds btts ${e.sport_key}/${e.id}`,
    });
    return r.data ? convertOaEvent(r.data, r.fetchedAt, { onlyOuLine: OU_LINE }).map(q => ({ ...q, fromCache: r.fromCache })) : [];
  }
}

function toFixture(e: { id: string; sport_key: string; sport_title?: string; home_team: string; away_team: string; commence_time: string }, status: ProviderFixture['status']): ProviderFixture {
  return {
    provider: 'theoddsapi', providerEventId: e.id,
    competition: { providerId: e.sport_key, name: e.sport_title ?? e.sport_key },
    home: { providerId: 'name:' + e.home_team, name: e.home_team },
    away: { providerId: 'name:' + e.away_team, name: e.away_team },
    kickoffUtc: new Date(e.commence_time).toISOString(), status,
  };
}

/** /scores-Zeile → Fixture. Nur "completed" mit beiden Toren zählt als beendet; sonst kein Ergebnis. */
export function scoreToFixture(s: OaScore, now: Date = new Date()): ProviderFixture {
  const goals = (team: string) => { const v = s.scores?.find(x => x.name === team)?.score; const n = v == null ? NaN : Number(v); return Number.isInteger(n) && n >= 0 ? n : null; };
  const hg = goals(s.home_team), ag = goals(s.away_team);
  const finished = s.completed && hg != null && ag != null;
  const started = Date.parse(s.commence_time) <= now.getTime();
  return { ...toFixture(s, finished ? 'finished' : started ? 'live' : 'scheduled'), homeGoals: finished ? hg : null, awayGoals: finished ? ag : null };
}

/**
 * Wandelt ein The-Odds-API-Event in normalisierte Quoten um. retrievedAt MUSS der echte Abrufzeitpunkt sein.
 * onlyOuLine: nur diese Torlinie übernehmen (Provider: 2,5). Fehlende Auswahlen bleiben fehlen → Validierung lehnt ab.
 */
export function convertOaEvent(e: OaEvent, retrievedAt: string, opts: { onlyOuLine?: number } = {}): ProviderOddsQuote[] {
  const out: ProviderOddsQuote[] = [];
  for (const b of e.bookmakers ?? []) for (const m of b.markets ?? []) {
    // h2h_3_way nur, wenn der Buchmacher kein h2h mit Unentschieden liefert (keine doppelten 1X2-Snapshots)
    if (m.key === 'h2h_3_way' && b.markets.some(x => x.key === 'h2h' && x.outcomes.some(o => /^draw$/i.test(o.name)))) continue;
    const base = {
      provider: 'theoddsapi', providerEventId: e.id, rawHome: e.home_team, rawAway: e.away_team, rawCompetition: e.sport_title,
      kickoffUtc: new Date(e.commence_time).toISOString(), bookmakerProviderId: b.key, bookmakerName: b.title,
      marketStatus: 'open' as const, retrievedAt, sourceTimestamp: m.last_update ?? b.last_update ?? null, snapshotKind: 'live' as const,
    };
    if (m.key === 'h2h' || m.key === 'h2h_3_way') {
      const p: Partial<Record<SelectionId, number>> = {};
      for (const o of m.outcomes) {
        if (o.name === e.home_team) p.HOME = o.price; else if (o.name === e.away_team) p.AWAY = o.price; else if (/^draw$/i.test(o.name)) p.DRAW = o.price;
      }
      out.push({ ...base, market: '1X2', line: null, prices: p });
    } else if (m.key === 'totals') {
      const byLine = new Map<number, Partial<Record<SelectionId, number>>>();
      for (const o of m.outcomes) {
        if (o.point == null) continue;
        if (opts.onlyOuLine != null && o.point !== opts.onlyOuLine) continue;
        const rec = byLine.get(o.point) ?? {};
        if (/^over$/i.test(o.name)) rec.OVER = o.price; else if (/^under$/i.test(o.name)) rec.UNDER = o.price;
        byLine.set(o.point, rec);
      }
      for (const [line, prices] of byLine) out.push({ ...base, market: 'OU', line, prices });
    } else if (m.key === 'btts') {
      const p: Partial<Record<SelectionId, number>> = {};
      for (const o of m.outcomes) { if (/^yes$/i.test(o.name)) p.YES = o.price; else if (/^no$/i.test(o.name)) p.NO = o.price; }
      out.push({ ...base, market: 'BTTS', line: null, prices: p });
    }
  }
  return out;
}
