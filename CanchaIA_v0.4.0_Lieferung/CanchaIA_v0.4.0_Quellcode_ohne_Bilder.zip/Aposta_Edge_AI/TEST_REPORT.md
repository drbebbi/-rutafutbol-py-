# Testbericht v0.3.0

Stand: 13.10.2026.

**Umgebung**
- Linux, Node.js 22.22, TypeScript (strict), esbuild, React 19.2, Chromium (Playwright)
- Netzwerk: **kein Zugang** zu The Odds API, football-data.co.uk und Highlightly (HTTP 000, geprüft am 13.10.2026, 14:56 UTC)
- Kein Docker, kein Zugang zur npm-Registry

**Alle Zahlen stammen aus tatsächlich ausgeführten Läufen. Es gibt keine erfundenen Ergebnisse.**

## 1. Ausgangsstand (vor den Änderungen)

| Schritt | Ergebnis |
|---|---|
| Original gesichert | `backup_v0.2.0_original.zip`, unverändert. Git-Basis-Commit „v0.2.0 baseline (bereitgestelltes Original)“ |
| Inhalt geprüft | identisch mit der zuletzt gelieferten v0.2.0 (Dateivergleich ohne Unterschiede) |
| Bestehende Tests | **93/93 bestanden** |
| Frontend-Build | erfolgreich |

## 2. Prüfungen nach den Änderungen

| # | Prüfung (laut Auftrag) | Ergebnis |
|---|---|---|
| 1 | alle bisherigen 93 Backend-Tests | ✅ bestanden. Nur der v0.1.0-Migrationstest wurde angepasst: Er erwartete exakt eine neue Migration, jetzt folgen 004–006. Die Prüfung der Reihenfolge bleibt |
| 2 | neue Tests für alle fünf Änderungen | ✅ 28 neue Tests (siehe 4) |
| 3 | Migration einer v0.2.0-Datenbank | ✅ echte DB, mit dem v0.2.0-Build erzeugt (1.008 Spiele, 264 Snapshots, 168 Signale, 3 Empfehlungen, 3 Meldungen, davon 2 gelesen): alle Daten erhalten, Lesestatus übernommen, Snapshot-Trigger aktiv, keine Abos automatisch angelegt |
| 4 | Wiederholung der Migration (Idempotenz) | ✅ zweiter Lauf: keine Migration, keine Änderung (Datei- und In-Memory-Test) |
| 5 | Frontend-Produktionsbuild | ✅ main.js 293,1 kB (v0.2.0: 266,6 kB), styles.css 10,5 kB |
| 6 | TypeScript-Backend-Build | ✅ tsc strict, 0 Fehler |
| 7 | Sicherheitstest Benutzerrechte und Tarife | ✅ 11 Tests (V4 und V5, siehe 4) |
| 8 | abgelaufene Empfehlungen | ✅ bestehende Tests TEST A–E, Gültigkeitsgrenze, API-Revalidierung +6 h |
| 9 | alte Quoten aus dem Cache | ✅ bestehender Cache-Zeitstempel-Test plus neuer Test zur dynamischen Cache-Regel |
| 10 | API-Budgetgrenzen | ✅ Monatsbudget (Abbruch vor Überschreitung), BTTS-Reserve, App-Verdrahtung |
| 11 | persönliche Benachrichtigungen | ✅ 5 Tests |
| 12 | manuelle Abonnementfreischaltung | ✅ Prüfablauf, begründete Freischaltung, Ablauf |
| 13 | End-to-End im Mock-Modus | ✅ CLI `sync`: dieselben 3 Empfehlungen mit denselben EV-Werten wie v0.2.0 (keine Modelländerung). `validate`: UNVALIDATED mit Bericht. Browser: Admin und Benutzer bei 390 px und 1366 px ohne JS-Fehler und ohne horizontales Überlaufen. Kontrollierter Sync, Validierung und Bestellung bis „Pagos pendientes“ durchgeklickt |
| 14 | kontrollierter Live-Test | ⛔ **NOT VERIFIED**: kein API-Schlüssel, kein Netzwerk. Siehe [LIVE_API_TEST_REPORT.md](LIVE_API_TEST_REPORT.md) |
| – | Endpunkt-Kompatibilität | ✅ v0.3.0-Server auf der migrierten v0.2.0-DB: 12 bestehende und neue Lese-Endpunkte antworten mit 200. Antwortformen bleiben rückwärtskompatibel (Felder nur ergänzt) |
| – | Secret-Scan | ✅ kein Highlightly-Schlüssel, keine Demo-Passwörter, keine Bankdaten oder C.I.-Nummern im Paket |
| – | Docker-Build | ⚠️ nicht ausführbar (kein Docker) |
| – | Frontend-Typprüfung | ⚠️ nicht ausführbar (`@types/react` nicht installierbar). esbuild baut, die Oberfläche ist im Browser geprüft |

Testlauf vom 13.10.2026: `# tests 121 · # pass 121 · # fail 0` (≈ 50 s).

## 3. Gefundene und korrigierte Fehler

| # | Datei | Ursache | Auswirkung | Behebung | Regressionstest |
|---|---|---|---|---|---|
| F1 | `config.ts` | `configIssues` prüfte nur Highlightly als Fixture-Quelle | falsche Meldung „kein Fixture-Provider“, obwohl The Odds API konfiguriert war | `providerStates()` als eine Quelle der Wahrheit | V1-B |
| F2 | `discovery.ts` | nicht konfigurierte Provider landeten in `errors` | Lauf ohne Prognosen endete als `failed` | Hinweis (`notices`), solange ein Fixture-Provider nutzbar ist | V1-B, Live-Modus-Test unverändert grün |
| F3 | `app.ts` | `includeBtts` nie übergeben | BTTS über The Odds API nie abrufbar | Option + Limit + Reserve | V1-A (2 Tests) |
| F4 | `theOddsApi.ts`, `highlightly.ts` | fester 20-min-Quoten-Cache | Cache-Kopien in der letzten Stunde sofort unbrauchbar | dynamische Regel `oddsCacheMaxAgeSeconds` | V1-C |
| F5 | `pages.tsx`, `server.ts` | leere Märkte als „MARKET SUSPENDED“ angezeigt | irreführende Anzeige | `availability` mit Grund | V1 Marktverfügbarkeit |
| F6 | `repository.ts`, `matching.ts` | Teams/Wettbewerbe nur je Provider | Live-Spiele ohne Historie (immer INSUFFICIENT DATA) | `linking.ts` (konservativ) | V2 Verknüpfung, V2 kontrollierter Sync |
| F7 | `theOddsApi.ts` | keine Ergebnisabfrage | Pilot-Empfehlungen nicht abrechenbar | `/scores?daysFrom=3` | V2 Ergebnisse |
| F8 | `discovery.ts` | begonnene Spiele aus dem Feed als `scheduled` angelegt | Risiko einer Pre-Match-Verarbeitung (wurde in v0.2.0 durch Freshness abgefangen) | Ausschluss beim Abruf | V2 kontrollierter Sync |
| F9 | `footballDataCsv.ts` | pauschal UTC−1 h | Winter-Anstoß 1 h zu früh: Entscheidungszeitpunkt im Backtest und Zuordnung ±2 h verschoben | GMT/BST korrekt | V3-Datenfehler |
| F10 | `server.ts` | `alerts_sent.read_at` global | Benutzer A ändert den Lesestatus für B | `alert_reads` je Benutzer | V5 Zugriffskontrolle |
| F11 | `backtest.ts` | `INSERT OR REPLACE` in `model_versions` | Modellversion überschreibbar | `INSERT` + Trigger | V3 Unveränderlichkeit |

Keine dieser Korrekturen ändert die Mathematik der Prognosemodelle. Der Mock-Lauf liefert vor und nach dem Update identische Empfehlungen.

## 4. Testabdeckung (121 Tests)

| Datei | Anzahl | neu | Inhalt |
|---|---|---|---|
| `v030_api_pilot.test.ts` | 12 | 12 | Provider-Diagnose; BTTS aus/an/Limit/Reserve; dynamischer Cache; Monatsbudget und Abrufprotokoll ohne Schlüssel; Pilot-Keys gegen `/v4/sports`; Wettbewerbs-/Teamverknüpfung inkl. „Man City ≠ Man United“ und Nicht-Raten; kontrollierter Sync mit Prüfungen und begonnenem Spiel; NOT CONFIGURED ohne Abruf; `/scores`; CSV-Sommerzeit; Marktverfügbarkeit |
| `v030_validation.test.ts` | 4 | 4 | Datenqualität (fehlende Ergebnisse, Duplikate, Doppel-Teams, keine Leakage); Blocker verhindern VALIDATED; Validierungsbericht je Liga und Markt mit Log Loss, Brier, ECE, Quellen; Mock bleibt UNVALIDATED; Modellversionen unveränderlich |
| `v030_subscriptions.test.ts` | 6 | 6 | ohne Durchsetzung keine Regression; Bestellung → Beleg → keine Freischaltung → Prüfung → ACTIVE; Sicherheit (fremde Zahlungen, Admin-Endpunkte, Selbstfreigabe, doppelte Bankreferenz, Protokoll unveränderlich, Rolle ≠ Tarif); Durchsetzung FREE/PRO/Ablauf; uPay nur Test; Laufzeiten |
| `v030_alerts.test.ts` | 5 | 5 | Filter je Benutzer und Dedupe; Tarif-Durchsetzung; keine systemweiten Kanäle für persönliche Meldungen; Zugriffskontrolle A/B; 402 beim Einschalten ohne Tarif |
| `migration.test.ts` | 2 | 1 | v0.1.0 → v0.2.0 (angepasst); **v0.2.0 → v0.3.0** (neu) |
| bestehend: `lifecycle` 15, `math` 19, `server` 14, `pipeline` 10, `backtest` 7, `apiQueue` 7, `scheduler` 7, `providers` 7, `models` 6 | 92 | – | unverändert |

## 5. Backtest/Validierung auf Mock-Daten (tatsächliches Ergebnis)

| Markt | Holdout | Log Loss Ensemble | Basisrate | Brier | ECE | Δ vs. Basisrate (95-%-KI) |
|---|---|---|---|---|---|---|
| 1X2 | 248 | 1,0904 | 1,0904 | 0,6598 | 0,027 | −0,0000 [−0,028; +0,030] |
| Ü/U 2,5 | 248 | 0,6856 | 0,6876 | 0,4913 | 0,053 | −0,0020 [−0,032; +0,027] |
| BTTS | 248 | 0,6993 | 0,6969 | 0,5056 | 0,059 | +0,0024 [−0,020; +0,024] |

**UNVALIDATED.** Gründe: Mock-Daten, Holdout < 300, keine Marktquoten zum Entscheidungszeitpunkt. Es wird keine Rendite ausgewiesen. Die fiktiven Mock-Daten sind kein Qualitätsnachweis. Echte Daten lagen nicht vor.

## 6. Statusmatrix

| Komponente | Status |
|---|---|
| V1 Provider-Diagnose (READY / NOT CONFIGURED / BLOCKED) | IMPLEMENTED · TESTED |
| V1 BTTS-Option mit Limit und Reserve | IMPLEMENTED · TESTED · NOT VERIFIED (live) |
| V1 dynamische Cache-Regel | IMPLEMENTED · TESTED |
| V1 Abrufprotokoll | IMPLEMENTED · TESTED |
| V1 Marktverfügbarkeit „NOT AVAILABLE“ | IMPLEMENTED · TESTED |
| V2 Pilotmodus | IMPLEMENTED · TESTED · NOT VERIFIED (live) |
| V2 kontrollierter Diagnose-Sync | IMPLEMENTED · TESTED · NOT VERIFIED (live) |
| V2 Verknüpfung CSV ↔ The Odds API | IMPLEMENTED · TESTED · NOT VERIFIED (echte Teamnamen) |
| V2 Ergebnisse über `/scores` | IMPLEMENTED · TESTED · NOT VERIFIED (live) |
| V3 Datenqualitätsprüfung | IMPLEMENTED · TESTED |
| V3 Validierungsablauf | IMPLEMENTED · TESTED · auf echten Daten NOT RUN |
| Prognosemodelle | **UNVALIDATED** (unverändert) |
| STRONG_VALUE | gesperrt bis VALIDATED |
| V4 Tarife, Abo-Status, Berechtigungen | IMPLEMENTED · TESTED (Durchsetzung standardmäßig aus) |
| V4 Banküberweisung SIPAP/Alias mit Admin-Prüfung | IMPLEMENTED · TESTED (ohne echte Bank) |
| V4 uPay | Schnittstelle + Testmodus IMPLEMENTED · echte Integration NOT IMPLEMENTED · BLOCKED (keine Händlerfreigabe) |
| V5 persönliche Benachrichtigungen (In-App) | IMPLEMENTED · TESTED |
| V5 persönliche Telegram-/Webhook-Meldungen | NOT IMPLEMENTED (bewusst) |
| Highlightly | BLOCKED |
| The Odds API live | NOT VERIFIED |
| Docker | NOT VERIFIED |
| Base44 | NOT IMPLEMENTED |
| Automatische Wettplatzierung, echte Zahlungen | bewusst NOT IMPLEMENTED |

Eine bestandene Testsuite bedeutet nicht Produktionsreife (siehe [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md)).

## 7. Wiederholen

```bash
npm run install:all
npm --prefix backend test           # 121 Tests
npm --prefix frontend run build
DATA_MODE=mock npm --prefix backend run validate
```

## Anhang: Testbericht v0.2.0

Die v0.2.0-Audit-Befunde A1–A15 (Lebenszyklus, Cache-Zeitstempel, Freshness, Leave-one-out, Look-Ahead im Backtest, Credits, 429, Scheduler, Sicherheit) und ihre Regressionstests sind im TEST_REPORT.md der v0.2.0-ZIP beschrieben. Alle zugehörigen Tests sind in v0.3.0 weiterhin enthalten und grün.

---

# Testbericht v0.3.2 (Rebranding CanchaIA)

Stand: 13.10.2026. Umgebung wie oben (Node.js 22.22, esbuild 0.28, React 19.2, TypeScript 6, Chromium/Playwright). Die npm-Registry war nicht erreichbar; verwendet wurden lokal vorhandene, versionsgleiche Pakete (`@types/node` 26 statt 22).

| Prüfung | Vorher (v0.3.1) | Nachher (v0.3.2) |
|---|---|---|
| Backend-Tests `npm test` | 121/121 | **121/121** |
| Frontend-Build (esbuild) | ok | **ok** |
| E2E-Branding/Regression `scripts/e2e-branding.mjs` | – | **88/88** |

Der E2E-Test läuft gegen die echte App (Backend im Mock-Modus + gebautes React-Frontend), Desktop 1440×900 und Smartphone 390×844 (DPR 2), und prüft:
- Titel, `lang="es-PY"`, Marke und Slogan auf allen Seiten; kein „Aposta“, „EDGE ANALYST“ oder „Edge AI“ mehr im sichtbaren Text (ES/EN/DE)
- Standard `language=es`, `timezone=America/Asuncion`; angezeigte Anstoßzeit = Asunción-Zeit
- Guaraní-Preise im Format `79.000 Gs.`
- Sprachwechsel EN/DE/ES inkl. `lang`-Attribut, Slogan bleibt
- Favicon und Apple-Touch-Icon werden ausgeliefert
- Sync, Spieldetail, KI-Analyst (Regelmodus), Performance, Einstellungen, Admin ohne JS-/Konsolenfehler
- Normaler Benutzer: `/admin` zeigt die Startseite, Admin-API liefert 403, Abmelden funktioniert

Gefundener und behobener Befund: Bei Nicht-Admins zeigte `/admin` (wie bisher) die Startseite, der Tab-Titel lautete aber „Inicio · CanchaIA“. Titel und Wortmarke hängen jetzt an der tatsächlich angezeigten Seite.

Nicht geprüft: Live-Provider, echte Zahlungen, KI-Modus mit Schlüssel (Prompt-Text geändert, im Test nicht ausgeführt), Safari/iOS-Geräte.

---

# Testbericht v0.3.3 (The Odds API)

Stand: 13.10.2026.

## Automatisierte Tests mit nachgebauten Antworten (kein Netzwerk, kein echter Schlüssel)

| | Ergebnis |
|---|---|
| Backend gesamt `npm test` | **137/137** (vorher 121; 121 bestehende weiterhin grün) |
| Neu `test/v033_odds_api.test.ts` | **16/16** |
| Gegenprobe | Stopp bei Anbieter-Restcredits und Sperre deaktiviert → 3 Tests schlagen wie erwartet fehl; danach wiederhergestellt |
| Frontend-Build | ok |
| E2E-Regression v0.3.2 (`scripts/e2e-branding.mjs`, Mock-Modus) | **88/88** |
| Admin-Karte im Live-Modus ohne Secret (Browser, Desktop + Smartphone) | DISCONNECTED, Test-Button deaktiviert, kein horizontaler Überlauf, keine JS-Fehler |

| Prüfpunkt (Auftrag) | Test | Ergebnis |
|---|---|---|
| 1 Schlüssel serverseitig geladen | #1 | bestanden |
| 2 Authentifizierung (200 / 401 / 503, ein Versuch) | #2 (3 Tests) | bestanden |
| 3 Champions-League-Key erkannt (aktiv / inaktiv / unbekannt) | #3 | bestanden |
| 4 Quoten verarbeitet, als LIVE gespeichert, Sperre vor Test | #4 (2 Tests) | bestanden |
| 5 1X2 inkl. Unentschieden | #5 | bestanden |
| 6 Über/Unter 2,5 | #6 | bestanden |
| 7 BTTS, sofern geliefert | #7 | bestanden |
| 8 fehlende Märkte nicht erfunden, keine Value Bet ohne Historie | #8 | bestanden |
| 9 API-Limits | #9 | bestanden |
| 10 Schlüssel nicht im Frontend, in Antworten, Protokoll, DB | #10 + Log-Test | bestanden |

## Tatsächlich ausgeführte Live-Tests

`npm run odds:check` im Live-Modus: kein Secret → kein Abruf, DISCONNECTED. **Kein Live-Test gegen The Odds API möglich** (Secret fehlt, Host gesperrt). Siehe LIVE_API_TEST_REPORT.md.
