#!/usr/bin/env bash
# CanchaIA v0.4.0 - iPhone Codespaces launch helper.
# No external sports data calls except ONE free GET /v4/sports, and NO paid calls.
set -Eeuo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")"
PROJECT_ROOT="$PWD"
umask 077

printf '\n=== CanchaIA v0.4.0 | GitHub Codespaces ===\n'
printf 'Modus: LIVE | Scheduler: AUS | Quotenabrufe: KEINE\n'

# GitHub Codespaces injects secrets as environment variables. Never print their values.
missing=()
[[ -n "${THE_ODDS_API_KEY:-}" ]] || missing+=(THE_ODDS_API_KEY)
[[ -n "${ADMIN_EMAIL:-}" ]] || missing+=(ADMIN_EMAIL)
[[ -n "${ADMIN_PASSWORD:-}" ]] || missing+=(ADMIN_PASSWORD)
if ((${#missing[@]})); then
  printf '\nFehlende Codespaces-Secrets: %s\n' "${missing[*]}"
  printf 'GitHub Repository > Settings > Secrets and variables > Codespaces.\n'
  printf 'Secrets eintragen, Codespace stoppen und neu starten.\n'
  exit 2
fi
if [[ "${#ADMIN_PASSWORD}" -lt 12 || ! "${ADMIN_PASSWORD}" =~ [[:alpha:]] || ! "${ADMIN_PASSWORD}" =~ [[:digit:]] ]]; then
  printf 'ADMIN_PASSWORD muss >=12 Zeichen sowie Buchstaben und Zahlen enthalten.\n'
  exit 2
fi

# Node.js >=22.13.0 required for native node:sqlite. Prefer nvm when available.
if [[ -s "${NVM_DIR:-$HOME/.nvm}/nvm.sh" ]]; then
  # shellcheck disable=SC1090
  source "${NVM_DIR:-$HOME/.nvm}/nvm.sh"
  nvm install 22 >/dev/null
  nvm use 22 >/dev/null
fi
if ! command -v node >/dev/null 2>&1; then
  printf 'Node.js nicht gefunden. In Codespaces muss Node.js >=22.13 installiert sein.\n'
  exit 3
fi
node -e 'let p=process.versions.node.split(".").map(Number);if(p[0]<22||(p[0]===22&&p[1]<13)){process.stderr.write("Node.js >=22.13 erforderlich. Installiere Node 22 mit nvm.\\n");process.exit(1)}'

export DATA_MODE=live
export PORT=8080
export HOST=0.0.0.0
export DB_PATH="$PROJECT_ROOT/data/canchaia.sqlite"
export FRONTEND_DIR="$PROJECT_ROOT/frontend/dist"
export APP_TIMEZONE=America/Asuncion
export COOKIE_SECURE=true
export TRUST_PROXY=false
export ALLOW_REGISTRATION=false
export SCHEDULER_ENABLED=false
export THE_ODDS_API_BASE_URL=https://api.the-odds-api.com
export THE_ODDS_API_SPORT_KEYS=soccer_uefa_champs_league
export THE_ODDS_API_REGIONS=eu
export THE_ODDS_API_MONTHLY_BUDGET=500
export THE_ODDS_API_DAILY_BUDGET=16
export THE_ODDS_API_INCLUDE_BTTS=false
export THE_ODDS_API_RESULTS=false
export PILOT_MODE=false
# Only The Odds API is authorised here.
export HIGHLIGHTLY_API_KEY=''
export HIGHLIGHTLY_BETTING_USE_CONFIRMED=false
export ANTHROPIC_API_KEY=''
mkdir -p "$PROJECT_ROOT/data"

printf '\n[1/4] Abhängigkeiten installieren (GitHub Codespaces)...\n'
npm --prefix backend install --no-audit --no-fund
npm --prefix frontend install --no-audit --no-fund
printf '\n[2/4] Frontend und Backend bauen...\n'
npm run build
printf '\n[3/4] Kostenloser The-Odds-API-Verbindungstest (GET /v4/sports, EINMAL)...\n'
if npm --prefix backend run odds:check; then
  printf '\nAPI-Verbindungstest beendet. Prüfe die oben angezeigten HTTP- und Credit-Werte.\n'
else
  printf '\nWARNUNG: API-Verbindung fehlgeschlagen. KEINE kostenpflichtigen Abrufe starten.\n'
  printf 'Die App kann zum Debuggen trotzdem starten.\n'
fi
printf '\n[4/4] CanchaIA auf Port 8080 starten...\n'
printf 'Codespaces > PORTS > 8080 > Open in Browser; Sichtbarkeit PRIVATE lassen.\n'
printf 'Kein automatischer Quoten-Sync und kein kostenpflichtiger API-Test.\n\n'
exec npm start
