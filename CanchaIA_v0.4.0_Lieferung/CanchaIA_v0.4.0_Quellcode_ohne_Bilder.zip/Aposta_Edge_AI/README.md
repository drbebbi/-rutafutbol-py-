> **v0.4.0** (kontrollierter Live-Pilot, nicht produktionsreif): [START.md](START.md) · [CHANGES_v0.4.0.md](CHANGES_v0.4.0.md) · [TEST_REPORT_v0.4.0.md](TEST_REPORT_v0.4.0.md) · [OPEN_BLOCKERS.md](OPEN_BLOCKERS.md)
> 169/169 Backend-Tests, Frontend-Typprüfung ohne Fehler. **Kein echter Quotenabruf** (kein Schlüssel verfügbar), **keine Validierung mit echten Daten**: alle Modelle UNVALIDATED, Signale experimentell.

**Aktualisierung v0.3.4:** Die Spielsuche nutzt jetzt das kostenlose `/v4/sports/{sport}/events`; Quoten werden erst im nachgelagerten Sync geladen. Die Zugriffssperre nach 401/403 ist repariert. 139/139 Backend-Tests bestanden (simulierte Antworten). **Eine echte API-Verbindung ist hier noch nicht nachgewiesen.** Siehe [V034_TEST_REPORT.md](V034_TEST_REPORT.md) und [THE_ODDS_API_INTEGRATION.md](THE_ODDS_API_INTEGRATION.md).

# CanchaIA · Inteligencia Futbolística · v0.4.0

> Öffentliche Marke ab v0.3.2: **CanchaIA** (zunächst für Paraguay). Technischer Projektname weiterhin `aposta-edge-ai`.
> ⚠️ Namensverfügbarkeit und Markenregistrierung sind **noch nicht rechtlich bestätigt**. Siehe [BRANDING.md](BRANDING.md).

Fußball-Value-Analyse, die selbstständig Spiele der nächsten 48 Stunden findet, Quoten mehrerer Buchmacher prüft, Wahrscheinlichkeiten mit vier Modellen berechnet und **höchstens fünf** qualifizierte Value-Bet-Kandidaten mit mindestens **+5 % EV** zeigt. Findet sie keine, meldet sie `NO QUALIFIED VALUE BETS`.

Die App platziert **niemals** Wetten, fragt keine Wettkonto-Daten ab und führt keine Finanztransaktionen aus. Eine positive EV-Schätzung ist keine Gewinnzusage.

> **Status:** funktional implementiert und im Mock-Modus automatisiert getestet (v0.4.0: 169 automatisierte Tests). Weder die Live-Provider noch die Prognosequalität auf echten Daten sind verifiziert: Die Modelle sind **UNVALIDATED**. Details in [TEST_REPORT.md](TEST_REPORT.md) und [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md).

## Neu in v0.3.3

The Odds API integriert: kostenloser Verbindungstest, Status CONNECTED/DEGRADED/DISCONNECTED im Admin, Sperre kostenpflichtiger Abrufe bis zum bestandenen Test, Kostenvoranschlag und Budgetschutz, Champions League (`soccer_uefa_champs_league`). **Live noch nicht verifiziert.** Siehe [THE_ODDS_API_INTEGRATION.md](THE_ODDS_API_INTEGRATION.md).

## Neu in v0.3.2

Rebranding auf **CanchaIA – Inteligencia Futbolística**: neuer Name, Slogan, Logo, Favicon und Seitentitel, Standardsprache Español (Paraguay), Preise in Guaraní, Zeitzone America/Asuncion. Englisch und Deutsch bleiben verfügbar. Backend funktional unverändert. Siehe [BRANDING.md](BRANDING.md) und `docs/screenshots/`.

## Neu in v0.3.1

Neues Frontend „Professional Analytics“ (nur Oberfläche, Backend unverändert): Design-System mit UI-Kit, überarbeitete Übersicht, Spiele, Spieldetail, EDGE-ANALYST-Konsole (ab v0.3.2: Analista IA), Performance, Einstellungen, Anmeldung und Admin. Siehe [FRONTEND_REDESIGN.md](FRONTEND_REDESIGN.md) und `docs/screenshots/`.

## Neu in v0.3.0

1. **API und Konfiguration:**
   - The Odds API wird korrekt als Fixture-Provider erkannt. Fehlende Provider erscheinen als `NOT CONFIGURED`.
   - BTTS lässt sich gezielt aktivieren, mit Limit je Lauf und Budget-Reserve.
   - Nicht verfügbare Märkte werden mit Grund angezeigt.
   - Dynamische Cache-Regel nach Anstoß.
   - Jeder API-Abruf wird protokolliert, ohne Schlüssel.
2. **Kontrollierter Live-Betrieb:**
   - Pilotmodus für ausgewählte Wettbewerbe.
   - Admin-Diagnose: genau ein begrenzter Sync mit vollständigem Bericht und automatischen Prüfungen.
   - Verknüpfung der The-Odds-API-Spiele mit der CSV-Historie, Ergebnisse über `/scores`.
3. **Historische Validierung:**
   - Datenqualitätsprüfung (Duplikate, Aliase, fehlende Ergebnisse, zeitliche Trennung).
   - Validierungsbericht je Liga und Markt mit Log Loss, Brier und Kalibrierung, Vergleich mit Basisrate und Markt.
   - Unveränderliche Modellversionen.
   - Korrektur der CSV-Anstoßzeiten (Sommer-/Winterzeit).
4. **Tarifverwaltung (Testmodus):**
   - FREE, PRO und PREMIUM, getrennt von den Rollen.
   - SIPAP/Alias-Überweisung mit Admin-Prüfung; ein Beleg schaltet nichts frei.
   - uPay-Schnittstelle nur als Test.
   - Änderungsprotokoll.
   - Durchsetzung standardmäßig aus.
5. **Persönliche Benachrichtigungen:** Opt-in, eigene Typen und Mindest-EV, Deduplizierung und Lesestatus je Benutzer, strikte Zugriffskontrolle.

## Neu in v0.2.0

- **Keine veralteten Empfehlungen mehr:** Jede Empfehlung wird bei jedem Abruf gegen die aktuelle Uhr und die aktuellen Daten geprüft. Ohne frische Quote läuft sie ab, auch wenn ein Sync ausfällt.
- **Korrekte Quotenzeitstempel:** Abruf-, Quell-, Cache-, Verarbeitungs- und Validierungszeit sind getrennt. Cache-Treffer altern weiter, Zeitstempel in der Zukunft werden abgelehnt. Die Frische-Grenzen werden mit Nähe zum Anstoß strenger (90/60/30/10 min).
- **Marktreferenz ohne doppelte Information:** Der bewertete Buchmacher fließt nicht in seinen eigenen fairen Preis ein.
- **Backtest neu:** Entscheidungszeitpunkt vor dem Anstoß. Schlusskurse sind nie Wettquote. Vergleich gegen Basisrate, Markt und Mischgewichte mit Bootstrap-Konfidenzintervallen.
- **Betrieb:** Credits pro Tag und Monat, persistente Rate-Limit-Sperren, Scheduler mit Heartbeat und Absturz-Wiederaufnahme.
- **Sicherheit:** Benutzerkonten mit Rollen, scrypt, HttpOnly-Session-Cookies, CSRF, Origin-Prüfung. Kein Token mehr im Browser-Speicher.

## Schnellstart (Mock-Modus, fiktive Daten)

Voraussetzung: Node.js ≥ 22.13 (eingebautes SQLite).

```bash
npm run install:all
npm run build
cd backend
DATA_MODE=mock DB_PATH=./data/dev.sqlite COOKIE_SECURE=false \
ADMIN_EMAIL=admin@example.com ADMIN_PASSWORD='<eigenes Passwort, mind. 12 Zeichen>' \
FRONTEND_DIR=../frontend/dist npm start
# → http://localhost:8080, Anmeldung mit ADMIN_EMAIL / ADMIN_PASSWORD
```

Im Mock-Modus sind alle Ligen, Teams, Buchmacher und Ergebnisse **fiktiv** und überall als MOCK markiert. Im Live-Modus werden Mock-Daten nie ausgeliefert.

Weitere Konten: Admin → Benutzer, oder `NEW_USER_PASSWORD='…' npm --prefix backend run user:create -- name@example.com user`.

## Live-Modus

`DATA_MODE=live` plus mindestens ein **freigegebener** Provider:

| Weg | Spielplan | Historie für Modelle | Quoten | Status |
|---|---|---|---|---|
| A: Highlightly PRO | Highlightly | Highlightly | Highlightly `/odds` | BLOCKED: Nutzungsrechte für Wettanalysen nicht geklärt |
| B: lizenzierte Alternative | The Odds API | CSV (football-data.co.uk) | The Odds API | IMPLEMENTED, TESTED (nachgebaute Antworten), NOT VERIFIED live |

Highlightly bleibt gesperrt, bis `HIGHLIGHTLY_BETTING_USE_CONFIRMED=true` gesetzt ist. Das sollst du erst tun, wenn Highlightly die Nutzung für Wettanalysen schriftlich bestätigt hat.

## Wie eine Empfehlung entsteht

1. **Discovery**: Spiele im Fenster jetzt + 5 min bis + 48 h. Priorisiert nach Datenlage, Quotenverfügbarkeit und Anstoß, nicht nach Bekanntheit. Wettbewerbe lassen sich auf eine Auswahl beschränken.
2. **Quoten**: Jeder Markt eines Buchmachers ist ein unveränderlicher Snapshot mit Herkunft. Geprüft werden Zuordnung, Vollständigkeit, gleiche Torlinie, Status, Frische und Marge.
3. **Modelle** (nur Daten vor dem Anstoß): Poisson-Stärke, Dixon-Coles, Elo mit geordnetem Logit, Poisson-Regression. Das Ensemble ist gleichgewichtet, bis ein Backtest validierte Gewichte liefert.
4. **Value**:
   - `p_Modell` ist die unabhängige Modellwahrscheinlichkeit.
   - `p_Markt` ist der faire Preis ohne den bewerteten Buchmacher.
   - `p_dec = w·p_Modell + (1−w)·p_Markt`, mit `w` = 0,35 (BALANCED, vorläufig) oder dem im Backtest validierten Gewicht.
   - `EV = p_dec × Quote − 1`. Qualifiziert ist nur, was EV ≥ 5 % **und** EV an der Untergrenze > 0 **und** ausreichende Datenqualität hat.
5. **Ranking** nach EV-Untergrenze × Qualität, höchstens eine Empfehlung je Spiel. Jede Empfehlung hat eine Gültigkeit (`valid_until`) und wird bei jedem Abruf neu geprüft.
6. **Auswertung**: Jede Empfehlung wird eingefroren und abgerechnet (Ergebnis, CLV, Brier, Log Loss, Kalibrierung, Drawdown).

Statusmeldungen in der Oberfläche: `STALE ODDS`, `INSUFFICIENT DATA`, `UNVALIDATED MODEL`, `MARKET SUSPENDED`, `NO QUALIFIED VALUE BETS`, `PROVIDER UNAVAILABLE`.

## Projektstruktur

```
backend/   Node 22 + TypeScript, keine Laufzeit-Abhängigkeiten (node:http, node:sqlite, node:crypto)
  src/api/apiQueue.ts         Credits, Budgets, Cache mit Abrufzeit, Dedupe, 429-Regel, persistente Sperren
  src/auth.ts                 Benutzer, Rollen, scrypt, Sessions, CSRF
  src/engines/freshness.ts    Frische-Regeln (eine Quelle der Wahrheit)
  src/engines/recommendation.ts  Lebenszyklus und Revalidierung
  src/engines/…               matching, odds, prediction/*, value, discovery, alerts, performance, backtest, analyst
  src/scheduler.ts            Heartbeat-Locks, Wiederaufnahme
  src/db/migrations/          001–006 (004–006 = v0.3.0, ergänzend)
  src/engines/linking.ts      Wettbewerbs-/Teamverknüpfung CSV ↔ The Odds API
  src/engines/diagnostic.ts   kontrollierter Diagnose-Sync
  src/engines/dataQuality.ts, validation.ts   historische Validierung
  src/subscriptions.ts        Tarife, Zahlungsprüfung, uPay-Schnittstelle (Test)
  test/                       121 Tests (node:test)
frontend/  React 19 + esbuild · Spanisch (Standard), Deutsch, Englisch
  src/ui.tsx                  UI-Kit (Design-System)
  src/pages/*                 Seiten
```

## Dokumente

[DEPLOYMENT.md](DEPLOYMENT.md) · [API_INTEGRATION.md](API_INTEGRATION.md) · [LIVE_API_TEST_REPORT.md](LIVE_API_TEST_REPORT.md) · [SUBSCRIPTION_SYSTEM.md](SUBSCRIPTION_SYSTEM.md) · [PAYMENT_INTEGRATION.md](PAYMENT_INTEGRATION.md) · [SECURITY_REVIEW.md](SECURITY_REVIEW.md) · [BASE44_INTEGRATION.md](BASE44_INTEGRATION.md) · [TEST_REPORT.md](TEST_REPORT.md) · [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md) · [FRONTEND_REDESIGN.md](FRONTEND_REDESIGN.md) · [CHANGELOG.md](CHANGELOG.md)
