# Tarifverwaltung (v0.3.0)

**Status:** IMPLEMENTED · TESTED (automatisierte Tests, Testmodus). Keine echten Zahlungen. Durchsetzung standardmäßig **aus**.

## Grundsätze

- **Rolle ≠ Tarif.**
  - Rollen (`user`, `admin`) regeln, was jemand verwalten darf. Sie bleiben unverändert.
  - Tarife (FREE, PRO, PREMIUM) regeln, welche Analysefunktionen ein Benutzer nutzen darf.
  - Admins haben unabhängig vom Tarif immer vollen Zugriff.
- **Keine unbeabsichtigte Sperre.**
  - Ohne `SUBSCRIPTIONS_ENFORCE=true` werden Berechtigungen nur berechnet und angezeigt. Alle bisherigen Funktionen bleiben für alle Benutzer frei (getestet).
  - Nach dem Update hat niemand automatisch einen Tarif. Alle gelten als FREE, aber ohne Einschränkung, solange die Durchsetzung aus ist.
- **Freischaltung nur nach verifiziertem Zahlungseingang** (siehe [PAYMENT_INTEGRATION.md](PAYMENT_INTEGRATION.md)).

## Tarife

| Tarif | Monat | Jahr | Top-Empfehlungen | EDGE ANALYST | Persönliche Meldungen | Eigener Mindest-EV |
|---|---|---|---|---|---|---|
| FREE | 0 Gs. | 0 Gs. | 1 | – | – | – |
| PRO | 79.000 Gs. | 790.000 Gs. | 5 | 20 / Tag | ja | – |
| PREMIUM | 139.000 Gs. | 1.200.000 Gs. | 5 | 100 / Tag | ja | ja |

Die Preise kommen aus deinem Auftrag. **Die Leistungsinhalte je Tarif sind ein Vorschlag von mir** und müssen vor dem Start festgelegt werden. Sie stehen als JSON in der Tabelle `plans.entitlements` und lassen sich dort ändern, ohne den Code anzufassen.

## Status eines Abos

| Status | Bedeutung |
|---|---|
| `PENDING` | bestellt, Zahlung offen. Keine erweiterten Rechte |
| `ACTIVE` | Zahlung verifiziert oder vom Admin begründet freigeschaltet, `started_at` bis `expires_at` |
| `CANCELLED` | gekündigt. Zugriff bleibt bis `expires_at` (Kündigung durch Admin: sofort) |
| `EXPIRED` | Laufzeit vorbei. Wird beim Lesen und im täglichen Cleanup gesetzt |

- **Laufzeit:** monatlich (+1 Kalendermonat, Monatsende korrekt: 31.01. → 28./29.02.) oder jährlich (+12 Monate).
- **Verlängerung:** Eine weitere verifizierte Zahlung verlängert ab dem Ablauf des laufenden Abos.

## Serverseitige Prüfung

- `SubscriptionService.entitlements(userId, role)` liefert den Tarif, den Status und die wirksamen Rechte.
- `require(...)` liefert HTTP **402**, wenn eine Funktion nicht enthalten ist. Das greift nur bei aktiver Durchsetzung.

Geprüft werden:

| Funktion | Regel bei aktiver Durchsetzung |
|---|---|
| `GET /api/recommendations` | höchstens `maxRecommendations`; die Antwort nennt die Zahl ausgeblendeter Empfehlungen |
| `POST /api/analyst` | Tageskontingent (`usage_counters`) |
| `PUT /api/settings` | Einschalten persönlicher Meldungen (`personalAlerts`) und eigener Mindest-EV (`customAlertMinEv`) |
| Zustellung persönlicher Meldungen | nur bei berechtigtem Tarif |

## Änderungsprotokoll

Die Tabelle `subscription_events` ist nur anhängend: Trigger verhindern UPDATE und DELETE.

- **Ereignisse:** `checkout`, `proof_submitted`, `payment_verified`, `payment_rejected`, `activated`, `granted`, `cancelled`, `expired`
- **Jeder Eintrag enthält:** betroffenen Benutzer, handelnde Person, Status vorher/nachher, Details
- **Anzeige:** Admin → Abonnements → Log

## Endpunkte

| Methode | Pfad | Zugriff |
|---|---|---|
| GET | `/api/plans` | öffentlich |
| GET | `/api/subscription` | eigener Benutzer |
| POST | `/api/subscription/checkout` `{planId, period, method}` | eigener Benutzer |
| POST | `/api/subscription/cancel` | eigener Benutzer |
| POST | `/api/payments/:id/proof` `{fileName, mime, dataBase64}` | nur eigene Zahlung (sonst 404) |
| GET | `/api/admin/subscriptions`, `/api/admin/payments`, `/api/admin/payments/:id/proof`, `/api/admin/subscription-events` | admin |
| POST | `/api/admin/payments/:id/verify`, `/api/admin/payments/:id/reject` | admin (nie die eigene Zahlung) |
| POST | `/api/admin/subscriptions/grant` `{userId, planId, months, reason}` | admin, Begründung Pflicht |
| POST | `/api/admin/subscriptions/:id/cancel` | admin |

## Einschalten

1. Leistungsinhalte in `plans.entitlements` festlegen.
2. `PAYMENT_BANK_ALIAS`, `PAYMENT_BANK_NAME` und `PAYMENT_ACCOUNT_HOLDER` setzen.
3. Bestehende Testkonten bei Bedarf per „Ohne Zahlung freischalten“ mit Begründung versorgen.
4. `SUBSCRIPTIONS_ENFORCE=true` setzen und neu starten.

Vorher die rechtlichen Punkte in [KNOWN_LIMITATIONS.md](KNOWN_LIMITATIONS.md#kommerzieller-start) klären.
