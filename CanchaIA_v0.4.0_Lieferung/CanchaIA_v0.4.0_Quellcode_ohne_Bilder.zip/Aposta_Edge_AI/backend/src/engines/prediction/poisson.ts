/**
 * Poisson- und Dixon-Coles-Grundlagen: Ergebnismatrix und Ableitung der Marktwahrscheinlichkeiten.
 */
export type Probs = { '1X2': { HOME: number; DRAW: number; AWAY: number }; OU: { OVER: number; UNDER: number; line: number }; BTTS: { YES: number; NO: number } };

export function poissonPmf(k: number, lambda: number): number {
  if (lambda <= 0) return k === 0 ? 1 : 0;
  let logF = 0;
  for (let i = 2; i <= k; i++) logF += Math.log(i);
  return Math.exp(-lambda + k * Math.log(lambda) - logF);
}

/** Dixon-Coles-Korrekturfaktor τ für niedrige Ergebnisse. */
export function dcTau(x: number, y: number, lh: number, la: number, rho: number): number {
  if (x === 0 && y === 0) return 1 - lh * la * rho;
  if (x === 0 && y === 1) return 1 + lh * rho;
  if (x === 1 && y === 0) return 1 + la * rho;
  if (x === 1 && y === 1) return 1 - rho;
  return 1;
}

/** Normalisierte Ergebnismatrix M[h][a]. rho = 0 → unabhängiges Poisson. */
export function scoreMatrix(lh: number, la: number, maxGoals = 10, rho = 0): number[][] {
  const ph = Array.from({ length: maxGoals + 1 }, (_, k) => poissonPmf(k, lh));
  const pa = Array.from({ length: maxGoals + 1 }, (_, k) => poissonPmf(k, la));
  const M: number[][] = [];
  let sum = 0;
  for (let h = 0; h <= maxGoals; h++) {
    M.push([]);
    for (let a = 0; a <= maxGoals; a++) {
      const v = Math.max(0, ph[h] * pa[a] * (rho ? dcTau(h, a, lh, la, rho) : 1));
      M[h].push(v); sum += v;
    }
  }
  for (const row of M) for (let a = 0; a < row.length; a++) row[a] /= sum;
  return M;
}

export function marketsFromMatrix(M: number[][], ouLine = 2.5): Probs {
  let H = 0, D = 0, A = 0, over = 0, btts = 0;
  for (let h = 0; h < M.length; h++) for (let a = 0; a < M[h].length; a++) {
    const p = M[h][a];
    if (h > a) H += p; else if (h === a) D += p; else A += p;
    if (h + a > ouLine) over += p;
    if (h > 0 && a > 0) btts += p;
  }
  return { '1X2': { HOME: H, DRAW: D, AWAY: A }, OU: { OVER: over, UNDER: 1 - over, line: ouLine }, BTTS: { YES: btts, NO: 1 - btts } };
}

export function probsFromLambdas(lh: number, la: number, rho = 0, ouLine = 2.5): Probs {
  return marketsFromMatrix(scoreMatrix(lh, la, 10, rho), ouLine);
}
