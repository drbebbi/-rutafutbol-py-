/**
 * Verknüpfung von Wettbewerben und Teams über Provider-Grenzen (v0.3.0).
 *
 * Problem (in v0.2.0 reproduzierbar): The Odds API liefert "Manchester United" in "soccer_epl", der CSV-Import
 * "Man United" in "div:E0". Ohne Verknüpfung entstehen zwei Wettbewerbe und zwei Teams; die Modelle finden für
 * Live-Spiele keine Historie (immer INSUFFICIENT DATA), und Ergebnisse aus der CSV landen nicht beim Live-Spiel.
 *
 * Regeln (konservativ – lieber nicht verknüpfen als falsch verknüpfen):
 *  - Wettbewerbe: nur feste, dokumentierte Zuordnungen (COMPETITION_LINKS) oder manuell durch einen Admin.
 *  - Teams: nur innerhalb desselben (verknüpften) Wettbewerbs, nur mit Teams, die für diesen Provider noch keinen Alias haben,
 *    Ähnlichkeit ≥ 0,85 nach Normalisierung und Abkürzungs-Erweiterung, und Abstand ≥ 0,10 zum zweitbesten Kandidaten.
 *  - Alles andere bleibt getrennt und erscheint in Admin → Missing Data (unlinked_team) zur manuellen Zuordnung.
 */
import { nameSimilarity, normName } from '../util/core.js';

/** Feste Wettbewerbs-Zuordnungen The Odds API ↔ football-data.co.uk (Sport-Keys laut https://the-odds-api.com/sports-odds-data/sports-apis.html). */
export const COMPETITION_LINKS: { provider: string; providerId: string }[][] = [
  [{ provider: 'theoddsapi', providerId: 'soccer_epl' }, { provider: 'football-data-csv', providerId: 'div:E0' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_efl_champ' }, { provider: 'football-data-csv', providerId: 'div:E1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_spain_la_liga' }, { provider: 'football-data-csv', providerId: 'div:SP1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_germany_bundesliga' }, { provider: 'football-data-csv', providerId: 'div:D1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_italy_serie_a' }, { provider: 'football-data-csv', providerId: 'div:I1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_france_ligue_one' }, { provider: 'football-data-csv', providerId: 'div:F1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_netherlands_eredivisie' }, { provider: 'football-data-csv', providerId: 'div:N1' }],
  [{ provider: 'theoddsapi', providerId: 'soccer_portugal_primeira_liga' }, { provider: 'football-data-csv', providerId: 'div:P1' }],
  // soccer_uefa_champs_league: keine CSV-Quelle bei football-data.co.uk → keine Historie, Modelle liefern INSUFFICIENT DATA
];

export function linkedCompetitionIds(provider: string, providerId: string): { provider: string; providerId: string }[] {
  const g = COMPETITION_LINKS.find(grp => grp.some(x => x.provider === provider && x.providerId === providerId));
  return g ? g.filter(x => !(x.provider === provider && x.providerId === providerId)) : [];
}

/**
 * Abkürzungen, die football-data.co.uk in Teamnamen verwendet (Phrase → ausgeschriebene Form).
 * Sie dienen nur als zusätzliche Schreibweise für den Ähnlichkeitsvergleich; die Eindeutigkeitsregel bleibt bestehen.
 */
const EXPANSIONS: [RegExp, string][] = [
  [/^man (united|utd)$/, 'manchester united'], [/^man city$/, 'manchester city'],
  [/^nott ?m forest$/, 'nottingham forest'], [/^wolves$/, 'wolverhampton wanderers'],
  [/^sheffield weds$/, 'sheffield wednesday'], [/^sheffield (utd|united)$/, 'sheffield united'],
  [/^west brom$/, 'west bromwich albion'], [/^qpr$/, 'queens park rangers'], [/^spurs$/, 'tottenham hotspur'],
  [/^ath madrid$/, 'atletico madrid'], [/^ath bilbao$/, 'athletic bilbao'], [/^sociedad$/, 'real sociedad'],
  [/^vallecano$/, 'rayo vallecano'], [/^espanol$/, 'espanyol'], [/^betis$/, 'real betis'], [/^celta$/, 'celta vigo'],
  [/^la coruna$/, 'deportivo la coruna'], [/^sp gijon$/, 'sporting gijon'],
  [/^m gladbach$/, 'borussia monchengladbach'], [/^ein frankfurt$/, 'eintracht frankfurt'],
  [/^(.*) utd$/, '$1 united'],
];

export function expandedNames(name: string): string[] {
  const n = normName(name);
  const out = new Set([n]);
  for (const [re, rep] of EXPANSIONS) if (re.test(n)) out.add(n.replace(re, rep));
  return [...out];
}

export function linkSimilarity(a: string, b: string): number {
  let best = 0;
  for (const x of expandedNames(a)) for (const y of expandedNames(b)) best = Math.max(best, nameSimilarity(x, y));
  return best;
}

export const LINK_MIN = 0.85, LINK_GAP = 0.10;

/** Wählt höchstens einen Kandidaten; null bei zu geringer Ähnlichkeit oder Mehrdeutigkeit. */
export function pickTeamLink<T extends { name: string }>(raw: string, candidates: T[]): { team: T; score: number } | { team: null; reason: string; best?: string; score?: number } {
  const scored = candidates.map(c => ({ c, s: linkSimilarity(raw, c.name) })).sort((x, y) => y.s - x.s);
  const [b1, b2] = scored;
  if (!b1 || b1.s < LINK_MIN) return { team: null, reason: 'kein ausreichend ähnliches Team', best: b1?.c.name, score: b1?.s };
  if (b2 && b2.s > b1.s - LINK_GAP) return { team: null, reason: `mehrdeutig (${b1.c.name} / ${b2.c.name})`, best: b1.c.name, score: b1.s };
  return { team: b1.c, score: b1.s };
}
