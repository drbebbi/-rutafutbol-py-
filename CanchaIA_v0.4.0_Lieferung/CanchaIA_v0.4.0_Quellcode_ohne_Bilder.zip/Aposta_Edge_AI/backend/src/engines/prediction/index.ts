/**
 * PredictionEngine: rechnet alle Modelle für ein Event, kombiniert sie und bewertet die Datenqualität.
 * Ergebnis wird mit Eingabe-Hash gespeichert (reproduzierbar, keine Doppel-Einträge).
 */
import type { Db } from '../../db/db.js';
import { json } from '../../db/db.js';
import { Repository } from '../repository.js';
import type { HistMatch } from './history.js';
import { countTeamGames } from './history.js';
import { buildElo, dixonColes, elo, featureModel, fitDixonColes, fitFeatureModel, poissonStrength, type DcFit, type EloState, type FeatureFit, type ModelOutput } from './models.js';
import { combine, type EnsembleResult, type Weights } from './ensemble.js';
import { nowIso, sha, stableStringify } from '../../util/core.js';
import type { MarketId } from '../../providers/types.js';

export const MODEL_VERSION_BASE = 'ensemble-1.0.0';

export interface DataQuality { score: number; status: 'good' | 'fair' | 'poor' | 'insufficient'; issues: string[]; homeGames: number; awayGames: number; leagueGames: number; lineups: string; xgCoverage: number }

export interface PredictionRecord {
  id: number; eventId: number; modelVersion: string; createdAt: string;
  ensemble: EnsembleResult; components: ModelOutput[]; dataQuality: DataQuality;
}

export interface ModelVersionForScope {
  id: string; weights: Weights | null; status: 'VALIDATED' | 'UNVALIDATED';
  /** Märkte, die für diesen Wettbewerb validiert sind */
  validatedMarkets: MarketId[];
  /** Märkte mit statistisch belegtem Mehrwert gegenüber dem Markt */
  marketEdgeMarkets: MarketId[];
  blendWeightByMarket: Partial<Record<MarketId, number>>;
}

interface LeagueFits { key: string; hist: HistMatch[]; dc: DcFit | null; elo: EloState; feat: FeatureFit | null }

/**
 * Datenqualität eines Spiels – reine Funktion, damit Live-Prognose und Backtest dieselbe Regel verwenden (v0.4.0).
 * Im Backtest sind historische Aufstellungen unbekannt: dort immer lineups = 'none' (konservativ).
 */
export function computeDataQuality(hist: HistMatch[], home: number, away: number, before: string, outputs: ModelOutput[], lineups: 'confirmed' | 'expected' | 'none'): DataQuality {
  const issues: string[] = [];
  const hg = countTeamGames(hist, home, before), ag = countTeamGames(hist, away, before);
  const recent = hist.filter(m => (m.home === home || m.away === home || m.home === away || m.away === away)).slice(-16);
  const xgCoverage = recent.length ? recent.filter(m => m.xgH != null).length / recent.length : 0;
  let score = 0;
  score += Math.min(30, Math.min(hg, ag) * 1.5);              // Teamhistorie bis 20 Spiele
  score += Math.min(20, hist.length / 15);                     // Ligadatenbasis bis 300 Spiele
  score += outputs.filter(o => o.available).length * 7.5;      // verfügbare Modelle (max 30)
  score += lineups === 'confirmed' ? 10 : lineups === 'expected' ? 5 : 0;
  score += xgCoverage * 10;
  if (Math.min(hg, ag) < 6) issues.push(`zu wenig Teamhistorie (Heim ${hg}, Gast ${ag} Spiele)`);
  if (!hist.length) issues.push('keine Historie für diesen Wettbewerb: keine Wahrscheinlichkeiten (Modelle anderer Wettbewerbe werden nicht übertragen)');
  else if (hist.length < 80) issues.push(`kleine Ligadatenbasis (${hist.length} Spiele)`);
  if (lineups === 'none') issues.push('keine Aufstellungen');
  if (xgCoverage === 0) issues.push('keine xG-Daten');
  for (const o of outputs) if (!o.available) issues.push(`${o.model}: ${o.reason}`);
  issues.push('Verletzungen/Sperren: keine Datenquelle angebunden');
  const status = Math.min(hg, ag) < 6 || !outputs.some(o => o.available) ? 'insufficient' : score >= 70 ? 'good' : score >= 50 ? 'fair' : 'poor';
  return { score: Math.round(score), status, issues, homeGames: hg, awayGames: ag, leagueGames: hist.length, lineups, xgCoverage };
}

/** Inhalts-Hash der Historie (alle Felder, die in die Modelle eingehen). */
export function histHash(hist: HistMatch[]): string {
  return sha(hist.map(m => `${m.eventId}|${m.kickoff}|${m.home}|${m.away}|${m.hg}|${m.ag}|${m.neutral ? 1 : 0}|${m.xgH ?? ''}|${m.xgA ?? ''}`).join(';'), 20);
}

export class PredictionEngine {
  private repo: Repository;
  private fits = new Map<number, LeagueFits>();
  constructor(private db: Db) { this.repo = new Repository(db); }

  /**
   * Modellversion für einen Wettbewerb (v0.4.0).
   * Vorher: neueste GLOBAL validierte Version für alle Wettbewerbe. Jetzt: nur eine Version mit VALIDATED-Eintrag für genau
   * diesen Wettbewerb (model_scope_validations); Gewichte nur für die dort validierten Märkte. Sonst Basisversion UNVALIDATED.
   * Versionen ohne Scope-Einträge (vor v0.4.0) werden live nicht mehr als validiert verwendet – Validierung neu ausführen.
   */
  currentModelVersion(competitionId?: number): ModelVersionForScope {
    if (competitionId != null) {
      const v = this.db.get<{ id: string; weights: string | null }>(`SELECT mv.id, mv.weights FROM model_scope_validations s JOIN model_versions mv ON mv.id = s.model_version_id
          WHERE s.competition_id = ? AND s.status = 'VALIDATED' ORDER BY mv.created_at DESC, s.id DESC LIMIT 1`, competitionId);
      if (v) {
        const scopes = this.db.all<{ market_id: MarketId; status: string; market_evidence: string; blend_weight: number | null }>(
          'SELECT market_id, status, market_evidence, blend_weight FROM model_scope_validations WHERE model_version_id = ? AND competition_id = ?', v.id, competitionId);
        const ok = scopes.filter(x => x.status === 'VALIDATED');
        const all = json.parse<Record<string, unknown> | null>(v.weights, null) ?? {};
        const weights: Weights = {};
        for (const x of ok) if (all[x.market_id]) weights[x.market_id] = all[x.market_id] as Record<string, number>;
        return { id: v.id, weights, status: 'VALIDATED', validatedMarkets: ok.map(x => x.market_id), marketEdgeMarkets: ok.filter(x => x.market_evidence === 'BETTER').map(x => x.market_id),
          blendWeightByMarket: Object.fromEntries(ok.filter(x => x.blend_weight != null).map(x => [x.market_id, x.blend_weight!])) };
      }
    }
    this.db.run(`INSERT OR IGNORE INTO model_versions (id, description, weights, validation_status) VALUES (?, ?, NULL, 'UNVALIDATED')`,
      MODEL_VERSION_BASE, 'Gleichgewichtetes Ensemble aus Poisson, Dixon-Coles, Elo und Merkmalsmodell (nicht validiert)');
    return { id: MODEL_VERSION_BASE, weights: null, status: 'UNVALIDATED', validatedMarkets: [], marketEdgeMarkets: [], blendWeightByMarket: {} };
  }

  /**
   * Liga-Fits einmal pro Datenstand berechnen.
   * v0.4.0: Cache-Schlüssel = Inhalts-Hash ALLER Modelleingaben (Spiel, Anstoß, Teams, Tore, neutraler Platz, xG) + Stunde.
   * Vorher nur Anzahl + letzte Event-ID + Stunde: korrigierte Ergebnisse oder xG-Werte wurden innerhalb derselben Stunde
   * nicht berücksichtigt und die gespeicherte Prognose wich von der zurückgegebenen ab (Regressionstest v040_p1).
   */
  leagueFits(competitionId: number, before: string): LeagueFits {
    const hist = this.repo.competitionHistory(competitionId, before);
    const key = `${hist.length}:${histHash(hist)}:${before.slice(0, 13)}`;
    const c = this.fits.get(competitionId);
    if (c && c.key === key) return c;
    const f: LeagueFits = { key, hist, dc: fitDixonColes(hist, before), elo: buildElo(hist, before), feat: fitFeatureModel(hist, before) };
    this.fits.set(competitionId, f);
    return f;
  }

  dataQuality(eventId: number, hist: HistMatch[], home: number, away: number, before: string, outputs: ModelOutput[]): DataQuality {
    return computeDataQuality(hist, home, away, before, outputs, this.repo.lineupStatus(eventId));
  }

  predictEvent(eventId: number, at: Date = new Date()): PredictionRecord | null {
    const ev = this.repo.event(eventId);
    if (!ev) return null;
    const before = new Date(Math.min(at.getTime(), new Date(ev.kickoff_utc).getTime())).toISOString();
    const lf = this.leagueFits(ev.competition_id, before);
    const neutral = !!ev.neutral_venue;
    const outputs = [
      poissonStrength(lf.hist, ev.home_team_id, ev.away_team_id, before, neutral),
      dixonColes(lf.dc, lf.hist, ev.home_team_id, ev.away_team_id, before, neutral),
      elo(lf.elo, ev.home_team_id, ev.away_team_id, neutral),
      featureModel(lf.feat, lf.hist, ev.home_team_id, ev.away_team_id, before, neutral),
    ];
    const mv = this.currentModelVersion(ev.competition_id);
    const dq = this.dataQuality(eventId, lf.hist, ev.home_team_id, ev.away_team_id, before, outputs);
    const ens = combine(outputs, mv.weights, Math.min(dq.homeGames, dq.awayGames));
    // v0.4.0: zusätzlich Gewichte und das Ergebnis selbst – gespeicherte und zurückgegebene Prognose sind damit immer identisch
    const inputsHash = sha(stableStringify({ mv: mv.id, w: mv.weights, lf: lf.key, ev: [ev.home_team_id, ev.away_team_id, ev.kickoff_utc, neutral], lu: dq.lineups,
      out: { p: ens.probs, sd: ens.sd, lh: ens.lambdaHome, la: ens.lambdaAway }, dq: [dq.score, dq.status] }), 24);
    const existing = this.db.get<{ id: number; created_at: string }>('SELECT id, created_at FROM predictions WHERE event_id = ? AND inputs_hash = ?', eventId, inputsHash);
    const createdAt = existing?.created_at ?? nowIso(at);
    const id = existing?.id ?? this.db.run(
      `INSERT INTO predictions (event_id, model_version, created_at, lambda_home, lambda_away, probs, components, uncertainty, data_quality, inputs_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      eventId, mv.id, createdAt, ens.lambdaHome, ens.lambdaAway, JSON.stringify(ens.probs), JSON.stringify(outputs), JSON.stringify({ sd: ens.sd, agreement: ens.agreement, modelsUsed: ens.modelsUsed }), JSON.stringify(dq), inputsHash).lastInsertRowid;
    this.db.run('UPDATE events SET analysis_status = ?, last_analysed_at = ? WHERE id = ?', dq.status === 'insufficient' ? 'insufficient_data' : 'analysed', nowIso(at), eventId);
    return { id, eventId, modelVersion: mv.id, createdAt, ensemble: ens, components: outputs, dataQuality: dq };
  }

  clearCache(): void { this.fits.clear(); }
}
