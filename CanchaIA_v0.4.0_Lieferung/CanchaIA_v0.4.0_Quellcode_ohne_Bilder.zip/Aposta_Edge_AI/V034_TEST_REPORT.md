# CanchaIA v0.3.4 – Technischer Implementierungs- und Testbericht

Stand: 13. Oktober 2026 (Paraguay), Überprüfung in isolierter Arbeitsumgebung.

## Ergebnis

**Implementierung und lokale Tests abgeschlossen. Live-Provider-Anbindung NICHT verifiziert.**

| Prüfung | Ergebnis |
|---|---|
| Eingesetzte Grundlage | User-ZIP `CanchaIA_v0.3.3_TheOddsAPI_Integrated(1).zip` |
| Backend TypeScript-Build | PASS |
| Backend gesamt | 139 PASS, 0 FAIL |
| The Odds API Integration (isolierte Fake-Fetcher) | 18 PASS |
| Weitere alte Tests, angepasst | PASS |
| Frontend-Produktionsbuild | NICHT erneut durchgeführt (esbuild/React-Dependencies fehlen lokal) |
| Echter GET /v4/sports | NICHT AUSGEFÜHRT, Key nicht als Environment-Secret gesetzt |
| Echter GET /v4/sports/soccer_uefa_champs_league/events | NICHT AUSGEFÜHRT |
| Echter kostenpflichtiger GET /odds | NICHT AUSGEFÜHRT |
| Provider HTTP-Status und Restcredits | Unbekannt – keine Live-API-Antwort |
| Echte gespeicherte UEFA-Spiele / Quoten | Nicht verifiziert (keine produktive Datenbank verfügbar) |
| Deployment | NICHT DURCHGEFÜHRT |
| Tatsächlicher Credit-Verbrauch dieses Auftrags | 0 (keine Provider-Aufrufe) |

## Technische Änderungen

1. `backend/src/providers/theOddsApi.ts`: Kostenlose Fixtures über `/events`, Zeitfenster und Eingabevalidierung, Trennung von späteren Quoten-Aufrufen, kein Odds-Abruf bei leerer Auswahl, nur Events des laufenden Durchgangs verarbeiten.
2. `backend/src/engines/oddsApiStatus.ts`: Zugangsfehler nach bestandenem Test anhand persistenter Request-IDs verfolgen; spätere erfolgreiche Gratis-Anfragen geben kostenpflichtige Abrufe nicht versehentlich frei.
3. `backend/src/config.ts`: Korrigierter Hinweis auf Fixtures-Quelle.
4. `backend/test/v033_odds_api.test.ts`: Zwei neue Tests für kostenlose Events und angepasste Integrations-Simulationen.
5. `backend/test/v030_api_pilot.test.ts`, `backend/test/lifecycle.test.ts`: Alte Tests an /events + /odds-Trennung angepasst.
6. Dokumentation/Versionen: `THE_ODDS_API_INTEGRATION.md`, `CHANGELOG.md`, `README.md`, `package.json`, `backend/package.json`, `frontend/package.json`.

Die bestehende React-Admin-Oberfläche kann weiterhin die gespeicherten API-Header `x-requests-remaining`, `x-requests-used`, `x-requests-last` anzeigen. Diese Werte sind in diesem Bericht nicht mit echten Anbieterantworten belegt.

## Kosten und Live-Test-Prozedur

Offizielle Dokumentation: https://the-odds-api.com/liveapi/guides/v4/

- `GET /v4/sports` = 0 Credits, aber benötigt API-Key.
- `GET /v4/sports/soccer_uefa_champs_league/events` = 0 Credits, liefert ausschließlich Events und Anstoßzeiten.
- `GET /v4/sports/soccer_uefa_champs_league/odds?regions=eu&markets=h2h,totals` = nach Dokumentation 2 Credits bei zwei angeforderten Standardmärkten und einer Region. Die tatsächlichen Kosten melden die Response-Header.
- `GET /v4/sports/{sport}/events/{eventId}/odds?markets=btts` nur falls angeboten und bewusst aktiviert.

Die Produktionsumgebung muss den **neu generierten** Key als serverseitiges Secret unter exakt `THE_ODDS_API_KEY` haben. Da der bisherige Schlüssel im Chat offengelegt wurde, **vorher beim Anbieter rotieren**.

### Wo Secret eintragen

**Docker Compose / eigener Server**: In der Deployment-Umgebung im Projektverzeichnis neben `docker-compose.yml` eine nicht ins Git eingecheckte `.env`-Datei auf Basis von `.env.example` anlegen. Dort `THE_ODDS_API_KEY` mit dem rotierten Schlüssel hinterlegen (`chmod 600 .env`) oder ein Plattform-/Docker-Secret einsetzen. Die Beispiel-Datei im ZIP enthält bewusst keinen Schlüssel.

**Hosting-Plattform / Backend-Service**: In den serverseitigen Environment Variables / Secrets des Node-Backend-Dienstes `THE_ODDS_API_KEY` setzen (nicht im Frontend). Diese ZIP-Datei konfiguriert keinen Remote-Service automatisch.

### Einmalige sichere Konfiguration

```dotenv
DATA_MODE=live
THE_ODDS_API_KEY=            # nur lokal/hosting-seitig befüllen
THE_ODDS_API_BASE_URL=https://api.the-odds-api.com
THE_ODDS_API_SPORT_KEYS=soccer_uefa_champs_league
THE_ODDS_API_REGIONS=eu
THE_ODDS_API_MONTHLY_BUDGET=500
THE_ODDS_API_DAILY_BUDGET=16
THE_ODDS_API_INCLUDE_BTTS=false
THE_ODDS_API_RESULTS=false
SCHEDULER_ENABLED=false
```

Vor Aufrufen die echten Restcredits und vertraglichen Kosten kontrollieren. Auto-Sync zunächst deaktiviert lassen.

### Testreihenfolge im deployten Backend

1. Als Admin im Adminbereich **„Verbindung testen (kostenlos)“** ausführen; HTTP 200, Sport-Key aktiv und echte Header belegen.
2. Den angezeigten `x-requests-remaining`-Wert sowie interne Tages-/Monatsbudgets prüfen.
3. Erst dann gezielt **einen** kontrollierten Quoten-Sync durchführen (Admin > Diagnose), mit einem einzelnen Sport, Region `eu`, Märkten `h2h,totals`, BTTS und Results vorerst deaktiviert.
4. Im Adminbereich Datenquelle `LIVE`, Anzahl importierter Spiele, Buchmacher und gültige Quoten-Snapshots prüfen. Bei fehlenden Events keinen Erfolg erfinden.
5. Automatisierung nur nach gesonderter Freigabe einschalten. Kein bestätigter EV ohne historische Modelldaten.

## Grenzen

- Alle 139 Tests basieren auf lokalen Programmausführungen; Provider-Netzantworten sind **simuliert**.
- Kein API-Key in dieser Runtime; keine verifizierte Live-Antwort, keine verfügbaren Restcredits.
- Frontend-Source wurde unverändert übernommen; der Frontend-Build erfordert `npm --prefix frontend install` und `npm --prefix frontend run build` in der Deployment-Umgebung.
- Historische Wettbewerbsdaten und validierte Ensemble-Wahrscheinlichkeiten bleiben ein gesonderter Blocker für bestätigte Value-Bets.
