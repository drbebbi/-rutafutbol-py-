/**
 * Discovery Engine + stündlicher Analyse-Durchlauf (SyncService).
 * Ablauf je Durchlauf:
 *  1 Zeit bestimmen · 2 Spiele der nächsten 48 h · 3/4 neue vs. bekannte Spiele · 5 Ergebnisse/Live-Status
 *  6 Priorisieren (Datenlage, Anstoßzeit – nicht Bekanntheit) · 7 Historie/Statistik/Aufstellungen
 *  8 Quoten abrufen, validieren, speichern · 9 Prognosen & EV · 10 alte Signale deaktivieren, neue speichern
 *  11 Top-5-Bericht · 12 Benachrichtigungen
 */
import type { Db } from '../db/db.js';
import type { Config } from '../config.js';
import type { FootballDataProvider, OddsProvider, ProviderFixture, ProviderRunReport } from '../providers/types.js';
import { ProviderBlockedError, QuotaExhaustedError } from '../providers/types.js';
import { EventMatchingEngine } from './matching.js';
import { Repository } from './repository.js';
import { OddsStore, validateQuote } from './odds.js';
import { PredictionEngine } from './prediction/index.js';
import { ValueBettingEngine, type StoredSignal } from './value.js';
import { RecommendationEngine, type RecommendationView } from './recommendation.js';
import { AlertEngine, dispatchPersonal } from './alerts.js';
import { SubscriptionService } from '../subscriptions.js';
import { Settlement } from './performance.js';
import { addHours, addMinutes, nowIso } from '../util/core.js';
import { logError, noteMissing } from '../util/log.js';
import { json } from '../db/db.js';

export interface ProviderSet {
  fixtures: FootballDataProvider[];
  odds: OddsProvider[];
  isMock: boolean;
  blocked: { provider: string; reason: string }[];
}

export interface SyncSummary {
  runId: number; status: string; window: { from: string; to: string };
  fixturesFound: number; newEvents: number; prioritized: number; historyLoaded: number; oddsSnapshots: number; oddsRejected: number;
  predictions: number; signals: Record<string, number>; recommendations: number; alerts: number; settled: number; errors: string[];
  /** Hinweise ohne Fehlercharakter (z. B. optionaler Provider nicht konfiguriert). */
  notices: string[];
  /** Marktabdeckung je Quoten-Provider (angefragt / geliefert / Grund für "nicht verfügbar"). */
  providerReports: ProviderRunReport[];
  /** Ausgeschlossen, weil begonnen/abgelaufen (nie als Pre-Match verarbeitet). */
  startedExcluded: number;
  pilot: boolean;
  /** v0.3.0: zugestellte persönliche Meldungen (In-App) */
  personalAlerts: number;
}

export class SyncService {
  private match: EventMatchingEngine; private repo: Repository; private odds: OddsStore;
  private pred: PredictionEngine; private value: ValueBettingEngine; private rec: RecommendationEngine; private alerts: AlertEngine; private settle: Settlement;

  constructor(private db: Db, private cfg: Config, private providers: ProviderSet, alerts?: AlertEngine) {
    this.match = new EventMatchingEngine(db); this.repo = new Repository(db); this.odds = new OddsStore(db);
    this.pred = new PredictionEngine(db); this.value = new ValueBettingEngine(db); this.rec = new RecommendationEngine(db, { oddsMaxAgeMinutes: cfg.analysis.oddsMaxAgeMinutes, allowMock: providers.isMock });
    this.alerts = alerts ?? new AlertEngine(db, cfg); this.settle = new Settlement(db);
  }

  private step(runId: number, name: string, data: unknown) {
    const r = this.db.get<{ steps: string }>('SELECT steps FROM sync_runs WHERE id = ?', runId)!;
    const steps = json.parse<Record<string, unknown>>(r.steps, {});
    steps[name] = { at: nowIso(), ...(typeof data === 'object' ? data as object : { value: data }) };
    this.db.run('UPDATE sync_runs SET steps = ? WHERE id = ?', JSON.stringify(steps), runId);
  }

  async run(now: Date = new Date(), opts: { maxFixtures?: number; job?: 'hourly_sync' | 'controlled_sync' } = {}): Promise<SyncSummary> {
    const runId = this.db.run("INSERT INTO sync_runs (job, started_at, status) VALUES (?, ?, 'running')", opts.job ?? 'hourly_sync', nowIso(now)).lastInsertRowid;
    const from = addMinutes(now, 5), to = addHours(now, this.cfg.analysis.horizonHours);
    const sum: SyncSummary = { runId, status: 'done', window: { from: from.toISOString(), to: to.toISOString() }, fixturesFound: 0, newEvents: 0, prioritized: 0, historyLoaded: 0, oddsSnapshots: 0, oddsRejected: 0, predictions: 0, signals: {}, recommendations: 0, alerts: 0, settled: 0, errors: [], notices: [], providerReports: [], startedExcluded: 0, pilot: this.cfg.pilot.enabled, personalAlerts: 0 };
    const guard = async (name: string, fn: () => Promise<void>) => {
      try { await fn(); }
      catch (e) {
        if (e instanceof QuotaExhaustedError) { sum.status = 'paused_quota'; sum.errors.push(`${name}: ${e.message}`); }
        else if (e instanceof ProviderBlockedError) { sum.errors.push(`${name}: ${e.message}`); }
        else { sum.errors.push(`${name}: ${(e as Error).message}`); logError(this.db, `sync.${name}`, e); }
      }
    };
    // Gesperrte/fehlende Provider: nur dann ein Fehler, wenn gar kein Fixture-Provider nutzbar ist; sonst ein Hinweis
    for (const b of this.providers.blocked) (this.providers.fixtures.length ? sum.notices : sum.errors).push(`${b.provider} gesperrt: ${b.reason}`);

    // 1 Abgelaufene Signale (begonnen oder Quote über die Gültigkeit hinaus)
    this.value.expire(now);
    for (const op of this.providers.odds) op.setNow?.(now);

    // 2 Spiele finden
    const fixtures: ProviderFixture[] = [];
    for (const p of this.providers.fixtures) await guard(`discover.${p.name}`, async () => { fixtures.push(...await p.upcomingFixtures(from, to)); });
    sum.fixturesFound = fixtures.length;
    for (const f of fixtures) {
      // Begonnene oder abgelaufene Spiele nie als Pre-Match anlegen/aktualisieren (Provider-Fenster kann ungenau sein)
      if (!(Date.parse(f.kickoffUtc) > now.getTime()) && f.status === 'scheduled') { sum.startedExcluded++; continue; }
      const known = this.match.existing(f.provider, f.providerEventId);
      this.match.upsertFixture(f);
      if (!known) sum.newEvents++;
    }
    this.step(runId, 'discover', { found: fixtures.length, new: sum.newEvents });

    // 3 Ergebnisse und Status vergangener Spiele aktualisieren
    await guard('results', async () => { await this.refreshResults(now); });
    const st = this.settle.run(now); sum.settled = st.settled;

    // 4 Priorisieren: begonnene Spiele ausgeschlossen; Reihenfolge nach Datenlage und Anstoß
    const candidates = this.db.all<{ id: number; competition_id: number; kickoff_utc: string; hist: number; last_analysed_at: string | null; has_odds: number }>(
      `SELECT e.id, e.competition_id, e.kickoff_utc, e.last_analysed_at,
              (SELECT COUNT(*) FROM events h WHERE h.competition_id = e.competition_id AND h.status = 'finished') AS hist,
              EXISTS (SELECT 1 FROM odds_snapshots o WHERE o.event_id = e.id) AS has_odds
         FROM events e WHERE e.status = 'scheduled' AND e.kickoff_utc > ? AND e.kickoff_utc <= ? ${this.providers.isMock ? '' : 'AND e.is_mock = 0'}`, from.toISOString(), to.toISOString());
    const sys = this.systemSettings();
    const maxF = Math.min(opts.maxFixtures ?? sys.max_fixtures_per_run ?? 60, this.cfg.pilot.enabled ? this.cfg.pilot.maxEventsPerRun : Infinity);
    const enabled = json.parse<number[]>(sys.enabled_competitions, []);
    const prioritized = candidates
      .filter(c => !enabled.length || enabled.includes(c.competition_id))
      // Priorität: Datenlage (Historie, Quotenverfügbarkeit) und Anstoß – nicht Bekanntheit; zuletzt analysierte etwas nach hinten
      .map(c => ({ ...c, prio: Math.min(1, c.hist / 200) * 2 + (c.has_odds ? 0.5 : 0)
        + (1 - (new Date(c.kickoff_utc).getTime() - now.getTime()) / (this.cfg.analysis.horizonHours * 3_600_000))
        - (c.last_analysed_at && now.getTime() - new Date(c.last_analysed_at).getTime() < 30 * 60_000 ? 0.3 : 0) }))
      .sort((a, b) => b.prio - a.prio).slice(0, maxF);
    sum.prioritized = prioritized.length;
    this.step(runId, 'prioritize', { candidates: candidates.length, prioritized: prioritized.length });

    // 5 Historie je Wettbewerb nachladen (Cache im Provider-Layer verhindert doppelte Abrufe)
    const comps = [...new Set(prioritized.map(p => p.competition_id))];
    for (const compId of comps) await guard(`history.${compId}`, async () => { sum.historyLoaded += await this.loadHistory(compId); });
    this.step(runId, 'history', { competitions: comps.length, matches: sum.historyLoaded });

    // 6 Aufstellungen kurz vor Anstoß, Statistiken (xG) der letzten Spiele
    for (const p of prioritized) {
      if (new Date(p.kickoff_utc).getTime() - now.getTime() <= 3 * 3_600_000) await guard(`lineups.${p.id}`, async () => { await this.loadLineups(p.id); });
    }
    await guard('stats', async () => { await this.loadRecentStats(prioritized.map(p => p.id), 40); });

    // 7 Quoten
    const pfx = this.fixturesForEvents(prioritized.map(p => p.id));
    for (const op of this.providers.odds) await guard(`odds.${op.name}`, async () => {
      const quotes = await op.oddsForFixtures(pfx.filter(f => op.sharesEventIdsWith === null || f.provider === op.sharesEventIdsWith || op.name === 'theoddsapi'));
      for (const q of quotes) {
        let mapping = this.match.existing(q.provider, q.providerEventId);
        if (!mapping && q.rawHome && q.rawAway && q.kickoffUtc) mapping = this.match.matchRaw(q.provider, q.providerEventId, q.rawHome, q.rawAway, q.kickoffUtc);
        if (!mapping) continue;
        const ev = this.repo.event(mapping.eventId); if (!ev) continue;
        const errs = validateQuote(q, { now, maxAgeMinutes: this.cfg.analysis.oddsMaxAgeMinutes, kickoffUtc: ev.kickoff_utc, mappingConfidence: mapping.confidence });
        this.odds.save(ev.id, q, errs, !!ev.is_mock);
        if (errs.length) sum.oddsRejected++; else sum.oddsSnapshots++;
      }
    });
    for (const op of this.providers.odds) { const r = op.lastRunReport?.(); if (r) sum.providerReports.push(r); }
    this.step(runId, 'odds', { valid: sum.oddsSnapshots, rejected: sum.oddsRejected, markets: sum.providerReports.map(r => ({ provider: r.provider, markets: r.markets, skipped: r.skippedSportKeys })) });

    // 8 Prognosen und Value
    const settings = sys;
    const changes: { prev: StoredSignal | null; next: StoredSignal }[] = [];
    for (const p of prioritized) {
      try {
        const pr = this.pred.predictEvent(p.id, now);
        if (!pr) continue;
        sum.predictions++;
        const ev = this.repo.event(p.id)!;
        const mv = this.pred.currentModelVersion(ev.competition_id);
        const sigs = this.value.evaluate(pr, {
          minEv: settings.min_ev ?? this.cfg.analysis.minEv, strategy: (settings.strategy as Config['analysis']['strategy']) ?? this.cfg.analysis.strategy,
          oddsMaxAgeMinutes: this.cfg.analysis.oddsMaxAgeMinutes, preferredBookmakers: json.parse<string[]>(settings.preferred_bookmakers, []),
          // v0.4.0: Validierung je Wettbewerb × Markt (nie die neueste global validierte Version für ungeprüfte Wettbewerbe)
          modelValidated: mv.validatedMarkets.length > 0, validatedMarkets: mv.validatedMarkets, marketEdgeMarkets: mv.marketEdgeMarkets, isMock: !!ev.is_mock,
          // Reihenfolge: manuell gesetztes Gewicht > im Backtest für diesen Markt validiertes Gewicht > Default je Risikoprofil
          modelWeight: settings.model_weight ?? null, modelWeightByMarket: settings.model_weight != null ? undefined : mv.blendWeightByMarket,
        }, now);
        for (const s of sigs) sum.signals[s.status] = (sum.signals[s.status] ?? 0) + 1;
        changes.push(...this.value.persist(sigs, now));
      } catch (e) { sum.errors.push(`predict.${p.id}: ${(e as Error).message}`); logError(this.db, 'sync.predict', e); }
    }
    this.step(runId, 'predict', { predictions: sum.predictions, signals: sum.signals });

    // 9 Bericht und Benachrichtigungen
    const top = this.rec.build(this.cfg.analysis.maxRecommendations, runId, now, this.providers.isMock);
    sum.recommendations = top.length;
    await guard('alerts', async () => { sum.alerts = await this.alerts.dispatch(this.alerts.draft(changes)); });
    // v0.3.0: persönliche Meldungen (gleiche Event-Erkennung, eigene Filter je Benutzer, nur In-App)
    await guard('alerts.personal', async () => {
      const subs = new SubscriptionService(this.db, this.cfg, () => now);
      sum.personalAlerts = dispatchPersonal(this.db, this.alerts.detect(changes), (uid, role) => subs.entitlements(uid, role).effective, sys.min_ev ?? this.cfg.analysis.minEv);
    });
    if (sum.status === 'done' && sum.errors.length && !sum.predictions) sum.status = 'failed';
    this.db.run('UPDATE sync_runs SET status = ?, finished_at = ?, summary = ?, error = ? WHERE id = ?', sum.status, nowIso(), JSON.stringify(sum), sum.errors.join('\n') || null, runId);
    return sum;
  }

  /**
   * v0.4.0: reine Spielsuche (Discovery) ohne kostenpflichtige Abrufe – eigener Scheduler-Job mit eigenem Intervall.
   * The Odds API: nur GET /v4/sports und /v4/sports/{sport}/events (laut offizieller V4-Doku kostenlos).
   * Keine Quoten, keine Ergebnisse (/scores kostet Credits), keine Prognosen.
   */
  async discover(now: Date = new Date()): Promise<{ fixturesFound: number; newEvents: number; startedExcluded: number; errors: string[]; window: { from: string; to: string } }> {
    const from = addMinutes(now, 5), to = addHours(now, this.cfg.analysis.horizonHours);
    const out = { fixturesFound: 0, newEvents: 0, startedExcluded: 0, errors: [] as string[], window: { from: from.toISOString(), to: to.toISOString() } };
    for (const op of this.providers.odds) op.setNow?.(now);
    for (const p of this.providers.fixtures) {
      try {
        const fx = await p.upcomingFixtures(from, to);
        out.fixturesFound += fx.length;
        for (const f of fx) {
          if (!(Date.parse(f.kickoffUtc) > now.getTime()) && f.status === 'scheduled') { out.startedExcluded++; continue; }
          const known = this.match.existing(f.provider, f.providerEventId);
          this.match.upsertFixture(f);
          if (!known) out.newEvents++;
        }
      } catch (e) {
        out.errors.push(`discover.${p.name}: ${(e as Error).message}`);
        if (!(e instanceof QuotaExhaustedError) && !(e instanceof ProviderBlockedError)) logError(this.db, `discover.${p.name}`, e);
      }
    }
    return out;
  }

  systemSettings() {
    return this.db.get<{ min_ev: number; strategy: string; preferred_bookmakers: string; model_weight: number | null; enabled_competitions: string; max_fixtures_per_run: number }>(
      'SELECT min_ev, strategy, preferred_bookmakers, model_weight, enabled_competitions, max_fixtures_per_run FROM system_settings WHERE id = 1')!;
  }

  /** Aktuell gültige Empfehlungen – jede wird beim Lesen gegen die Uhr `now` neu geprüft. */
  report(now: Date = new Date()): { recommendations: RecommendationView[]; message: string | null } {
    const recs = this.rec.current(now);
    return { recommendations: recs, message: recs.length ? null : 'NO QUALIFIED VALUE BETS' };
  }

  private fixturesForEvents(ids: number[]): ProviderFixture[] {
    if (!ids.length) return [];
    const rows = this.db.all<{ provider: string; provider_event_id: string; raw_home: string; raw_away: string; raw_competition: string; kickoff_utc: string; event_id: number }>(
      `SELECT pe.*, m.event_id FROM provider_events pe JOIN event_mappings m ON m.provider = pe.provider AND m.provider_event_id = pe.provider_event_id WHERE m.event_id IN (${ids.map(() => '?').join(',')})`, ...ids);
    return rows.map(r => ({ provider: r.provider, providerEventId: r.provider_event_id, competition: { providerId: '', name: r.raw_competition }, home: { providerId: '', name: r.raw_home }, away: { providerId: '', name: r.raw_away }, kickoffUtc: r.kickoff_utc, status: 'scheduled' as const }));
  }

  private providerFor(name: string): FootballDataProvider | undefined { return this.providers.fixtures.find(p => p.name === name); }

  private async loadHistory(competitionId: number): Promise<number> {
    const aliases = this.db.all<{ provider: string; provider_id: string }>('SELECT provider, provider_id FROM competition_aliases WHERE competition_id = ?', competitionId);
    let n = 0;
    for (const a of aliases) {
      const p = this.providerFor(a.provider);
      if (!p || !p.capabilities.history) continue;
      const seasonRow = this.db.get<{ season: string | null }>('SELECT season FROM events WHERE competition_id = ? AND season IS NOT NULL ORDER BY kickoff_utc DESC LIMIT 1', competitionId);
      const seasons = seasonRow?.season && /^\d{4}$/.test(seasonRow.season) ? [seasonRow.season, String(Number(seasonRow.season) - 1)] : [null];
      for (const s of seasons) {
        const rows = await p.historicalResults({ providerId: a.provider_id, name: '' }, s);
        this.db.tx(() => { for (const f of rows) { this.match.upsertFixture(f); n++; } });
      }
    }
    const count = this.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM events WHERE competition_id = ? AND status = 'finished'", competitionId)!.n;
    if (count < 80) noteMissing(this.db, 'missing_history', `competition:${competitionId}`, `${count} abgeschlossene Spiele`);
    return n;
  }

  private async refreshResults(now: Date): Promise<void> {
    const stale = this.db.all<{ id: number; competition_id: number; kickoff_utc: string }>(`SELECT id, competition_id, kickoff_utc FROM events WHERE status IN ('scheduled','live','unknown') AND kickoff_utc < ? ORDER BY kickoff_utc DESC LIMIT 30`, addHours(now, -2).toISOString());
    // v0.4.0: Provider mit gebündeltem Ergebnisabruf (The Odds API): ein Abruf je Wettbewerb statt je Spiel
    const done = new Set<number>();
    for (const p of this.providers.fixtures) {
      if (!p.resultsFor) continue;
      const items = stale.flatMap(e => this.db.all<{ provider_event_id: string }>('SELECT provider_event_id FROM event_mappings WHERE event_id = ? AND provider = ?', e.id, p.name).map(m => ({
        eventId: e.id, providerEventId: m.provider_event_id, kickoffUtc: e.kickoff_utc,
        competitionProviderId: this.db.get<{ provider_id: string }>('SELECT provider_id FROM competition_aliases WHERE competition_id = ? AND provider = ? LIMIT 1', e.competition_id, p.name)?.provider_id ?? null })));
      if (!items.length) continue;
      for (const f of await p.resultsFor(items)) {
        const it = items.find(i => i.providerEventId === f.providerEventId);
        this.match.upsertFixture(f);
        if (it && f.status === 'finished') done.add(it.eventId);
      }
    }
    for (const e of stale) {
      if (done.has(e.id)) continue;
      const maps = this.db.all<{ provider: string; provider_event_id: string }>('SELECT provider, provider_event_id FROM event_mappings WHERE event_id = ?', e.id);
      for (const m of maps) {
        const p = this.providerFor(m.provider);
        if (!p?.matchDetails || p.resultsFor) continue;
        const f = await p.matchDetails(m.provider_event_id);
        if (f) { this.match.upsertFixture(f); break; }
      }
    }
  }

  private async loadLineups(eventId: number): Promise<void> {
    for (const m of this.db.all<{ provider: string; provider_event_id: string }>('SELECT provider, provider_event_id FROM event_mappings WHERE event_id = ?', eventId)) {
      const p = this.providerFor(m.provider);
      if (!p?.lineups || !p.capabilities.lineups) continue;
      const ls = await p.lineups(m.provider_event_id);
      if (ls.length) { this.repo.saveLineups(eventId, p.name, ls, pid => this.repo.findTeamByProviderId(p.name, pid)); return; }
    }
    noteMissing(this.db, 'missing_lineup', `event:${eventId}`);
  }

  /** xG/Schüsse der letzten Spiele beider Teams nachladen (begrenzt, um Kontingent zu schonen). */
  private async loadRecentStats(eventIds: number[], cap: number): Promise<void> {
    if (!eventIds.length) return;
    const need = this.db.all<{ id: number }>(
      `SELECT DISTINCT h.id FROM events h JOIN events e ON (h.home_team_id IN (e.home_team_id, e.away_team_id) OR h.away_team_id IN (e.home_team_id, e.away_team_id))
        WHERE e.id IN (${eventIds.map(() => '?').join(',')}) AND h.status = 'finished'
          AND NOT EXISTS (SELECT 1 FROM match_statistics s WHERE s.event_id = h.id)
          AND NOT EXISTS (SELECT 1 FROM missing_data md WHERE md.kind = 'missing_stats' AND md.ref = 'event:' || h.id)
        ORDER BY h.kickoff_utc DESC LIMIT ?`, ...eventIds, cap);
    for (const h of need) {
      let saved = 0;
      for (const m of this.db.all<{ provider: string; provider_event_id: string }>('SELECT provider, provider_event_id FROM event_mappings WHERE event_id = ?', h.id)) {
        const p = this.providerFor(m.provider);
        if (!p?.matchStatistics || !p.capabilities.matchStats) continue;
        saved += this.repo.saveMatchStats(h.id, p.name, await p.matchStatistics(m.provider_event_id), pid => this.repo.findTeamByProviderId(p.name, pid));
        if (saved) break;
      }
      if (!saved) noteMissing(this.db, 'missing_stats', `event:${h.id}`);
    }
  }
}
