import { test } from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { ANCHOR, mockApp, TEST_ADMIN, TEST_SERVICE_TOKEN } from './helpers.js';
import { createServer } from '../src/server.js';
import { Scheduler } from '../src/scheduler.js';
import { AuthService, hashPassword, verifyPassword } from '../src/auth.js';

async function start(over: Record<string, string> = {}, clockHours = 0) {
  const app = await mockApp(over);
  await app.sync.run(ANCHOR);
  let clock = new Date(ANCHOR.getTime() + clockHours * 3_600_000);
  const server = createServer(app, new Scheduler(app), { clock: () => clock });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  const raw = (p: string, init: RequestInit = {}) => fetch(base + p, { ...init, headers: { 'content-type': 'application/json', ...(init.headers ?? {}) } });
  async function login(email = TEST_ADMIN.email, password = TEST_ADMIN.password) {
    const r = await raw('/api/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) });
    const cookie = (r.headers.get('set-cookie') ?? '').split(';')[0];
    const body = await r.json() as any;
    const call = (p: string, init: RequestInit = {}) => raw(p, { ...init, headers: { cookie, 'x-csrf-token': body.csrfToken, ...(init.headers ?? {}) } });
    return { status: r.status, setCookie: r.headers.get('set-cookie') ?? '', cookie, csrf: body.csrfToken, body, call };
  }
  return { app, server, raw, login, setClock: (d: Date) => { clock = d; } };
}

test('Passwort-Hashing: scrypt, Salt, zeitkonstante Prüfung', () => {
  const h = hashPassword('richtig-passwort-1');
  assert.match(h, /^scrypt\$32768\$8\$1\$/);
  assert.notEqual(h, hashPassword('richtig-passwort-1'), 'zufälliges Salt');
  assert.equal(verifyPassword('richtig-passwort-1', h), true);
  assert.equal(verifyPassword('falsch-passwort-1', h), false);
});

test('Login: Session-Cookie HttpOnly/SameSite=Strict/Secure, kein Token im Body', async () => {
  const { server, login } = await start();
  try {
    const s = await login();
    assert.equal(s.status, 200);
    assert.match(s.setCookie, /HttpOnly/); assert.match(s.setCookie, /SameSite=Strict/); assert.match(s.setCookie, /Secure/);
    assert.equal(s.body.user.role, 'admin');
    assert.ok(s.csrf && !JSON.stringify(s.body).includes(s.cookie.split('=')[1]), 'Session-Token nie im JSON');
    assert.equal((await s.call('/api/auth/me')).status, 200);
  } finally { server.close(); }
});

test('Nicht autorisiert: ohne Anmeldung 401, falsches Passwort 401, Sperre nach 5 Fehlversuchen', async () => {
  const { server, raw, login, app } = await start();
  try {
    assert.equal((await raw('/api/health')).status, 200);
    for (const p of ['/api/status', '/api/recommendations', '/api/matches', '/api/admin/diagnostics']) assert.equal((await raw(p)).status, 401, p);
    for (let i = 0; i < 5; i++) assert.equal((await login(TEST_ADMIN.email, 'falsch-passwort-' + i)).status, 401);
    assert.equal((await login()).status, 423, 'nach 5 Fehlversuchen gesperrt, auch mit richtigem Passwort');
    assert.ok(app.db.get("SELECT 1 FROM security_events WHERE kind = 'locked'"));
  } finally { server.close(); }
});

test('Rollen: normaler Benutzer hat keinen Zugriff auf Admin-Endpunkte', async () => {
  const { server, app, login } = await start();
  try {
    new AuthService(app.db, null).createUser('user@example.test', 'user-passwort-12345', 'user');
    const u = await login('user@example.test', 'user-passwort-12345');
    assert.equal(u.body.user.role, 'user');
    assert.equal((await u.call('/api/recommendations')).status, 200);
    for (const [m, p] of [['GET', '/api/admin/diagnostics'], ['POST', '/api/admin/jobs/hourly_sync/run'], ['POST', '/api/admin/import-csv'], ['GET', '/api/admin/users'], ['PUT', '/api/system-settings'], ['POST', '/api/backtest/run']] as const)
      assert.equal((await u.call(p, { method: m, body: m === 'GET' ? undefined : '{}' })).status, 403, `${m} ${p}`);
    assert.ok(app.db.get("SELECT 1 FROM security_events WHERE kind = 'forbidden'"));
    // eigene Einstellungen erlaubt
    assert.equal((await u.call('/api/settings', { method: 'PUT', body: JSON.stringify({ language: 'de' }) })).status, 200);
  } finally { server.close(); }
});

test('CSRF und Origin: schreibende Anfragen ohne Token oder von fremder Seite werden abgelehnt', async () => {
  const { server, login } = await start();
  try {
    const s = await login();
    const noCsrf = await s.call('/api/settings', { method: 'PUT', body: '{}', headers: { 'x-csrf-token': '' } });
    assert.equal(noCsrf.status, 403);
    const foreign = await s.call('/api/settings', { method: 'PUT', body: '{}', headers: { origin: 'https://boese.example' } });
    assert.equal(foreign.status, 403);
    assert.equal(foreign.headers.get('access-control-allow-origin'), null, 'kein CORS');
    assert.equal((await s.call('/api/settings', { method: 'PUT', body: '{}', headers: { origin: 'null' } })).status, 403, 'Origin "null" → 403, nicht 500');
    assert.equal((await s.call('/api/settings', { method: 'PUT', body: '{}' })).status, 200);
  } finally { server.close(); }
});

test('Logout beendet die Session', async () => {
  const { server, login } = await start();
  try {
    const s = await login();
    assert.equal((await s.call('/api/auth/logout', { method: 'POST' })).status, 200);
    assert.equal((await s.call('/api/status')).status, 401);
  } finally { server.close(); }
});

test('Service-Token (Server-zu-Server): Admin-Zugriff per Bearer, ohne CSRF; zu kurzes Token wird ignoriert', async () => {
  const { server, raw } = await start();
  try {
    assert.equal((await raw('/api/admin/diagnostics', { headers: { authorization: `Bearer ${TEST_SERVICE_TOKEN}` } })).status, 200);
    assert.equal((await raw('/api/admin/diagnostics', { headers: { authorization: 'Bearer falsch' } })).status, 401);
  } finally { server.close(); }
  const s2 = await start({ ADMIN_TOKEN: 'kurz' });
  try { assert.equal((await s2.raw('/api/status', { headers: { authorization: 'Bearer kurz' } })).status, 401); } finally { s2.server.close(); }
});

test('Secrets: Antworten enthalten keine API-Schlüssel', async () => {
  const { server, login } = await start({ HIGHLIGHTLY_API_KEY: 'geheim-hl-schluessel-xyz', THE_ODDS_API_KEY: 'geheim-odds-schluessel-xyz', ANTHROPIC_API_KEY: 'geheim-llm-xyz' });
  try {
    const s = await login();
    for (const p of ['/api/status', '/api/admin/diagnostics', '/api/system-settings', '/api/recommendations']) {
      const t = await (await s.call(p)).text();
      assert.ok(!/geheim-/.test(t), `${p} enthält ein Secret`);
    }
  } finally { server.close(); }
});

test('API-Revalidierung: 6 h später ohne Sync liefert /api/recommendations keine Empfehlung', async () => {
  const { server, login, setClock } = await start();
  try {
    const s = await login();
    const a = await (await s.call('/api/recommendations')).json() as any;
    assert.ok(a.recommendations.length >= 1);
    assert.ok(a.recommendations.every((r: any) => r.oddsAgeMinutes != null && r.validUntil && r.provider));
    setClock(new Date(ANCHOR.getTime() + 6 * 3_600_000));
    const s2 = await login(); // Session-Leerlauf > 2 h → neu anmelden
    const b = await (await s2.call('/api/recommendations')).json() as any;
    assert.equal(b.recommendations.length, 0);
    assert.equal(b.message, 'NO QUALIFIED VALUE BETS');
    assert.ok(b.recentlyDeactivated.length >= 1);
  } finally { server.close(); }
});

test('Live-Modus: Mock-Daten in der DB werden nie ausgeliefert; fehlende API-Schlüssel werden gemeldet', async () => {
  const mock = await mockApp();
  await mock.sync.run(ANCHOR);
  const { buildApp } = await import('../src/app.js');
  const { testConfig } = await import('./helpers.js');
  const liveApp = buildApp(testConfig({ DATA_MODE: 'live' }), { db: mock.db, mockAnchor: ANCHOR });
  const sum = await liveApp.sync.run(ANCHOR);
  assert.equal(sum.fixturesFound, 0, 'ohne freigegebene Provider keine Spiele');
  assert.ok(sum.errors.some(e => /HIGHLIGHTLY_API_KEY fehlt/.test(e)));
  const server = createServer(liveApp, null, { clock: () => ANCHOR });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  try {
    const h = { authorization: `Bearer ${TEST_SERVICE_TOKEN}` };
    const recs = await (await fetch(base + '/api/recommendations', { headers: h })).json() as any;
    assert.equal(recs.recommendations.length, 0);
    assert.equal((await (await fetch(base + '/api/matches', { headers: h })).json() as any[]).length, 0, 'keine Mock-Spiele im Live-Modus');
    assert.equal((await (await fetch(base + '/api/signals', { headers: h })).json() as any[]).length, 0);
    const st = await (await fetch(base + '/api/status', { headers: h })).json() as any;
    assert.ok(st.configIssues.some((i: string) => /HIGHLIGHTLY_API_KEY/.test(i)));
    assert.equal(st.isMock, false);
  } finally { server.close(); }
});

test('Eingabevalidierung und Rate-Limit', async () => {
  const { server, login } = await start();
  try {
    const s = await login();
    assert.equal((await s.call('/api/matches/abc')).status, 400);
    assert.equal((await s.call('/api/matches/999999')).status, 404);
    assert.equal((await s.call('/api/system-settings', { method: 'PUT', body: JSON.stringify({ min_ev: 5 }) })).status, 400);
    assert.equal((await s.call('/api/settings', { method: 'PUT', body: JSON.stringify({ timezone: 'Mars/Base' }) })).status, 400);
    assert.equal((await s.call('/api/analyst', { method: 'POST', body: JSON.stringify({ question: '' }) })).status, 400);
    assert.equal((await s.call('/api/admin/users', { method: 'POST', body: JSON.stringify({ email: 'x@example.test', password: 'kurz' }) })).status, 400, 'Passwortregel');
    const codes: number[] = [];
    for (let i = 0; i < 15; i++) codes.push((await s.call('/api/analyst', { method: 'POST', body: JSON.stringify({ question: 'top', lang: 'es' }) })).status);
    assert.ok(codes.includes(429));
    const trav = await s.call('/..%2f..%2fetc%2fpasswd');
    assert.ok(!(await trav.text()).includes('root:'));
  } finally { server.close(); }
});

test('Admin: Benutzerverwaltung, letzter Admin kann sich nicht entmachten', async () => {
  const { server, login } = await start();
  try {
    const s = await login();
    const created = await (await s.call('/api/admin/users', { method: 'POST', body: JSON.stringify({ email: 'neu@example.test', password: 'neu-passwort-12345', role: 'user' }) })).json() as any;
    assert.equal(created.role, 'user');
    const me = await (await s.call('/api/auth/me')).json() as any;
    assert.equal((await s.call(`/api/admin/users/${me.user.id}`, { method: 'PUT', body: JSON.stringify({ role: 'user' }) })).status, 409);
  } finally { server.close(); }
});

test('Passwort-Reset (Betreiber): neues Passwort gilt, altes nicht, bestehende Sessions enden', async () => {
  const { app, server, login } = await start();
  try {
    const s = await login();
    assert.equal((await s.call('/api/auth/me')).status, 200);
    new AuthService(app.db, null).setPassword(TEST_ADMIN.email, 'ganz-neues-passwort-42');
    assert.equal((await s.call('/api/auth/me')).status, 401, 'alte Session beendet');
    assert.equal((await login()).status, 401, 'altes Passwort ungültig');
    assert.equal((await login(TEST_ADMIN.email, 'ganz-neues-passwort-42')).status, 200);
    assert.ok(app.db.get("SELECT 1 FROM security_events WHERE kind = 'password_reset'"));
  } finally { server.close(); }
});

test('Lese-Token: nur GET mit Benutzerrechten, kein Admin, kein Schreiben', async () => {
  const READ = 'r'.repeat(40);
  const { server, raw } = await start({ READ_TOKEN: READ });
  try {
    const h = { authorization: `Bearer ${READ}` };
    assert.equal((await raw('/api/recommendations', { headers: h })).status, 200);
    assert.equal((await raw('/api/admin/users', { headers: h })).status, 403, 'kein Admin');
    assert.equal((await raw('/api/settings', { method: 'PUT', body: '{}', headers: h })).status, 403, 'kein Schreiben');
    assert.equal((await raw('/api/recommendations', { headers: { authorization: 'Bearer ' + 'x'.repeat(40) } })).status, 401);
  } finally { server.close(); }
});
