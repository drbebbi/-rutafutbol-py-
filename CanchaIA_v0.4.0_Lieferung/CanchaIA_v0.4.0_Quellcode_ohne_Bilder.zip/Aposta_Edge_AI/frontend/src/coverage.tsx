/**
 * v0.4.0 – Admin-Karte „Datengrundlage je Wettbewerb“. Alle Werte aus GET /api/admin/coverage (Backend, DB).
 * Nichts wird hier berechnet oder ergänzt. Wettbewerbe ohne geeignete Historie zeigen INSUFFICIENT DATA mit Erklärung.
 */
import React from 'react';
import { localTime } from './api';
import { useApp } from './components';
import { useLoad } from './hooks';
import { Card, ErrorBox, Loading, StatusBadge } from './ui';

const L = {
  es: { title: 'Base de datos por competición', sub: 'Calendario · cuotas · historial · equipos · modelos · validación por mercado', comp: 'Competición', fixtures: 'Calendario', odds: 'Cuotas', history: 'Historial', teams: 'Equipos', models: 'Modelos', validation: 'Validación', yes: 'sí', no: 'no', next: 'próximo', none: 'Sin competiciones con datos.' },
  de: { title: 'Datengrundlage je Wettbewerb', sub: 'Spielplan · Quoten · Historie · Teams · Modelle · Validierung je Markt', comp: 'Wettbewerb', fixtures: 'Spielplan', odds: 'Quoten', history: 'Historie', teams: 'Teams', models: 'Modelle', validation: 'Validierung', yes: 'ja', no: 'nein', next: 'nächstes', none: 'Keine Wettbewerbe mit Daten.' },
  en: { title: 'Data foundation per competition', sub: 'Fixtures · odds · history · teams · models · validation per market', comp: 'Competition', fixtures: 'Fixtures', odds: 'Odds', history: 'History', teams: 'Teams', models: 'Models', validation: 'Validation', yes: 'yes', no: 'no', next: 'next', none: 'No competitions with data.' },
};

export function CoveragePanel() {
  const { lang, tz } = useApp();
  const T = L[lang] ?? L.es;
  const c = useLoad<any>('/api/admin/coverage');
  if (c.err) return <Card title={T.title}><ErrorBox e={c.err} onRetry={c.reload} /></Card>;
  if (!c.data) return <Card title={T.title}><Loading lines={4} /></Card>;
  const yn = (b: boolean) => b ? T.yes : T.no;
  return (
    <Card id="coverage" title={T.title} sub={T.sub}>
      {!c.data.competitions.length ? <p className="small t-2">{T.none}</p> : <div className="stack lg">
        {c.data.competitions.map((x: any) => (
          <div key={x.competitionId ?? x.sportKey} className="stack" style={{ gap: 6, borderTop: '1px solid var(--line, rgba(127,127,127,.2))', paddingTop: 8 }}>
            <div className="row-flex between" style={{ flexWrap: 'wrap', gap: 6 }}>
              <strong>{x.name}{x.isMock ? ' (MOCK)' : ''}</strong>
              <StatusBadge s={x.status} />
            </div>
            <dl className="kv small">
              <dt>{T.fixtures}</dt><dd>{yn(x.fixtures.available)} · {x.fixtures.upcoming}{x.fixtures.nextKickoff ? ` · ${T.next} ${localTime(x.fixtures.nextKickoff, tz, lang)}` : ''}</dd>
              <dt>{T.odds}</dt><dd>{yn(x.odds.available)} · 1X2 {x.odds.byMarket['1X2']} · OU {x.odds.byMarket.OU} · BTTS {x.odds.byMarket.BTTS}</dd>
              <dt>{T.history}</dt><dd>{yn(x.history.available)} · {x.history.finishedMatches} ({x.history.seasons}) {x.history.sources.join(', ')}</dd>
              <dt>{T.teams}</dt><dd>{yn(x.teams.unique)}{x.teams.unlinked ? ` · unlinked ${x.teams.unlinked}` : ''}{x.teams.withoutHistory.length ? ` · ${x.teams.withoutHistory.length} ≠ hist.` : ''}</dd>
              <dt>{T.models}</dt><dd>{yn(x.models.computable)} · {x.models.eventsComputable}/{x.models.eventsTotal}{x.models.reason ? ` · ${x.models.reason}` : ''}</dd>
              <dt>{T.validation}</dt><dd className="row-flex" style={{ flexWrap: 'wrap', gap: 4 }}>{(['1X2', 'OU', 'BTTS'] as const).map(m => <StatusBadge key={m} s={x.validation[m].status} label={`${m}: ${x.validation[m].status}${x.validation[m].marketEvidence === 'BETTER' ? ' +' : ''}`} />)}</dd>
            </dl>
            {x.explanation.length ? <ul className="xs t-2" style={{ margin: 0, paddingLeft: 18 }}>{x.explanation.map((e: string) => <li key={e}>{e}</li>)}</ul> : null}
          </div>))}
        <p className="xs t-3">{c.data.notes.join(' ')}</p>
      </div>}
    </Card>
  );
}
