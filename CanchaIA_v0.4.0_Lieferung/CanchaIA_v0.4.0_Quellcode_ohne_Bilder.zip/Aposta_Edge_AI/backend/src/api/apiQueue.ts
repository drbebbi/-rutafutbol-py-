/**
 * Zentrale API-Queue für alle externen Provider.
 * - Tages- UND Monatsbudget je Provider in Credits (persistiert in api_requests.cost)
 * - Tatsächliche Kosten aus Antwort-Header (z. B. The Odds API `x-requests-last`), sonst geschätzte Kosten
 * - Datenbank-Cache mit TTL; Cache-Treffer liefern den ORIGINAL-Abrufzeitpunkt (fetchedAt), nie "jetzt"
 * - Deduplizierung gleichzeitiger identischer Anfragen
 * - Begrenzte Parallelität und Mindestabstand
 * - 429: höchstens EINE Wiederholung und nur bei Retry-After ≤ 60 s; sonst persistente Sperre
 * - Persistente Sperren (provider_health.paused_until) überleben Neustarts
 * - 401/403: Provider gesperrt, keine Wiederholung · 5xx/Netzwerk: exponentielles Backoff (max. 3)
 * - v0.3.3: noRetry (Verbindungstest: genau ein Versuch), vom Anbieter gemeldete Restcredits stoppen kostenpflichtige
 *   Abrufe VOR dem Senden, x-requests-used wird gespeichert, Antwortstatus und Kontingent-Header gehen an den Aufrufer.
 */
import type { Db } from '../db/db.js';
import { dayUtc, nowIso, sha, sleep } from '../util/core.js';
import { log, redact } from '../util/log.js';
import { QuotaExhaustedError } from '../providers/types.js';

export type Fetcher = (url: string, init: { headers: Record<string, string>; signal?: AbortSignal }) =>
  Promise<{ status: number; headers: { get(name: string): string | null }; text(): Promise<string> }>;

export interface ProviderBudget {
  provider: string;
  /** Maximale Credits pro UTC-Tag (eigenes Sicherheitsbudget unter dem Vertragslimit). */
  dailyBudget: number;
  /** Maximale Credits pro UTC-Monat (optional). */
  monthlyBudget?: number;
  maxConcurrent: number;
  minIntervalMs: number;
  /** Header mit Restkontingent, falls der Provider einen liefert. */
  remainingHeader?: string;
  limitHeader?: string;
  /** Header mit den tatsächlichen Kosten der letzten Anfrage (Credits). */
  costHeader?: string;
  /** Header mit den laut Anbieter bereits verbrauchten Credits (The Odds API: x-requests-used). */
  usedHeader?: string;
}

export interface RequestOptions {
  provider: string;
  url: string;              // vollständige URL inkl. Query
  headers?: Record<string, string>;
  /** Cache-Schlüssel ohne Secrets; Default: URL ohne Query-Parameter mit Schlüsselnamen. */
  cacheKey?: string;
  ttlSeconds: number;       // 0 = kein Cache
  priority?: number;        // höher = früher
  maxRetries?: number;
  /** Geschätzte Kosten in Credits (Default 1); wird durch costHeader ersetzt, wenn vorhanden. */
  cost?: number;
  /**
   * Dynamische Cache-Regel (v0.3.0): höchstes zulässiges Alter eines Cache-Eintrags in Sekunden, berechnet aus dem
   * gecachten Inhalt (z. B. nächster Anstoß). null = nur TTL. Ein zu alter Eintrag wird verworfen und neu abgerufen.
   */
  maxCacheAgeSeconds?: (data: any, now: Date) => number | null;
  /** Zweck der Anfrage fürs Abrufprotokoll (z. B. "odds h2h,totals soccer_epl"). Keine Secrets. */
  note?: string;
  /** Genau ein Versuch: keine Wiederholung bei 5xx, Netzwerkfehler oder 429 (z. B. Verbindungstest). */
  noRetry?: boolean;
}

/** Antwort mit Herkunft. fetchedAt = Zeitpunkt des echten HTTP-Abrufs (bei Cache-Treffern der ursprüngliche). */
export interface ApiResult<T> {
  data: T; fetchedAt: string; fromCache: boolean;
  /** Nur bei echtem Abruf: HTTP-Status und Kontingent-Header dieser Antwort (null = Header fehlte). */
  status?: number; quota?: { remaining: number | null; used: number | null; last: number | null };
}

export class ApiError extends Error {
  constructor(public provider: string, public status: number, message: string) { super(message); }
}

interface Pending { opts: RequestOptions; resolve: (v: ApiResult<unknown>) => void; reject: (e: unknown) => void; priority: number; seq: number }

export class ApiQueue {
  private budgets = new Map<string, ProviderBudget>();
  private inflight = new Map<string, Promise<ApiResult<unknown>>>();
  private queue: Pending[] = [];
  private running = new Map<string, number>();
  private lastStart = new Map<string, number>();
  private seq = 0;

  constructor(private db: Db, private fetcher: Fetcher = defaultFetcher, private now: () => Date = () => new Date(), private backoffScale = 1) {}

  register(b: ProviderBudget): void { this.budgets.set(b.provider, b); }
  /** Uhr der Queue (in Tests simuliert); Provider nutzen sie, wenn kein Lauf-Zeitpunkt gesetzt ist. */
  currentTime(): Date { return this.now(); }

  /** Verbrauchte Credits heute (ohne Cache-Treffer). */
  usedToday(provider: string): number {
    const r = this.db.get<{ n: number | null }>('SELECT SUM(cost) AS n FROM api_requests WHERE provider = ? AND day = ? AND from_cache = 0', provider, dayUtc(this.now()));
    return r?.n ?? 0;
  }
  usedThisMonth(provider: string): number {
    const r = this.db.get<{ n: number | null }>('SELECT SUM(cost) AS n FROM api_requests WHERE provider = ? AND month = ? AND from_cache = 0', provider, dayUtc(this.now()).slice(0, 7));
    return r?.n ?? 0;
  }

  /** Persistente Sperre lesen (überlebt Neustarts). */
  pausedUntil(provider: string): { until: number; reason: string | null } | null {
    const r = this.db.get<{ paused_until: string | null; pause_reason: string | null }>('SELECT paused_until, pause_reason FROM provider_health WHERE provider = ?', provider);
    if (!r?.paused_until) return null;
    const until = Date.parse(r.paused_until);
    return until > this.now().getTime() ? { until, reason: r.pause_reason } : null;
  }
  pause(provider: string, untilMs: number, reason: string): void {
    const t = nowIso(this.now());
    this.db.run(`INSERT INTO provider_health (provider, status, paused_until, pause_reason, last_error_at, last_error, updated_at) VALUES (?, 'paused', ?, ?, ?, ?, ?)
                 ON CONFLICT(provider) DO UPDATE SET status = 'paused', paused_until = excluded.paused_until, pause_reason = excluded.pause_reason,
                   last_error_at = excluded.last_error_at, last_error = excluded.last_error, updated_at = excluded.updated_at`,
      provider, new Date(untilMs).toISOString(), reason, t, reason, t);
    log.warn(`${provider}: pausiert bis ${new Date(untilMs).toISOString()} (${reason})`);
  }
  resume(provider: string): void {
    this.db.run("UPDATE provider_health SET paused_until = NULL, pause_reason = NULL, status = CASE WHEN status = 'paused' THEN 'ok' ELSE status END WHERE provider = ?", provider);
  }

  budgetStatus(provider: string) {
    const b = this.budgets.get(provider);
    const used = this.usedToday(provider), usedMonth = this.usedThisMonth(provider);
    const h = this.db.get<{ quota_remaining: number | null; quota_limit: number | null; quota_used: number | null; credits_used_last: number | null }>('SELECT quota_remaining, quota_limit, quota_used, credits_used_last FROM provider_health WHERE provider = ?', provider);
    const p = this.pausedUntil(provider);
    return {
      provider, used, budget: b?.dailyBudget ?? 0, remainingBudget: Math.max(0, (b?.dailyBudget ?? 0) - used),
      usedMonth, monthlyBudget: b?.monthlyBudget ?? null,
      providerRemaining: h?.quota_remaining ?? null, providerLimit: h?.quota_limit ?? null, providerUsed: h?.quota_used ?? null, lastCost: h?.credits_used_last ?? null,
      paused: !!p, pausedUntil: p ? new Date(p.until).toISOString() : null, pauseReason: p?.reason ?? null,
    };
  }

  private cacheKeyOf(o: RequestOptions): string {
    if (o.cacheKey) return o.provider + ':' + o.cacheKey;
    const u = new URL(o.url);
    for (const k of [...u.searchParams.keys()]) if (/key|token|secret/i.test(k)) u.searchParams.delete(k);
    return o.provider + ':' + u.pathname + '?' + [...u.searchParams.entries()].sort().map(([k, v]) => `${k}=${v}`).join('&');
  }

  /** JSON-Anfrage über die Queue (nur Daten). */
  async request<T = unknown>(o: RequestOptions): Promise<T> { return (await this.requestMeta<T>(o)).data; }

  /** JSON-Anfrage mit Herkunft (fetchedAt, fromCache). Für alles, was zeitkritisch ist (Quoten). */
  requestMeta<T = unknown>(o: RequestOptions): Promise<ApiResult<T>> {
    const key = this.cacheKeyOf(o);
    if (o.ttlSeconds > 0) {
      const c = this.db.get<{ body: string; expires_at: string; fetched_at: string }>('SELECT body, expires_at, fetched_at FROM api_cache WHERE cache_key = ?', key);
      if (c && c.expires_at > nowIso(this.now())) {
        const data = JSON.parse(c.body) as T;
        const ageS = (this.now().getTime() - Date.parse(c.fetched_at)) / 1000;
        const maxAge = o.maxCacheAgeSeconds ? o.maxCacheAgeSeconds(data, this.now()) : null;
        if (maxAge == null || ageS <= maxAge) {
          this.recordRequest(o.provider, o.url, 200, 0, 0, true, o.note ?? null);
          return Promise.resolve({ data, fetchedAt: c.fetched_at, fromCache: true });
        }
        o = { ...o, note: `${o.note ? o.note + ' · ' : ''}Cache verworfen: ${Math.round(ageS)} s alt, erlaubt ${maxAge} s` };
      }
    }
    const existing = this.inflight.get(key);
    if (existing) return existing as Promise<ApiResult<T>>;
    const p = new Promise<ApiResult<unknown>>((resolve, reject) => {
      this.queue.push({ opts: o, resolve, reject, priority: o.priority ?? 0, seq: this.seq++ });
      this.queue.sort((a, b) => b.priority - a.priority || a.seq - b.seq);
      this.pump();
    }).finally(() => this.inflight.delete(key));
    this.inflight.set(key, p);
    return p as Promise<ApiResult<T>>;
  }

  private pump(): void {
    for (let i = 0; i < this.queue.length; i++) {
      const item = this.queue[i];
      const b = this.budgets.get(item.opts.provider);
      if (!b) { this.queue.splice(i, 1); i--; item.reject(new Error(`Provider ${item.opts.provider} nicht registriert`)); continue; }
      const running = this.running.get(b.provider) ?? 0;
      if (running >= b.maxConcurrent) continue;
      const wait = (this.lastStart.get(b.provider) ?? 0) + b.minIntervalMs - Date.now();
      if (wait > 0) { setTimeout(() => this.pump(), wait); continue; }
      this.queue.splice(i, 1); i--;
      this.running.set(b.provider, running + 1);
      this.lastStart.set(b.provider, Date.now());
      this.execute(item.opts, b).then(item.resolve, item.reject).finally(() => {
        this.running.set(b.provider, (this.running.get(b.provider) ?? 1) - 1);
        this.pump();
      });
    }
  }

  private async execute(o: RequestOptions, b: ProviderBudget): Promise<ApiResult<unknown>> {
    const maxRetries = o.noRetry ? 0 : (o.maxRetries ?? 3);
    const estCost = o.cost ?? 1;
    let retried429 = false;
    for (let attempt = 0; ; attempt++) {
      const p = this.pausedUntil(b.provider);
      if (p) throw new QuotaExhaustedError(b.provider, `${b.provider}: gesperrt bis ${new Date(p.until).toISOString()} (${p.reason ?? 'Kontingent'})`);
      if (this.usedToday(b.provider) + estCost > b.dailyBudget) {
        this.setHealth(b.provider, 'degraded', 'Tagesbudget erreicht');
        throw new QuotaExhaustedError(b.provider, `${b.provider}: Tagesbudget von ${b.dailyBudget} Credits erreicht`);
      }
      if (b.monthlyBudget != null && this.usedThisMonth(b.provider) + estCost > b.monthlyBudget) {
        this.setHealth(b.provider, 'degraded', 'Monatsbudget erreicht');
        throw new QuotaExhaustedError(b.provider, `${b.provider}: Monatsbudget von ${b.monthlyBudget} Credits erreicht`);
      }
      // Vom Anbieter gemeldete Restcredits (aus diesem UTC-Monat) reichen nicht: gar nicht erst senden
      const prov = estCost > 0 ? this.providerReportedRemaining(b.provider) : null;
      if (prov != null && prov < estCost) {
        this.setHealth(b.provider, 'degraded', `laut Anbieter nur ${prov} Credits übrig`);
        throw new QuotaExhaustedError(b.provider, `${b.provider}: laut Anbieter nur noch ${prov} Credits übrig, Abruf kostet ${estCost}`);
      }
      const started = Date.now();
      const fetchedAt = nowIso(this.now());
      let status = 0;
      try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 20_000);
        const res = await this.fetcher(o.url, { headers: { accept: 'application/json', ...(o.headers ?? {}) }, signal: ctrl.signal });
        clearTimeout(timer);
        status = res.status;
        const hdrCost = b.costHeader ? Number(res.headers.get(b.costHeader)) : NaN;
        const cost = Number.isFinite(hdrCost) && hdrCost >= 0 && res.headers.get(b.costHeader!) !== null ? hdrCost : (status >= 200 && status < 300 ? estCost : (status === 429 ? 0 : estCost));
        this.recordRequest(b.provider, o.url, status, Date.now() - started, cost, false, o.note ?? null);
        this.syncQuotaHeaders(b, res.headers, cost);
        const body = await res.text();
        if (status >= 200 && status < 300) {
          const data = body ? JSON.parse(body) : null;
          if (o.ttlSeconds > 0) {
            const key = this.cacheKeyOf(o);
            const exp = new Date(this.now().getTime() + o.ttlSeconds * 1000).toISOString();
            this.db.run(`INSERT INTO api_cache (cache_key, provider, body, fetched_at, expires_at) VALUES (?, ?, ?, ?, ?)
                         ON CONFLICT(cache_key) DO UPDATE SET body = excluded.body, fetched_at = excluded.fetched_at, expires_at = excluded.expires_at`,
              key, b.provider, body, fetchedAt, exp);
          }
          this.setHealth(b.provider, 'ok', null);
          return { data, fetchedAt, fromCache: false, status, quota: quotaOf(b, res.headers) };
        }
        if (status === 429) {
          const ra = retryAfterMs(res.headers.get('retry-after'));
          const remHeader = res.headers.get(b.remainingHeader ?? 'x-ratelimit-requests-remaining');
          const exhausted = remHeader !== null && Number(remHeader) <= 0;
          // Nur eine einzige, kurze Wiederholung; alles andere führt zu einer persistenten Sperre
          if (!o.noRetry && !exhausted && !retried429 && ra != null && ra <= 60_000) { retried429 = true; await sleep(ra * this.backoffScale); continue; }
          const until = exhausted ? nextUtcDay(this.now()) : this.now().getTime() + (ra ?? 15 * 60_000);
          this.pause(b.provider, until, exhausted ? 'Kontingent laut Provider aufgebraucht (429)' : 'Rate-Limit (429)');
          throw new QuotaExhaustedError(b.provider, `${b.provider}: Rate-Limit erreicht, gesperrt bis ${new Date(until).toISOString()}`);
        }
        if (status >= 500 && attempt < maxRetries) { await sleep(backoff(attempt) * this.backoffScale); continue; }
        if (status === 401 || status === 403) this.setHealth(b.provider, 'blocked', `HTTP ${status}: Zugang verweigert oder Kontingent erschöpft`);
        else this.setHealth(b.provider, 'degraded', `HTTP ${status}`);
        throw new ApiError(b.provider, status, `${b.provider} ${endpointOf(o.url)}: HTTP ${status} ${redact(body.slice(0, 200))}`);
      } catch (e) {
        if (e instanceof ApiError || e instanceof QuotaExhaustedError) throw e;
        if (status === 0) this.recordRequest(b.provider, o.url, 0, Date.now() - started, 0, false, o.note ?? null);
        if (attempt < maxRetries) { await sleep(backoff(attempt) * this.backoffScale); continue; }
        this.setHealth(b.provider, 'down', redact((e as Error).message));
        throw new ApiError(b.provider, 0, `${b.provider}: Netzwerkfehler ${redact((e as Error).message)}`);
      }
    }
  }

  /** Jeder Abruf (auch Cache-Treffer und Fehlversuche) wird protokolliert: Endpunkt, bereinigte Parameter (ohne Schlüssel), Status, Kosten. */
  private recordRequest(provider: string, url: string, status: number, ms: number, cost: number, fromCache: boolean, note: string | null) {
    const d = dayUtc(this.now());
    this.db.run('INSERT INTO api_requests (provider, day, month, endpoint, query, note, status, duration_ms, from_cache, cost, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      provider, d, d.slice(0, 7), endpointOf(url), safeQuery(url), note, status, ms, fromCache ? 1 : 0, cost, nowIso(this.now()));
  }

  /** Abrufprotokoll für die Admin-Diagnose (neueste zuerst). */
  recentRequests(opts: { provider?: string; since?: string; limit?: number } = {}) {
    const where: string[] = [], args: (string | number)[] = [];
    if (opts.provider) { where.push('provider = ?'); args.push(opts.provider); }
    if (opts.since) { where.push('created_at >= ?'); args.push(opts.since); }
    return this.db.all<{ id: number; provider: string; endpoint: string; query: string | null; note: string | null; status: number; from_cache: number; cost: number; duration_ms: number; created_at: string }>(
      `SELECT id, provider, endpoint, query, note, status, from_cache, cost, duration_ms, created_at FROM api_requests ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY id DESC LIMIT ?`,
      ...args, Math.min(500, Math.max(1, opts.limit ?? 100)));
  }

  private syncQuotaHeaders(b: ProviderBudget, h: { get(n: string): string | null }, cost: number) {
    const rem = h.get(b.remainingHeader ?? 'x-ratelimit-requests-remaining');
    const lim = h.get(b.limitHeader ?? 'x-ratelimit-requests-limit');
    const usedH = b.usedHeader ? h.get(b.usedHeader) : null;
    const n = (v: string | null) => v === null || !Number.isFinite(Number(v)) ? null : Number(v);
    this.db.run(`INSERT INTO provider_health (provider, status, quota_remaining, quota_limit, quota_used, credits_used_last, updated_at) VALUES (?, 'ok', ?, ?, ?, ?, ?)
                 ON CONFLICT(provider) DO UPDATE SET quota_remaining = COALESCE(excluded.quota_remaining, quota_remaining), quota_limit = COALESCE(excluded.quota_limit, quota_limit),
                   quota_used = COALESCE(excluded.quota_used, quota_used), credits_used_last = excluded.credits_used_last, updated_at = excluded.updated_at`,
      b.provider, n(rem), n(lim), n(usedH), cost, nowIso(this.now()));
    if (rem !== null && Number(rem) <= 0) this.pause(b.provider, nextUtcDay(this.now()), 'Kontingent laut Provider aufgebraucht');
  }

  /** Laut Anbieter verbleibende Credits, nur wenn im laufenden UTC-Monat gemeldet (Anbieter setzt monatlich zurück). */
  providerReportedRemaining(provider: string): number | null {
    const r = this.db.get<{ quota_remaining: number | null; updated_at: string }>('SELECT quota_remaining, updated_at FROM provider_health WHERE provider = ?', provider);
    if (r?.quota_remaining == null) return null;
    return r.updated_at.slice(0, 7) === dayUtc(this.now()).slice(0, 7) ? r.quota_remaining : null;
  }

  setHealth(provider: string, status: string, error: string | null): void {
    const t = nowIso(this.now());
    this.db.run(`INSERT INTO provider_health (provider, status, last_success_at, last_error_at, last_error, updated_at) VALUES (?, ?, ?, ?, ?, ?)
                 ON CONFLICT(provider) DO UPDATE SET status = CASE WHEN provider_health.paused_until > ? THEN 'paused' ELSE excluded.status END,
                   last_success_at = COALESCE(excluded.last_success_at, last_success_at),
                   last_error_at = COALESCE(excluded.last_error_at, last_error_at),
                   last_error = COALESCE(excluded.last_error, last_error), updated_at = excluded.updated_at`,
      provider, status, error ? null : t, error ? t : null, error, t, t);
  }

  purgeExpiredCache(): number {
    return this.db.run('DELETE FROM api_cache WHERE expires_at < ?', nowIso(this.now())).changes;
  }
}

function quotaOf(b: ProviderBudget, h: { get(n: string): string | null }) {
  const n = (name?: string) => { if (!name) return null; const v = h.get(name); return v === null || !Number.isFinite(Number(v)) ? null : Number(v); };
  return { remaining: n(b.remainingHeader), used: n(b.usedHeader), last: n(b.costHeader) };
}
function nextUtcDay(now: Date): number { const d = new Date(now); d.setUTCHours(24, 5, 0, 0); return d.getTime(); }
/** Query-Parameter ohne Schlüssel/Tokens (fürs Protokoll). */
export function safeQuery(url: string): string | null {
  try {
    const u = new URL(url);
    for (const k of [...u.searchParams.keys()]) if (/key|token|secret|auth/i.test(k)) u.searchParams.delete(k);
    const q = u.searchParams.toString();
    return q ? decodeURIComponent(q).slice(0, 400) : null;
  } catch { return null; }
}
function endpointOf(url: string): string {
  try { return new URL(url).pathname; } catch { return url.slice(0, 80); }
}
function retryAfterMs(v: string | null): number | null {
  if (!v) return null;
  const s = Number(v);
  if (Number.isFinite(s)) return Math.min(s * 1000, 24 * 3_600_000);
  const d = Date.parse(v);
  return Number.isFinite(d) ? Math.max(0, Math.min(d - Date.now(), 24 * 3_600_000)) : null;
}
function backoff(attempt: number): number {
  const base = 500 * 2 ** attempt;
  return Math.min(30_000, base + Math.floor(Math.random() * base * 0.3));
}

export const defaultFetcher: Fetcher = (url, init) => fetch(url, init);

export function cacheKeyHash(s: string): string { return sha(s, 24); }
