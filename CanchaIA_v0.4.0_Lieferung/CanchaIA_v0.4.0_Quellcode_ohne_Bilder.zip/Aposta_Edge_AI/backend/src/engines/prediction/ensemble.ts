/**
 * Ensemble: lineare Mischung der verfügbaren Modelle je Markt.
 * Gewichte kommen ausschließlich aus einem Backtest (model_versions.weights). Ohne validierten
 * Backtest werden gleiche Gewichte verwendet und die Modellversion bleibt UNVALIDATED.
 * Unsicherheit = Streuung zwischen den Modellen ⊕ Stichprobenunsicherheit der Torerwartung.
 */
import type { ModelOutput } from './models.js';
import { probsFromLambdas } from './poisson.js';
import type { MarketId, SelectionId } from '../../providers/types.js';
import { MARKET_SELECTIONS } from '../../providers/types.js';

export type MarketProbs = Partial<Record<MarketId, Partial<Record<SelectionId, number>>>>;
export type Weights = Partial<Record<MarketId, Record<string, number>>>;

export interface EnsembleResult {
  probs: MarketProbs;
  sd: MarketProbs;
  modelsUsed: Partial<Record<MarketId, string[]>>;
  lambdaHome: number | null;
  lambdaAway: number | null;
  agreement: number; // 0..1 (1 = Modelle einig)
}

export function combine(outputs: ModelOutput[], weights: Weights | null, sampleSizeMin: number, ouLine = 2.5): EnsembleResult {
  const avail = outputs.filter(o => o.available && o.probs);
  const probs: MarketProbs = {}, sd: MarketProbs = {}, used: Partial<Record<MarketId, string[]>> = {};
  let maxSpread = 0;
  for (const market of ['1X2', 'OU', 'BTTS'] as MarketId[]) {
    const ms = avail.filter(o => o.probs![market]);
    if (!ms.length) continue;
    const wRaw = ms.map(o => weights?.[market]?.[o.model] ?? 1);
    const wSum = wRaw.reduce((a, b) => a + b, 0) || 1;
    const sels = MARKET_SELECTIONS[market];
    probs[market] = {}; sd[market] = {}; used[market] = ms.map(o => o.model);
    for (const s of sels) {
      const vals = ms.map(o => (o.probs![market] as Record<string, number>)[s]);
      const mean = vals.reduce((a, v, i) => a + v * wRaw[i], 0) / wSum;
      const between = ms.length > 1 ? Math.sqrt(vals.reduce((a, v, i) => a + wRaw[i] * (v - mean) ** 2, 0) / wSum) : 0;
      probs[market]![s] = mean;
      sd[market]![s] = between;
      maxSpread = Math.max(maxSpread, Math.max(...vals) - Math.min(...vals));
    }
  }
  // Torerwartung: gewichtetes Mittel der Modelle mit λ
  const lam = avail.filter(o => o.lambdaHome != null);
  const lh = lam.length ? lam.reduce((a, o) => a + o.lambdaHome!, 0) / lam.length : null;
  const la = lam.length ? lam.reduce((a, o) => a + o.lambdaAway!, 0) / lam.length : null;
  // Stichprobenunsicherheit (Delta-Methode): relativer Standardfehler einer Poisson-Rate aus n Spielen
  // ist ≈ 1/√(n·λ); Angriffs- und Abwehrschätzung tragen beide bei (Faktor √2). Wirkung je λ numerisch.
  if (lh != null && la != null) {
    const n = Math.max(4, sampleSizeMin);
    const rh = Math.min(0.35, Math.SQRT2 / Math.sqrt(n * Math.max(0.3, lh))), ra = Math.min(0.35, Math.SQRT2 / Math.sqrt(n * Math.max(0.3, la)));
    const hUp = probsFromLambdas(lh * (1 + rh), la, 0, ouLine), hDn = probsFromLambdas(lh * (1 - rh), la, 0, ouLine);
    const aUp = probsFromLambdas(lh, la * (1 + ra), 0, ouLine), aDn = probsFromLambdas(lh, la * (1 - ra), 0, ouLine);
    for (const market of Object.keys(sd) as MarketId[]) for (const s of MARKET_SELECTIONS[market]) {
      const pick = (p: ReturnType<typeof probsFromLambdas>) => (p[market] as Record<string, number>)[s];
      const dH = (pick(hUp) - pick(hDn)) / 2, dA = (pick(aUp) - pick(aDn)) / 2;
      sd[market]![s] = Math.sqrt((sd[market]![s] ?? 0) ** 2 + dH ** 2 + dA ** 2);
    }
  }
  return { probs, sd, modelsUsed: used, lambdaHome: lh, lambdaAway: la, agreement: Math.max(0, 1 - maxSpread / 0.2) };
}
