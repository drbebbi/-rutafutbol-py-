/**
 * Freshness-Regeln für Quoten (eine Quelle der Wahrheit für Aufnahme, Value-Engine und Empfehlungen).
 *
 * Zeitpunkte, die nie verwechselt werden dürfen:
 *  1 sourceTimestamp – Zeitpunkt der Quote beim Anbieter (falls geliefert)
 *  2 retrievedAt     – tatsächlicher HTTP-Abruf beim Provider (Cache-Treffer behalten den ORIGINAL-Abrufzeitpunkt)
 *  3 cachedAt        – Speicherung in unserem Cache (= retrievedAt des Abrufs, der den Cache füllte)
 *  4 processedAt     – Verarbeitung in unserer Anwendung
 *  5 validatedAt     – letzte erfolgreiche Marktvalidierung (Signal/Empfehlung)
 *
 * Maximales Alter abhängig von der Zeit bis zum Anstoß (Basis = ODDS_MAX_AGE_MINUTES, Default 90):
 *   > 24 h : Basis          6–24 h : min(Basis, 60)          1–6 h : min(Basis, 30)          < 1 h : min(Basis, 10)
 * Referenzzeit = ältere von Quellzeit und Abrufzeit. Ohne Quellzeit gilt die halbe Grenze (konservativ).
 * Zeitstempel in der Zukunft (> 2 min Toleranz) oder unlesbar → ungültig.
 */
export const FUTURE_TOLERANCE_MIN = 2;

export function maxOddsAgeMinutes(minutesToKickoff: number, base = 90): number {
  if (minutesToKickoff > 24 * 60) return base;
  if (minutesToKickoff > 6 * 60) return Math.min(base, 60);
  if (minutesToKickoff > 60) return Math.min(base, 30);
  return Math.min(base, 10);
}

export interface FreshnessInput { retrievedAt: string; sourceTimestamp: string | null; kickoffUtc: string; snapshotKind?: string }
export interface FreshnessResult { ok: boolean; ageMinutes: number | null; limitMinutes: number; reference: string | null; expiresAt: string | null; reasons: string[] }

const parse = (s: string | null | undefined): number | null => {
  if (!s) return null;
  const t = Date.parse(s);
  return Number.isFinite(t) ? t : NaN;
};

export function checkFreshness(s: FreshnessInput, now: Date, base = 90): FreshnessResult {
  const reasons: string[] = [];
  const n = now.getTime(), kick = Date.parse(s.kickoffUtc);
  const fetched = parse(s.retrievedAt), source = parse(s.sourceTimestamp);
  const minsToKick = (kick - n) / 60_000;
  let limit = maxOddsAgeMinutes(minsToKick, base);
  if (s.snapshotKind && s.snapshotKind !== 'live') reasons.push(`historischer Snapshot (${s.snapshotKind}), keine aktuelle Quote`);
  if (!Number.isFinite(kick)) reasons.push('Anstoßzeit unlesbar');
  else if (kick <= n) reasons.push('Spiel hat begonnen');
  if (fetched == null || Number.isNaN(fetched)) reasons.push('Abrufzeitpunkt fehlt oder ist unlesbar');
  else if (fetched > n + FUTURE_TOLERANCE_MIN * 60_000) reasons.push('Abrufzeitpunkt liegt in der Zukunft');
  if (Number.isNaN(source)) reasons.push('Quellzeitstempel unlesbar');
  else if (source != null && (source > n + FUTURE_TOLERANCE_MIN * 60_000 || (fetched != null && !Number.isNaN(fetched) && source > fetched + FUTURE_TOLERANCE_MIN * 60_000)))
    reasons.push('Quellzeitstempel liegt in der Zukunft');
  if (reasons.length || fetched == null || Number.isNaN(fetched)) return { ok: false, ageMinutes: null, limitMinutes: limit, reference: null, expiresAt: null, reasons };
  const known = source != null && !Number.isNaN(source);
  const ref = known ? Math.min(source!, fetched) : fetched;
  const effLimit = (m: number) => maxOddsAgeMinutes(m, base) / (known ? 1 : 2);
  limit = effLimit(minsToKick);
  const age = (n - ref) / 60_000;
  if (!known) reasons.push(`kein Quellzeitstempel: strengere Grenze ${limit} min`);
  const ok = age <= limit;
  if (!ok) reasons.push(`Quote ${Math.round(age)} min alt, erlaubt ${limit} min (${Math.round(minsToKick)} min vor Anstoß)`);
  // Ablaufzeit: frühester Zeitpunkt t ≥ jetzt, an dem Alter > Grenze(t) oder Anstoß erreicht ist (minutengenau)
  let expires: number | null = null;
  if (ok) {
    for (let t = n; t <= kick; t += 60_000) {
      if ((t - ref) / 60_000 > effLimit((kick - t) / 60_000)) { expires = t; break; }
    }
    expires ??= kick;
  }
  return { ok, ageMinutes: Math.round(age * 10) / 10, limitMinutes: limit, reference: new Date(ref).toISOString(), expiresAt: expires ? new Date(expires).toISOString() : null,
    reasons: ok ? reasons.filter(r => r.startsWith('kein Quellzeitstempel')) : reasons };
}

/** Obergrenze jedes Quoten-Caches (Sekunden), unabhängig vom Anstoß. */
export const ODDS_CACHE_MAX_SECONDS = 20 * 60;
/** Untergrenze, damit wiederholte manuelle Läufe kurz vor Anstoß nicht jede Minute Credits verbrauchen. */
export const ODDS_CACHE_MIN_SECONDS = 2 * 60;

/**
 * Dynamische Cache-Regel für Quoten (v0.3.0):
 * Ein Cache-Eintrag darf höchstens halb so alt sein wie die Frische-Grenze, die für den nächsten Anstoß gilt
 * (ohne Quellzeitstempel nochmals halbiert). Dadurch bleibt nach einem Cache-Treffer immer Restgültigkeit,
 * und eine 20-min-Cache-Kopie wird in der letzten Stunde vor Anstoß nicht mehr verwendet.
 *   > 24 h: 20 min (Obergrenze) · 6–24 h: 20 min · 1–6 h: 15 min · < 1 h: 5 min (ohne Quellzeit: 2,5 min; Untergrenze 2 min)
 * Die Freshness-Prüfung (checkFreshness) bleibt davon unberührt und ist weiterhin die letzte Instanz.
 */
export function oddsCacheMaxAgeSeconds(minutesToKickoff: number, base = 90, hasSourceTimestamp = true): number {
  const limitMin = maxOddsAgeMinutes(minutesToKickoff, base) / (hasSourceTimestamp ? 1 : 2);
  return Math.max(ODDS_CACHE_MIN_SECONDS, Math.min(ODDS_CACHE_MAX_SECONDS, Math.floor(limitMin * 60 / 2)));
}

/** Nächster noch nicht begonnener Anstoß aus einer Liste (ISO-Zeiten); null, wenn keiner mehr bevorsteht. */
export function minutesToNextKickoff(kickoffs: (string | null | undefined)[], now: Date): number | null {
  let best: number | null = null;
  for (const k of kickoffs) {
    const t = k ? Date.parse(k) : NaN;
    if (!Number.isFinite(t) || t <= now.getTime()) continue;
    const m = (t - now.getTime()) / 60_000;
    if (best == null || m < best) best = m;
  }
  return best;
}
