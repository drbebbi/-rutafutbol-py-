/** Spiele: Filterleiste (Wettbewerb, Zeitraum, Team, Signal, Mindest-EV) und Liste/Tabelle. Server-Filter wie v0.3.0, Signal/EV clientseitig. */
import React, { useMemo, useState } from 'react';
import { fmt } from '../i18n';
import { useApp, Icon } from '../components';
import { useLoad } from '../hooks';
import { Button, EmptyState, ErrorBox, Loading, PageHeader } from '../ui';
import { MatchRow } from './shared';

const STATUSES = ['STRONG_VALUE', 'VALUE', 'WATCH', 'NO_VALUE', 'AVOID', 'STALE', 'INSUFFICIENT_DATA'];

export function Matches() {
  const { t, u } = useApp();
  const [q, setQ] = useState(''), [region, setRegion] = useState(''), [comp, setComp] = useState(''), [hours, setHours] = useState(48), [status, setStatus] = useState(''), [minEv, setMinEv] = useState('');
  const comps = useLoad<any[]>('/api/competitions');
  const path = `/api/matches?hours=${hours}${region ? `&region=${region}` : ''}${comp ? `&competition=${comp}` : ''}`;
  const list = useLoad<any[]>(path, [path]);
  const regions = [...new Set((comps.data ?? []).map(c => c.region))];
  const shown = useMemo(() => (list.data ?? []).filter(m => {
    if (q && !`${m.home} ${m.away} ${m.competition}`.toLowerCase().includes(q.toLowerCase())) return false;
    if (status === 'QUALIFIED' && !['VALUE', 'STRONG_VALUE'].includes(m.top_signal?.status)) return false;
    if (status && status !== 'QUALIFIED' && m.top_signal?.status !== status) return false;
    if (minEv !== '' && !(m.top_signal?.ev != null && m.top_signal.ev >= Number(minEv) / 100)) return false;
    return true;
  }), [list.data, q, status, minEv]);
  const filtered = !!(q || region || comp || status || minEv !== '' || hours !== 48);
  const reset = () => { setQ(''); setRegion(''); setComp(''); setHours(48); setStatus(''); setMinEv(''); };

  return (
    <>
      <PageHeader title={t.matches} />
      <div className="filterbar" role="search">
        <div className="fb-row">
          <div className="fb-search"><Icon name="search" /><input id="q" type="search" placeholder={u.fTeam} value={q} onChange={e => setQ(e.target.value)} aria-label={u.fTeam} /></div>
          <select id="comp" value={comp} onChange={e => setComp(e.target.value)} aria-label={u.fCompetition}>
            <option value="">{t.allComps}</option>
            {(comps.data ?? []).filter(c => !region || c.region === region).map(c => <option key={c.id} value={c.id}>{c.name}{c.upcoming ? ` (${c.upcoming})` : ''}</option>)}
          </select>
          <select id="region" value={region} onChange={e => { setRegion(e.target.value); setComp(''); }} aria-label={u.fRegion}>
            <option value="">{t.allRegions}</option>{regions.map(r => <option key={r} value={r}>{t.regions[r] ?? r}</option>)}
          </select>
          <select id="hours" value={hours} onChange={e => setHours(Number(e.target.value))} aria-label={u.fRange}>
            <option value={24}>{u.fRange}: 24 h</option><option value={48}>{u.fRange}: 48 h</option><option value={168}>{u.fRange}: 7 d</option>
          </select>
          <select id="status" value={status} onChange={e => setStatus(e.target.value)} aria-label={u.fStatus}>
            <option value="">{u.fStatus}: {u.fAll}</option><option value="QUALIFIED">VALUE + STRONG VALUE</option>
            {STATUSES.map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
          </select>
          <select id="minev" value={minEv} onChange={e => setMinEv(e.target.value)} aria-label={u.fMinEv}>
            <option value="">{u.fMinEv}</option>{[0, 3, 5, 8, 10, 15].map(v => <option key={v} value={v}>{u.fMinEv} ≥ {v} %</option>)}
          </select>
        </div>
        <div className="fb-foot"><span>{list.data ? fmt(u.results, { n: shown.length }) : ''}</span>{filtered ? <Button variant="quiet" size="sm" onClick={reset}>{u.reset}</Button> : null}</div>
      </div>

      {list.err ? <ErrorBox e={list.err} onRetry={list.reload} /> : !list.data ? <Loading lines={6} /> : shown.length ? (
        <div className="stack" style={{ gap: 6 }}>
          <div className="mhead" aria-hidden="true"><span>{u.colKickoff}</span><span>{u.colMatch}</span><span style={{ textAlign: 'left' }}>{t.market}</span><span>{u.colOdds}</span><span>{u.colEv}</span><span>{u.colBooks}</span><span>{u.colSignal}</span></div>
          <div className="mlist table">{shown.map(m => <MatchRow key={m.id} m={m} />)}</div>
        </div>
      ) : list.data.length ? (
        <EmptyState title={u.emptyFilter} text={u.emptyFilterText} icon="search" action={<Button variant="secondary" onClick={reset}>{u.reset}</Button>} />
      ) : <EmptyState title={u.emptyMatches} text={u.emptyMatchesText} icon="matches" />}
    </>
  );
}
