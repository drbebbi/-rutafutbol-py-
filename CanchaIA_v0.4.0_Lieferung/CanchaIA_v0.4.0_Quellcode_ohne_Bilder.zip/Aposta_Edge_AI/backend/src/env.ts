/**
 * .env-Laden (v0.4.0) – eindeutig und ohne Abhängigkeiten.
 *
 * Reihenfolge:
 *  1. ENV_FILE=<pfad> → genau diese Datei (ENV_FILE=none → keine Datei laden)
 *  2. sonst die erste vorhandene von: ./.env (Arbeitsverzeichnis), ../.env, <Projektwurzel>/.env
 * Echte Umgebungsvariablen haben IMMER Vorrang (Secrets aus Hosting/Codespaces/Docker werden nie überschrieben).
 * Es werden nur Dateiname und Anzahl der übernommenen Schlüssel gemeldet – nie Werte.
 * Wird als ERSTER Import von main.ts/cli.ts ausgeführt, vor allen Modulen, die Umgebungsvariablen lesen.
 */
import fs from 'node:fs';
import path from 'node:path';
import { parseEnv } from 'node:util';
import { fileURLToPath } from 'node:url';

export interface EnvLoadResult { file: string | null; applied: number; skippedExisting: number; error: string | null }

export function loadDotEnv(env: NodeJS.ProcessEnv = process.env, cwd: string = process.cwd()): EnvLoadResult {
  const explicit = env.ENV_FILE?.trim();
  if (explicit && explicit.toLowerCase() === 'none') return { file: null, applied: 0, skippedExisting: 0, error: null };
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..', '..'); // dist/src/env.js → Projektwurzel
  const candidates = explicit ? [path.resolve(cwd, explicit)] : [path.join(cwd, '.env'), path.join(cwd, '..', '.env'), path.join(root, '.env')];
  const file = candidates.find(f => { try { return fs.statSync(f).isFile(); } catch { return false; } }) ?? null;
  if (!file) return { file: null, applied: 0, skippedExisting: 0, error: explicit ? `ENV_FILE nicht gefunden: ${explicit}` : null };
  let parsed: Record<string, string>;
  try { parsed = parseEnv(fs.readFileSync(file, 'utf8')) as Record<string, string>; }
  catch (e) { return { file, applied: 0, skippedExisting: 0, error: `ENV-Datei nicht lesbar: ${(e as Error).message.slice(0, 120)}` }; }
  let applied = 0, skipped = 0;
  for (const [k, v] of Object.entries(parsed)) {
    if (env[k] !== undefined) { skipped++; continue; }   // echte Umgebung gewinnt
    if (v === '') continue;                                // leere Platzhalter aus .env.example nicht als gesetzt werten
    env[k] = v; applied++;
  }
  return { file, applied, skippedExisting: skipped, error: null };
}

/** Ergebnis des Ladens beim Prozessstart (für die Startmeldung). */
export const envLoad: EnvLoadResult = loadDotEnv();
