/**
 * P0-Regressionstests v0.2.0: Empfehlungs-Lebenszyklus und Quotenzeitstempel.
 * Alle Tests mit kontrollierter Uhr (ANCHOR + Offset), ohne Abhängigkeit von der Systemzeit.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, mockApp, memDb } from './helpers.js';
import { RecommendationEngine } from '../src/engines/recommendation.js';
import { checkFreshness, maxOddsAgeMinutes } from '../src/engines/freshness.js';
import { validateQuote, consensusNoVig, noVig, type MarketBookView } from '../src/engines/odds.js';
import { ApiQueue } from '../src/api/apiQueue.js';
import { TheOddsApiProvider } from '../src/providers/theOddsApi.js';
import type { ProviderOddsQuote } from '../src/providers/types.js';

const H = 3_600_000;
const at = (h: number) => new Date(ANCHOR.getTime() + h * H);

async function withRecommendation() {
  const app = await mockApp();
  const s = await app.sync.run(ANCHOR);
  const recs = app.sync.report(ANCHOR).recommendations;
  return { app, s, recs };
}

test('TEST A: im Mock-Modus entsteht eine gültige Empfehlung mit vollständigem Datenstand', async () => {
  const { recs } = await withRecommendation();
  assert.ok(recs.length >= 1, 'mindestens eine Empfehlung erwartet');
  for (const r of recs) {
    assert.ok(r.predictedAt && r.oddsRetrievedAt && r.lastValidatedAt && r.validUntil, 'Zeitstempel vollständig');
    assert.ok(new Date(r.validUntil!) > ANCHOR, 'gültig in der Zukunft');
    assert.ok(new Date(r.validUntil!) <= new Date(r.signal.kickoff_utc), 'nie über den Anstoß hinaus gültig');
    assert.ok(r.oddsAgeMinutes != null && r.oddsAgeMinutes >= 0);
  }
});

test('TEST B+C: Uhr +6 h, ohne neuen Sync → keine abgelaufene Empfehlung mehr aktiv', async () => {
  const { app, recs } = await withRecommendation();
  assert.ok(recs.length >= 1);
  const later = app.sync.report(at(6));
  assert.equal(later.recommendations.length, 0, 'alle Empfehlungen müssen nach 6 h ohne neue Quote abgelaufen sein');
  assert.equal(later.message, 'NO QUALIFIED VALUE BETS');
  const reasons = app.db.all<{ deactivation_reason: string }>('SELECT deactivation_reason FROM recommendations WHERE active = 0');
  assert.ok(reasons.length >= recs.length);
  assert.ok(reasons.every(r => /STALE ODDS|begonnen/.test(r.deactivation_reason)), JSON.stringify(reasons));
});

test('Empfehlung läuft genau an ihrer Gültigkeitsgrenze ab (nicht vorher, nicht nachher)', async () => {
  const { app, recs } = await withRecommendation();
  const r = recs[0];
  const until = new Date(r.validUntil!).getTime();
  assert.equal(new RecommendationEngine(app.db, { allowMock: true }).current(new Date(until - 60_000)).some(x => x.signalId === r.signalId), true);
  assert.equal(new RecommendationEngine(app.db, { allowMock: true }).current(new Date(until + 60_000)).some(x => x.signalId === r.signalId), false);
});

test('TEST D: Quotenprovider fällt aus → alte Empfehlungen werden nicht als aktuell veröffentlicht', async () => {
  const { app, recs } = await withRecommendation();
  assert.ok(recs.length >= 1);
  (app.providers.odds[0] as any).oddsForFixtures = async () => { throw new Error('Provider down'); };
  for (const h of [1, 2, 3, 6]) {
    const s = await app.sync.run(at(h));
    assert.ok(s.errors.some(e => e.includes('Provider down')));
    const rep = app.sync.report(at(h)).recommendations;
    for (const x of rep) {
      const age = (at(h).getTime() - new Date(x.oddsRetrievedAt!).getTime()) / 60_000;
      assert.ok(age <= 90, `Stunde ${h}: Empfehlung mit ${age} min alter Quote`);
      assert.ok(new Date(x.validUntil!) > at(h));
    }
    if (h >= 2) assert.equal(rep.length, 0, `Stunde ${h}: ohne neue Quoten darf nichts mehr empfohlen werden`);
  }
});

test('TEST E: Spielbeginn → keine Pre-Match-Empfehlung mehr für dieses Spiel', async () => {
  const { app, recs } = await withRecommendation();
  const r = recs[0];
  // Variante 1: Uhr erreicht den Anstoß
  assert.equal(app.sync.report(new Date(r.signal.kickoff_utc)).recommendations.some(x => x.eventId === r.eventId), false);
  // Variante 2: Status wechselt vor dem geplanten Anstoß auf live (z. B. vorgezogener Anstoß)
  const { app: app2, recs: recs2 } = await withRecommendation();
  app2.db.run("UPDATE events SET status = 'live' WHERE id = ?", recs2[0].eventId);
  assert.equal(app2.sync.report(ANCHOR).recommendations.some(x => x.eventId === recs2[0].eventId), false);
});

test('Markt ausgesetzt / Quote gefallen / unsichere Zuordnung / neuere Prognose → Empfehlung ungültig', async () => {
  const { app, recs } = await withRecommendation();
  const r = recs[0];
  const eng = new RecommendationEngine(app.db, { allowMock: true });
  const snap = app.db.get<any>('SELECT * FROM odds_snapshots WHERE id = ?', r.signal.best_snapshot_id)!;
  // neuere, schlechtere Quote desselben Buchmachers (Value weg)
  const t = new Date(new Date(snap.retrieved_at).getTime() + 5 * 60_000).toISOString();
  app.db.run(`INSERT INTO odds_snapshots (id, event_id, provider, bookmaker_id, market_id, line, market_status, retrieved_at, source_timestamp, is_complete, validation_errors, overround, snapshot_kind)
              VALUES ('newer', ?, ?, ?, ?, ?, 'open', ?, ?, 1, '[]', 0.05, 'live')`, snap.event_id, snap.provider, snap.bookmaker_id, snap.market_id, snap.line, t, t);
  for (const sel of ['HOME', 'DRAW', 'AWAY', 'OVER', 'UNDER', 'YES', 'NO']) app.db.run("INSERT INTO odds_prices (snapshot_id, selection_id, odds) SELECT 'newer', selection_id, 1.05 FROM odds_prices WHERE snapshot_id = ? AND selection_id = ?", snap.id, sel);
  const v = eng.validate(app.db.get<any>(`SELECT s.*, th.name AS home, ta.name AS away, c.name AS competition, e.kickoff_utc, e.status AS event_status, b.name AS bookmaker_name, e.is_mock
    FROM value_signals s JOIN events e ON e.id = s.event_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id LEFT JOIN bookmakers b ON b.id = s.best_bookmaker_id WHERE s.id = ?`, r.signalId)!, ANCHOR);
  assert.equal(v.ok, false);
  assert.ok(v.reasons.some(x => x.includes('Value-Vorteil besteht nicht mehr')), v.reasons.join('|'));
  assert.equal(app.sync.report(ANCHOR).recommendations.some(x => x.signalId === r.signalId), false);

  const { app: a2, recs: r2 } = await withRecommendation();
  a2.db.run("UPDATE event_mappings SET confidence = 0.8 WHERE event_id = ?", r2[0].eventId);
  assert.equal(a2.sync.report(ANCHOR).recommendations.some(x => x.eventId === r2[0].eventId), false, 'unsichere Zuordnung');

  const { app: a3, recs: r3 } = await withRecommendation();
  a3.db.run(`INSERT INTO predictions (event_id, model_version, created_at, probs, components, uncertainty, data_quality, inputs_hash) VALUES (?, 'x', ?, '{}', '[]', '{}', '{"status":"insufficient","score":10}', 'newer-pred')`, r3[0].eventId, at(0.1).toISOString());
  const rep3 = a3.sync.report(ANCHOR);
  assert.equal(rep3.recommendations.some(x => x.eventId === r3[0].eventId), false, 'neuere Prognose / kritische Daten fehlen');
});

test('Mock-Daten im Live-Modus werden nie empfohlen', async () => {
  const { app } = await withRecommendation();
  const live = new RecommendationEngine(app.db, { allowMock: false });
  assert.equal(live.current(ANCHOR).length, 0);
  assert.ok(app.db.get("SELECT 1 FROM recommendations WHERE deactivation_reason LIKE '%MOCK-Daten im Live-Modus%'"));
});

// ---------------------------------------------------------------- Zeitstempel & Freshness
test('Freshness: Grenzen werden näher am Anstoß strenger', () => {
  assert.equal(maxOddsAgeMinutes(30 * 60), 90);
  assert.equal(maxOddsAgeMinutes(12 * 60), 60);
  assert.equal(maxOddsAgeMinutes(3 * 60), 30);
  assert.equal(maxOddsAgeMinutes(30), 10);
  const now = new Date('2026-10-12T12:00:00Z');
  const k = (h: number) => new Date(now.getTime() + h * H).toISOString();
  const r = (m: number) => new Date(now.getTime() - m * 60_000).toISOString();
  assert.equal(checkFreshness({ retrievedAt: r(50), sourceTimestamp: r(50), kickoffUtc: k(30) }, now).ok, true, '50 min alt, 30 h vor Anstoß');
  assert.equal(checkFreshness({ retrievedAt: r(50), sourceTimestamp: r(50), kickoffUtc: k(3) }, now).ok, false, '50 min alt, 3 h vor Anstoß');
  assert.equal(checkFreshness({ retrievedAt: r(12), sourceTimestamp: r(12), kickoffUtc: k(0.5) }, now).ok, false, '12 min alt, 30 min vor Anstoß');
});

test('Freshness: unbekannter Quellzeitpunkt → halbe Grenze; Zukunft/unlesbar → ungültig', () => {
  const now = new Date('2026-10-12T12:00:00Z');
  const kick = new Date(now.getTime() + 30 * H).toISOString();
  const r = (m: number) => new Date(now.getTime() - m * 60_000).toISOString();
  assert.equal(checkFreshness({ retrievedAt: r(60), sourceTimestamp: null, kickoffUtc: kick }, now).ok, false, '60 > 45 min ohne Quellzeit');
  assert.equal(checkFreshness({ retrievedAt: r(40), sourceTimestamp: null, kickoffUtc: kick }, now).ok, true);
  assert.equal(checkFreshness({ retrievedAt: r(-10), sourceTimestamp: null, kickoffUtc: kick }, now).ok, false, 'Abruf in der Zukunft');
  assert.equal(checkFreshness({ retrievedAt: r(5), sourceTimestamp: r(-30), kickoffUtc: kick }, now).ok, false, 'Quellzeit in der Zukunft');
  assert.equal(checkFreshness({ retrievedAt: 'kaputt', sourceTimestamp: null, kickoffUtc: kick }, now).ok, false);
  assert.equal(checkFreshness({ retrievedAt: r(5), sourceTimestamp: 'kaputt', kickoffUtc: kick }, now).ok, false);
  // Quellzeit älter als Abruf → Alter zählt ab Quellzeit
  assert.equal(checkFreshness({ retrievedAt: r(5), sourceTimestamp: r(240), kickoffUtc: kick }, now).ok, false, '4 h alte Quellzeit (v0.1.0 akzeptierte das)');
  assert.equal(checkFreshness({ retrievedAt: r(5), sourceTimestamp: r(5), kickoffUtc: kick, snapshotKind: 'closing' }, now).ok, false, 'historischer Snapshot nie live');
});

test('Quotenvalidierung: Zukunfts- und alte Quellzeitstempel werden abgelehnt', () => {
  const q: ProviderOddsQuote = { provider: 't', providerEventId: '1', bookmakerProviderId: 'b', bookmakerName: 'B', market: '1X2', line: null, marketStatus: 'open',
    prices: { HOME: 2, DRAW: 3.4, AWAY: 3.5 }, retrievedAt: '2026-10-12T12:00:00Z', sourceTimestamp: '2026-10-12T08:00:00Z', snapshotKind: 'live' };
  const ctx = { now: new Date('2026-10-12T12:00:00Z'), maxAgeMinutes: 90, kickoffUtc: '2026-10-13T19:00:00Z', mappingConfidence: 1 };
  assert.ok(validateQuote(q, ctx).length > 0, '4 h alte Quellzeit');
  assert.ok(validateQuote({ ...q, sourceTimestamp: '2026-10-12T15:00:00Z' }, ctx).some(e => e.includes('Zukunft')));
  assert.deepEqual(validateQuote({ ...q, sourceTimestamp: '2026-10-12T11:50:00Z' }, ctx), []);
});

function fakeOddsApi(lastUpdate: string) {
  const db = memDb(); let calls = 0;
  let clock = new Date('2026-10-12T12:00:00Z');
  const body = [{ id: 'ev1', sport_key: 'soccer_epl', sport_title: 'EPL', commence_time: '2026-10-13T19:00:00Z', home_team: 'Arsenal', away_team: 'Lille',
    bookmakers: [{ key: 'pinnacle', title: 'Pinnacle', last_update: lastUpdate, markets: [{ key: 'h2h', last_update: lastUpdate, outcomes: [{ name: 'Arsenal', price: 1.25 }, { name: 'Lille', price: 13 }, { name: 'Draw', price: 6.5 }] }] }] }];
  const q = new ApiQueue(db, async (url) => {
    calls++;
    const isEvents = new URL(url).pathname.endsWith('/events');
    const data = isEvents ? body.map(({ bookmakers, ...event }) => event) : body;
    return { status: 200, headers: { get: (n: string) => ({ 'x-requests-remaining': '480', 'x-requests-last': isEvents ? '0' : '4' } as Record<string, string>)[n] ?? null }, text: async () => JSON.stringify(data) };
  }, () => clock, 0.001);
  q.register({ provider: 'theoddsapi', dailyBudget: 100, monthlyBudget: 500, maxConcurrent: 1, minIntervalMs: 0, remainingHeader: 'x-requests-remaining', costHeader: 'x-requests-last' });
  const p = new TheOddsApiProvider(q, { apiKey: 'k', baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'] });
  return { db, q, p, calls: () => calls, setClock: (d: Date) => { clock = d; } };
}

test('Cache-Treffer behalten den ursprünglichen Abrufzeitpunkt (keine künstliche Aktualisierung)', async () => {
  const f = fakeOddsApi('2026-10-12T11:58:00Z');
  const from = new Date('2026-10-12T12:00:00Z'), to = new Date('2026-10-14T12:00:00Z');
  const fx = await f.p.upcomingFixtures(from, to);
  const a = await f.p.oddsForFixtures(fx);
  f.setClock(new Date('2026-10-12T12:15:00Z'));
  const fresh = new TheOddsApiProvider(f.q, { apiKey: 'k', baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'] });
  const fx2 = await fresh.upcomingFixtures(from, to); // Cache-Treffer
  const b = await fresh.oddsForFixtures(fx2);
  assert.equal(f.calls(), 3, 'ein kostenpflichtiger Odds-Abruf aus Cache; freie Spielsuche nach TTL erneut');
  assert.equal(a[0].retrievedAt, '2026-10-12T12:00:00.000Z');
  assert.equal(b[0].retrievedAt, '2026-10-12T12:00:00.000Z', 'Cache-Treffer darf den Abrufzeitpunkt nicht auf 12:15 setzen');
  assert.equal(b[0].fromCache, true);
  assert.equal(b[0].sourceTimestamp, '2026-10-12T11:58:00Z');
});

test('Credits: tatsächliche Kosten aus x-requests-last, Tages- und Monatsbudget', async () => {
  const f = fakeOddsApi('2026-10-12T11:58:00Z');
  const fx = await f.p.upcomingFixtures(new Date('2026-10-12T12:00:00Z'), new Date('2026-10-14T12:00:00Z'));
  assert.equal(f.q.usedToday('theoddsapi'), 0, 'kostenlose Spielsuche');
  await f.p.oddsForFixtures(fx);
  assert.equal(f.q.usedToday('theoddsapi'), 4);
  assert.equal(f.q.usedThisMonth('theoddsapi'), 4);
  assert.equal(f.q.budgetStatus('theoddsapi').providerRemaining, 480);
});

test('Marktintegrität: Referenz ohne bewerteten Buchmacher (keine doppelte Marktinformation)', () => {
  const v = (id: string, sharp: boolean, h: number, d: number, a: number): MarketBookView => ({ snapshotId: id, bookmakerId: id, bookmakerName: id, isSharp: sharp, retrievedAt: '', sourceTimestamp: null, status: 'open', errors: [], valid: true, prices: { HOME: h, DRAW: d, AWAY: a }, overround: 0, noVig: noVig({ HOME: h, DRAW: d, AWAY: a }, '1X2') });
  const views = [v('sharp', true, 2.0, 3.5, 4.0), v('soft', false, 2.3, 3.3, 3.6)];
  assert.equal(consensusNoVig(views, '1X2', 'sharp')!.source, 'median:1', 'ohne den scharfen Buchmacher selbst');
  assert.equal(consensusNoVig(views, '1X2', 'soft')!.source, 'sharp:sharp');
  assert.equal(consensusNoVig([views[0]], '1X2', 'sharp'), null, 'einzige Quelle = bewerteter Buchmacher → keine Referenz');
});

test('Signal speichert Datenstand (Abruf, Quelle, Validierung, Gültigkeit, Referenzquelle)', async () => {
  const { app } = await withRecommendation();
  const s = app.db.get<any>("SELECT * FROM value_signals WHERE status = 'VALUE' AND active = 1 LIMIT 1")!;
  assert.ok(s.odds_retrieved_at && s.validated_at && s.valid_until && s.market_ref_source);
  assert.notEqual(s.market_ref_source, `sharp:${s.best_bookmaker_id}`, 'Referenz darf nicht der bewertete Buchmacher sein');
  const snap = app.db.get<any>('SELECT * FROM odds_snapshots WHERE id = ?', s.best_snapshot_id)!;
  assert.equal(snap.snapshot_kind, 'live');
  assert.ok(snap.processed_at);
});

test('App-Verdrahtung Live: The Odds API mit Monatsbudget und Kosten-Header (nicht nur im Test registriert)', async () => {
  const { buildProviders } = await import('../src/app.js');
  const { testConfig } = await import('./helpers.js');
  const cfg = testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: 'test-key-not-real', THE_ODDS_API_MONTHLY_BUDGET: '300', THE_ODDS_API_SPORT_KEYS: 'soccer_epl' });
  const db = memDb();
  const q = new ApiQueue(db, async () => ({ status: 200, headers: { get: (n: string) => ({ 'x-requests-remaining': '297', 'x-requests-last': '3' } as Record<string, string>)[n] ?? null }, text: async () => '[]' }), () => ANCHOR, 0.001);
  const { set } = buildProviders(cfg, db, q);
  await set.fixtures[0].upcomingFixtures(ANCHOR, at(48));
  const st = q.budgetStatus('theoddsapi');
  assert.equal(st.monthlyBudget, 300);
  assert.equal(q.usedThisMonth('theoddsapi'), 3, 'Kosten aus x-requests-last, nicht die Schätzung 4');
});
