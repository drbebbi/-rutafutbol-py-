// Produktions-Build mit esbuild (keine weiteren Abhängigkeiten)
import * as esbuild from 'esbuild';
import fs from 'node:fs';

const watch = process.argv.includes('--watch');
fs.rmSync('dist', { recursive: true, force: true });
fs.mkdirSync('dist', { recursive: true });
fs.copyFileSync('index.html', 'dist/index.html');
for (const f of fs.existsSync('public') ? fs.readdirSync('public') : []) fs.copyFileSync(`public/${f}`, `dist/${f}`);

const opts = {
  entryPoints: ['src/main.tsx', 'src/styles.css'],
  bundle: true, minify: !watch, sourcemap: watch, outdir: 'dist/assets',
  target: ['es2020'], jsx: 'automatic', loader: { '.svg': 'dataurl' },
  define: { 'process.env.NODE_ENV': watch ? '"development"' : '"production"' },
  logLevel: 'info',
};
if (watch) { const ctx = await esbuild.context(opts); await ctx.watch(); }
else await esbuild.build(opts);
