import { test } from 'node:test';
import assert from 'node:assert/strict';
import { simulateLeague } from './helpers.js';
import { fitDixonColes, dixonColes, buildElo, elo, fitFeatureModel, featureModel, poissonStrength } from '../src/engines/prediction/models.js';
import { leagueMeans } from '../src/engines/prediction/history.js';

const { matches, att } = simulateLeague({ teams: 12, seasons: 3, home: 1.3 });
const before = new Date(new Date(matches[matches.length - 1].kickoff).getTime() + 3_600_000).toISOString();

test('Dixon-Coles schätzt Heimvorteil und Stärkereihenfolge aus simulierten Daten', () => {
  const fit = fitDixonColes(matches, before)!;
  assert.ok(fit, 'Fit erwartet');
  assert.ok(fit.home > 1.1 && fit.home < 1.55, `Heimvorteil ${fit.home}`);
  assert.ok(fit.rho > -0.25 && fit.rho < 0.15);
  // stärkster vs. schwächster Angriff korrekt geordnet
  const best = att.indexOf(Math.max(...att)) + 1, worst = att.indexOf(Math.min(...att)) + 1;
  assert.ok(fit.attack.get(best)! > fit.attack.get(worst)!);
});

test('Dixon-Coles verweigert die Schätzung bei zu wenig Daten', () => {
  assert.equal(fitDixonColes(matches.slice(0, 50), before), null);
  const out = dixonColes(null, matches, 1, 2, before);
  assert.equal(out.available, false);
  assert.ok(out.reason);
});

test('Elo: Ergebnismodell wird geschätzt, Wahrscheinlichkeiten summieren sich zu 1', () => {
  const st = buildElo(matches, before);
  assert.ok(st.fitted);
  const o = elo(st, 1, 2);
  const p = o.probs!['1X2']!;
  assert.ok(Math.abs(p.HOME + p.DRAW + p.AWAY - 1) < 1e-9);
  assert.ok(st.slope > 0, 'höhere Elo-Differenz → höhere Heimsiegchance');
});

test('Merkmalsmodell: Poisson-Regression konvergiert, Heim-Koeffizient positiv', () => {
  const fit = fitFeatureModel(matches, before)!;
  assert.ok(fit);
  assert.ok(fit.beta[1] > 0, `Heim-Koeffizient ${fit.beta[1]}`);
  const o = featureModel(fit, matches, 1, 2, before);
  assert.ok(o.available && o.lambdaHome! > 0 && o.lambdaAway! > 0);
});

test('Keine Data Leakage: zukünftige Spiele ändern die Prognose nicht', () => {
  const cut = matches[300].kickoff;
  const a = poissonStrength(matches, 3, 4, cut);
  const b = poissonStrength(matches.slice(0, 300), 3, 4, cut);
  assert.deepEqual(a.probs, b.probs);
  const fa = fitDixonColes(matches, cut), fb = fitDixonColes(matches.slice(0, 300), cut);
  assert.equal(fa!.home, fb!.home);
  assert.deepEqual(leagueMeans(matches, cut), leagueMeans(matches.slice(0, 300), cut));
});

test('Poisson-Stärke: zu wenige Spiele → nicht verfügbar mit Begründung', () => {
  // Team 12 hat in den ersten 30 Spielen nur 2 Einsätze
  const o = poissonStrength(matches.slice(0, 30), 1, 12, before);
  assert.equal(o.available, false);
  assert.match(o.reason!, /zu wenige Spiele/);
});
