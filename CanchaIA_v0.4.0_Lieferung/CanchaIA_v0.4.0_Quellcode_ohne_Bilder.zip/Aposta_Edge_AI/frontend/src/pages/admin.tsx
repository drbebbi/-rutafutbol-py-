/** Admin (nur Rolle admin). Funktionen und Endpunkte unverändert aus v0.3.0, neu gegliedert und im UI-Kit dargestellt. */
import React, { useState } from 'react';
import { api, fx, localTime } from '../api';
import { tr } from '../reasons';
import { useApp } from '../components';
import { useLoad } from '../hooks';
import { Banner, Button, Card, ErrorBox, Field, Loading, PageHeader, StatusBadge } from '../ui';
import { ProviderStates, ControlledSync, ApiLog, Validation, PaymentsAdmin } from '../v030';
import { OddsApiPanel } from '../oddsapi';
import { CoveragePanel } from '../coverage';

export function Admin() {
  const { t, lang, tz } = useApp();
  const d = useLoad<any>('/api/admin/diagnostics');
  const [csv, setCsv] = useState(''), [out, setOut] = useState('');
  const job = async (name: string) => { setOut('…'); try { setOut(JSON.stringify(await api(`/api/admin/jobs/${name}/run`, { method: 'POST' }), null, 2).slice(0, 4000)); d.reload(); } catch (e) { setOut((e as Error).message); } };
  const imp = async () => { setOut('…'); try { setOut(JSON.stringify(await api('/api/admin/import-csv', { method: 'POST', body: JSON.stringify({ csv }) }))); d.reload(); } catch (e) { setOut((e as Error).message); } };
  if (d.err) return <><PageHeader title="Admin" /><ErrorBox e={d.err} onRetry={d.reload} /></>;
  if (!d.data) return <><PageHeader title="Admin" /><Loading lines={8} /></>;
  const x = d.data;
  return (
    <>
      <PageHeader title="Admin" lead={`${x.dataMode.toUpperCase()} · ${x.providerStates?.map((p: any) => `${p.provider}: ${p.status}`).join(' · ') ?? ''}`} actions={<Button variant="secondary" size="sm" icon="refresh" onClick={d.reload}>{t.refresh}</Button>} />
      {x.configIssues.length ? <Banner tone="error" title="Config">{x.configIssues.map((i: string) => <div key={i}>{i}</div>)}</Banner> : null}
      <OddsApiPanel />
      <CoveragePanel />
      {x.providerStates ? <ProviderStates states={x.providerStates} pilot={x.pilot} /> : null}
      <ControlledSync />
      {x.apiRequestLog ? <ApiLog rows={x.apiRequestLog} /> : null}

      <div className="grid two">
        <Card title="API Health"><div className="tablewrap"><table><thead><tr><th>Provider</th><th>{t.status}</th><th>Last OK</th><th>Last error</th></tr></thead>
          <tbody>{x.providerHealth.map((p: any) => <tr key={p.provider}><td>{p.provider}</td><td><StatusBadge s={p.status} /></td><td className="small">{p.last_success_at ? localTime(p.last_success_at, tz, lang) : '–'}</td><td className="small t-2">{p.last_error ?? ''}</td></tr>)}</tbody></table></div></Card>
        <Card title="Quota"><div className="tablewrap"><table><thead><tr><th>Provider</th><th className="n">Credits / day</th><th className="n">Month</th><th className="n">Remaining</th><th></th></tr></thead>
          <tbody>{x.quota.map((q: any) => <tr key={q.provider}><td>{q.provider}</td><td className="n">{fx(q.used, 0)}/{q.budget > 1e8 ? '∞' : q.budget}</td><td className="n">{fx(q.usedMonth, 0)}{q.monthlyBudget ? `/${q.monthlyBudget}` : ''}</td><td className="n">{q.providerRemaining ?? '–'}</td>
            <td>{q.paused ? <span className="row-flex"><StatusBadge s="PAUSED" label={`paused · ${localTime(q.pausedUntil, tz, lang)}`} /><Button variant="secondary" size="sm" onClick={async () => { await api(`/api/admin/providers/${q.provider}/resume`, { method: 'POST' }); d.reload(); }}>{t.resume}</Button></span> : null}</td></tr>)}</tbody></table></div></Card>
        <Card title="Scheduler"><div className="tablewrap"><table><thead><tr><th>Job</th><th className="n">min</th><th>Last</th><th>{t.status}</th><th></th></tr></thead>
          <tbody>{(x.scheduler ?? []).map((j: any) => <tr key={j.name}><td>{j.name}</td><td className="n">{j.intervalMin}</td><td className="small">{j.lastRun ? localTime(j.lastRun, tz, lang) : '–'}</td><td><StatusBadge s={j.running ? 'RUNNING' : j.lastStatus} label={j.running ? 'running' : j.lastStatus ?? '–'} /></td><td><Button variant="secondary" size="sm" onClick={() => job(j.name)} aria-label={`${j.name} starten`}>Run</Button></td></tr>)}</tbody></table></div></Card>
        <Card title="Data freshness"><dl className="kv small"><dt>Odds</dt><dd>{x.freshness?.last_odds ? localTime(x.freshness.last_odds, tz, lang) : '–'}</dd><dt>Events</dt><dd>{x.freshness?.last_event_update ? localTime(x.freshness.last_event_update, tz, lang) : '–'}</dd><dt>Predictions</dt><dd>{x.freshness?.last_prediction ? localTime(x.freshness.last_prediction, tz, lang) : '–'}</dd><dt>Mode</dt><dd>{x.dataMode}</dd></dl></Card>
      </div>

      <Card title="Sync runs"><div className="tablewrap"><table><thead><tr><th>#</th><th>Job</th><th>Start</th><th>{t.status}</th><th>Summary / error</th></tr></thead>
        <tbody>{x.syncRuns.map((r: any) => <tr key={r.id}><td className="n">{r.id}</td><td>{r.job}</td><td className="small">{localTime(r.started_at, tz, lang)}</td><td><StatusBadge s={r.status} /></td><td className="small t-2">{r.summary?.fixturesFound != null ? `fx ${r.summary.fixturesFound} · odds ${r.summary.oddsSnapshots}/${r.summary.oddsRejected}✗ · pred ${r.summary.predictions} · rec ${r.summary.recommendations}` : ''} {r.error ?? ''}</td></tr>)}</tbody></table></div></Card>

      <div className="grid two">
        <Card title="Missing data"><div className="tablewrap"><table><tbody>{x.missingData.map((m: any) => <tr key={m.kind + m.ref}><td className="small">{m.kind}</td><td className="small">{m.ref}</td><td className="small t-2">{m.detail}</td><td className="n">{m.count}</td></tr>)}</tbody></table></div></Card>
        <Card title="Error logs"><div className="tablewrap"><table><tbody>{x.errorLogs.map((e: any) => <tr key={e.id}><td className="small">{localTime(e.created_at, tz, lang)}</td><td className="small">{e.source}</td><td className="small t-2">{e.message}</td></tr>)}</tbody></table></div></Card>
      </div>

      <Users />
      <PaymentsAdmin />
      <Validation />

      <div className="grid two">
        <Card title={t.recentlyDeactivated}><div className="tablewrap"><table><tbody>{(x.recentlyDeactivated ?? []).map((r: any) => <tr key={r.id}><td>{r.home} – {r.away}</td><td className="small">{localTime(r.deactivated_at, tz, lang)}</td><td className="small t-2">{tr(r.deactivation_reason ?? '', lang)}</td></tr>)}</tbody></table></div></Card>
        <Card title="Security"><div className="tablewrap"><table><tbody>{(x.securityEvents ?? []).map((e: any) => <tr key={e.id}><td className="small">{localTime(e.created_at, tz, lang)}</td><td className="small">{e.kind}</td><td className="small">{e.email ?? ''}</td><td className="small t-2">{e.ip ?? ''} {e.detail ?? ''}</td></tr>)}</tbody></table></div></Card>
      </div>
      <Card title="Model versions"><div className="stack" style={{ gap: 6 }}>{x.modelValidation.models.map((m: any) => <div key={m.id} className="row-flex between small"><span className="t-2">{m.id}</span><StatusBadge s={m.validation_status} /></div>)}</div></Card>
      <Card title="CSV import" sub="football-data.co.uk">
        <div className="stack">
          <input type="file" accept=".csv,text/csv" onChange={async e => { const f = e.target.files?.[0]; if (f) setCsv(await f.text()); }} />
          <textarea id="csv" value={csv} onChange={e => setCsv(e.target.value)} placeholder="Div,Date,Time,HomeTeam,AwayTeam,FTHG,FTAG,…" />
          <div><Button disabled={!csv} onClick={imp}>Import</Button></div>
        </div>
      </Card>
      {out ? <pre className="code">{out}</pre> : null}
    </>
  );
}

function Users() {
  const { t } = useApp();
  const u = useLoad<any[]>('/api/admin/users');
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [role, setRole] = useState('user'), [msg, setMsg] = useState('');
  const create = async () => { setMsg(''); try { await api('/api/admin/users', { method: 'POST', body: JSON.stringify({ email, password: pw, role }) }); setEmail(''); setPw(''); u.reload(); setMsg(t.saved); } catch (e) { setMsg((e as Error).message); } };
  const patch = async (id: number, body: object) => { try { await api(`/api/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(body) }); u.reload(); } catch (e) { setMsg((e as Error).message); } };
  return <Card title={t.users}>
    <div className="stack lg">
      <div className="tablewrap"><table><thead><tr><th>{t.email}</th><th>{t.role}</th><th>{t.active}</th><th>Login</th></tr></thead>
        <tbody>{(u.data ?? []).map(x => <tr key={x.id}><td>{x.email}</td>
          <td><select value={x.role} onChange={e => patch(x.id, { role: e.target.value })} aria-label={t.role}><option value="user">user</option><option value="admin">admin</option></select></td>
          <td><input type="checkbox" checked={!!x.active} onChange={e => patch(x.id, { active: e.target.checked })} aria-label={t.active} /></td>
          <td className="small">{x.last_login_at ?? '–'}</td></tr>)}</tbody></table></div>
      <div className="form-grid two">
        <Field label={t.email}><input id="nu-email" type="email" value={email} onChange={e => setEmail(e.target.value)} /></Field>
        <Field label={t.password} hint="≥ 12"><input id="nu-pw" type="password" autoComplete="new-password" value={pw} onChange={e => setPw(e.target.value)} /></Field>
        <Field label={t.role}><select id="nu-role" value={role} onChange={e => setRole(e.target.value)}><option value="user">user</option><option value="admin">admin</option></select></Field>
        <div style={{ alignSelf: 'end' }}><Button disabled={!email || pw.length < 12} onClick={create}>{t.createUser}</Button></div>
      </div>
      {msg ? <span className="small t-2">{msg}</span> : null}
    </div>
  </Card>;
}
