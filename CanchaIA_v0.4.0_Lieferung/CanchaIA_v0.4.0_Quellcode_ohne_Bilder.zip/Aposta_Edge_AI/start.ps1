# CanchaIA – Start unter Windows (PowerShell). Aufruf: .\start.ps1 [mock|live] [--no-install] [--no-build]
# Falls die Ausführung von Skripten gesperrt ist: powershell -ExecutionPolicy Bypass -File .\start.ps1 mock
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { Write-Error "Node.js >= 22.13 nicht gefunden (https://nodejs.org)."; exit 3 }
& node scripts/start.mjs @args
exit $LASTEXITCODE
