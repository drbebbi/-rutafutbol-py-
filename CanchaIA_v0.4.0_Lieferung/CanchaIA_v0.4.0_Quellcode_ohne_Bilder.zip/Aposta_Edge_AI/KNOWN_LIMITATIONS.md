# Bekannte Einschränkungen (v0.3.1)

Diese Liste ist absichtlich vollständig. Nichts davon ist verschwiegen oder "gelöst" dargestellt.

## Nicht verifiziert

| Bereich | Status | Grund / Was fehlt |
|---|---|---|
| Live-Abruf Highlightly | BLOCKED | (1) Nutzungsrechte für Wettanalysen nicht schriftlich bestätigt. (2) Kein Netzwerkzugang aus der Entwicklungsumgebung. Adapter nur gegen die OpenAPI-Spezifikation 8.2.7 getestet. |
| Live-Abruf The Odds API | NOT VERIFIED | Kein API-Schlüssel und kein Netzwerkzugang. Pilotmodus, kontrollierter Sync, BTTS, Ergebnisse und Credits nur mit nach der Doku nachgebauten Antworten getestet. Anleitung in [LIVE_API_TEST_REPORT.md](LIVE_API_TEST_REPORT.md). |
| Teamnamen The Odds API | NOT VERIFIED | Die Verknüpfung mit CSV-Teams ist mit typischen Namensformen getestet. Die tatsächlichen Schreibweisen von The Odds API sind nicht geprüft. Nicht verknüpfte Teams erscheinen als `unlinked_team` und brauchen einen manuellen Alias. |
| CSV football-data.co.uk | IMPLEMENTED / TESTED (Format) | Mit Beispieldateien im echten Spaltenformat getestet. Echte Saisondateien wurden nicht geladen (kein Download möglich). |
| Prognosequalität | UNVALIDATED | Kein Backtest auf echten Daten. Auf Mock-Daten kann es keine gültige Validierung geben. **STRONG_VALUE wird deshalb nie vergeben.** |
| Historische Rendite | nicht vorhanden | Es gibt keine. Der Mock-Backtest liefert absichtlich keine Rendite ("UNVOLLSTÄNDIG: keine zeitlich gültigen Marktquoten"). |
| Docker-Image | NOT VERIFIED | Kein Docker in der Umgebung. Dockerfile und Compose sind geschrieben, nicht gebaut. |
| Frontend-Typprüfung | nicht ausführbar | `@types/react` nicht installierbar. esbuild baut fehlerfrei, die Oberfläche (v0.3.1-Redesign) wurde in Chromium bei 1440 px und 390 px geprüft, nicht in echten iOS-/Android-Browsern. |
| Telegram/Webhook/Anthropic | NOT LIVE VERIFIED | Kein Netzwerkzugang. Mit Attrappen getestet. |
| Zahlungen | Testmodus | Banküberweisung: manueller Prüfablauf IMPLEMENTED/TESTED, ohne echte Bank. uPay: nur Schnittstelle und Testmodus, echte Integration NOT IMPLEMENTED (keine Händlerfreigabe). |
| Persönliche Telegram-/Webhook-Meldungen | NOT IMPLEMENTED | Persönliche Meldungen gibt es bewusst nur in der App. Systemweite Kanäle werden dafür nicht verwendet. |
| Base44 | NOT IMPLEMENTED | Kein Base44-Projekt und kein Zugang. Nur Architektur-Leitfaden in [BASE44_INTEGRATION.md](BASE44_INTEGRATION.md). |

## Fachliche Grenzen

- **Keine Verletzungs-/Sperrdaten.** Keiner der angebundenen Provider liefert sie laut Spezifikation. Die App zeigt das an und erfindet nichts.
- **Aufstellungen** fließen nicht in die Modelle ein, nur in die Datenqualitätsanzeige.
- **Modelle sind wettbewerbsgebunden.** Für Wettbewerbe ohne eigene Historie (z. B. Champions League: keine CSV bei football-data.co.uk) liefern die Modelle INSUFFICIENT DATA. Eine wettbewerbsübergreifende Teamstärke wäre eine Modelländerung und ist ohne Out-of-Sample-Nachweis bewusst nicht umgesetzt.
- **Alte Doppel-Teams** (aus einem v0.2.0-Live-Betrieb vor der Verknüpfung) werden nicht automatisch zusammengeführt. Sie erscheinen in der Datenqualität und werden manuell bereinigt.
- **Persönliche Meldungen** nutzen dieselben Schalter (`notify_*`) wie die systemweiten Meldungen. Für den ersten Admin steuern die Schalter weiterhin auch die systemweiten Meldungen. Trifft eine Änderung gleichzeitig Quote und EV, gibt es eine Meldung (Quote) statt zwei.
- **Märkte:** nur 1X2, Über/Unter (Torlinien aus der Konfiguration), BTTS. Keine Handicaps, Ecken, Karten, Halbzeit.
- **Highlightly-Marktnamen** sind in der Spezifikation nicht dokumentiert. Unbekannte Märkte landen in Admin → Missing Data und müssen nach dem ersten Live-Abruf ggf. im Mapper ergänzt werden.
- **Modellgewicht w = 0,35 (BALANCED)** ist eine vorläufige Annahme, keine gemessene Größe. Ein validierter Backtest ersetzt sie (kann auch 0 ergeben: dann folgt die App dem Markt und findet nur Abweichungen einzelner Buchmacher).
- **Pre-Closing-Quoten aus CSV** (`B365H`, `PSH`, `AvgH` …) haben bei football-data.co.uk keinen exakten Zeitstempel. Die App setzt "Anstoß − 24 h" und markiert sie als `time_estimated`. Backtests mit diesen Quoten sind deshalb eine Näherung.
- **Korrelation:** Höchstens eine Empfehlung je Spiel. Korrelation zwischen Spielen (z. B. gleiche Liga, gleicher Spieltag) wird nur angezeigt, nicht eingepreist.
- **EV ist eine Schätzung.** Auch ein validiertes Modell garantiert keinen Gewinn. Die App platziert keine Wetten.

## Betrieb

- **Eine Instanz.** Mehrere Prozesse auf derselben SQLite-Datei sind durch Locks abgesichert, aber nicht das Ziel. Für horizontale Skalierung siehe unten.
- **Rate-Limits im Arbeitsspeicher** (pro Prozess). Kontosperren nach Fehlversuchen und Provider-Sperren sind dagegen persistent.
- **Kein Passwort-Reset per E-Mail oder in der Oberfläche.** Der Betreiber setzt ein Passwort per Kommandozeile neu: `NEW_USER_PASSWORD='…' npm --prefix backend run user:password -- name@example.com` (beendet alle Sessions des Kontos).
- **Keine Zwei-Faktor-Anmeldung.**
- **Zeitzone:** Der tägliche Backtest richtet sich nach `APP_TIMEZONE`. Bei Zeitumstellung kann er einmal eine Stunde früher oder später laufen.
- **Abhängigkeitsversionen:** Ohne Registry-Zugang konnte kein `package-lock.json` erzeugt werden. Beim ersten `npm install` werden die Versionen aufgelöst. Danach einchecken und `npm audit` ausführen.

## Kosten und Budget

- Mit dem Standardbudget von 500 Credits/Monat (Tagesbudget 16) reichen die Credits bei 2 aktiven Pilot-Wettbewerben für **2 Läufe pro Tag**, nicht für stündliche Läufe. Rechnung und Optionen stehen in [API_INTEGRATION.md](API_INTEGRATION.md#the-odds-api-v4).

## Kommerzieller Start

Vor einem Verkauf als Softwareplattform offen (nicht Teil der Software, Status NICHT GEKLÄRT):

- Nutzungsrechte von football-data.co.uk und The Odds API für ein kostenpflichtiges Produkt und für die Anzeige an Endkunden
- Highlightly: schriftliche Freigabe für Wettanalysen
- Rechtliche Einordnung eines Dienstes mit Wettanalysen in den Zielmärkten (Paraguay und ggf. weitere)
- Steuer und Rechnung (RUC, Timbrado, IVA), AGB, Datenschutzerklärung, Aufbewahrung von Zahlungsbelegen
- uPay-Händlerfreigabe und echte Integration (Webhook-Signaturen, Erstattungen)
- Unabhängiger Sicherheitstest, Zwei-Faktor-Anmeldung, Passwort-Reset per E-Mail
- Validierung der Modelle auf echten Daten. Ohne bestandene Validierung kein Marketing mit Treffer- oder Renditeversprechen.

## Datenbank

SQLite (WAL) reicht für einen Betreiber mit stündlichem Lauf und einer Handvoll Benutzer. Postgres lohnt sich bei mehreren App-Instanzen, vielen gleichzeitigen Benutzern oder einer gemanagten Datenbank.

Migrationsplan:

1. **Zugriffsschicht:** Alle Abfragen laufen über `backend/src/db/db.ts` (`get`, `all`, `run`, `tx`). Diese Klasse durch eine Postgres-Variante (`pg`) mit derselben Schnittstelle ersetzen. Sie wird dabei asynchron, das betrifft alle Aufrufer (mechanische Umstellung auf `await`).
2. **SQL-Dialekt:** `INSERT … ON CONFLICT` funktioniert in beiden. Anzupassen sind `AUTOINCREMENT` → `GENERATED ALWAYS AS IDENTITY`, `datetime('now')` → `now()`, JSON-Spalten als `jsonb`, Platzhalter `?` → `$1…`.
3. **Unveränderliche Snapshots:** SQLite-Trigger `odds_snapshots_immutable` als Postgres-Trigger (`BEFORE UPDATE … RAISE EXCEPTION`, Ausnahme nur für `snapshot_kind`-Umklassifizierung beim CSV-Import) neu anlegen.
4. **Locks:** `job_locks` funktioniert unverändert. Alternativ `pg_try_advisory_lock`.
5. **Datenübernahme:** einmaliges Skript, das Tabelle für Tabelle in Abhängigkeitsreihenfolge kopiert, danach die Sequenzen setzen. Vorher `VACUUM INTO` als Backup.
6. **Tests:** Die Suite verwendet In-Memory-SQLite. Für Postgres einen Testcontainer oder eine Wegwerf-Datenbank pro Lauf vorsehen.

Status: NOT IMPLEMENTED (nur Plan).
