/**
 * Historische Spiele als Modell-Input. Alle Funktionen arbeiten nur mit Spielen VOR dem
 * Stichtag (`before`), damit weder Live-Prognosen noch Backtests Daten aus der Zukunft sehen.
 */
export interface HistMatch {
  eventId: number;
  competitionId: number;
  kickoff: string;     // ISO
  home: number;        // team id
  away: number;
  hg: number;
  ag: number;
  neutral?: boolean;
  xgH?: number | null;
  xgA?: number | null;
}

export const DAY_MS = 86_400_000;

/** Zeitgewicht: Halbwertszeit ~ 120 Tage. */
export function timeWeight(kickoff: string, before: string, xi = 0.0058): number {
  const days = (new Date(before).getTime() - new Date(kickoff).getTime()) / DAY_MS;
  return days < 0 ? 0 : Math.exp(-xi * days);
}

export function priorTo(ms: HistMatch[], before: string): HistMatch[] {
  return ms.filter(m => m.kickoff < before);
}

export interface LeagueMeans { home: number; away: number; n: number; drawRate: number }

export function leagueMeans(ms: HistMatch[], before: string): LeagueMeans {
  let wh = 0, wa = 0, w = 0, d = 0;
  for (const m of ms) {
    if (m.kickoff >= before) continue;
    const t = timeWeight(m.kickoff, before);
    wh += t * m.hg; wa += t * m.ag; w += t; if (m.hg === m.ag) d += t;
  }
  // Fallback auf allgemeine Fußball-Durchschnitte, wenn kaum Daten
  if (w < 1e-9) return { home: 1.45, away: 1.15, n: 0, drawRate: 0.26 };
  return { home: wh / w, away: wa / w, n: ms.filter(m => m.kickoff < before).length, drawRate: d / w };
}

export interface TeamForm {
  games: number; gf: number; ga: number; points: number;
  lastKickoff: string | null;
  xgFor: number | null; xgAgainst: number | null;
}

/** Letzte n Spiele eines Teams vor dem Stichtag. */
export function recentGames(ms: HistMatch[], team: number, before: string, n: number): HistMatch[] {
  const out: HistMatch[] = [];
  for (let i = ms.length - 1; i >= 0 && out.length < n; i--) {
    const m = ms[i];
    if (m.kickoff >= before) continue;
    if (m.home === team || m.away === team) out.push(m);
  }
  return out;
}

export function teamForm(ms: HistMatch[], team: number, before: string, n = 6): TeamForm {
  const g = recentGames(ms, team, before, n);
  let gf = 0, ga = 0, pts = 0, xf = 0, xa = 0, xn = 0;
  for (const m of g) {
    const home = m.home === team;
    const f = home ? m.hg : m.ag, a = home ? m.ag : m.hg;
    gf += f; ga += a; pts += f > a ? 3 : f === a ? 1 : 0;
    const xF = home ? m.xgH : m.xgA, xA = home ? m.xgA : m.xgH;
    if (xF != null && xA != null) { xf += xF; xa += xA; xn++; }
  }
  return { games: g.length, gf, ga, points: pts, lastKickoff: g[0]?.kickoff ?? null, xgFor: xn ? xf / xn : null, xgAgainst: xn ? xa / xn : null };
}

export function countTeamGames(ms: HistMatch[], team: number, before: string): number {
  let n = 0;
  for (const m of ms) if (m.kickoff < before && (m.home === team || m.away === team)) n++;
  return n;
}

/** Sortiert aufsteigend nach Anstoß (Voraussetzung für alle Funktionen hier). */
export function sortHist(ms: HistMatch[]): HistMatch[] {
  return [...ms].sort((a, b) => a.kickoff.localeCompare(b.kickoff) || a.eventId - b.eventId);
}
