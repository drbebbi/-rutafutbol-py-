/**
 * Antwortbeispiele für The Odds API v4 – NACHGEBAUT nach der offiziellen Dokumentation
 * (https://the-odds-api.com/liveapi/guides/v4/), KEINE aufgezeichneten echten Provider-Antworten.
 * Felder und Struktur entsprechen der Doku: id, sport_key, sport_title, commence_time, home_team, away_team,
 * bookmakers[].{key,title,last_update,markets[].{key,last_update,outcomes[].{name,price,point?}}}.
 * Zeiten werden relativ zu "jetzt" erzeugt, damit Frische-Regeln realistisch greifen.
 */
export const iso = (t: number) => new Date(t).toISOString().replace(/\.\d{3}Z$/, 'Z');

export function sportsList() {
  return [
    { key: 'soccer_epl', group: 'Soccer', title: 'EPL', description: 'English Premier League', active: true, has_outrights: false },
    { key: 'soccer_spain_la_liga', group: 'Soccer', title: 'La Liga - Spain', description: 'Spanish Soccer', active: true, has_outrights: false },
    { key: 'soccer_uefa_champs_league', group: 'Soccer', title: 'UEFA Champions League', description: 'European Champions League', active: false, has_outrights: false },
  ];
}

export function oddsEvent(o: { id: string; sport: string; title: string; home: string; away: string; kickoff: number; updatedAt: number; books?: { key: string; title: string; h: number; d: number; a: number; over?: number; under?: number }[] }) {
  const books = o.books ?? [
    { key: 'pinnacle', title: 'Pinnacle', h: 2.10, d: 3.60, a: 3.55, over: 1.95, under: 1.95 },
    { key: 'williamhill', title: 'William Hill', h: 2.05, d: 3.50, a: 3.40, over: 1.90, under: 1.90 },
    { key: 'unibet_eu', title: 'Unibet', h: 2.30, d: 3.55, a: 3.30, over: 1.97, under: 1.86 },
  ];
  return {
    id: o.id, sport_key: o.sport, sport_title: o.title, commence_time: iso(o.kickoff), home_team: o.home, away_team: o.away,
    bookmakers: books.map(b => ({
      key: b.key, title: b.title, last_update: iso(o.updatedAt),
      markets: [
        { key: 'h2h', last_update: iso(o.updatedAt), outcomes: [{ name: o.home, price: b.h }, { name: o.away, price: b.a }, { name: 'Draw', price: b.d }] },
        ...(b.over ? [{ key: 'totals', last_update: iso(o.updatedAt), outcomes: [{ name: 'Over', price: b.over, point: 2.5 }, { name: 'Under', price: b.under!, point: 2.5 }] }] : []),
      ],
    })),
  };
}

export function bttsEvent(e: { id: string; sport_key: string; sport_title: string; commence_time: string; home_team: string; away_team: string }, updatedAt: number) {
  return { ...e, bookmakers: [{ key: 'pinnacle', title: 'Pinnacle', last_update: iso(updatedAt), markets: [{ key: 'btts', last_update: iso(updatedAt), outcomes: [{ name: 'Yes', price: 1.80 }, { name: 'No', price: 2.02 }] }] }] };
}

export function scoresRow(e: { id: string; sport_key: string; commence_time: string; home_team: string; away_team: string }, hg: number | null, ag: number | null, completed: boolean) {
  return { ...e, sport_title: 'EPL', completed, scores: hg == null ? null : [{ name: e.home_team, score: String(hg) }, { name: e.away_team, score: String(ag) }], last_update: hg == null ? null : e.commence_time };
}

type Route = { status?: number; body: unknown; headers?: Record<string, string> };
/** Fake-Fetcher: Antwort je Pfad; protokolliert alle URLs (zum Prüfen, dass kein Schlüssel in Logs/Protokoll landet). */
export function fakeFetcher(routes: (path: string, q: URLSearchParams) => Route | null) {
  const calls: string[] = [];
  const fetcher = async (url: string) => {
    calls.push(url);
    const u = new URL(url);
    const r = routes(u.pathname, u.searchParams) ?? { status: 404, body: { message: 'Unknown' } };
    const h: Record<string, string> = { 'x-requests-remaining': '480', 'x-requests-used': '20', ...(r.headers ?? {}) };
    return { status: r.status ?? 200, headers: { get: (n: string) => h[n.toLowerCase()] ?? null }, text: async () => JSON.stringify(r.body) };
  };
  return { fetcher, calls };
}

/** football-data.co.uk-CSV (Hauptligen-Format) für eine kleine, synthetische E0-Historie. */
export function e0Csv(teams: string[], rounds = 2, startUtc = Date.UTC(2025, 7, 16)): string {
  const head = 'Div,Date,Time,HomeTeam,AwayTeam,FTHG,FTAG,FTR,PSH,PSD,PSA,PSCH,PSCD,PSCA';
  const rows: string[] = [];
  let day = 0, k = 0;
  for (let r = 0; r < rounds; r++) for (let i = 0; i < teams.length; i++) for (let j = 0; j < teams.length; j++) {
    if (i === j) continue;
    const d = new Date(startUtc + (day++) * 86_400_000);
    const ds = `${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')}/${d.getUTCFullYear()}`;
    const hg = (i * 7 + j * 3 + r + k++) % 4, ag = (j * 5 + i + r) % 3;
    rows.push(`E0,${ds},15:00,${teams[i]},${teams[j]},${hg},${ag},${hg > ag ? 'H' : hg < ag ? 'A' : 'D'},2.1,3.5,3.6,2.05,3.6,3.7`);
  }
  return [head, ...rows].join('\n');
}
