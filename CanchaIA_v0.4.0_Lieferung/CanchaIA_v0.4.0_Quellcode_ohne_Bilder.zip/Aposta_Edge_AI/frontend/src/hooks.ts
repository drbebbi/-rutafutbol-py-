import { useEffect, useState } from 'react';
import { api } from './api';

/** Lädt JSON von einem Pfad; reload() lädt neu. Bisherige Logik aus pages.tsx (v0.3.0), unverändert. */
export function useLoad<T>(path: string | null, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null), [err, setErr] = useState<unknown>(null), [n, setN] = useState(0);
  useEffect(() => { if (!path) return; let live = true; setErr(null);
    api<T>(path).then(d => live && setData(d)).catch(e => live && setErr(e)); return () => { live = false; }; }, [path, n, ...deps]);
  return { data, err, reload: () => setN(x => x + 1) };
}
