/**
 * Kontrollierte Diagnose-Synchronisierung (v0.3.0, Admin).
 *
 * Führt GENAU EINEN Sync mit begrenzter Spielanzahl aus und legt offen:
 *  - welche Provider bereit / NOT CONFIGURED / BLOCKED sind (ohne Schlüssel wird nichts abgerufen und nichts erfunden)
 *  - jeden tatsächlichen API-Abruf dieses Laufs (Endpunkt, bereinigte Parameter, Status, Cache, Credits)
 *  - gefundene Spiele je Wettbewerb, Teamzuordnung, Event-IDs, Quoten je Markt mit Zeitstempeln und Frische
 *  - automatische Prüfungen (Spieltermine, eindeutige IDs, vollständige Snapshots, Zeitstempel, keine begonnenen Spiele)
 * Der Bericht wird in diagnostic_runs gespeichert.
 */
import type { App } from '../app.js';
import { providerStates } from '../config.js';
import { OddsStore } from './odds.js';
import { checkFreshness, FUTURE_TOLERANCE_MIN } from './freshness.js';
import { json } from '../db/db.js';
import { nowIso } from '../util/core.js';
import type { MarketId } from '../providers/types.js';
import type { SyncSummary } from './discovery.js';
import { budgetBlockReason, estimateRunCost, paidGateReason } from './oddsApiStatus.js';

export interface DiagnosticCheck { name: string; ok: boolean; detail: string }

export interface ControlledSyncReport {
  diagnosticId: number; startedAt: string; finishedAt: string; clock: string; dataMode: string; isMock: boolean; pilot: { enabled: boolean; sportKeys: string[]; maxEvents: number };
  status: 'DONE' | 'NOT CONFIGURED' | 'NOT CONNECTED' | 'BUDGET' | 'FAILED' | 'BUSY';
  /** v0.3.3: geschätzte Credits dieses Laufs (The Odds API) vor dem ersten Abruf */
  costEstimate?: { credits: number | null; detail: string };
  liveVerification: 'LIVE VERIFIED' | 'NOT VERIFIED';
  providers: ReturnType<typeof providerStates>;
  summary: SyncSummary | null;
  apiRequests: { provider: string; endpoint: string; query: string | null; note: string | null; status: number; fromCache: boolean; cost: number; at: string }[];
  creditsUsed: Record<string, number>;
  budgets: unknown[];
  competitions: { competitionId: number; name: string; events: number; historicalMatches: number; modelsPossible: boolean }[];
  events: {
    eventId: number; kickoffUtc: string; competition: string; home: string; away: string; providerEventIds: string[];
    markets: Record<MarketId, { books: number; valid: number; fresh: number; newestRetrievedAt: string | null; newestSourceTimestamp: string | null }>;
    prediction: string; topSignal: string | null;
  }[];
  mapping: { linkedTeams: number; unlinkedTeams: { ref: string; detail: string | null }[]; unmatchedEvents: { ref: string; detail: string | null }[] };
  rejectedReasons: Record<string, number>;
  checks: DiagnosticCheck[];
  notes: string[];
}

export async function controlledSync(app: App, opts: { now?: Date; maxEvents?: number; userId?: number | null; withLock?: <T>(fn: () => Promise<T>) => Promise<{ started: boolean; result?: T; error?: string }> } = {}): Promise<ControlledSyncReport> {
  const now = opts.now ?? new Date();
  const wallStart = nowIso();
  const db = app.db, cfg = app.cfg;
  const maxEvents = Math.max(1, Math.min(opts.maxEvents ?? 10, cfg.pilot.enabled ? cfg.pilot.maxEventsPerRun : 60));
  const diagId = Number(db.run("INSERT INTO diagnostic_runs (kind, started_at, started_by, status) VALUES ('controlled_sync', ?, ?, 'running')", wallStart, opts.userId ?? null).lastInsertRowid);
  const providers = providerStates(cfg);
  const base: ControlledSyncReport = {
    diagnosticId: diagId, startedAt: wallStart, finishedAt: wallStart, clock: now.toISOString(), dataMode: cfg.dataMode, isMock: app.providers.isMock,
    pilot: { enabled: cfg.pilot.enabled, sportKeys: cfg.pilot.enabled ? cfg.pilot.sportKeys : cfg.theOddsApi.sportKeys, maxEvents },
    status: 'DONE', liveVerification: 'NOT VERIFIED', providers, summary: null, apiRequests: [], creditsUsed: {}, budgets: [], competitions: [], events: [],
    mapping: { linkedTeams: 0, unlinkedTeams: [], unmatchedEvents: [] }, rejectedReasons: {}, checks: [], notes: [],
  };
  const finish = (r: ControlledSyncReport) => {
    r.finishedAt = nowIso();
    db.run('UPDATE diagnostic_runs SET finished_at = ?, status = ?, report = ? WHERE id = ?', r.finishedAt, r.status, JSON.stringify(r).slice(0, 2_000_000), diagId);
    return r;
  };

  if (!app.providers.isMock && !app.providers.fixtures.length) {
    base.status = 'NOT CONFIGURED';
    base.notes.push('Kein Fixture-Provider bereit. Es wurde KEIN API-Abruf durchgeführt und es werden keine Live-Daten erzeugt. THE_ODDS_API_KEY setzen (Highlightly nur mit schriftlich bestätigten Nutzungsrechten).');
    return finish(base);
  }
  if (app.providers.isMock) base.notes.push('MOCK-MODUS: alle Spiele, Teams, Buchmacher und Quoten sind fiktiv. Dieser Lauf ist kein Live-Test.');

  // v0.3.3: The Odds API erst nach bestandenem Verbindungstest und nur, wenn der Kostenvoranschlag ins Budget passt
  if (!app.providers.isMock && app.providers.odds.some(p => p.name === 'theoddsapi')) {
    base.costEstimate = estimateRunCost(app);
    const gate = app.requireOddsConnectionTest ? paidGateReason(app) : null;
    if (gate) { base.status = 'NOT CONNECTED'; base.notes.push(`${gate} Es wurde KEIN kostenpflichtiger Abruf ausgeführt.`); return finish(base); }
    const budget = budgetBlockReason(app);
    if (budget) { base.status = 'BUDGET'; base.notes.push(`${budget} Es wurde KEIN kostenpflichtiger Abruf ausgeführt.`); return finish(base); }
    base.notes.push(`Kostenvoranschlag The Odds API: ${base.costEstimate.detail} Credits (tatsächliche Kosten laut x-requests-last im Abrufprotokoll).`);
  }

  const firstReq = db.get<{ id: number | null }>('SELECT MAX(id) AS id FROM api_requests')!.id ?? 0;
  const run = async () => app.sync.run(now, { maxFixtures: maxEvents, job: 'controlled_sync' });
  let summary: SyncSummary;
  if (opts.withLock) {
    const r = await opts.withLock(run);
    if (!r.started) { base.status = 'BUSY'; base.notes.push(`Nicht gestartet: ${r.error ?? 'ein Sync läuft bereits'}`); return finish(base); }
    if (!r.result) { base.status = 'FAILED'; base.notes.push(`Fehler: ${r.error}`); return finish(base); }
    summary = r.result;
  } else summary = await run();
  base.summary = summary;
  if (summary.status === 'failed') base.status = 'FAILED';

  // Jeder API-Abruf dieses Laufs
  const reqs = db.all<{ provider: string; endpoint: string; query: string | null; note: string | null; status: number; from_cache: number; cost: number; created_at: string }>(
    'SELECT provider, endpoint, query, note, status, from_cache, cost, created_at FROM api_requests WHERE id > ? ORDER BY id', firstReq);
  base.apiRequests = reqs.map(r => ({ provider: r.provider, endpoint: r.endpoint, query: r.query, note: r.note, status: r.status, fromCache: !!r.from_cache, cost: r.cost ?? 0, at: r.created_at }));
  for (const r of base.apiRequests) base.creditsUsed[r.provider] = (base.creditsUsed[r.provider] ?? 0) + r.cost;
  base.budgets = ['theoddsapi', 'highlightly'].map(p => app.queue.budgetStatus(p));
  if (!app.liveNetwork) base.notes.push('Test-Fetcher aktiv (eingespielte Antworten): Ergebnis gilt nicht als Live-Nachweis.');
  const realLive = app.liveNetwork && !app.providers.isMock && base.apiRequests.some(r => !r.fromCache && r.status >= 200 && r.status < 300 && r.provider !== 'mock');
  base.liveVerification = realLive && summary.fixturesFound > 0 && summary.oddsSnapshots > 0 ? 'LIVE VERIFIED' : 'NOT VERIFIED';
  if (base.liveVerification === 'LIVE VERIFIED') base.notes.push('Echte Provider-Antworten verarbeitet. LIVE VERIFIED gilt nur für diesen Lauf und die geprüften Punkte unten; Prognosequalität bleibt davon unberührt.');

  // Spiele im Fenster (nur aus diesem Modus)
  const store = new OddsStore(db);
  const mockSql = app.providers.isMock ? '' : 'AND e.is_mock = 0';
  const evs = db.all<{ id: number; kickoff_utc: string; status: string; competition_id: number; comp: string; home: string; away: string }>(
    `SELECT e.id, e.kickoff_utc, e.status, e.competition_id, c.name AS comp, th.name AS home, ta.name AS away FROM events e
       JOIN competitions c ON c.id = e.competition_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
      WHERE e.kickoff_utc > ? AND e.kickoff_utc <= ? AND e.status = 'scheduled' ${mockSql}
        AND EXISTS (SELECT 1 FROM odds_snapshots s WHERE s.event_id = e.id AND s.snapshot_kind = 'live')
      ORDER BY e.kickoff_utc LIMIT ?`, summary.window.from, summary.window.to, maxEvents * 3);
  for (const e of evs) {
    const markets = {} as ControlledSyncReport['events'][number]['markets'];
    for (const m of ['1X2', 'OU', 'BTTS'] as MarketId[]) {
      const books = store.latestPerBookmaker(e.id, m, m === 'OU' ? 2.5 : null);
      const fresh = books.filter(b => b.valid && checkFreshness({ retrievedAt: b.retrievedAt, sourceTimestamp: b.sourceTimestamp, kickoffUtc: e.kickoff_utc, snapshotKind: b.kind }, now, cfg.analysis.oddsMaxAgeMinutes).ok);
      const newest = books.map(b => b.retrievedAt).sort().pop() ?? null;
      const newestSrc = books.map(b => b.sourceTimestamp).filter(Boolean).sort().pop() ?? null;
      markets[m] = { books: books.length, valid: books.filter(b => b.valid).length, fresh: fresh.length, newestRetrievedAt: newest, newestSourceTimestamp: newestSrc };
    }
    const pred = db.get<{ data_quality: string; model_version: string }>('SELECT data_quality, model_version FROM predictions WHERE event_id = ? ORDER BY id DESC LIMIT 1', e.id);
    const dq = json.parse<{ status?: string; score?: number }>(pred?.data_quality ?? null, {});
    const sig = db.get<{ status: string; market_id: string; selection_id: string; ev: number | null }>('SELECT status, market_id, selection_id, ev FROM value_signals WHERE event_id = ? AND active = 1 ORDER BY ev_low DESC LIMIT 1', e.id);
    base.events.push({
      eventId: e.id, kickoffUtc: e.kickoff_utc, competition: e.comp, home: e.home, away: e.away,
      providerEventIds: db.all<{ p: string }>("SELECT provider || ':' || provider_event_id AS p FROM event_mappings WHERE event_id = ?", e.id).map(r => r.p),
      markets, prediction: pred ? `${dq.status ?? '?'} (${dq.score ?? '?'}/100, ${pred.model_version})` : 'keine Prognose (INSUFFICIENT DATA)',
      topSignal: sig ? `${sig.status} ${sig.market_id}/${sig.selection_id}${sig.ev != null ? ` EV ${(sig.ev * 100).toFixed(1)} %` : ''}` : null,
    });
  }

  // Wettbewerbe: genug Historie für Modelle?
  const compIds = [...new Set(evs.map(e => e.competition_id))];
  for (const c of compIds) {
    const hist = db.get<{ n: number }>("SELECT COUNT(*) AS n FROM events WHERE competition_id = ? AND status = 'finished' AND home_goals IS NOT NULL", c)!.n;
    base.competitions.push({ competitionId: c, name: evs.find(e => e.competition_id === c)!.comp, events: evs.filter(e => e.competition_id === c).length, historicalMatches: hist, modelsPossible: hist >= 80 });
    if (hist < 80) base.notes.push(`${evs.find(e => e.competition_id === c)!.comp}: nur ${hist} historische Spiele – Modelle liefern INSUFFICIENT DATA. CSV-Historie importieren (Champions League hat bei football-data.co.uk keine CSV).`);
  }

  // Zuordnung
  base.mapping.linkedTeams = db.get<{ n: number }>("SELECT COUNT(*) AS n FROM team_aliases a WHERE a.provider != 'football-data-csv' AND EXISTS (SELECT 1 FROM team_aliases b WHERE b.team_id = a.team_id AND b.provider = 'football-data-csv')")!.n;
  base.mapping.unlinkedTeams = db.all<{ ref: string; detail: string | null }>("SELECT ref, detail FROM missing_data WHERE kind = 'unlinked_team' AND last_seen >= ? ORDER BY last_seen DESC LIMIT 50", wallStart);
  base.mapping.unmatchedEvents = db.all<{ ref: string; detail: string | null }>("SELECT ref, detail FROM missing_data WHERE kind IN ('unmatched_event','ambiguous_event','swapped_home_away') AND last_seen >= ? ORDER BY last_seen DESC LIMIT 50", wallStart);

  // Ablehnungsgründe der in diesem Lauf gespeicherten Snapshots
  for (const r of db.all<{ e: string }>("SELECT validation_errors AS e FROM odds_snapshots WHERE processed_at >= ? AND validation_errors != '[]'", wallStart))
    for (const x of json.parse<string[]>(r.e, [])) { const k = x.replace(/\d+(\.\d+)?/g, '#'); base.rejectedReasons[k] = (base.rejectedReasons[k] ?? 0) + 1; }

  // Automatische Prüfungen
  const t = now.getTime();
  const chk = (name: string, ok: boolean, detail: string) => base.checks.push({ name, ok, detail });
  chk('Spieltermine in der Zukunft und im Fenster', base.events.every(e => Date.parse(e.kickoffUtc) > t && e.kickoffUtc <= summary.window.to), `${base.events.length} Spiele geprüft`);
  const ids = base.events.flatMap(e => e.providerEventIds);
  chk('Eindeutige Provider-Event-IDs', new Set(ids).size === ids.length && base.events.every(e => e.providerEventIds.length >= 1), `${ids.length} IDs`);
  const dup = db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM events a JOIN events b ON a.id < b.id AND a.home_team_id = b.home_team_id AND a.away_team_id = b.away_team_id
      AND ABS(julianday(a.kickoff_utc) - julianday(b.kickoff_utc)) < 0.125 WHERE a.kickoff_utc > ? ${mockSql.replace(/e\./g, 'a.')}`, now.toISOString())!.n;
  chk('Keine doppelten Spiele (gleiche Paarung ±3 h)', dup === 0, dup ? `${dup} mögliche Duplikate` : 'keine');
  const future = db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM odds_snapshots WHERE processed_at >= ? AND (retrieved_at > ? OR (source_timestamp IS NOT NULL AND source_timestamp > ?))`,
    wallStart, new Date(Date.parse(wallStart) + FUTURE_TOLERANCE_MIN * 60_000).toISOString(), new Date(t + FUTURE_TOLERANCE_MIN * 60_000).toISOString())!.n;
  chk('Zeitstempel plausibel (nicht in der Zukunft)', future === 0, future ? `${future} Snapshots mit Zukunftszeit` : 'ok');
  const incomplete = db.get<{ n: number }>("SELECT COUNT(*) AS n FROM odds_snapshots WHERE processed_at >= ? AND is_complete = 0", wallStart)!.n;
  chk('Vollständige Marktsnapshots', incomplete === 0, incomplete ? `${incomplete} unvollständige Snapshots (abgelehnt, nicht verwendet)` : 'alle vollständig');
  const startedRec = db.get<{ n: number }>("SELECT COUNT(*) AS n FROM recommendations r JOIN events e ON e.id = r.event_id WHERE r.active = 1 AND e.kickoff_utc <= ?", now.toISOString())!.n;
  chk('Keine Empfehlung für begonnene Spiele', startedRec === 0, `${summary.startedExcluded} begonnene Spiele beim Abruf ausgeschlossen`);
  const budgetOk = base.budgets.every((b: any) => b.used <= b.budget && (b.monthlyBudget == null || b.usedMonth <= b.monthlyBudget));
  chk('API-Budget eingehalten', budgetOk, Object.entries(base.creditsUsed).map(([p, c]) => `${p}: ${c} Credits`).join(', ') || '0 Credits');
  chk('Teamzuordnung ohne offene Fälle', !base.mapping.unlinkedTeams.length && !base.mapping.unmatchedEvents.length,
    `${base.mapping.unlinkedTeams.length} Teams ohne Verknüpfung, ${base.mapping.unmatchedEvents.length} Quoten ohne Spiel`);
  return finish(base);
}
