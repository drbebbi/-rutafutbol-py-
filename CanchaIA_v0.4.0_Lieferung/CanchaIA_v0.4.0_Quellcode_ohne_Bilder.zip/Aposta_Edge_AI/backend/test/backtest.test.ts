import { test } from 'node:test';
import assert from 'node:assert/strict';
import { memDb, simulateLeague, insertSyntheticLeague } from './helpers.js';
import { BacktestingEngine, pairedBootstrap } from '../src/engines/backtest.js';
import { buildElo, fitDixonColes, poissonStrength } from '../src/engines/prediction/models.js';
import { leagueMeans } from '../src/engines/prediction/history.js';

const { matches } = simulateLeague({ teams: 14, seasons: 3, home: 1.3, seed: 'calib' });
const before = new Date(new Date(matches[matches.length - 1].kickoff).getTime() + 3_600_000).toISOString();

test('Elo-Logit konvergiert: mittlere vorhergesagte Heim-/Remis-/Gastquote ≈ beobachtet (ML-Eigenschaft)', () => {
  const st = buildElo(matches, before);
  const data = st.history.slice(60);
  const sig = (x: number) => 1 / (1 + Math.exp(-x));
  let pA = 0, pD = 0, oA = 0, oD = 0;
  for (const h of data) { const a = sig(st.cut1 - st.slope * h.d / 100), ad = sig(st.cut2 - st.slope * h.d / 100); pA += a; pD += ad - a; if (h.res === 0) oA++; if (h.res === 1) oD++; }
  assert.ok(Math.abs(pA / data.length - oA / data.length) < 0.01, `Gast ${pA / data.length} vs ${oA / data.length}`);
  assert.ok(Math.abs(pD / data.length - oD / data.length) < 0.01, `Remis ${pD / data.length} vs ${oD / data.length}`);
});

test('Dixon-Coles: mittlere Torerwartung ≈ beobachtete Tore (Heim/Gast)', () => {
  const fit = fitDixonColes(matches, before, { prior: 0.001 })!;
  let lh = 0, la = 0, hg = 0, ag = 0;
  for (const m of matches) { lh += fit.attack.get(m.home)! * fit.defense.get(m.away)! * fit.home; la += fit.attack.get(m.away)! * fit.defense.get(m.home)!; hg += m.hg; ag += m.ag; }
  // Zeitgewichtung verschiebt leicht; Toleranz 8 %
  assert.ok(Math.abs(lh / hg - 1) < 0.08, `Heim ${lh / hg}`); assert.ok(Math.abs(la / ag - 1) < 0.08, `Gast ${la / ag}`);
});

test('Poisson-Stärke: Torerwartung liegt im Mittel beim Ligamittel', () => {
  const L = leagueMeans(matches, before);
  let s = 0, n = 0;
  for (let a = 1; a <= 14; a++) for (let b = 1; b <= 14; b++) if (a !== b) { const o = poissonStrength(matches, a, b, before); s += o.lambdaHome!; n++; }
  assert.ok(Math.abs(s / n / L.home - 1) < 0.1, `${s / n} vs ${L.home}`);
});

test('Bootstrap-Intervall: deterministisch und enthält den Mittelwert', () => {
  const d = Array.from({ length: 400 }, (_, i) => Math.sin(i) * 0.1 - 0.01);
  const a = pairedBootstrap(d, 'x')!, b = pairedBootstrap(d, 'x')!;
  assert.deepEqual(a, b);
  assert.ok(a.lo <= a.diff && a.diff <= a.hi);
});

test('Backtest mit Markt: Schlusskurse werden nie als Wettquote genutzt (Look-Ahead-Test)', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 14, seasons: 3, closingOdds: 50 });
  const r = new BacktestingEngine(db).run({ refitDays: 60, minMatches: 200 });
  const m = r.metrics;
  assert.ok(m.betting, 'Wettsimulation mit Pre-Closing-Quoten erwartet');
  assert.ok((m.betting!.avgOdds ?? 0) < 20, `Durchschnittsquote ${m.betting!.avgOdds}: Schlusskurs 50,0 darf nie gewettet werden`);
  assert.equal(m.bettingIncompleteReason, null);
  assert.ok(m.market['1X2']!.n > 0 && m.market['1X2']!.decision);
  assert.ok(m.blend['1X2']!.walkForwardByWeight.length > 0, 'Gewichtsvergleich auf dem Walk-Forward-Teil');
  assert.ok(m.comparisons['1X2']!.ensembleVsMarket, 'Vergleich Ensemble vs. Markt');
  assert.ok(m.byCompetition.length === 1);
  assert.notEqual(m.validation.status, 'VALIDATED', 'zu kleiner Holdout / synthetische Daten');
});

test('Backtest: Markt nahe der Wahrheit → kleines Modellgewicht, kein VALIDATED', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 16, seasons: 4, marketNoise: 0.01, seed: 'sharp' });
  const r = new BacktestingEngine(db).run({ refitDays: 60, minMatches: 200 });
  const m = r.metrics;
  // Der Markt kennt die wahren Stärken; das geschätzte Modell kann ihn nicht schlagen
  assert.ok(m.comparisons['1X2']!.ensembleVsMarket!.diff > 0, `Ensemble sollte schlechter als der Markt sein: ${JSON.stringify(m.comparisons['1X2'])}`);
  assert.ok((m.blend['1X2']!.chosenWeight ?? 1) <= 0.3, `gewähltes Gewicht ${m.blend['1X2']!.chosenWeight}`);
  assert.notEqual(m.validation.status, 'VALIDATED');
  const mv = db.get<{ validation_status: string; weights: string }>("SELECT validation_status, weights FROM model_versions WHERE id LIKE 'ensemble-1.1.0+bt%'")!;
  assert.notEqual(mv.validation_status, 'VALIDATED');
  assert.ok('blendWeight' in JSON.parse(mv.weights));
});

test('Backtest ohne zeitlich gültige Quoten: keine Rendite, als unvollständig markiert', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 14, seasons: 3, withOdds: false });
  const r = new BacktestingEngine(db).run({ refitDays: 60, minMatches: 200 });
  assert.equal(r.metrics.betting, null);
  assert.match(r.metrics.bettingIncompleteReason!, /UNVOLLSTÄNDIG/);
  assert.ok(r.metrics.validation.reasons.some(x => /Marktquoten/.test(x)));
});
