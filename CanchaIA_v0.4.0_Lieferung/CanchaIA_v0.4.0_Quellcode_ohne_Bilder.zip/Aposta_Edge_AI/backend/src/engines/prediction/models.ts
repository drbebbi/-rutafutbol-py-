/**
 * Die vier Einzelmodelle. Alle Parameter werden aus historischen Daten geschätzt;
 * es gibt keine von Hand gesetzten "validierten" Gewichte.
 *
 * 1. PoissonStrength  – zeitgewichtete Angriffs-/Abwehrstärken mit Schrumpfung zum Ligamittel
 * 2. DixonColes       – Maximum-Likelihood (Maher-Iteration) + Profil-Schätzung von ρ, zeitgewichtet
 * 3. Elo              – chronologische Elo-Ratings + geordnetes Logit für 1X2 (Parameter per ML)
 * 4. FeatureModel     – Poisson-Regression (IRLS, Ridge) auf zeitlich korrekten Merkmalen
 */
import { HistMatch, LeagueMeans, leagueMeans, timeWeight, teamForm, countTeamGames, DAY_MS } from './history.js';
import { dcTau, probsFromLambdas, Probs } from './poisson.js';

export interface ModelOutput {
  model: 'poisson' | 'dixon_coles' | 'elo' | 'feature';
  available: boolean;
  reason?: string;
  lambdaHome?: number;
  lambdaAway?: number;
  rho?: number;
  probs?: Partial<Probs>;
  meta?: Record<string, unknown>;
}

const MIN_TEAM_GAMES = 6;

// ---------------------------------------------------------------- 1. Poisson
export function poissonStrength(ms: HistMatch[], home: number, away: number, before: string, neutral = false): ModelOutput {
  const nH = countTeamGames(ms, home, before), nA = countTeamGames(ms, away, before);
  if (nH < MIN_TEAM_GAMES || nA < MIN_TEAM_GAMES) return { model: 'poisson', available: false, reason: `zu wenige Spiele (Heim ${nH}, Gast ${nA}, mindestens ${MIN_TEAM_GAMES})` };
  const L = leagueMeans(ms, before);
  const k = 3; // Pseudo-Spiele zum Ligamittel
  const rate = (team: number) => {
    let att = 0, def = 0, w = 0;
    for (const m of ms) {
      if (m.kickoff >= before) continue;
      const isH = m.home === team; if (!isH && m.away !== team) continue;
      const t = timeWeight(m.kickoff, before);
      const gf = isH ? m.hg : m.ag, ga = isH ? m.ag : m.hg;
      att += t * gf / (isH ? L.home : L.away);
      def += t * ga / (isH ? L.away : L.home);
      w += t;
    }
    return { att: (att + k) / (w + k), def: (def + k) / (w + k) };
  };
  const h = rate(home), a = rate(away);
  const hb = neutral ? (L.home + L.away) / 2 : L.home, ab = neutral ? (L.home + L.away) / 2 : L.away;
  const lh = hb * h.att * a.def, la = ab * a.att * h.def;
  return { model: 'poisson', available: true, lambdaHome: lh, lambdaAway: la, probs: probsFromLambdas(lh, la), meta: { leagueHome: L.home, leagueAway: L.away, attHome: h.att, defHome: h.def, attAway: a.att, defAway: a.def } };
}

// ---------------------------------------------------------------- 2. Dixon-Coles
export interface DcFit { attack: Map<number, number>; defense: Map<number, number>; home: number; rho: number; n: number; teams: number; logLik: number }

export function fitDixonColes(ms: HistMatch[], before: string, opts: { minMatches?: number; iterations?: number; prior?: number } = {}): DcFit | null {
  const data = ms.filter(m => m.kickoff < before).map(m => ({ ...m, w: timeWeight(m.kickoff, before) })).filter(m => m.w > 1e-4);
  if (data.length < (opts.minMatches ?? 80)) return null;
  const teams = [...new Set(data.flatMap(m => [m.home, m.away]))];
  const att = new Map(teams.map(t => [t, 1])), def = new Map(teams.map(t => [t, 1]));
  let gamma = 1.3;
  const prior = opts.prior ?? 2; // Schrumpfung: Pseudo-Beobachtungen mit Stärke 1
  for (let it = 0; it < (opts.iterations ?? 60); it++) {
    // Angriff
    for (const t of teams) {
      let num = prior, den = prior;
      for (const m of data) {
        if (m.home === t) { num += m.w * m.hg; den += m.w * def.get(m.away)! * (m.neutral ? 1 : gamma); }
        else if (m.away === t) { num += m.w * m.ag; den += m.w * def.get(m.home)!; }
      }
      att.set(t, num / den);
    }
    const meanA = teams.reduce((s, t) => s + att.get(t)!, 0) / teams.length;
    for (const t of teams) att.set(t, att.get(t)! / meanA);
    // Abwehr (Faktor für Gegentore)
    for (const t of teams) {
      let num = prior, den = prior;
      for (const m of data) {
        if (m.home === t) { num += m.w * m.ag; den += m.w * att.get(m.away)!; }
        else if (m.away === t) { num += m.w * m.hg; den += m.w * att.get(m.home)! * (m.neutral ? 1 : gamma); }
      }
      def.set(t, num / den);
    }
    // Heimvorteil
    let hn = 0, hd = 0;
    for (const m of data) if (!m.neutral) { hn += m.w * m.hg; hd += m.w * att.get(m.home)! * def.get(m.away)!; }
    gamma = hd > 0 ? hn / hd : 1;
  }
  // ρ per Profil-Likelihood (Goldener Schnitt) im zulässigen Bereich
  const ll = (rho: number) => {
    let s = 0;
    for (const m of data) {
      const lh = att.get(m.home)! * def.get(m.away)! * (m.neutral ? 1 : gamma), la = att.get(m.away)! * def.get(m.home)!;
      const tau = dcTau(m.hg, m.ag, lh, la, rho);
      if (tau <= 0) return -Infinity;
      s += m.w * (Math.log(tau) - lh - la + m.hg * Math.log(lh) + m.ag * Math.log(la));
    }
    return s;
  };
  let lo = -0.25, hi = 0.15;
  const g = (Math.sqrt(5) - 1) / 2;
  let c = hi - g * (hi - lo), d = lo + g * (hi - lo);
  for (let i = 0; i < 40; i++) { if (ll(c) > ll(d)) hi = d; else lo = c; c = hi - g * (hi - lo); d = lo + g * (hi - lo); }
  const rho = (lo + hi) / 2;
  return { attack: att, defense: def, home: gamma, rho, n: data.length, teams: teams.length, logLik: ll(rho) };
}

export function dixonColes(fit: DcFit | null, ms: HistMatch[], home: number, away: number, before: string, neutral = false): ModelOutput {
  if (!fit) return { model: 'dixon_coles', available: false, reason: 'zu wenige Ligaspiele für die Parameterschätzung (mindestens 80)' };
  const nH = countTeamGames(ms, home, before), nA = countTeamGames(ms, away, before);
  if (!fit.attack.has(home) || !fit.attack.has(away) || nH < 8 || nA < 8) return { model: 'dixon_coles', available: false, reason: `Team(s) ohne ausreichende Ligahistorie (Heim ${nH}, Gast ${nA}, mindestens 8)` };
  const lh = fit.attack.get(home)! * fit.defense.get(away)! * (neutral ? 1 : fit.home);
  const la = fit.attack.get(away)! * fit.defense.get(home)!;
  return { model: 'dixon_coles', available: true, lambdaHome: lh, lambdaAway: la, rho: fit.rho, probs: probsFromLambdas(lh, la, fit.rho), meta: { home: fit.home, rho: fit.rho, n: fit.n } };
}

// ---------------------------------------------------------------- 3. Elo
export interface EloState { ratings: Map<number, number>; homeAdv: number; k: number; history: { d: number; res: 0 | 1 | 2 }[]; cut1: number; cut2: number; slope: number; fitted: boolean }

export function buildElo(ms: HistMatch[], before: string, opts: { k?: number; homeAdv?: number } = {}): EloState {
  const k = opts.k ?? 20, homeAdv = opts.homeAdv ?? 65;
  const r = new Map<number, number>();
  const history: { d: number; res: 0 | 1 | 2 }[] = [];
  for (const m of ms) {
    if (m.kickoff >= before) break;
    const rh = r.get(m.home) ?? 1500, ra = r.get(m.away) ?? 1500;
    const d = rh + (m.neutral ? 0 : homeAdv) - ra;
    history.push({ d, res: m.hg > m.ag ? 2 : m.hg === m.ag ? 1 : 0 });
    const e = 1 / (1 + 10 ** (-d / 400));
    const s = m.hg > m.ag ? 1 : m.hg === m.ag ? 0.5 : 0;
    const gd = Math.abs(m.hg - m.ag);
    const mult = gd <= 1 ? 1 : Math.log(gd + 1) * 1.2;
    const delta = k * mult * (s - e);
    r.set(m.home, rh + delta); r.set(m.away, ra - delta);
  }
  const st: EloState = { ratings: r, homeAdv, k, history, cut1: -0.6, cut2: 0.55, slope: 0.5, fitted: false };
  fitOrderedLogit(st);
  return st;
}

const sig = (x: number) => 1 / (1 + Math.exp(-x));

/** Geordnetes Logit: P(Gast) = σ(c1 − b·d), P(Gast ∪ Remis) = σ(c2 − b·d), d in 100 Elo-Punkten. ML per Gradientenaufstieg. Erste 60 Spiele = Einschwingphase. */
function fitOrderedLogit(st: EloState): void {
  const data = st.history.slice(60).map(h => ({ d: h.d / 100, res: h.res }));
  if (data.length < 100) return;
  let c1 = -0.6, c2 = 0.55, b = 0.5;
  const lr = 1.0;
  for (let it = 0; it < 600; it++) {
    let g1 = 0, g2 = 0, gb = 0;
    for (const { d, res } of data) {
      const s1 = sig(c1 - b * d), s2 = sig(c2 - b * d);
      const pA = s1, pD = Math.max(1e-9, s2 - s1), pH = 1 - s2;
      // Ableitungen der Log-Likelihood
      if (res === 0) { const k1 = (1 - s1); g1 += k1; gb += -d * k1; }
      else if (res === 1) { const a1 = s1 * (1 - s1), a2 = s2 * (1 - s2); g1 += -a1 / pD; g2 += a2 / pD; gb += (d * a1 - d * a2) / pD; }
      else { const k2 = -s2; g2 += k2; gb += -d * k2; }
      void pA; void pH;
    }
    const n = data.length;
    c1 += lr * g1 / n; c2 += lr * g2 / n; b += lr * gb / n;
    if (c2 <= c1 + 0.05) c2 = c1 + 0.05;
  }
  st.cut1 = c1; st.cut2 = c2; st.slope = b; st.fitted = true;
}

export function elo(st: EloState, home: number, away: number, neutral = false): ModelOutput {
  if (!st.fitted) return { model: 'elo', available: false, reason: 'zu wenige Spiele zum Schätzen des Elo-Ergebnismodells (mindestens 160)' };
  if (!st.ratings.has(home) || !st.ratings.has(away)) return { model: 'elo', available: false, reason: 'Team ohne Elo-Historie' };
  const d = st.ratings.get(home)! + (neutral ? 0 : st.homeAdv) - st.ratings.get(away)!;
  const pA = sig(st.cut1 - st.slope * d / 100), pAD = sig(st.cut2 - st.slope * d / 100);
  return { model: 'elo', available: true, probs: { '1X2': { HOME: 1 - pAD, DRAW: pAD - pA, AWAY: pA } }, meta: { ratingHome: st.ratings.get(home), ratingAway: st.ratings.get(away), diff: d } };
}

// ---------------------------------------------------------------- 4. Merkmalsmodell
export const FEATURE_NAMES = ['home', 'att', 'oppDef', 'form', 'restDiff', 'xgAtt'] as const;

/** Merkmale für "Tore von team gegen opp" – ausschließlich aus Spielen vor `before`. */
export function featuresFor(ms: HistMatch[], L: LeagueMeans, team: number, opp: number, isHome: boolean, before: string, neutral: boolean): number[] | null {
  const ft = teamForm(ms, team, before, 8), fo = teamForm(ms, opp, before, 8);
  if (ft.games < 5 || fo.games < 5) return null;
  const mu = (L.home + L.away) / 2;
  const att = Math.log(((ft.gf / ft.games) + mu * 0.5) / (mu * 1.5));
  const oppDef = Math.log(((fo.ga / fo.games) + mu * 0.5) / (mu * 1.5));
  const recent = teamForm(ms, team, before, 4);
  const form = (recent.points / Math.max(1, recent.games) - ft.points / ft.games) / 3;
  const rest = (d: string | null) => d ? Math.min(10, (new Date(before).getTime() - new Date(d).getTime()) / DAY_MS) : 7;
  const restDiff = (rest(ft.lastKickoff) - rest(fo.lastKickoff)) / 7;
  const xgAtt = ft.xgFor != null && fo.xgAgainst != null ? Math.log((ft.xgFor + 0.2) / (mu + 0.2)) : att; // ohne xG: Torbasis
  return [neutral ? 0 : isHome ? 1 : 0, att, oppDef, form, restDiff, xgAtt];
}

export interface FeatureFit { beta: number[]; n: number; deviance: number }

/** Poisson-Regression per IRLS mit Ridge-Strafe (Achsenabschnitt unbestraft). */
export function fitFeatureModel(ms: HistMatch[], before: string, opts: { minRows?: number; ridge?: number } = {}): FeatureFit | null {
  const X: number[][] = [], y: number[] = [], w: number[] = [];
  const prior = ms.filter(m => m.kickoff < before);
  for (let i = 0; i < prior.length; i++) {
    const m = prior[i];
    const L = leagueMeans(prior, m.kickoff);
    if (L.n < 30) continue;
    const fh = featuresFor(prior, L, m.home, m.away, true, m.kickoff, !!m.neutral);
    const fa = featuresFor(prior, L, m.away, m.home, false, m.kickoff, !!m.neutral);
    const tw = timeWeight(m.kickoff, before, 0.004);
    if (fh) { X.push([1, ...fh]); y.push(m.hg); w.push(tw); }
    if (fa) { X.push([1, ...fa]); y.push(m.ag); w.push(tw); }
  }
  if (X.length < (opts.minRows ?? 200)) return null;
  const p = X[0].length, ridge = opts.ridge ?? 2;
  let beta = new Array(p).fill(0); beta[0] = Math.log(y.reduce((a, b) => a + b, 0) / y.length || 1.3);
  for (let it = 0; it < 25; it++) {
    const A = Array.from({ length: p }, () => new Array(p).fill(0)), bvec = new Array(p).fill(0);
    for (let i = 0; i < X.length; i++) {
      const eta = X[i].reduce((s, x, j) => s + x * beta[j], 0);
      const mu = Math.exp(Math.max(-5, Math.min(3, eta)));
      const z = eta + (y[i] - mu) / mu;
      const wi = w[i] * mu;
      for (let j = 0; j < p; j++) { bvec[j] += wi * X[i][j] * z; for (let k = 0; k < p; k++) A[j][k] += wi * X[i][j] * X[i][k]; }
    }
    for (let j = 1; j < p; j++) A[j][j] += ridge;
    const nb = solve(A, bvec);
    if (!nb) return null;
    const diff = Math.max(...nb.map((v, j) => Math.abs(v - beta[j])));
    beta = nb;
    if (diff < 1e-6) break;
  }
  let dev = 0;
  for (let i = 0; i < X.length; i++) { const mu = Math.exp(X[i].reduce((s, x, j) => s + x * beta[j], 0)); dev += 2 * w[i] * ((y[i] ? y[i] * Math.log(y[i] / mu) : 0) - (y[i] - mu)); }
  return { beta, n: X.length, deviance: dev };
}

export function featureModel(fit: FeatureFit | null, ms: HistMatch[], home: number, away: number, before: string, neutral = false): ModelOutput {
  if (!fit) return { model: 'feature', available: false, reason: 'zu wenige historische Team-Spiele zum Schätzen der Regression (mindestens 200 Zeilen)' };
  const L = leagueMeans(ms, before);
  const fh = featuresFor(ms, L, home, away, true, before, neutral), fa = featuresFor(ms, L, away, home, false, before, neutral);
  if (!fh || !fa) return { model: 'feature', available: false, reason: 'Merkmale unvollständig (weniger als 5 Spiele je Team)' };
  const lam = (f: number[]) => Math.exp([1, ...f].reduce((s, x, j) => s + x * fit.beta[j], 0));
  const lh = lam(fh), la = lam(fa);
  return { model: 'feature', available: true, lambdaHome: lh, lambdaAway: la, probs: probsFromLambdas(lh, la),
    meta: { coefficients: Object.fromEntries(['intercept', ...FEATURE_NAMES].map((n, i) => [n, +fit.beta[i].toFixed(4)])), featuresHome: fh, featuresAway: fa } };
}

function solve(A: number[][], b: number[]): number[] | null {
  const n = b.length, M = A.map((r, i) => [...r, b[i]]);
  for (let c = 0; c < n; c++) {
    let piv = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
    if (Math.abs(M[piv][c]) < 1e-12) return null;
    [M[c], M[piv]] = [M[piv], M[c]];
    for (let r = 0; r < n; r++) if (r !== c) { const f = M[r][c] / M[c][c]; for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k]; }
  }
  return M.map((r, i) => r[n] / M[i][i]);
}
