/** Seitenübergreifende Analyse-Bausteine: Value-Karte, Spielzeile, Zeitformat. */
import React from 'react';
import { fx, pct, signed, localTime } from '../api';
import { SEL, MKT, fmt } from '../i18n';
import { useApp } from '../components';
import { Badge, EdgeMeter, MockChip, SignalBadge } from '../ui';
import { LOCALE } from '../brand';

export function ValueCard({ r }: { r: any }) {
  const { t, u, lang, tz, go } = useApp();
  const s = r.signal;
  const open = () => go(`/match/${s.event_id}`);
  return (
    <article className="card vcard" role="link" tabIndex={0} aria-label={`${s.home} – ${s.away}`} onClick={open} onKeyDown={e => (e.key === 'Enter' || e.key === ' ') && (e.preventDefault(), open())}>
      <div className="vc-top">
        <span className="rank" aria-label={`Rang ${r.rank}`}>{r.rank}</span>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div className="teams">{s.home} – {s.away}</div>
          <div className="meta">{s.competition} · {localTime(s.kickoff_utc, tz, lang)}</div>
        </div>
        <div className="row-flex" style={{ justifyContent: 'flex-end' }}>{s.is_mock ? <MockChip /> : null}<SignalBadge s={s.status} /></div>
      </div>
      <div className="pick">
        <span className="what">{MKT[s.market_id]} · {SEL[lang][s.selection_id]}</span>
        <span className="odds">{fx(s.best_odds)}</span>
        <span className="book">{s.bookmaker_name}</span>
        <div className="ev"><div className="v">{signed(s.ev)}</div><div className="k">EV · {t.evLow} {signed(s.ev_low)}</div></div>
      </div>
      <EdgeMeter decision={s.decision_prob ?? s.model_prob} fair={s.novig_prob} odds={s.best_odds} />
      <div className="facts">
        <div><span>{t.modelProb}</span><b>{pct(s.model_prob)}</b></div>
        <div><span>{t.fairOdds}</span><b>{fx(s.fair_odds)}</b></div>
        <div><span>{t.quality}</span><b>{s.quality_score}/100</b></div>
        <div><span>{t.oddsAge}</span><b>{r.oddsAgeMinutes != null ? `${Math.round(r.oddsAgeMinutes)} min` : '–'}</b></div>
      </div>
      <div className="foot">
        <span>{t.validUntil} {r.validUntil ? localTime(r.validUntil, tz, lang, false) : '–'}</span>
        <span>{t.oddsSource}: {r.provider ?? '–'}{r.fromCache ? ` (${t.fromCache})` : ''}</span>
        {s.model_weight != null ? <span>{fmt(t.blend, { w: Math.round(s.model_weight * 100), m: Math.round((1 - s.model_weight) * 100) })}</span> : null}
        {r.correlatedSignalIds?.length ? <span className="warn">+{r.correlatedSignalIds.length} {t.correlated}</span> : null}
      </div>
      <span className="sr-only" style={{ position: 'absolute', left: -9999 }}>{u.details}</span>
    </article>
  );
}

export function dayLabel(iso: string, tz: string, lang: string) {
  return new Intl.DateTimeFormat(LOCALE[lang as keyof typeof LOCALE] ?? LOCALE.es, { timeZone: tz, weekday: 'short', day: '2-digit', month: '2-digit' }).format(new Date(iso));
}

/** Spielzeile; als Tabelle ab 900 px (Klasse .table an der Liste). */
export function MatchRow({ m }: { m: any }) {
  const { lang, tz, go, t, u } = useApp();
  const sig = m.top_signal;
  return (
    <a className="mrow" href={`#/match/${m.id}`} onClick={e => { e.preventDefault(); go(`/match/${m.id}`); }}>
      <span className="when">{localTime(m.kickoff_utc, tz, lang, false)}<span>{dayLabel(m.kickoff_utc, tz, lang)}</span></span>
      <span className="who"><b>{m.home} – {m.away}</b><span>{m.competition}{m.is_mock ? ' · MOCK' : ''}{m.analysis_status && m.analysis_status !== 'analysed' ? ` · ${t.analysis[m.analysis_status] ?? m.analysis_status}` : ''}</span></span>
      <span className="cols">
        <span className="t-2" style={{ textAlign: 'left', fontFamily: 'var(--f-ui)', fontSize: '.84rem' }}>{sig ? `${MKT[sig.market]} · ${SEL[lang][sig.selection] ?? sig.selection}` : '–'}</span>
        <span>{sig?.odds ? fx(sig.odds) : '–'}</span>
        <span className={sig?.ev != null ? (sig.ev > 0 ? 'pos' : 'neg') : 't-3'}>{sig?.ev != null ? signed(sig.ev) : '–'}</span>
        <span className="t-2">{m.bookmakers ?? 0}</span>
      </span>
      <span className="sigcol">{sig ? <SignalBadge s={sig.status} /> : <Badge tone="outline">{m.bookmakers ? `${m.bookmakers} ${u.colBooks.toLowerCase()}` : '–'}</Badge>}
        {sig?.ev != null ? <span className="num">EV {signed(sig.ev)}</span> : null}</span>
    </a>
  );
}
