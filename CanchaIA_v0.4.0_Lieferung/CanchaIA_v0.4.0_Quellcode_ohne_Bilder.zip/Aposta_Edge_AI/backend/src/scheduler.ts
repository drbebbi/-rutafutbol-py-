/**
 * Scheduler im Backend-Prozess (unabhängig von einem offenen Chat oder Browser).
 * - Kostenlose Spielsuche 'discovery' (THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES, Standard 30 min) und kostenpflichtiger
 *   Quoten-/Analyselauf 'hourly_sync' (THE_ODDS_API_ODDS_INTERVAL_MINUTES, Standard 60 min, mind. 15) getrennt (v0.4.0)
 * - Abrechnung 30 min, Validierung (Datenqualität → Backtest) täglich 04:00 Ortszeit, Bereinigung täglich
 * - DB-Lock mit kurzer Ablaufzeit (LOCK_TTL) und Heartbeat: der laufende Job verlängert sein Lock jede Minute.
 *   Stirbt der Prozess, läuft das Lock nach LOCK_TTL ab → keine dauerhafte Blockade.
 * - Abgestürzte Läufe (status 'running' ohne Heartbeat) werden beim Start und bei jedem Tick als 'interrupted' markiert.
 * - Fälligkeit: Intervall seit dem letzten ERFOLGREICHEN Lauf; nach einem Fehler/Abbruch frühestens nach RETRY_AFTER_FAIL erneut.
 *   Nach einem Neustart wird ein verpasster Lauf daher kontrolliert nachgeholt (einmal, nicht für jede verpasste Stunde).
 * - Kein Überholen: derselbe Job läuft nie zweimal gleichzeitig (Prozess-Set + DB-Lock).
 */
import type { App } from './app.js';
import { runValidation } from './engines/validation.js';
import { SubscriptionService } from './subscriptions.js';
import { Settlement } from './engines/performance.js';
import { nowIso, sha } from './util/core.js';
import { log, logError } from './util/log.js';

/** Strategie/Mindest-EV/Gewicht aus den Systemeinstellungen, damit der Backtest dieselben Regeln wie der Live-Betrieb nutzt. */
export function validationSettings(app: App) {
  const s = app.db.get<{ min_ev: number | null; strategy: string | null; model_weight: number | null }>('SELECT min_ev, strategy, model_weight FROM system_settings WHERE id = 1');
  return { minEv: s?.min_ev ?? app.cfg.analysis.minEv, strategy: (s?.strategy ?? app.cfg.analysis.strategy) as App['cfg']['analysis']['strategy'], modelWeight: s?.model_weight ?? null,
    maxRecommendations: app.cfg.analysis.maxRecommendations, timezone: app.cfg.timezone };
}

export const LOCK_TTL_MIN = 10;
export const HEARTBEAT_MS = 60_000;
export const STALE_RUN_MIN = 15;
export const RETRY_AFTER_FAIL_MIN = 10;

interface Job { name: string; intervalMin: number; dailyAtHour?: number; run: (now: Date) => Promise<unknown> }

export class Scheduler {
  private timer: NodeJS.Timeout | null = null;
  readonly holder = `${process.pid}-${sha(String(Math.random()), 6)}`;
  private jobs: Job[];
  private running = new Set<string>();

  constructor(private app: App) {
    this.jobs = [
      // v0.4.0: kostenlose Spielsuche und kostenpflichtiger Quoten-/Analyselauf mit getrennten Intervallen
      { name: 'discovery', intervalMin: app.cfg.theOddsApi.discoveryIntervalMinutes, run: now => app.sync.discover(now) },
      { name: 'hourly_sync', intervalMin: app.cfg.analysis.syncIntervalMinutes, run: now => app.sync.run(now) },
      { name: 'settlement', intervalMin: 30, run: async now => new Settlement(app.db).run(now) },
      // v0.4.0: derselbe Weg wie die manuelle Validierung (Datenqualitätsprüfung, Blocker je Wettbewerb, Bericht)
      { name: 'backtest', intervalMin: 1440, dailyAtHour: 4, run: async () => {
        const r = runValidation(app.db, { includeMock: app.providers.isMock, ...validationSettings(app) });
        return { validationId: r.id, status: r.status, backtestRunId: r.backtestRunId, reasons: r.reasons.slice(0, 20) };
      } },
      { name: 'cleanup', intervalMin: 1440, run: async now => ({ cache: app.queue.purgeExpiredCache(), requests: app.db.run("DELETE FROM api_requests WHERE created_at < ?", new Date(now.getTime() - 35 * 86_400_000).toISOString()).changes,
        sessions: app.db.run('DELETE FROM sessions WHERE expires_at < ?', nowIso(now)).changes,
        // v0.3.0: abgelaufene Abos und Aufbewahrungsfrist der Zahlungsbelege
        ...(() => { const sv = new SubscriptionService(app.db, app.cfg, () => now); return { expiredSubscriptions: sv.expireDue(), purgedProofs: sv.purgeOldProofs() }; })() }) },
    ];
  }

  start(): void {
    if (this.timer) return;
    const n = this.recoverStaleRuns(new Date());
    log.info('Scheduler gestartet', { jobs: this.jobs.map(j => `${j.name}/${j.intervalMin}min`), recoveredRuns: n });
    const tick = () => { void this.tick(new Date()); };
    setTimeout(tick, 5_000);
    this.timer = setInterval(tick, 60_000);
  }
  stop(): void { if (this.timer) clearInterval(this.timer); this.timer = null; }

  /** Läufe ohne Heartbeat (Absturz/Neustart) als 'interrupted' markieren. */
  recoverStaleRuns(now: Date): number {
    const cutoff = new Date(now.getTime() - STALE_RUN_MIN * 60_000).toISOString();
    return this.app.db.run(`UPDATE sync_runs SET status = 'interrupted', finished_at = ?, error = COALESCE(error, 'abgebrochen: kein Heartbeat (Prozessabsturz oder Neustart)')
      WHERE status = 'running' AND COALESCE(heartbeat_at, started_at) < ?`, nowIso(now), cutoff).changes;
  }

  private lastAt(job: string, statuses: string[]): Date | null {
    const r = this.app.db.get<{ started_at: string }>(`SELECT started_at FROM sync_runs WHERE job = ? AND status IN (${statuses.map(() => '?').join(',')}) ORDER BY started_at DESC LIMIT 1`, job, ...statuses);
    return r ? new Date(r.started_at) : null;
  }
  lastRun(job: string): Date | null { return this.lastAt(job, ['done', 'paused_quota', 'running', 'failed', 'interrupted']); }

  isDue(j: Job, now: Date): boolean {
    const ok = this.lastAt(j.name, ['done', 'paused_quota', 'running']);
    const fail = this.lastAt(j.name, ['failed', 'interrupted']);
    if (fail && (!ok || fail > ok) && now.getTime() - fail.getTime() < RETRY_AFTER_FAIL_MIN * 60_000) return false;
    if (j.dailyAtHour != null) {
      const h = Number(new Intl.DateTimeFormat('en-GB', { timeZone: this.app.cfg.timezone, hour: '2-digit', hour12: false }).format(now));
      return h === j.dailyAtHour && (!ok || now.getTime() - ok.getTime() > 20 * 3_600_000);
    }
    return !ok || now.getTime() - ok.getTime() >= j.intervalMin * 60_000;
  }

  private acquire(name: string, now: Date): boolean {
    const exp = new Date(now.getTime() + LOCK_TTL_MIN * 60_000).toISOString();
    const r = this.app.db.run(`INSERT INTO job_locks (name, holder, expires_at, heartbeat_at) VALUES (?, ?, ?, ?)
      ON CONFLICT(name) DO UPDATE SET holder = excluded.holder, expires_at = excluded.expires_at, heartbeat_at = excluded.heartbeat_at
      WHERE job_locks.expires_at < ? OR job_locks.holder = excluded.holder`, name, this.holder, exp, nowIso(now), nowIso(now));
    return r.changes > 0;
  }
  /** Lock verlängern und Heartbeat des laufenden Laufs schreiben. Gibt false zurück, wenn das Lock verloren ging. */
  heartbeat(name: string, now: Date = new Date()): boolean {
    const exp = new Date(now.getTime() + LOCK_TTL_MIN * 60_000).toISOString();
    const r = this.app.db.run('UPDATE job_locks SET expires_at = ?, heartbeat_at = ? WHERE name = ? AND holder = ?', exp, nowIso(now), name, this.holder);
    this.app.db.run("UPDATE sync_runs SET heartbeat_at = ? WHERE job = ? AND status = 'running'", nowIso(now), name);
    return r.changes > 0;
  }
  private release(name: string) { this.app.db.run('DELETE FROM job_locks WHERE name = ? AND holder = ?', name, this.holder); }

  async tick(now: Date): Promise<void> {
    this.recoverStaleRuns(now);
    for (const j of this.jobs) {
      if (this.running.has(j.name) || !this.isDue(j, now)) continue;
      await this.runJob(j.name, now);
    }
  }

  /**
   * Führt fn exklusiv unter dem Lock eines Jobs aus (z. B. kontrollierter Diagnose-Sync unter 'hourly_sync'),
   * damit nie zwei Synchronisierungen gleichzeitig laufen.
   */
  async withLock<T>(name: string, fn: () => Promise<T>, now: Date = new Date()): Promise<{ started: boolean; result?: T; error?: string }> {
    if (this.running.has(name) || !this.acquire(name, now)) return { started: false, error: 'läuft bereits' };
    this.running.add(name);
    const hb = setInterval(() => { if (!this.heartbeat(name)) log.warn(`${name}: Lock verloren`); }, HEARTBEAT_MS);
    hb.unref();
    try { return { started: true, result: await fn() }; }
    catch (e) { logError(this.app.db, `lock.${name}`, e); return { started: true, error: (e as Error).message }; }
    finally { clearInterval(hb); this.running.delete(name); this.release(name); }
  }

  /** Startet einen Job sofort (Admin). Gibt started=false zurück, wenn er bereits läuft. */
  async runJob(name: string, now: Date = new Date()): Promise<{ started: boolean; result?: unknown; error?: string }> {
    const j = this.jobs.find(x => x.name === name);
    if (!j) return { started: false, error: 'unbekannter Job' };
    if (this.running.has(name) || !this.acquire(name, now)) return { started: false, error: 'läuft bereits' };
    this.running.add(name);
    const isSync = name === 'hourly_sync';
    const rid = isSync ? null : this.app.db.run("INSERT INTO sync_runs (job, started_at, status, heartbeat_at) VALUES (?, ?, 'running', ?)", name, nowIso(now), nowIso(now)).lastInsertRowid;
    const hb = setInterval(() => { if (!this.heartbeat(name)) log.warn(`${name}: Lock verloren`); }, HEARTBEAT_MS);
    hb.unref();
    try {
      const result = await j.run(now);
      if (rid) this.app.db.run("UPDATE sync_runs SET status = 'done', finished_at = ?, summary = ? WHERE id = ?", nowIso(), JSON.stringify(result ?? {}).slice(0, 20_000), rid);
      return { started: true, result };
    } catch (e) {
      logError(this.app.db, `job.${name}`, e);
      if (rid) this.app.db.run("UPDATE sync_runs SET status = 'failed', finished_at = ?, error = ? WHERE id = ?", nowIso(), (e as Error).message, rid);
      else if (!this.app.db.run("UPDATE sync_runs SET status = 'failed', finished_at = ?, error = ? WHERE job = ? AND status = 'running'", nowIso(), (e as Error).message, name).changes)
        this.app.db.run("INSERT INTO sync_runs (job, started_at, finished_at, status, error) VALUES (?, ?, ?, 'failed', ?)", name, nowIso(now), nowIso(), (e as Error).message);
      return { started: true, error: (e as Error).message };
    } finally {
      clearInterval(hb);
      this.running.delete(name);
      this.release(name);
    }
  }

  status(now: Date = new Date()) {
    return this.jobs.map(j => {
      const last = this.app.db.get<{ status: string; started_at: string; finished_at: string | null; heartbeat_at: string | null; error: string | null }>(
        'SELECT status, started_at, finished_at, heartbeat_at, error FROM sync_runs WHERE job = ? ORDER BY id DESC LIMIT 1', j.name);
      const ok = this.lastAt(j.name, ['done', 'paused_quota']);
      const lock = this.app.db.get<{ holder: string; expires_at: string; heartbeat_at: string | null }>('SELECT holder, expires_at, heartbeat_at FROM job_locks WHERE name = ?', j.name);
      return { name: j.name, intervalMin: j.intervalMin, running: this.running.has(j.name), due: this.isDue(j, now),
        lastRun: last?.started_at ?? null, lastStatus: last?.status ?? null, lastError: last?.error ?? null, lastHeartbeat: last?.heartbeat_at ?? null,
        lastSuccess: ok?.toISOString() ?? null, nextDue: ok ? new Date(ok.getTime() + j.intervalMin * 60_000).toISOString() : 'sofort',
        lock: lock ? { holder: lock.holder, expiresAt: lock.expires_at, mine: lock.holder === this.holder } : null };
    });
  }
}
