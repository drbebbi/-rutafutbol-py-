/**
 * Import historischer Ergebnisse und Schlussquoten im CSV-Format von football-data.co.uk.
 * Unterstützt das Hauptligen-Format (Div, Date, HomeTeam, AwayTeam, FTHG, FTAG, PSCH/PSCD/PSCA, PC>2.5/PC<2.5 …)
 * und das Format der Zusatzligen (Country, League, Season, Date, Home, Away, HG, AG, PSCH/PSCD/PSCA …).
 * Die Dateien lädt der Betreiber selbst herunter (Nutzungsbedingungen der Quelle beachten).
 */
import type { Db } from '../db/db.js';
import { EventMatchingEngine } from '../engines/matching.js';
import { OddsStore, validateQuote } from '../engines/odds.js';
import type { ProviderFixture, ProviderOddsQuote, SelectionId } from './types.js';

const DIV_NAMES: Record<string, [string, string]> = {
  E0: ['Premier League', 'GB'], E1: ['Championship', 'GB'], E2: ['League One', 'GB'], E3: ['League Two', 'GB'], SC0: ['Scottish Premiership', 'GB'],
  D1: ['Bundesliga', 'DE'], D2: ['2. Bundesliga', 'DE'], I1: ['Serie A', 'IT'], I2: ['Serie B', 'IT'], SP1: ['La Liga', 'ES'], SP2: ['Segunda División', 'ES'],
  F1: ['Ligue 1', 'FR'], F2: ['Ligue 2', 'FR'], N1: ['Eredivisie', 'NL'], B1: ['Jupiler Pro League', 'BE'], P1: ['Primeira Liga', 'PT'], T1: ['Süper Lig', 'TR'], G1: ['Super League Greece', 'GR'],
};

export function parseCsv(text: string): Record<string, string>[] {
  const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter(l => l.trim());
  if (!lines.length) return [];
  const split = (l: string) => {
    const out: string[] = []; let cur = '', q = false;
    for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; }
    out.push(cur); return out.map(s => s.trim());
  };
  const head = split(lines[0]);
  return lines.slice(1).map(l => { const v = split(l); return Object.fromEntries(head.map((h, i) => [h, v[i] ?? ''])); });
}

/**
 * football-data.co.uk gibt Datum und Uhrzeit in britischer Ortszeit an (GMT im Winter, BST = UTC+1 im Sommer).
 * v0.2.0 zog pauschal 1 h ab – im Winter lag der Anstoß dadurch 1 h zu früh (reproduzierbarer Fehler, Test vorhanden).
 * Jetzt: Sommerzeit vom letzten Sonntag im März 01:00 UTC bis zum letzten Sonntag im Oktober 01:00 UTC.
 */
export function ukLocalToUtc(y: number, mon: number, d: number, hh: number, mm: number): Date {
  const lastSunday = (month: number) => { const t = new Date(Date.UTC(y, month + 1, 0)); t.setUTCDate(t.getUTCDate() - t.getUTCDay()); return t.getUTCDate(); };
  const bstStart = Date.UTC(y, 2, lastSunday(2), 1, 0), bstEnd = Date.UTC(y, 9, lastSunday(9), 1, 0);
  const asIfUtc = Date.UTC(y, mon, d, hh, mm);
  const inBst = asIfUtc - 3_600_000 >= bstStart && asIfUtc - 3_600_000 < bstEnd;
  return new Date(asIfUtc - (inBst ? 3_600_000 : 0));
}

function parseDate(d: string, t: string | undefined): string | null {
  const m = /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/.exec(d.trim());
  if (!m) return null;
  let y = Number(m[3]); if (y < 100) y += y < 70 ? 2000 : 1900;
  const [hh, mm] = (t && /^\d{1,2}:\d{2}$/.test(t) ? t : '15:00').split(':').map(Number);
  return ukLocalToUtc(y, Number(m[2]) - 1, Number(m[1]), hh, mm).toISOString();
}

const num = (s: string | undefined) => { const n = Number(s); return s && Number.isFinite(n) && n > 1 ? n : undefined; };

export function rowsToFixtures(rows: Record<string, string>[], fileLabel: string): { fx: ProviderFixture; odds: Omit<ProviderOddsQuote, 'providerEventId'>[] }[] {
  const out: { fx: ProviderFixture; odds: Omit<ProviderOddsQuote, 'providerEventId'>[] }[] = [];
  for (const r of rows) {
    const home = r.HomeTeam || r.Home, away = r.AwayTeam || r.Away;
    const hg = r.FTHG ?? r.HG, ag = r.FTAG ?? r.AG;
    const kickoff = parseDate(r.Date, r.Time);
    if (!home || !away || hg === '' || ag === '' || hg == null || ag == null || !kickoff) continue;
    const div = r.Div;
    const [compName, cc] = div ? (DIV_NAMES[div] ?? [div, null]) : [`${r.Country} ${r.League}`.trim(), null];
    const season = r.Season || seasonOf(kickoff);
    const compId = div ? `div:${div}` : `lg:${r.Country}:${r.League}`;
    const fx: ProviderFixture = {
      provider: 'football-data-csv', providerEventId: `${compId}:${kickoff.slice(0, 10)}:${home}:${away}`,
      competition: { providerId: compId, name: compName, countryCode: cc, countryName: r.Country || null, season },
      home: { providerId: 'name:' + home, name: home }, away: { providerId: 'name:' + away, name: away },
      kickoffUtc: kickoff, status: 'finished', homeGoals: Number(hg), awayGoals: Number(ag),
    };
    // Zeitpunkte: Schlusskurse ≈ Anstoß − 1 min. Pre-Closing-Kurse erfasst football-data.co.uk laut eigener Angabe
    // vor dem Spieltag (meist Freitag bzw. Dienstag); der genaue Zeitpunkt fehlt → konservativ Anstoß − 24 h, als geschätzt markiert.
    const kick = new Date(kickoff).getTime();
    const closeAt = new Date(kick - 60_000).toISOString(), preAt = new Date(kick - 24 * 3_600_000).toISOString();
    const odds: Omit<ProviderOddsQuote, 'providerEventId'>[] = [];
    const add = (kind: 'pre_closing' | 'closing', bk: string, name: string, market: '1X2' | 'OU', vals: (number | undefined)[]) => {
      if (vals.some(v => v == null)) return;
      const t = kind === 'closing' ? closeAt : preAt;
      const prices = (market === '1X2' ? { HOME: vals[0], DRAW: vals[1], AWAY: vals[2] } : { OVER: vals[0], UNDER: vals[1] }) as Partial<Record<SelectionId, number>>;
      odds.push({ provider: 'football-data-csv', marketStatus: 'open', retrievedAt: t, sourceTimestamp: null, snapshotKind: kind, timeEstimated: true,
        bookmakerProviderId: bk, bookmakerName: name, market, line: market === 'OU' ? 2.5 : null, prices });
    };
    // Pre-Closing (zum Entscheidungszeitpunkt verfügbar)
    add('pre_closing', 'pinnacle', 'Pinnacle', '1X2', [num(r.PSH), num(r.PSD), num(r.PSA)]);
    add('pre_closing', 'bet365', 'Bet365', '1X2', [num(r.B365H), num(r.B365D), num(r.B365A)]);
    add('pre_closing', 'market_avg', 'Marktdurchschnitt', '1X2', [num(r.AvgH), num(r.AvgD), num(r.AvgA)]);
    add('pre_closing', 'pinnacle', 'Pinnacle', 'OU', [num(r['P>2.5']), num(r['P<2.5'])]);
    add('pre_closing', 'bet365', 'Bet365', 'OU', [num(r['B365>2.5']), num(r['B365<2.5'])]);
    add('pre_closing', 'market_avg', 'Marktdurchschnitt', 'OU', [num(r['Avg>2.5']), num(r['Avg<2.5'])]);
    // Schlusskurse (nur für CLV und als Benchmark, NIE als damals verfügbare Wettquote)
    add('closing', 'pinnacle', 'Pinnacle', '1X2', [num(r.PSCH), num(r.PSCD), num(r.PSCA)]);
    add('closing', 'bet365', 'Bet365', '1X2', [num(r.B365CH), num(r.B365CD), num(r.B365CA)]);
    add('closing', 'market_avg', 'Marktdurchschnitt', '1X2', [num(r.AvgCH), num(r.AvgCD), num(r.AvgCA)]);
    add('closing', 'pinnacle', 'Pinnacle', 'OU', [num(r['PC>2.5']), num(r['PC<2.5'])]);
    add('closing', 'bet365', 'Bet365', 'OU', [num(r['B365C>2.5']), num(r['B365C<2.5'])]);
    add('closing', 'market_avg', 'Marktdurchschnitt', 'OU', [num(r['AvgC>2.5']), num(r['AvgC<2.5'])]);
    out.push({ fx, odds });
    void fileLabel;
  }
  return out;
}

function seasonOf(iso: string): string {
  const d = new Date(iso); const y = d.getUTCFullYear();
  return d.getUTCMonth() >= 6 ? `${y}/${y + 1}` : `${y - 1}/${y}`;
}

/** Idempotent: erneuter Import derselben Datei erzeugt keine Duplikate (Event-Schlüssel + Snapshot-Hash). */
export function importFootballDataCsv(db: Db, text: string, label = 'csv'): { matches: number; odds: number; skipped: number } {
  const match = new EventMatchingEngine(db), store = new OddsStore(db);
  const rows = parseCsv(text);
  const items = rowsToFixtures(rows, label);
  let odds = 0;
  db.tx(() => {
    for (const it of items) {
      const m = match.upsertFixture(it.fx);
      for (const q of it.odds) {
        // Historische Schlusskurse: Aktualitätsprüfung relativ zum Abrufzeitpunkt (Anstoß − 1 min)
        const full: ProviderOddsQuote = { ...q, providerEventId: it.fx.providerEventId };
        const errs = validateQuote(full, { now: new Date(q.retrievedAt), maxAgeMinutes: 90, kickoffUtc: it.fx.kickoffUtc, mappingConfidence: 1, historical: true });
        store.save(m.eventId, full, errs, false);
        odds++;
      }
    }
  });
  return { matches: items.length, odds, skipped: rows.length - items.length };
}
