/**
 * EventMatchingEngine: ordnet Provider-Events internen Events zu.
 * 1. Bestehendes Mapping (Provider + Event-ID)
 * 2. Gleiche Provider-Team-IDs (wenn Provider Fixture-Quelle ist)
 * 3. Fuzzy: Anstoß ±2 h, beide Teamnamen Ähnlichkeit ≥ 0,85, eindeutiger Kandidat, Heim/Gast nicht vertauscht
 */
import type { Db } from '../db/db.js';
import type { ProviderFixture } from '../providers/types.js';
import { Repository } from './repository.js';
import { nameSimilarity, normName, nowIso } from '../util/core.js';
import { noteMissing } from '../util/log.js';

export interface MatchResult { eventId: number; confidence: number; method: 'id' | 'alias' | 'fuzzy' | 'created'; swapped?: boolean }

export class EventMatchingEngine {
  private repo: Repository;
  constructor(private db: Db) { this.repo = new Repository(db); }

  existing(provider: string, providerEventId: string): MatchResult | null {
    const r = this.db.get<{ event_id: number; confidence: number; method: string }>('SELECT event_id, confidence, method FROM event_mappings WHERE provider = ? AND provider_event_id = ?', provider, providerEventId);
    return r ? { eventId: r.event_id, confidence: r.confidence, method: r.method as MatchResult['method'] } : null;
  }

  private remember(provider: string, providerEventId: string, eventId: number, confidence: number, method: string) {
    this.db.run('INSERT OR REPLACE INTO event_mappings (provider, provider_event_id, event_id, confidence, method) VALUES (?, ?, ?, ?, ?)', provider, providerEventId, eventId, confidence, method);
  }

  /** Fixture-Provider: Event anlegen oder aktualisieren (Teams/Wettbewerb über Provider-IDs). */
  upsertFixture(f: ProviderFixture): MatchResult {
    const isMock = !!f.isMock;
    this.db.run(`INSERT INTO provider_events (provider, provider_event_id, raw_home, raw_away, raw_competition, kickoff_utc, fetched_at) VALUES (?, ?, ?, ?, ?, ?, ?)
                 ON CONFLICT(provider, provider_event_id) DO UPDATE SET kickoff_utc = excluded.kickoff_utc, fetched_at = excluded.fetched_at`,
      f.provider, f.providerEventId, f.home.name, f.away.name, f.competition.name, f.kickoffUtc, nowIso());
    const compId = this.repo.upsertCompetition(f.provider, f.competition, isMock);
    const home = this.repo.upsertTeam(f.provider, f.home, isMock, compId), away = this.repo.upsertTeam(f.provider, f.away, isMock, compId);
    const prev = this.existing(f.provider, f.providerEventId);
    if (prev) {
      this.db.run(`UPDATE events SET kickoff_utc = ?, status = ?, home_goals = COALESCE(?, home_goals), away_goals = COALESCE(?, away_goals), round = COALESCE(?, round), venue = COALESCE(?, venue), updated_at = ? WHERE id = ?`,
        f.kickoffUtc, f.status, f.homeGoals ?? null, f.awayGoals ?? null, f.round ?? null, f.venue ?? null, nowIso(), prev.eventId);
      return prev;
    }
    // Gleiche Paarung zur gleichen Zeit bereits von anderer Quelle angelegt?
    const same = this.db.get<{ id: number }>('SELECT id FROM events WHERE home_team_id = ? AND away_team_id = ? AND ABS(julianday(kickoff_utc) - julianday(?)) < 0.09', home, away, f.kickoffUtc);
    const eventId = same?.id ?? this.db.run(
      `INSERT INTO events (competition_id, season, round, home_team_id, away_team_id, kickoff_utc, status, home_goals, away_goals, venue, is_mock) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      compId, f.competition.season ?? null, f.round ?? null, home, away, f.kickoffUtc, f.status, f.homeGoals ?? null, f.awayGoals ?? null, f.venue ?? null, isMock ? 1 : 0).lastInsertRowid;
    this.remember(f.provider, f.providerEventId, eventId, 1, same ? 'alias' : 'id');
    return { eventId, confidence: 1, method: same ? 'alias' : 'created' };
  }

  /** Odds-Provider ohne gemeinsame IDs: Rohdaten einem bestehenden Event zuordnen. Null = keine sichere Zuordnung. */
  matchRaw(provider: string, providerEventId: string, rawHome: string, rawAway: string, kickoffUtc: string): MatchResult | null {
    const prev = this.existing(provider, providerEventId);
    if (prev) return prev;
    const cands = this.db.all<{ id: number; home: string; away: string; kickoff_utc: string; home_team_id: number; away_team_id: number }>(
      `SELECT e.id, th.name AS home, ta.name AS away, e.kickoff_utc, e.home_team_id, e.away_team_id FROM events e
         JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
        WHERE ABS(julianday(e.kickoff_utc) - julianday(?)) <= 0.0834 AND e.status IN ('scheduled','unknown')`, kickoffUtc);
    const aliasScore = (teamId: number, raw: string, canonical: string) => {
      const a = this.db.get('SELECT 1 FROM team_aliases WHERE team_id = ? AND alias_norm = ?', teamId, normName(raw || ''));
      return a ? 1 : nameSimilarity(raw, canonical);
    };
    const scored = cands.map(c => {
      const straight = Math.min(aliasScore(c.home_team_id, rawHome, c.home), aliasScore(c.away_team_id, rawAway, c.away));
      const swapped = Math.min(nameSimilarity(rawHome, c.away), nameSimilarity(rawAway, c.home));
      return { c, straight, swapped };
    }).sort((a, b) => b.straight - a.straight);
    const best = scored[0];
    if (!best || best.straight < 0.85) {
      if (scored.some(s => s.swapped >= 0.85)) noteMissing(this.db, 'swapped_home_away', `${provider}:${providerEventId}`, `${rawHome} vs ${rawAway}`);
      else noteMissing(this.db, 'unmatched_event', `${provider}:${providerEventId}`, `${rawHome} vs ${rawAway} @ ${kickoffUtc}`);
      return null;
    }
    if (scored[1] && scored[1].straight >= best.straight - 0.05) {
      noteMissing(this.db, 'ambiguous_event', `${provider}:${providerEventId}`, `${rawHome} vs ${rawAway}`);
      return null;
    }
    this.remember(provider, providerEventId, best.c.id, best.straight, 'fuzzy');
    // Namen als Alias lernen, damit künftige Zuordnungen exakt sind
    this.repo.addTeamAlias(best.c.home_team_id, provider, null, rawHome);
    this.repo.addTeamAlias(best.c.away_team_id, provider, null, rawAway);
    return { eventId: best.c.id, confidence: best.straight, method: 'fuzzy' };
  }
}
