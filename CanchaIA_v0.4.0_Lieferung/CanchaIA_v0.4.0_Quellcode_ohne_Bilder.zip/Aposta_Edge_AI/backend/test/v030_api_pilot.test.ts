/**
 * v0.3.0 – Verbesserung 1 (API/Konfiguration) und 2 (kontrollierter Live-/Pilotbetrieb).
 * Alle Provider-Antworten sind nach der Doku nachgebaut (test/fixtures/theOddsApiSamples.ts), es gibt keinen Netzwerkzugriff.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { configIssues, loadConfig, providerStates, effectiveSportKeys } from '../src/config.js';
import { ApiQueue } from '../src/api/apiQueue.js';
import { TheOddsApiProvider, scoreToFixture } from '../src/providers/theOddsApi.js';
import { oddsCacheMaxAgeSeconds } from '../src/engines/freshness.js';
import { buildApp } from '../src/app.js';
import { controlledSync } from '../src/engines/diagnostic.js';
import { importFootballDataCsv, ukLocalToUtc } from '../src/providers/footballDataCsv.js';
import { EventMatchingEngine } from '../src/engines/matching.js';
import { memDb, testConfig } from './helpers.js';
import { bttsEvent, e0Csv, fakeFetcher, oddsEvent, scoresRow, sportsList } from './fixtures/theOddsApiSamples.js';

const MIN = 60_000, H = 3_600_000;
const KEY = 'test-odds-key-not-real';

function queueWith(routes: Parameters<typeof fakeFetcher>[0], clock: () => Date, monthly = 500) {
  const db = memDb();
  // v0.3.4: Legacy-Fixtures kommen nun kostenlos über /events; Quoten separat über /odds.
  const f = fakeFetcher((path, params) => {
    if (/^\/v4\/sports\/[^/]+\/events$/.test(path)) {
      const old = routes(path.replace(/\/events$/, '/odds'), params);
      const body = Array.isArray(old?.body) ? old.body.map(({ bookmakers, ...e }: any) => e) : [];
      return { body, headers: { 'x-requests-last': '0' } };
    }
    return routes(path, params);
  });
  const q = new ApiQueue(db, f.fetcher, clock, 0.001);
  q.register({ provider: 'theoddsapi', dailyBudget: 100, monthlyBudget: monthly, maxConcurrent: 1, minIntervalMs: 0, remainingHeader: 'x-requests-remaining', costHeader: 'x-requests-last' });
  return { db, q, calls: f.calls };
}

test('V1-B: The Odds API wird als Fixture-Provider erkannt (keine falsche Diagnose)', () => {
  const only = loadConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY } as NodeJS.ProcessEnv);
  const issues = configIssues(only);
  assert.ok(!issues.some(i => /Fixture-Provider/.test(i)), `falsche Meldung: ${issues.join(' | ')}`);
  assert.ok(!issues.some(i => /Quoten-Provider/.test(i)));
  const st = providerStates(only);
  assert.equal(st.find(p => p.provider === 'theoddsapi')!.status, 'READY');
  assert.ok(st.find(p => p.provider === 'theoddsapi')!.roles.includes('fixtures'));
  assert.equal(st.find(p => p.provider === 'highlightly')!.status, 'NOT CONFIGURED');
  // ohne Schlüssel: klare Meldung, beide NOT CONFIGURED
  const none = loadConfig({ DATA_MODE: 'live' } as NodeJS.ProcessEnv);
  assert.ok(configIssues(none).some(i => /Kein freigegebener Fixture-Provider/.test(i)));
  assert.equal(providerStates(none).find(p => p.provider === 'theoddsapi')!.status, 'NOT CONFIGURED');
  // Highlightly mit Schlüssel, aber ohne Rechte: BLOCKED, auch wenn The Odds API bereit ist
  const hl = loadConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, HIGHLIGHTLY_API_KEY: 'x' } as NodeJS.ProcessEnv);
  assert.equal(providerStates(hl).find(p => p.provider === 'highlightly')!.status, 'BLOCKED');
});

test('V1-A: BTTS standardmäßig aus; gezielt aktivierbar, begrenzt je Lauf', async () => {
  const now = Date.now();
  const evs = [1, 2, 3].map(i => oddsEvent({ id: `ev${i}`, sport: 'soccer_epl', title: 'EPL', home: `Home ${i}`, away: `Away ${i}`, kickoff: now + (10 + i) * H, updatedAt: now - MIN }));
  const routes = (p: string) => p.endsWith('/odds') && p.includes('/events/') ? { body: bttsEvent(evs.find(e => p.includes(e.id))!, now - MIN), headers: { 'x-requests-last': '2' } }
    : p.endsWith('/odds') ? { body: evs, headers: { 'x-requests-last': '4' } } : null;
  // aus
  const a = queueWith(routes, () => new Date());
  const off = new TheOddsApiProvider(a.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'] });
  const fxA = await off.upcomingFixtures(new Date(now), new Date(now + 48 * H));
  const qa = await off.oddsForFixtures(fxA);
  assert.equal(qa.filter(x => x.market === 'BTTS').length, 0);
  assert.equal(a.calls.filter(c => c.includes('/events/')).length, 0, 'keine teuren Event-Abrufe');
  assert.match(off.lastRunReport().markets.BTTS.reason!, /nicht aktiviert/);
  // an, höchstens 2 je Lauf
  const b = queueWith(routes, () => new Date());
  const on = new TheOddsApiProvider(b.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'], includeBtts: true, bttsMaxEventsPerRun: 2 });
  const qb = await on.oddsForFixtures(await on.upcomingFixtures(new Date(now), new Date(now + 48 * H)));
  assert.equal(b.calls.filter(c => c.includes('/events/')).length, 2);
  assert.equal(new Set(qb.filter(x => x.market === 'BTTS').map(x => x.providerEventId)).size, 2);
  const rep = on.lastRunReport().markets.BTTS;
  assert.equal(rep.events, 2); assert.match(rep.reason!, /Limit 2/);
  assert.deepEqual([...new Set(qb.filter(x => x.market === 'BTTS').map(x => x.providerEventId))].sort(), ['ev1', 'ev2'], 'nächste Anstöße zuerst');
});

test('V1-A: BTTS pausiert, wenn die Monatsbudget-Reserve unterschritten ist (Kernmärkte haben Vorrang)', async () => {
  const now = Date.now();
  const evs = [oddsEvent({ id: 'ev1', sport: 'soccer_epl', title: 'EPL', home: 'H', away: 'A', kickoff: now + 5 * H, updatedAt: now - MIN })];
  const c = queueWith(p => p.includes('/events/') ? { body: bttsEvent(evs[0], now), headers: { 'x-requests-last': '2' } } : { body: evs, headers: { 'x-requests-last': '4' } }, () => new Date(), 5);
  const p = new TheOddsApiProvider(c.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'], includeBtts: true, bttsReservePct: 25 });
  const q = await p.oddsForFixtures(await p.upcomingFixtures(new Date(now), new Date(now + 48 * H)));
  assert.ok(q.some(x => x.market === '1X2'), 'Kernmärkte geladen');
  assert.equal(c.calls.filter(u => u.includes('/events/')).length, 0, 'BTTS nicht angefragt');
  assert.match(p.lastRunReport().markets.BTTS.reason!, /Reserve/);
});

test('V1-C: dynamischer Cache – in der letzten Stunde wird eine 6 min alte Cache-Kopie verworfen', async () => {
  assert.equal(oddsCacheMaxAgeSeconds(30), 5 * 60, '< 1 h: halbe 10-min-Grenze');
  assert.equal(oddsCacheMaxAgeSeconds(3 * 60), 15 * 60, '1–6 h: halbe 30-min-Grenze');
  assert.equal(oddsCacheMaxAgeSeconds(30 * 60), 20 * 60, 'Obergrenze 20 min');
  assert.equal(oddsCacheMaxAgeSeconds(30, 90, false), 150, 'ohne Quellzeit strenger (halbe 5-min-Grenze)');
  assert.equal(oddsCacheMaxAgeSeconds(1, 4, false), 120, 'Untergrenze 2 min');
  let clock = new Date();
  const t0 = clock.getTime();
  const soon = [oddsEvent({ id: 'soon', sport: 'soccer_epl', title: 'EPL', home: 'H', away: 'A', kickoff: t0 + 40 * MIN, updatedAt: t0 - MIN })];
  const later = [oddsEvent({ id: 'later', sport: 'soccer_epl', title: 'EPL', home: 'H2', away: 'A2', kickoff: t0 + 3 * H, updatedAt: t0 - MIN })];
  for (const [evs, expectCalls] of [[soon, 2], [later, 1]] as const) {
    clock = new Date(t0);
    const c = queueWith(() => ({ body: evs, headers: { 'x-requests-last': '4' } }), () => clock);
    const p = () => new TheOddsApiProvider(c.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl'] });
    await p().upcomingFixtures(new Date(t0), new Date(t0 + 48 * H));
    clock = new Date(t0 + 6 * MIN);
    const second = p();
    await second.upcomingFixtures(new Date(t0), new Date(t0 + 48 * H));
    assert.equal(c.calls.filter(u => new URL(u).pathname.endsWith('/odds')).length, 0, 'nur kostenlose Spielsuche');
    assert.equal(c.calls.filter(u => new URL(u).pathname.endsWith('/events')).length, 2, 'Fixture-Cache läuft nach fünf Minuten ab');
    const log = c.q.recentRequests({ limit: 5 });
    assert.ok(log.some(r => r.endpoint.endsWith('/events') && r.cost === 0), 'Fixture-Suche wird mit 0 Credits protokolliert');
  }
});

test('V1: Credit-Grenzen bleiben wirksam; jeder Abruf wird ohne Schlüssel protokolliert', async () => {
  const now = Date.now();
  const evs = [oddsEvent({ id: 'e', sport: 'soccer_epl', title: 'EPL', home: 'H', away: 'A', kickoff: now + 10 * H, updatedAt: now - MIN })];
  const c = queueWith(() => ({ body: evs, headers: { 'x-requests-last': '4' } }), () => new Date(), 6);
  const p = new TheOddsApiProvider(c.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: ['soccer_epl', 'soccer_spain_la_liga'] });
  const fixtures = await p.upcomingFixtures(new Date(now), new Date(now + 48 * H));
  assert.equal(c.q.usedThisMonth('theoddsapi'), 0, 'Spielsuche gratis');
  const first = fixtures[0];
  assert.ok(first);
  // v0.4.0: Budget wird VOR dem ersten kostenpflichtigen Abruf geprüft – der zweite Wettbewerb wird gar nicht erst angefragt
  await p.oddsForFixtures([
    { ...first, competition: { ...first.competition, providerId: 'soccer_epl' } },
    { ...first, providerEventId: 'other-event', competition: { ...first.competition, providerId: 'soccer_spain_la_liga' } },
  ]);
  assert.equal(c.calls.filter(x => new URL(x).pathname.endsWith('/odds')).length, 1, 'zweiter Quotenabruf wird wegen Budget nicht gesendet');
  assert.ok(p.lastRunReport().skippedSportKeys.some(k => k.key === 'soccer_spain_la_liga' && /Budget/.test(k.reason) && /Monatsbudget/.test(k.reason)), JSON.stringify(p.lastRunReport().skippedSportKeys));
  await assert.rejects(p.oddsForFixtures([{ ...first, competition: { ...first.competition, providerId: 'soccer_epl' } }]), /kein Quotenabruf/, 'Budget erschöpft → kein Abruf');
  assert.equal(c.q.usedThisMonth('theoddsapi'), 4);
  const log = c.q.recentRequests();
  assert.ok(log.length >= 1);
  for (const r of log) assert.ok(!JSON.stringify(r).includes(KEY), 'Schlüssel nie im Protokoll');
  const paidLog = log.find(r => r.endpoint.endsWith('/odds'))!;
  assert.ok(paidLog, 'ein tatsächlicher Quotenabruf');
  assert.match(paidLog.query ?? '', /markets=h2h,totals/);
  assert.match(paidLog.note ?? '', /odds h2h,totals soccer_epl/);
});

test('V2: Pilotmodus prüft Sport-Keys gegen /v4/sports und überspringt inaktive', async () => {
  const cfg = loadConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, PILOT_MODE: 'true', PILOT_SPORT_KEYS: 'soccer_epl,soccer_spain_la_liga,soccer_uefa_champs_league,soccer_gibt_es_nicht' } as NodeJS.ProcessEnv);
  assert.deepEqual(effectiveSportKeys(cfg), ['soccer_epl', 'soccer_spain_la_liga', 'soccer_uefa_champs_league', 'soccer_gibt_es_nicht']);
  const now = Date.now();
  const c = queueWith(p => p === '/v4/sports' ? { body: sportsList() } : { body: [], headers: { 'x-requests-last': '0' } }, () => new Date());
  const p = new TheOddsApiProvider(c.q, { apiKey: KEY, baseUrl: 'https://api.the-odds-api.com', regions: 'eu,uk', sportKeys: effectiveSportKeys(cfg), pilot: true });
  await p.upcomingFixtures(new Date(now), new Date(now + 48 * H));
  const r = p.lastRunReport();
  assert.deepEqual(r.sportKeys, ['soccer_epl', 'soccer_spain_la_liga']);
  assert.deepEqual(r.skippedSportKeys.map(s => s.key).sort(), ['soccer_gibt_es_nicht', 'soccer_uefa_champs_league']);
  assert.equal(c.calls.filter(u => u.includes('/odds')).length, 0, 'Spielsuche darf keine Credits kosten');
  assert.equal(c.calls.filter(u => new URL(u).pathname.endsWith('/events')).length, 2, 'nur aktive Wettbewerbe werden kostenlos durchsucht');
});

test('V2: Wettbewerbe und Teams werden zwischen CSV und The Odds API verknüpft (konservativ)', () => {
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY }), { db: memDb() });
  const teams = ['Arsenal', 'Man United', 'Man City', 'Liverpool', 'Nott\'m Forest', 'Wolves', 'Newcastle', 'Tottenham'];
  const imp = importFootballDataCsv(app.db, e0Csv(teams, 2), 'E0.csv');
  assert.equal(imp.matches, 112);
  const m = new EventMatchingEngine(app.db);
  const ko = new Date(Date.now() + 30 * H).toISOString();
  const r = m.upsertFixture({ provider: 'theoddsapi', providerEventId: 'abc', competition: { providerId: 'soccer_epl', name: 'EPL' }, home: { providerId: 'name:Manchester United', name: 'Manchester United' }, away: { providerId: 'name:Nottingham Forest', name: 'Nottingham Forest' }, kickoffUtc: ko, status: 'scheduled' });
  const ev = app.db.get<{ competition_id: number; home: string; away: string }>('SELECT e.competition_id, th.name AS home, ta.name AS away FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id WHERE e.id = ?', r.eventId)!;
  const csvComp = app.db.get<{ competition_id: number }>("SELECT competition_id FROM competition_aliases WHERE provider = 'football-data-csv' AND provider_id = 'div:E0'")!.competition_id;
  assert.equal(ev.competition_id, csvComp, 'soccer_epl ↔ div:E0');
  assert.equal(ev.home, 'Man United'); assert.equal(ev.away, "Nott'm Forest");
  assert.ok(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM events WHERE competition_id = ? AND status = 'finished'", csvComp)!.n >= 80, 'Historie für Modelle verfügbar');
  // nicht verwechseln: "Manchester City" → Man City, nicht Man United
  const r2 = m.upsertFixture({ provider: 'theoddsapi', providerEventId: 'def', competition: { providerId: 'soccer_epl', name: 'EPL' }, home: { providerId: 'name:Manchester City', name: 'Manchester City' }, away: { providerId: 'name:Arsenal', name: 'Arsenal' }, kickoffUtc: ko, status: 'scheduled' });
  assert.equal(app.db.get<{ n: string }>('SELECT th.name AS n FROM events e JOIN teams th ON th.id = e.home_team_id WHERE e.id = ?', r2.eventId)!.n, 'Man City');
  // unbekanntes Team: wird NICHT geraten, sondern getrennt angelegt und gemeldet
  m.upsertFixture({ provider: 'theoddsapi', providerEventId: 'ghi', competition: { providerId: 'soccer_epl', name: 'EPL' }, home: { providerId: 'name:Sunderland AFC', name: 'Sunderland AFC' }, away: { providerId: 'name:Liverpool', name: 'Liverpool' }, kickoffUtc: ko, status: 'scheduled' });
  assert.ok(app.db.get("SELECT 1 FROM missing_data WHERE kind = 'unlinked_team' AND ref = 'theoddsapi:name:Sunderland AFC'"));
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM teams WHERE name = 'Sunderland AFC'")!.n, 1);
});

test('V2: Kontrollierter Sync (Live-Modus, nachgebaute Antworten): Bericht, Abrufprotokoll, Prüfungen, keine begonnenen Spiele', async () => {
  const now = Date.now();
  const teams = ['Arsenal', 'Man United', 'Man City', 'Liverpool', 'Chelsea', 'Everton', 'Brighton', 'Fulham'];
  const evs = [
    oddsEvent({ id: 'oa-1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Manchester United', kickoff: now + 20 * H, updatedAt: now - 2 * MIN }),
    oddsEvent({ id: 'oa-2', sport: 'soccer_epl', title: 'EPL', home: 'Chelsea', away: 'Everton', kickoff: now + 26 * H, updatedAt: now - 2 * MIN }),
    // Anbieter liefert ein bereits begonnenes Spiel → darf nie als Pre-Match verarbeitet werden
    oddsEvent({ id: 'oa-old', sport: 'soccer_epl', title: 'EPL', home: 'Fulham', away: 'Brighton and Hove Albion', kickoff: now - 30 * MIN, updatedAt: now - 40 * MIN }),
  ];
  const f = fakeFetcher((p) => p === '/v4/sports' ? { body: sportsList() }
    : p.endsWith('/soccer_epl/events') ? { body: evs.map(({ bookmakers, ...e }) => e), headers: { 'x-requests-last': '0' } }
    : p.endsWith('/events') ? { body: [], headers: { 'x-requests-last': '0' } }
    : p.endsWith('/soccer_epl/odds') ? { body: evs, headers: { 'x-requests-last': '4' } }
    : p.endsWith('/odds') ? { body: [], headers: { 'x-requests-last': '0' } } : null);
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, PILOT_MODE: 'true' }), { db: memDb(), fetcher: f.fetcher });
  importFootballDataCsv(app.db, e0Csv(teams, 2), 'E0.csv');
  const rep = await controlledSync(app, { now: new Date(now), maxEvents: 10 });
  assert.equal(rep.status, 'DONE', rep.notes.join(' | '));
  assert.equal(rep.liveVerification, 'NOT VERIFIED', 'nachgebaute Antworten sind kein Live-Nachweis');
  assert.equal(rep.summary!.startedExcluded, 0, 'begonnene Spiele bereits beim kostenlosen /events-Filter ausgeschlossen');
  assert.equal(rep.events.length, 2);
  assert.ok(rep.events.every(e => e.markets['1X2'].fresh === 3), JSON.stringify(rep.events.map(e => e.markets)));
  assert.ok(rep.events.every(e => e.providerEventIds.some(id => id.startsWith('theoddsapi:'))));
  assert.ok(rep.events.some(e => e.home === 'Arsenal' && e.away === 'Man United'), 'Team aus CSV verknüpft');
  assert.ok(rep.apiRequests.length >= 2 && rep.apiRequests.every(r => !(r.query ?? '').includes(KEY)));
  assert.equal(rep.creditsUsed.theoddsapi, 4);
  assert.deepEqual(rep.pilot.sportKeys, ['soccer_epl', 'soccer_spain_la_liga', 'soccer_uefa_champs_league']);
  assert.ok(rep.summary!.providerReports[0].skippedSportKeys.some(s => s.key === 'soccer_uefa_champs_league'));
  const failed = rep.checks.filter(c => !c.ok && c.name !== 'Teamzuordnung ohne offene Fälle');
  assert.deepEqual(failed, [], JSON.stringify(failed));
  assert.ok(!app.db.get("SELECT 1 FROM events e JOIN event_mappings m ON m.event_id = e.id WHERE m.provider_event_id = 'oa-old'"), 'begonnenes Spiel nicht angelegt');
  assert.ok(app.db.get("SELECT report FROM diagnostic_runs WHERE id = ?", rep.diagnosticId));
});

test('V2: Ohne API-Schlüssel – NOT CONFIGURED, kein Abruf, keine erfundenen Daten', async () => {
  const f = fakeFetcher(() => ({ body: [] }));
  const app = buildApp(testConfig({ DATA_MODE: 'live' }), { db: memDb(), fetcher: f.fetcher });
  const rep = await controlledSync(app, { maxEvents: 5 });
  assert.equal(rep.status, 'NOT CONFIGURED');
  assert.equal(f.calls.length, 0);
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM events')!.n, 0);
  assert.equal(rep.providers.find(p => p.provider === 'theoddsapi')!.status, 'NOT CONFIGURED');
});

test('V2: Ergebnisse über /scores – nur abgeschlossene Spiele mit Toren gelten als beendet', () => {
  const base = { id: 'x', sport_key: 'soccer_epl', commence_time: '2026-10-10T14:00:00Z', home_team: 'Arsenal', away_team: 'Chelsea' };
  const now = new Date('2026-10-12T12:00:00Z');
  const done = scoreToFixture(scoresRow(base, 2, 1, true), now);
  assert.equal(done.status, 'finished'); assert.equal(done.homeGoals, 2); assert.equal(done.awayGoals, 1);
  const running = scoreToFixture(scoresRow(base, 1, 0, false), now);
  assert.equal(running.status, 'live'); assert.equal(running.homeGoals, null);
  const broken = scoreToFixture({ ...scoresRow(base, 2, 1, true), scores: [{ name: 'Arsenal', score: 'x' }] } as any, now);
  assert.notEqual(broken.status, 'finished', 'unlesbares Ergebnis wird nicht abgerechnet');
});

test('V3-Datenfehler: CSV-Anstoßzeiten mit britischer Sommer-/Winterzeit (v0.2.0 lag im Winter 1 h daneben)', () => {
  assert.equal(ukLocalToUtc(2025, 0, 18, 15, 0).toISOString(), '2025-01-18T15:00:00.000Z', 'Winter: GMT = UTC');
  assert.equal(ukLocalToUtc(2025, 7, 16, 15, 0).toISOString(), '2025-08-16T14:00:00.000Z', 'Sommer: BST = UTC+1');
  assert.equal(ukLocalToUtc(2025, 2, 30, 12, 0).toISOString(), '2025-03-30T11:00:00.000Z', 'Umstellung März');
  assert.equal(ukLocalToUtc(2025, 9, 26, 12, 0).toISOString(), '2025-10-26T12:00:00.000Z', 'Umstellung Oktober');
});

test('V1: Nicht verfügbare Märkte werden als NOT AVAILABLE mit Grund angezeigt (nicht als ausgesetzt)', async () => {
  const { createServer } = await import('../src/server.js');
  const { TEST_SERVICE_TOKEN } = await import('./helpers.js');
  const now = Date.now();
  const evs = [oddsEvent({ id: 'oa-9', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now - MIN })];
  const f = fakeFetcher(p => p.endsWith('/events') ? { body: evs.map(({ bookmakers, ...e }) => e), headers: { 'x-requests-last': '0' } }
    : p.endsWith('/odds') ? { body: evs, headers: { 'x-requests-last': '4' } } : null);
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, THE_ODDS_API_SPORT_KEYS: 'soccer_epl' }), { db: memDb(), fetcher: f.fetcher });
  await app.sync.run(new Date(now));
  const id = app.db.get<{ event_id: number }>("SELECT event_id FROM event_mappings WHERE provider_event_id = 'oa-9'")!.event_id;
  const server = createServer(app, null, { clock: () => new Date(now) });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  try {
    const { port } = server.address() as import('node:net').AddressInfo;
    const x = await (await fetch(`http://127.0.0.1:${port}/api/matches/${id}`, { headers: { authorization: `Bearer ${TEST_SERVICE_TOKEN}` } })).json() as any;
    const by = Object.fromEntries(x.odds.map((m: any) => [m.market, m.availability]));
    assert.equal(by['1X2'].status, 'AVAILABLE');
    assert.equal(by.BTTS.status, 'NOT AVAILABLE');
    assert.match(by.BTTS.reason, /nicht aktiviert/);
  } finally { server.close(); }
});
