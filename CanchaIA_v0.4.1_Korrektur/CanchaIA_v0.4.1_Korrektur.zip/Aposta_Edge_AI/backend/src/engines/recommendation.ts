/**
 * RecommendationEngine mit vollständigem Lebenszyklus.
 * - Rangfolge nach robustem Wert (EV an der Untergrenze × Qualität), nicht nach rohem EV
 * - Pro Spiel höchstens eine Empfehlung; weitere Signale desselben Spiels gelten als korreliert
 * - Jede qualifizierte Auswahl wird beim ersten Auftreten für die Auswertung eingefroren
 *
 * Lebenszyklus (v0.2.0): Jede Empfehlung wird bei JEDEM Lesen (current) und vor jedem Aufbau (build)
 * gegen die aktuelle Uhr und die aktuellen Daten geprüft. Sie wird deaktiviert (mit Grund), wenn
 *   die Quote zu alt ist · der Markt geschlossen/ausgesetzt ist · das Spiel begonnen hat ·
 *   die Spielzuordnung unsicher ist · eine neuere Prognose sie ersetzt hat · kritische Daten fehlen ·
 *   eine neuere Quote desselben Buchmachers den Value-Vorteil aufhebt · Mock-Daten im Live-Modus.
 * Ein fehlgeschlagener Datenabruf kann eine alte Empfehlung daher nie "verlängern": ohne neue Quote läuft sie ab.
 */
import type { Db } from '../db/db.js';
import { json } from '../db/db.js';
import { nowIso } from '../util/core.js';
import type { StoredSignal } from './value.js';
import { checkFreshness } from './freshness.js';
import { OddsStore } from './odds.js';
import type { MarketId } from '../providers/types.js';

export type RecSignal = StoredSignal & { home: string; away: string; competition: string; kickoff_utc: string; event_status: string; bookmaker_name: string | null; is_mock: number };

export interface RecommendationView {
  rank: number; signalId: number; eventId: number; rankScore: number; correlatedSignalIds: number[];
  predictedAt: string | null; oddsRetrievedAt: string | null; oddsSourceTimestamp: string | null; oddsAgeMinutes: number | null;
  lastValidatedAt: string; validUntil: string | null; provider: string | null; fromCache: boolean;
  signal: RecSignal;
}

export interface LifecycleOptions {
  /** Basis-Altersgrenze (ODDS_MAX_AGE_MINUTES). */
  oddsMaxAgeMinutes?: number;
  /** false im Live-Modus: Mock-Events werden nie empfohlen. */
  allowMock?: boolean;
}

export interface Validity { ok: boolean; reasons: string[]; oddsAgeMinutes: number | null; validUntil: string | null; provider: string | null; fromCache: boolean }

const SIGNAL_SQL = `SELECT s.*, th.name AS home, ta.name AS away, c.name AS competition, e.kickoff_utc, e.status AS event_status, b.name AS bookmaker_name, e.is_mock
  FROM value_signals s JOIN events e ON e.id = s.event_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
  JOIN competitions c ON c.id = e.competition_id LEFT JOIN bookmakers b ON b.id = s.best_bookmaker_id`;

/** Robuster Rangwert: EV an der Untergrenze × Qualität (gleich für Live-Bericht und Backtest). */
export function rankScore(s: { ev_low: number | null; quality_score: number }): number {
  return Math.max(0, s.ev_low ?? 0) * (s.quality_score / 100) + (s.quality_score / 100) * 0.001;
}

/**
 * v0.4.0: gemeinsame Auswahlregel für Live-Bericht und Backtest-Simulation.
 * Höchstens eine Auswahl je Spiel (weitere gelten als korreliert), danach Rangfolge nach rankScore, höchstens `max`.
 * Gleichstand: stabile Reihenfolge nach id (deterministisch).
 */
export function selectTop<T extends { id: number; event_id: number; ev_low: number | null; quality_score: number }>(cands: T[], max: number): { pick: T; correlated: T[] }[] {
  const byEvent = new Map<number, T[]>();
  for (const c of cands) byEvent.set(c.event_id, [...(byEvent.get(c.event_id) ?? []), c]);
  const cmp = (a: T, b: T) => rankScore(b) - rankScore(a) || a.id - b.id;
  const picks = [...byEvent.values()].map(list => { const s = [...list].sort(cmp); return { pick: s[0], correlated: s.slice(1) }; });
  return picks.sort((a, b) => cmp(a.pick, b.pick)).slice(0, Math.max(0, max));
}

/**
 * v0.4.1: zeitlich korrekte Nachbildung des Live-Ablaufs für den Backtest.
 * Zu jedem Entscheidungszeitpunkt t (chronologisch) gilt wie im Live-Bericht (build):
 *   aktiv = selectTop(alle zu t gültigen Kandidaten, max)  – gültig = availableFrom ≤ t < validUntil
 * Eine Auswahl wird beim ersten Erscheinen eingefroren (wie freeze() live) und nur einmal gezählt (Schlüssel `key`).
 * Spätere Kandidaten können frühere Auswahlen nicht rückwirkend ändern; sie konkurrieren nur ab ihrem eigenen Zeitpunkt.
 * Höchstens `max` gleichzeitig aktiv, höchstens eine Auswahl je Spiel (selectTop) und je Spiel nur einmal eingefroren.
 */
export function simulateTimeline<T extends { id: number; event_id: number; ev_low: number | null; quality_score: number; availableFrom: string; validUntil: string; key: string }>(cands: T[], max: number):
  { selected: { cand: T; at: string }[]; decisionPoints: number; maxActiveObserved: number; correlated: number; neverSelected: number } {
  const points = [...new Set(cands.map(c => c.availableFrom))].sort();
  const frozen = new Map<string, { cand: T; at: string }>(), frozenEvents = new Set<number>(), correlatedIds = new Set<number>();
  let maxActive = 0;
  for (const t of points) {
    const pool = cands.filter(c => c.availableFrom <= t && t < c.validUntil);
    const top = selectTop(pool, max);
    maxActive = Math.max(maxActive, top.length);
    for (const x of top) {
      for (const c of x.correlated) correlatedIds.add(c.id);
      if (frozen.has(x.pick.key) || frozenEvents.has(x.pick.event_id)) continue;   // nie doppelt zählen, je Spiel höchstens eine
      frozen.set(x.pick.key, { cand: x.pick, at: t }); frozenEvents.add(x.pick.event_id);
    }
  }
  const selected = [...frozen.values()];
  const chosenIds = new Set(selected.map(x => x.cand.id));
  return { selected, decisionPoints: points.length, maxActiveObserved: maxActive, correlated: correlatedIds.size,
    neverSelected: cands.filter(c => !chosenIds.has(c.id) && !correlatedIds.has(c.id)).length };
}

export class RecommendationEngine {
  private odds: OddsStore;
  constructor(private db: Db, private opts: LifecycleOptions = {}) { this.odds = new OddsStore(db); }

  private minEv(): number { return this.db.get<{ min_ev: number }>('SELECT min_ev FROM system_settings WHERE id = 1')?.min_ev ?? 0.05; }

  rankScore(s: { ev_low: number | null; quality_score: number }): number { return rankScore(s); }

  /** Prüft, ob ein Signal JETZT noch als aktuelle Pre-Match-Empfehlung gelten darf. */
  validate(s: RecSignal, now: Date): Validity {
    const reasons: string[] = [];
    const out = (extra: Partial<Validity> = {}): Validity => ({ ok: reasons.length === 0, reasons, oddsAgeMinutes: null, validUntil: null, provider: null, fromCache: false, ...extra });
    if (s.is_mock && this.opts.allowMock === false) reasons.push('MOCK-Daten im Live-Modus');
    if (!s.active) reasons.push('Signal nicht mehr aktiv');
    if (!['VALUE', 'STRONG_VALUE'].includes(s.status)) reasons.push(`Signalstatus ${s.status}`);
    if (s.event_status !== 'scheduled' || new Date(s.kickoff_utc).getTime() <= now.getTime()) reasons.push('Spiel hat begonnen oder ist nicht mehr angesetzt');
    // Prognose: die Empfehlung muss auf der jüngsten Prognose des Spiels beruhen
    const latestPred = this.db.get<{ id: number; data_quality: string }>('SELECT id, data_quality FROM predictions WHERE event_id = ? ORDER BY created_at DESC, id DESC LIMIT 1', s.event_id);
    if (!latestPred) reasons.push('Prognose fehlt');
    else {
      if (latestPred.id !== s.prediction_id) reasons.push('Prognose wurde durch eine neuere ersetzt');
      if (json.parse<{ status?: string }>(latestPred.data_quality, {}).status === 'insufficient') reasons.push('INSUFFICIENT DATA');
    }
    // Quote: Snapshot muss existieren, gültig, offen und frisch sein
    const snap = s.best_snapshot_id ? this.db.get<{ id: string; provider: string; market_status: string; validation_errors: string; retrieved_at: string; source_timestamp: string | null; snapshot_kind: string; from_cache: number; bookmaker_id: string; market_id: MarketId; line: number | null }>(
      'SELECT id, provider, market_status, validation_errors, retrieved_at, source_timestamp, snapshot_kind, from_cache, bookmaker_id, market_id, line FROM odds_snapshots WHERE id = ?', s.best_snapshot_id) : undefined;
    if (!snap) { reasons.push('Quoten-Snapshot fehlt'); return out(); }
    if (snap.market_status !== 'open') reasons.push('MARKET SUSPENDED');
    if (JSON.parse(snap.validation_errors || '[]').length) reasons.push('Quote hat die Marktvalidierung nicht bestanden');
    const f = checkFreshness({ retrievedAt: snap.retrieved_at, sourceTimestamp: snap.source_timestamp, kickoffUtc: s.kickoff_utc, snapshotKind: snap.snapshot_kind }, now, this.opts.oddsMaxAgeMinutes ?? 90);
    if (!f.ok) reasons.push('STALE ODDS: ' + f.reasons.join('; '));
    // Spielzuordnung des Quoten-Providers
    const map = this.db.get<{ c: number | null }>('SELECT MIN(confidence) AS c FROM event_mappings WHERE event_id = ? AND provider = ?', s.event_id, snap.provider);
    if (map?.c != null && map.c < 0.9) reasons.push(`Spielzuordnung unsicher (${map.c.toFixed(2)})`);
    // Neuere Quote desselben Buchmachers? Dann zählt sie – nicht die alte.
    const latest = this.odds.latestPerBookmaker(s.event_id, snap.market_id, snap.line).find(v => v.bookmakerId === snap.bookmaker_id);
    if (latest && latest.snapshotId !== snap.id) {
      const newOdds = latest.prices[s.selection_id];
      if (!latest.valid || latest.status !== 'open') reasons.push('neuere Quote desselben Buchmachers ist ungültig oder ausgesetzt');
      else if (newOdds == null || s.decision_prob == null || s.decision_prob * newOdds - 1 < this.minEv()) reasons.push(`Quote auf ${newOdds?.toFixed(2) ?? '–'} gefallen: Value-Vorteil besteht nicht mehr`);
      else reasons.push('neuere Quote vorhanden: Neubewertung im nächsten Lauf nötig');
    }
    return out({ oddsAgeMinutes: f.ageMinutes, validUntil: f.expiresAt, provider: snap.provider, fromCache: !!snap.from_cache });
  }

  /** Erstellt den aktuellen Bericht aus Signalen, die JETZT gültig sind. Leere Liste = NO QUALIFIED VALUE BETS. */
  build(max: number, runId: number | null, now: Date = new Date(), includeMock = true): RecommendationView[] {
    const cands = this.db.all<RecSignal>(`${SIGNAL_SQL} WHERE s.active = 1 AND s.status IN ('STRONG_VALUE','VALUE') AND e.kickoff_utc > ? ${includeMock ? '' : 'AND e.is_mock = 0'}`, nowIso(now));
    const valid: { s: RecSignal; v: Validity }[] = [];
    for (const s of cands) { const v = this.validate(s, now); if (v.ok) valid.push({ s, v }); }
    const vById = new Map(valid.map(x => [x.s.id, x.v]));
    const top = selectTop(valid.map(x => x.s), max).map(t => ({ s: t.pick, v: vById.get(t.pick.id)!, correlated: t.correlated.map(c => c.id) }));
    this.db.tx(() => {
      const keep = new Set(top.map(t => t.s.id));
      for (const r of this.db.all<{ id: number; signal_id: number }>('SELECT id, signal_id FROM recommendations WHERE active = 1'))
        this.deactivate(r.id, keep.has(r.signal_id) ? 'durch neuen Bericht ersetzt' : 'nicht mehr unter den Top-Empfehlungen oder nicht mehr gültig', now);
      top.forEach((p, i) => {
        const pred = this.db.get<{ created_at: string }>('SELECT created_at FROM predictions WHERE id = ?', p.s.prediction_id);
        this.db.run(`INSERT INTO recommendations (signal_id, event_id, rank, report_run_id, rank_score, correlated_signal_ids, active, created_at,
                       predicted_at, odds_retrieved_at, odds_source_timestamp, last_validated_at, valid_until) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)`,
          p.s.id, p.s.event_id, i + 1, runId, this.rankScore(p.s), JSON.stringify(p.correlated), nowIso(now),
          pred?.created_at ?? null, p.s.odds_retrieved_at, p.s.odds_source_timestamp, nowIso(now), p.v.validUntil);
        this.freeze(p.s, now);
      });
    });
    return this.current(now);
  }

  private deactivate(id: number, reason: string, now: Date) {
    this.db.run('UPDATE recommendations SET active = 0, deactivated_at = ?, deactivation_reason = ? WHERE id = ? AND active = 1', nowIso(now), reason, id);
  }

  /** Friert die erste qualifizierte Version einer Auswahl ein (eine Zeile je Event/Markt/Auswahl/Linie). */
  private freeze(s: RecSignal, now: Date) {
    const exists = this.db.get(`SELECT 1 FROM prediction_outcomes WHERE event_id = ? AND market_id = ? AND selection_id = ? AND ${s.line == null ? 'line IS NULL' : 'line = ?'}`,
      ...([s.event_id, s.market_id, s.selection_id, ...(s.line == null ? [] : [s.line])] as (string | number)[]));
    if (exists) return;
    const pred = this.db.get<{ model_version: string; data_quality: string }>('SELECT model_version, data_quality FROM predictions WHERE id = ?', s.prediction_id)!;
    this.db.run(`INSERT OR IGNORE INTO prediction_outcomes (signal_id, event_id, predicted_at, market_id, selection_id, line, odds, bookmaker_id, model_prob, decision_prob, ev, model_version, data_quality_score, is_mock, odds_retrieved_at, odds_source_timestamp)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      s.id, s.event_id, nowIso(now), s.market_id, s.selection_id, s.line, s.best_odds, s.best_bookmaker_id, s.model_prob, s.decision_prob, s.ev, pred.model_version, JSON.parse(pred.data_quality).score, s.is_mock,
      s.odds_retrieved_at, s.odds_source_timestamp);
  }

  /**
   * Aktuell gültige Empfehlungen. Prüft jede aktive Empfehlung gegen die Uhr `now` und die aktuellen Daten;
   * ungültige werden mit Grund deaktiviert und nicht zurückgegeben. Kein Sync-Lauf nötig.
   */
  current(now: Date = new Date()): RecommendationView[] {
    const rows = this.db.all<{ id: number; rank: number; signal_id: number; event_id: number; rank_score: number; correlated_signal_ids: string; predicted_at: string | null; odds_retrieved_at: string | null; odds_source_timestamp: string | null }>(
      'SELECT id, rank, signal_id, event_id, rank_score, correlated_signal_ids, predicted_at, odds_retrieved_at, odds_source_timestamp FROM recommendations WHERE active = 1 ORDER BY rank');
    const out: RecommendationView[] = [];
    for (const r of rows) {
      const s = this.db.get<RecSignal>(`${SIGNAL_SQL} WHERE s.id = ?`, r.signal_id);
      const v = s ? this.validate(s, now) : { ok: false, reasons: ['Signal fehlt'] } as Validity;
      if (!s || !v.ok) { this.deactivate(r.id, v.reasons.join('; '), now); continue; }
      this.db.run('UPDATE recommendations SET last_validated_at = ?, valid_until = ? WHERE id = ?', nowIso(now), v.validUntil, r.id);
      out.push({ rank: out.length + 1, signalId: r.signal_id, eventId: r.event_id, rankScore: r.rank_score, correlatedSignalIds: JSON.parse(r.correlated_signal_ids),
        predictedAt: r.predicted_at, oddsRetrievedAt: r.odds_retrieved_at, oddsSourceTimestamp: r.odds_source_timestamp, oddsAgeMinutes: v.oddsAgeMinutes,
        lastValidatedAt: nowIso(now), validUntil: v.validUntil, provider: v.provider, fromCache: v.fromCache, signal: s });
    }
    return out;
  }

  /** Zuletzt deaktivierte Empfehlungen mit Grund (für Transparenz im Dashboard/Admin). */
  recentlyDeactivated(limit = 20) {
    return this.db.all(`SELECT r.id, r.signal_id, r.event_id, r.created_at, r.deactivated_at, r.deactivation_reason, th.name AS home, ta.name AS away
      FROM recommendations r JOIN events e ON e.id = r.event_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
      WHERE r.active = 0 AND r.deactivated_at IS NOT NULL ORDER BY r.deactivated_at DESC LIMIT ?`, limit);
  }
}
