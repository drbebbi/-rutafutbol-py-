// CanchaIA – plattformunabhängiger Start (Windows/PowerShell, Linux, macOS). v0.4.0
// Aufruf:  node scripts/start.mjs [mock|live] [--no-install] [--no-build]
//   mock  = fiktive Daten (Standard, wenn DATA_MODE nirgends gesetzt ist)
//   live  = echte Provider gemäß .env / Umgebungsvariablen
// Ablauf: Node-Version prüfen → .env anlegen (falls fehlt, aus .env.example) → Abhängigkeiten aus Lockfiles (npm ci)
//         → Build inkl. Typprüfung → Backend starten. Es werden nie Werte von Secrets ausgegeben.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const mode = args.find(a => a === 'mock' || a === 'live');
const bad = args.filter(a => !['mock', 'live', '--no-install', '--no-build'].includes(a));
if (bad.length) { console.error(`Unbekannte Option(en): ${bad.join(' ')}\nAufruf: node scripts/start.mjs [mock|live] [--no-install] [--no-build]`); process.exit(2); }

const [maj, min] = process.versions.node.split('.').map(Number);
if (maj < 22 || (maj === 22 && min < 13)) { console.error(`Node.js >= 22.13 erforderlich (gefunden ${process.versions.node}). Node 22 LTS installieren: https://nodejs.org`); process.exit(3); }

const npm = (cwd, ...a) => {
  const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', a, { cwd, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) { console.error(`Fehlgeschlagen: npm ${a.join(' ')} (${path.relative(root, cwd) || '.'})`); process.exit(r.status ?? 1); }
};

// .env: nur anlegen, nie überschreiben. Echte Umgebungsvariablen haben im Backend immer Vorrang.
const envFile = path.join(root, '.env');
if (!fs.existsSync(envFile) && !process.env.ENV_FILE) {
  fs.copyFileSync(path.join(root, '.env.example'), envFile);
  try { fs.chmodSync(envFile, 0o600); } catch { /* Windows */ }
  console.log(`.env aus .env.example angelegt: ${envFile}\n  → ADMIN_EMAIL und ADMIN_PASSWORD (≥ 12 Zeichen, Buchstaben + Ziffern) eintragen, sonst ist keine Anmeldung möglich.`);
}

if (!args.includes('--no-install')) for (const dir of ['backend', 'frontend']) {
  const cwd = path.join(root, dir);
  if (!fs.existsSync(path.join(cwd, 'node_modules'))) { console.log(`[install] ${dir}: npm ci (aus package-lock.json)`); npm(cwd, 'ci', '--no-audit', '--no-fund'); }
}
if (!args.includes('--no-build')) { console.log('[build] Frontend (mit Typprüfung) und Backend'); npm(root, 'run', 'build'); }

const env = { ...process.env };
if (mode) env.DATA_MODE = mode;
console.log(`[start] CanchaIA · Modus: ${env.DATA_MODE ?? 'aus .env (Standard mock)'} · Zeitzone America/Asuncion · http://localhost:${env.PORT ?? 8080}`);
if (mode === 'live') console.log('[start] LIVE: kostenpflichtige Quotenabrufe erst nach bestandenem kostenlosen Verbindungstest (Admin → The Odds API) und nur innerhalb der Budgets. SCHEDULER_ENABLED=false verhindert automatische Abrufe.');
const child = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'dist/src/main.js'], { cwd: path.join(root, 'backend'), env, stdio: 'inherit' });
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => child.kill(sig));
child.on('exit', code => process.exit(code ?? 0));
