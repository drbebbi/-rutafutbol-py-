/**
 * Tarifverwaltung und Zahlungsprüfung (v0.3.0) – TESTMODUS, keine echten Zahlungstransaktionen.
 *
 * Grundsätze
 *  - Rolle (user/admin) und Tarif (FREE/PRO/PREMIUM) sind getrennte Konzepte. Admins haben immer vollen Zugriff.
 *  - Ohne SUBSCRIPTIONS_ENFORCE=true werden Berechtigungen nur berechnet und angezeigt, aber nicht durchgesetzt:
 *    bestehende Funktionen werden durch die Einführung nicht gesperrt.
 *  - Ein Abo wird erst ACTIVE, wenn ein Admin den Zahlungseingang verifiziert hat (Bankreferenz + Betrag).
 *    Eine hochgeladene Zahlungsbestätigung setzt nur PROOF_SUBMITTED – nie eine Freischaltung.
 *  - Admins können ihre eigene Zahlung nicht verifizieren (Vier-Augen-Mindestregel).
 *  - Bankdaten (Alias, Bank, Kontoinhaber) kommen ausschließlich aus der Umgebung; keine C.I. oder Kontonummer im Code.
 *  - uPay: nur Schnittstelle + Testmodus ohne Netzwerkzugriff. Keine Belastungen, keine wiederkehrenden Abbuchungen.
 *  - Jede Änderung landet im unveränderlichen Änderungsprotokoll subscription_events.
 */
import crypto from 'node:crypto';
import type { Db } from './db/db.js';
import type { Config } from './config.js';
import { AppError } from './util/core.js';
import { json } from './db/db.js';

export type PlanId = 'FREE' | 'PRO' | 'PREMIUM';
export type Period = 'monthly' | 'yearly';
export type SubStatus = 'ACTIVE' | 'PENDING' | 'EXPIRED' | 'CANCELLED';
export type PayStatus = 'AWAITING_PAYMENT' | 'PROOF_SUBMITTED' | 'VERIFIED' | 'REJECTED' | 'CANCELLED';

export interface Entitlements { maxRecommendations: number; edgeAnalystPerDay: number; personalAlerts: boolean; customAlertMinEv: boolean; backtestReports: boolean }
export const FULL_ACCESS: Entitlements = { maxRecommendations: 5, edgeAnalystPerDay: 1_000_000, personalAlerts: true, customAlertMinEv: true, backtestReports: true };
export type Feature = 'edgeAnalyst' | 'personalAlerts' | 'customAlertMinEv' | 'backtestReports';

export interface PlanRow { id: PlanId; name: string; price_monthly_pyg: number; price_yearly_pyg: number; entitlements: string; active: number }
export interface SubRow { id: number; user_id: number; plan_id: PlanId; billing_period: Period | 'complimentary'; status: SubStatus; started_at: string | null; expires_at: string | null; cancelled_at: string | null; created_at: string; updated_at: string; note: string | null }
export interface PayRow { id: number; subscription_id: number; user_id: number; method: 'bank_transfer' | 'upay'; provider_mode: string; amount_pyg: number; currency: string; reference: string; status: PayStatus; provider_ref: string | null; proof_submitted_at: string | null; verified_by: number | null; verified_at: string | null; bank_reference: string | null; received_amount_pyg: number | null; received_at: string | null; decision_note: string | null; created_at: string; updated_at: string }

/** Schnittstelle für Zahlungsanbieter. Implementierungen dürfen NIE selbst ein Abo freischalten. */
export interface PaymentProvider {
  readonly method: 'bank_transfer' | 'upay';
  readonly mode: 'manual' | 'test';
  /** Startet eine Zahlung. Gibt nur Anweisungen/Test-Referenzen zurück; keine Belastung. */
  start(p: { reference: string; amountPyg: number; planId: PlanId; period: Period }): { providerRef: string | null; instructions: Record<string, string | number | null> };
}

export class BankTransferProvider implements PaymentProvider {
  readonly method = 'bank_transfer' as const; readonly mode = 'manual' as const;
  constructor(private bank: Config['subscriptions']['bankTransfer']) {}
  start(p: { reference: string; amountPyg: number }) {
    return { providerRef: null, instructions: {
      procedure: 'sipap_alias_manual_review',
      bank: this.bank.bankName, alias: this.bank.alias, accountHolder: this.bank.accountHolder,
      amountPyg: p.amountPyg, reference: p.reference,
      note: this.bank.alias ? 'activation_after_verified_payment' : 'bank_details_not_configured',
    } };
  }
}

/**
 * Vorbereitete uPay-Anbindung. NUR TESTMODUS: keine Netzwerkaufrufe, keine Belastungen, keine Wiederholungszahlungen.
 * Eine echte Integration (Checkout-URL, Webhook-Signaturprüfung) ist NOT IMPLEMENTED, bis eine Händlerfreigabe vorliegt.
 */
export class UpayTestProvider implements PaymentProvider {
  readonly method = 'upay' as const; readonly mode = 'test' as const;
  start(p: { reference: string; amountPyg: number }) {
    return { providerRef: `UPAY-TEST-${p.reference}`, instructions: {
      procedure: 'upay_test_mode_no_charge', amountPyg: p.amountPyg, reference: p.reference,
      note: 'no_merchant_approval_manual_review_only',
    } };
  }
}

const REF_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newReference(): string { const b = crypto.randomBytes(6); return 'AEA-' + [...b].map(x => REF_ALPHABET[x % REF_ALPHABET.length]).join(''); }

const ALLOWED_PROOF: Record<string, (b: Buffer) => boolean> = {
  'application/pdf': b => b.subarray(0, 5).toString('latin1') === '%PDF-',
  'image/png': b => b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])),
  'image/jpeg': b => b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff,
};
export const MAX_PROOF_BYTES = 2 * 1024 * 1024;

export function addPeriod(fromIso: string, period: Period | 'complimentary', months = 1): string {
  const d = new Date(fromIso);
  const m = period === 'yearly' ? 12 : period === 'monthly' ? 1 : months;
  const day = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + m);
  if (d.getUTCDate() < day) d.setUTCDate(0); // 31.01. + 1 Monat → 28./29.02.
  return d.toISOString();
}

export class SubscriptionService {
  private providers: PaymentProvider[];
  constructor(private db: Db, private cfg: Config, private clock: () => Date = () => new Date()) {
    this.providers = [];
    if (cfg.subscriptions.bankTransfer.enabled) this.providers.push(new BankTransferProvider(cfg.subscriptions.bankTransfer));
    if (cfg.subscriptions.upayMode === 'test') this.providers.push(new UpayTestProvider());
  }
  private now() { return this.clock().toISOString(); }

  methods() { return this.providers.map(p => ({ method: p.method, mode: p.mode })); }
  plans(): (Omit<PlanRow, 'entitlements'> & { entitlements: Entitlements })[] {
    return this.db.all<PlanRow>('SELECT * FROM plans WHERE active = 1 ORDER BY price_monthly_pyg').map(p => ({ ...p, entitlements: json.parse<Entitlements>(p.entitlements, FULL_ACCESS) }));
  }
  private plan(id: string): PlanRow {
    const p = this.db.get<PlanRow>('SELECT * FROM plans WHERE id = ? AND active = 1', id);
    if (!p) throw new AppError('invalid_input', 'Unbekannter Tarif', 400);
    return p;
  }

  log(e: { subscriptionId?: number | null; paymentId?: number | null; userId?: number | null; actorId?: number | null; action: string; from?: string | null; to?: string | null; detail?: string | null }) {
    this.db.run('INSERT INTO subscription_events (subscription_id, payment_id, user_id, actor_id, action, from_status, to_status, detail, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      e.subscriptionId ?? null, e.paymentId ?? null, e.userId ?? null, e.actorId ?? null, e.action, e.from ?? null, e.to ?? null, e.detail ?? null, this.now());
  }

  /** Abgelaufene Abos auf EXPIRED setzen (idempotent; auch bei jedem Lesen). */
  expireDue(): number {
    const now = this.now();
    const due = this.db.all<{ id: number; user_id: number; status: string }>("SELECT id, user_id, status FROM subscriptions WHERE status IN ('ACTIVE','CANCELLED') AND expires_at IS NOT NULL AND expires_at <= ?", now);
    for (const s of due) {
      this.db.run("UPDATE subscriptions SET status = 'EXPIRED', updated_at = ? WHERE id = ?", now, s.id);
      this.log({ subscriptionId: s.id, userId: s.user_id, action: 'expired', from: s.status, to: 'EXPIRED' });
    }
    return due.length;
  }

  /** Aktuell wirksames Abo: ACTIVE oder CANCELLED (bis Laufzeitende) mit expires_at in der Zukunft. */
  current(userId: number): SubRow | null {
    this.expireDue();
    return this.db.get<SubRow>("SELECT * FROM subscriptions WHERE user_id = ? AND status IN ('ACTIVE','CANCELLED') AND (expires_at IS NULL OR expires_at > ?) ORDER BY expires_at DESC, id DESC LIMIT 1", userId, this.now()) ?? null;
  }

  /** Berechtigungen. role=admin → voller Zugriff. enforced=false → bisheriges Verhalten (alles frei), nur angezeigt. */
  entitlements(userId: number | null, role: string): { plan: PlanId; status: SubStatus | 'NONE'; expiresAt: string | null; enforced: boolean; effective: Entitlements; planEntitlements: Entitlements } {
    const enforced = this.cfg.subscriptions.enforce;
    if (role === 'admin' || userId == null) return { plan: 'PREMIUM', status: 'NONE', expiresAt: null, enforced, effective: FULL_ACCESS, planEntitlements: FULL_ACCESS };
    const sub = this.current(userId);
    const planId = (sub?.plan_id ?? 'FREE') as PlanId;
    const ent = json.parse<Entitlements>(this.plan(planId).entitlements, FULL_ACCESS);
    return { plan: planId, status: sub?.status ?? 'NONE', expiresAt: sub?.expires_at ?? null, enforced, effective: enforced ? ent : FULL_ACCESS, planEntitlements: ent };
  }

  /** Serverseitige Prüfung. Wirft 402, wenn der Tarif die Funktion nicht enthält (nur bei aktiver Durchsetzung). */
  require(userId: number | null, role: string, f: Feature): void {
    const e = this.entitlements(userId, role).effective;
    const ok = f === 'edgeAnalyst' ? e.edgeAnalystPerDay > 0 : e[f];
    if (!ok) throw new AppError('plan_required', 'Diese Funktion ist in deinem Tarif nicht enthalten.', 402);
  }

  /** Tageskontingent (z. B. EDGE ANALYST). Zählt immer; begrenzt nur bei aktiver Durchsetzung. */
  consume(userId: number | null, role: string, feature: 'edgeAnalyst'): { used: number; limit: number } {
    const ent = this.entitlements(userId, role);
    const limit = ent.effective.edgeAnalystPerDay;
    if (userId == null) return { used: 0, limit };
    const day = this.now().slice(0, 10);
    const used = this.db.get<{ n: number }>('SELECT n FROM usage_counters WHERE user_id = ? AND day = ? AND feature = ?', userId, day, feature)?.n ?? 0;
    if (used >= limit) throw new AppError('plan_limit', `Tageslimit für ${feature} erreicht (${limit}).`, 402);
    this.db.run('INSERT INTO usage_counters (user_id, day, feature, n) VALUES (?, ?, ?, 1) ON CONFLICT(user_id, day, feature) DO UPDATE SET n = n + 1', userId, day, feature);
    return { used: used + 1, limit };
  }

  overview(userId: number) {
    const ent = this.entitlements(userId, 'user');
    const pending = this.db.all<PayRow>("SELECT * FROM payments WHERE user_id = ? AND status IN ('AWAITING_PAYMENT','PROOF_SUBMITTED') ORDER BY id DESC", userId);
    return {
      ...ent, current: this.current(userId), plans: this.plans(), methods: this.methods(),
      pendingPayments: pending.map(p => ({ ...this.publicPayment(p), instructions: this.provider(p.method)?.start({ reference: p.reference, amountPyg: p.amount_pyg, planId: 'PRO', period: 'monthly' }).instructions ?? null })),
      history: this.db.all('SELECT id, plan_id, billing_period, status, started_at, expires_at, created_at FROM subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 20', userId),
    };
  }
  private provider(m: string) { return this.providers.find(p => p.method === m); }
  publicPayment(p: PayRow) {
    return { id: p.id, subscriptionId: p.subscription_id, method: p.method, mode: p.provider_mode, amountPyg: p.amount_pyg, currency: p.currency, reference: p.reference, status: p.status, proofSubmittedAt: p.proof_submitted_at, createdAt: p.created_at, decisionNote: p.status === 'REJECTED' ? p.decision_note : null };
  }

  /** Bestellung: legt PENDING-Abo + Zahlung AWAITING_PAYMENT an. Ältere offene Bestellungen des Benutzers werden storniert. */
  checkout(userId: number, planId: string, period: string, method: string) {
    const plan = this.plan(planId);
    if (plan.id === 'FREE') throw new AppError('invalid_input', 'FREE benötigt keine Bestellung.', 400);
    if (period !== 'monthly' && period !== 'yearly') throw new AppError('invalid_input', 'period: monthly oder yearly', 400);
    const prov = this.provider(method);
    if (!prov) throw new AppError('invalid_input', `Zahlungsart ${method} ist nicht verfügbar.`, 400);
    const amount = period === 'yearly' ? plan.price_yearly_pyg : plan.price_monthly_pyg;
    const now = this.now();
    return this.db.tx(() => {
      for (const old of this.db.all<{ id: number; subscription_id: number }>("SELECT id, subscription_id FROM payments WHERE user_id = ? AND status IN ('AWAITING_PAYMENT','PROOF_SUBMITTED')", userId)) {
        this.db.run("UPDATE payments SET status = 'CANCELLED', updated_at = ?, decision_note = 'durch neue Bestellung ersetzt' WHERE id = ?", now, old.id);
        this.db.run("UPDATE subscriptions SET status = 'CANCELLED', cancelled_at = ?, updated_at = ? WHERE id = ? AND status = 'PENDING'", now, now, old.subscription_id);
        this.log({ subscriptionId: old.subscription_id, paymentId: old.id, userId, actorId: userId, action: 'cancelled', to: 'CANCELLED', detail: 'durch neue Bestellung ersetzt' });
      }
      const subId = Number(this.db.run("INSERT INTO subscriptions (user_id, plan_id, billing_period, status, created_by, created_at, updated_at) VALUES (?, ?, ?, 'PENDING', ?, ?, ?)", userId, plan.id, period, userId, now, now).lastInsertRowid);
      let reference = newReference();
      while (this.db.get('SELECT 1 FROM payments WHERE reference = ?', reference)) reference = newReference();
      const started = prov.start({ reference, amountPyg: amount, planId: plan.id, period: period as Period });
      const payId = Number(this.db.run("INSERT INTO payments (subscription_id, user_id, method, provider_mode, amount_pyg, reference, status, provider_ref, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, 'AWAITING_PAYMENT', ?, ?, ?)",
        subId, userId, prov.method, prov.mode, amount, reference, started.providerRef, now, now).lastInsertRowid);
      this.log({ subscriptionId: subId, paymentId: payId, userId, actorId: userId, action: 'checkout', to: 'PENDING', detail: `${plan.id}/${period}/${prov.method}/${amount} PYG` });
      return { subscriptionId: subId, paymentId: payId, reference, amountPyg: amount, status: 'AWAITING_PAYMENT' as PayStatus, instructions: started.instructions };
    });
  }

  private ownPayment(userId: number, id: number): PayRow {
    const p = this.db.get<PayRow>('SELECT * FROM payments WHERE id = ?', id);
    if (!p || p.user_id !== userId) throw new AppError('not_found', 'Zahlung nicht gefunden', 404); // fremde Zahlungen sind nicht sichtbar
    return p;
  }

  /** Zahlungsbestätigung hochladen. Ändert NUR den Status auf PROOF_SUBMITTED; schaltet nichts frei. */
  submitProof(userId: number, paymentId: number, f: { fileName: string; mime: string; dataBase64: string; note?: string | null }) {
    const p = this.ownPayment(userId, paymentId);
    if (!['AWAITING_PAYMENT', 'PROOF_SUBMITTED'].includes(p.status)) throw new AppError('conflict', `Zahlung hat Status ${p.status}`, 409);
    const check = ALLOWED_PROOF[f.mime];
    if (!check) throw new AppError('invalid_input', 'Erlaubt sind PDF, PNG oder JPEG.', 400);
    const buf = Buffer.from(String(f.dataBase64 ?? ''), 'base64');
    if (!buf.length || buf.length > MAX_PROOF_BYTES) throw new AppError('invalid_input', 'Datei leer oder größer als 2 MB.', 400);
    if (!check(buf)) throw new AppError('invalid_input', 'Dateiinhalt passt nicht zum Dateityp.', 400);
    const now = this.now();
    const name = String(f.fileName ?? 'beleg').replace(/[^\w.\- ]+/g, '_').slice(0, 120);
    this.db.tx(() => {
      this.db.run('INSERT INTO payment_proofs (payment_id, uploaded_by, file_name, mime, size, sha256, content, note, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        p.id, userId, name, f.mime, buf.length, crypto.createHash('sha256').update(buf).digest('hex'), buf, f.note ? String(f.note).slice(0, 500) : null, now);
      this.db.run("UPDATE payments SET status = 'PROOF_SUBMITTED', proof_submitted_at = ?, updated_at = ? WHERE id = ?", now, now, p.id);
      this.log({ subscriptionId: p.subscription_id, paymentId: p.id, userId, actorId: userId, action: 'proof_submitted', from: p.status, to: 'PROOF_SUBMITTED', detail: `${name} (${buf.length} B)` });
    });
    return { id: p.id, status: 'PROOF_SUBMITTED' as PayStatus, note: 'Beleg eingegangen. Die Freischaltung erfolgt erst nach Prüfung des Zahlungseingangs.' };
  }

  cancel(userId: number, actorId: number) {
    const now = this.now();
    const s = this.current(userId);
    if (!s) throw new AppError('not_found', 'Kein aktives Abo', 404);
    this.db.run("UPDATE subscriptions SET status = 'CANCELLED', cancelled_at = ?, updated_at = ? WHERE id = ?", now, now, s.id);
    this.log({ subscriptionId: s.id, userId, actorId, action: 'cancelled', from: s.status, to: 'CANCELLED', detail: `Zugriff bis ${s.expires_at}` });
    return { id: s.id, status: 'CANCELLED', accessUntil: s.expires_at };
  }

  // ------------------------------------------------------------ Admin
  adminPayments(status?: string) {
    return this.db.all(`SELECT p.*, u.email, s.plan_id, s.billing_period, (SELECT COUNT(*) FROM payment_proofs pr WHERE pr.payment_id = p.id) AS proofs
      FROM payments p JOIN users u ON u.id = p.user_id JOIN subscriptions s ON s.id = p.subscription_id ${status ? 'WHERE p.status = ?' : ''} ORDER BY p.id DESC LIMIT 200`, ...(status ? [status] : []));
  }
  adminSubscriptions() {
    this.expireDue();
    return this.db.all('SELECT s.*, u.email FROM subscriptions s JOIN users u ON u.id = s.user_id ORDER BY s.id DESC LIMIT 300');
  }
  adminProof(paymentId: number) {
    return this.db.all<{ id: number; file_name: string; mime: string; size: number; sha256: string; content: Uint8Array | null; note: string | null; created_at: string }>(
      'SELECT id, file_name, mime, size, sha256, content, note, created_at FROM payment_proofs WHERE payment_id = ? ORDER BY id', paymentId)
      .map(r => ({ ...r, content: r.content ? Buffer.from(r.content).toString('base64') : null, purged: !r.content }));
  }
  events(userId?: number) {
    return this.db.all(`SELECT e.*, a.email AS actor_email, u.email AS user_email FROM subscription_events e LEFT JOIN users a ON a.id = e.actor_id LEFT JOIN users u ON u.id = e.user_id
      ${userId ? 'WHERE e.user_id = ?' : ''} ORDER BY e.id DESC LIMIT 300`, ...(userId ? [userId] : []));
  }

  /**
   * Zahlungseingang bestätigen → Abo ACTIVE. Pflicht: Bankreferenz, erhaltener Betrag = erwarteter Betrag,
   * Eingangsdatum, ausdrückliche Bestätigung. Ein Admin darf die eigene Zahlung nicht freigeben.
   */
  verifyPayment(adminId: number, paymentId: number, b: { bankReference?: unknown; receivedAmountPyg?: unknown; receivedAt?: unknown; confirmReceived?: unknown; note?: unknown }) {
    const p = this.db.get<PayRow>('SELECT * FROM payments WHERE id = ?', paymentId);
    if (!p) throw new AppError('not_found', 'Zahlung nicht gefunden', 404);
    if (p.user_id === adminId) throw new AppError('forbidden', 'Eigene Zahlungen dürfen nicht selbst freigegeben werden.', 403);
    if (!['AWAITING_PAYMENT', 'PROOF_SUBMITTED'].includes(p.status)) throw new AppError('conflict', `Zahlung hat Status ${p.status}`, 409);
    if (b.confirmReceived !== true) throw new AppError('invalid_input', 'Bitte bestätigen, dass der Betrag auf dem Konto eingegangen ist (confirmReceived).', 400);
    const ref = typeof b.bankReference === 'string' ? b.bankReference.trim() : '';
    if (ref.length < 4 || ref.length > 100) throw new AppError('invalid_input', 'bankReference (Referenz aus dem Kontoauszug) fehlt.', 400);
    const amt = Number(b.receivedAmountPyg);
    if (!Number.isInteger(amt) || amt !== p.amount_pyg) throw new AppError('invalid_input', `Erhaltener Betrag (${b.receivedAmountPyg}) entspricht nicht dem erwarteten Betrag ${p.amount_pyg} PYG. Abweichungen bitte ablehnen oder klären.`, 400);
    const recAt = typeof b.receivedAt === 'string' && Number.isFinite(Date.parse(b.receivedAt)) ? new Date(b.receivedAt).toISOString() : null;
    if (!recAt || recAt > this.now() || recAt < p.created_at.slice(0, 10)) throw new AppError('invalid_input', 'receivedAt (Eingangsdatum) fehlt oder ist unplausibel.', 400);
    if (this.db.get("SELECT 1 FROM payments WHERE bank_reference = ? AND status = 'VERIFIED'", ref)) throw new AppError('conflict', 'Diese Bankreferenz wurde bereits für eine andere Zahlung verwendet.', 409);
    const sub = this.db.get<SubRow>('SELECT * FROM subscriptions WHERE id = ?', p.subscription_id)!;
    const now = this.now();
    return this.db.tx(() => {
      // Verlängerung: ab Ende des laufenden Abos desselben Benutzers, sonst ab jetzt
      const running = this.current(p.user_id);
      const start = running?.expires_at && running.expires_at > now ? running.expires_at : now;
      const expires = addPeriod(start, sub.billing_period as Period);
      this.db.run("UPDATE payments SET status = 'VERIFIED', verified_by = ?, verified_at = ?, bank_reference = ?, received_amount_pyg = ?, received_at = ?, decision_note = ?, updated_at = ? WHERE id = ?",
        adminId, now, ref, amt, recAt, typeof b.note === 'string' ? b.note.slice(0, 500) : null, now, p.id);
      this.db.run("UPDATE subscriptions SET status = 'ACTIVE', started_at = ?, expires_at = ?, updated_at = ? WHERE id = ?", start, expires, now, sub.id);
      this.log({ subscriptionId: sub.id, paymentId: p.id, userId: p.user_id, actorId: adminId, action: 'payment_verified', from: p.status, to: 'VERIFIED', detail: `Bankreferenz ${ref}, ${amt} PYG, Eingang ${recAt}` });
      this.log({ subscriptionId: sub.id, paymentId: p.id, userId: p.user_id, actorId: adminId, action: 'activated', from: sub.status, to: 'ACTIVE', detail: `${sub.plan_id} ${start} → ${expires}` });
      return { paymentId: p.id, subscriptionId: sub.id, status: 'ACTIVE' as SubStatus, startedAt: start, expiresAt: expires };
    });
  }

  rejectPayment(adminId: number, paymentId: number, reason: unknown) {
    const p = this.db.get<PayRow>('SELECT * FROM payments WHERE id = ?', paymentId);
    if (!p) throw new AppError('not_found', 'Zahlung nicht gefunden', 404);
    if (!['AWAITING_PAYMENT', 'PROOF_SUBMITTED'].includes(p.status)) throw new AppError('conflict', `Zahlung hat Status ${p.status}`, 409);
    const why = typeof reason === 'string' ? reason.trim().slice(0, 500) : '';
    if (why.length < 3) throw new AppError('invalid_input', 'Begründung erforderlich', 400);
    const now = this.now();
    this.db.tx(() => {
      this.db.run("UPDATE payments SET status = 'REJECTED', verified_by = ?, verified_at = ?, decision_note = ?, updated_at = ? WHERE id = ?", adminId, now, why, now, p.id);
      this.db.run("UPDATE subscriptions SET status = 'CANCELLED', cancelled_at = ?, updated_at = ? WHERE id = ? AND status = 'PENDING'", now, now, p.subscription_id);
      this.log({ subscriptionId: p.subscription_id, paymentId: p.id, userId: p.user_id, actorId: adminId, action: 'payment_rejected', from: p.status, to: 'REJECTED', detail: why });
    });
    return { paymentId: p.id, status: 'REJECTED' as PayStatus };
  }

  /** Manuelle Freischaltung OHNE Zahlung (z. B. Testkonto) – nur mit Begründung, im Protokoll als "granted" sichtbar. */
  grant(adminId: number, b: { userId?: unknown; planId?: unknown; months?: unknown; reason?: unknown }) {
    const userId = Number(b.userId), months = Number(b.months ?? 1);
    if (!Number.isInteger(userId) || !this.db.get("SELECT 1 FROM users WHERE id = ? AND role IN ('user','admin')", userId)) throw new AppError('invalid_input', 'userId ungültig', 400);
    const plan = this.plan(String(b.planId ?? ''));
    if (plan.id === 'FREE') throw new AppError('invalid_input', 'FREE muss nicht freigeschaltet werden', 400);
    if (!Number.isInteger(months) || months < 1 || months > 12) throw new AppError('invalid_input', 'months: 1–12', 400);
    const why = typeof b.reason === 'string' ? b.reason.trim().slice(0, 500) : '';
    if (why.length < 5) throw new AppError('invalid_input', 'Begründung erforderlich (z. B. "Testkonto Pilotphase")', 400);
    const now = this.now(), expires = addPeriod(now, 'complimentary', months);
    const id = Number(this.db.run("INSERT INTO subscriptions (user_id, plan_id, billing_period, status, started_at, expires_at, created_by, note, created_at, updated_at) VALUES (?, ?, 'complimentary', 'ACTIVE', ?, ?, ?, ?, ?, ?)",
      userId, plan.id, now, expires, adminId, why, now, now).lastInsertRowid);
    this.log({ subscriptionId: id, userId, actorId: adminId, action: 'granted', to: 'ACTIVE', detail: `${plan.id} ${months} Monat(e) ohne Zahlung: ${why}` });
    return { subscriptionId: id, status: 'ACTIVE' as SubStatus, expiresAt: expires };
  }

  adminCancel(adminId: number, subscriptionId: number, reason: unknown) {
    const s = this.db.get<SubRow>('SELECT * FROM subscriptions WHERE id = ?', subscriptionId);
    if (!s) throw new AppError('not_found', 'Abo nicht gefunden', 404);
    if (!['ACTIVE', 'PENDING'].includes(s.status)) throw new AppError('conflict', `Abo hat Status ${s.status}`, 409);
    const now = this.now();
    // Sofortige Beendigung durch Admin (z. B. Rückbuchung): expires_at = jetzt
    this.db.run("UPDATE subscriptions SET status = 'CANCELLED', cancelled_at = ?, expires_at = ?, updated_at = ? WHERE id = ?", now, now, now, s.id);
    this.log({ subscriptionId: s.id, userId: s.user_id, actorId: adminId, action: 'cancelled', from: s.status, to: 'CANCELLED', detail: typeof reason === 'string' ? reason.slice(0, 500) : 'durch Admin' });
    return { id: s.id, status: 'CANCELLED' };
  }

  /** Aufbewahrung: Inhalt hochgeladener Belege nach Entscheidung + Frist löschen (Prüfsumme bleibt). */
  purgeOldProofs(): number {
    const cutoff = new Date(this.clock().getTime() - this.cfg.subscriptions.proofRetentionDays * 86_400_000).toISOString();
    return this.db.run(`UPDATE payment_proofs SET content = NULL WHERE content IS NOT NULL AND payment_id IN
      (SELECT id FROM payments WHERE status IN ('VERIFIED','REJECTED','CANCELLED') AND updated_at < ?)`, cutoff).changes;
  }
}
