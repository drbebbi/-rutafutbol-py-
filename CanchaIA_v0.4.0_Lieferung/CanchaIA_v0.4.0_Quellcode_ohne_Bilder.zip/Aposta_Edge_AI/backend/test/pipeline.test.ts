import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, mockApp } from './helpers.js';
import { AlertEngine } from '../src/engines/alerts.js';
import { Settlement, PerformanceRepository } from '../src/engines/performance.js';
import { BacktestingEngine } from '../src/engines/backtest.js';
import { EdgeAnalyst } from '../src/engines/analyst.js';
import { Scheduler } from '../src/scheduler.js';
import { EventMatchingEngine } from '../src/engines/matching.js';

test('End-to-End (Mock): Discovery → Quoten → Prognose → Value → Top 5 → Alerts', async () => {
  const app = await mockApp();
  const s = await app.sync.run(ANCHOR);
  assert.equal(s.status, 'done', s.errors.join('\n'));
  assert.ok(s.fixturesFound > 0, 'Spiele gefunden');
  assert.equal(s.prioritized, s.fixturesFound);
  assert.ok(s.oddsSnapshots > 0);
  assert.equal(s.predictions, s.prioritized);
  // nur Spiele im 48-h-Fenster, nicht begonnen
  const out = app.db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM predictions p JOIN events e ON e.id = p.event_id WHERE e.kickoff_utc <= ? OR e.kickoff_utc > ?`, ANCHOR.toISOString(), new Date(ANCHOR.getTime() + 48 * 3_600_000).toISOString())!;
  assert.equal(out.n, 0);
  const rep = app.sync.report();
  assert.ok(rep.recommendations.length <= 5);
  if (!rep.recommendations.length) assert.equal(rep.message, 'NO QUALIFIED VALUE BETS');
  // höchstens eine Empfehlung je Spiel
  assert.equal(new Set(rep.recommendations.map(r => r.eventId)).size, rep.recommendations.length);
  for (const r of rep.recommendations) {
    assert.ok(['VALUE', 'STRONG_VALUE'].includes(r.signal.status));
    assert.ok(r.signal.ev! >= 0.05, 'Mindest-EV');
    assert.ok(r.signal.ev_low! > 0, 'EV an der Untergrenze positiv');
    assert.notEqual(r.signal.status, 'STRONG_VALUE', 'kein STRONG_VALUE ohne Validierung / mit Mock');
  }
  // EV-Formel stimmt mit gespeicherten Werten überein
  const sig = app.db.get<{ model_prob: number; decision_prob: number; model_weight: number; novig_prob: number; best_odds: number; ev: number }>("SELECT model_prob, decision_prob, model_weight, novig_prob, best_odds, ev FROM value_signals WHERE ev IS NOT NULL AND novig_prob IS NOT NULL LIMIT 1")!;
  assert.ok(Math.abs(sig.decision_prob * sig.best_odds - 1 - sig.ev) < 1e-9, 'EV = p_dec × Quote − 1');
  assert.ok(Math.abs(sig.model_weight * sig.model_prob + (1 - sig.model_weight) * sig.novig_prob - sig.decision_prob) < 1e-9, 'p_dec = w·Modell + (1−w)·Markt');
  assert.equal(sig.model_weight, 0.35, 'Default-Gewicht BALANCED');
});

test('Idempotenz: zweiter Lauf zur selben Zeit mit unveränderten Eingaben erzeugt keine doppelten Snapshots, Prognosen oder Signale', async () => {
  const app = await mockApp();
  // v0.4.0: Der Mock lädt je Lauf bis zu 40 weitere xG-Statistiken nach. Das IST eine Eingabeänderung und erzeugt
  // seit der Cache-Korrektur zu Recht eine neue Prognose. Für die Idempotenz werden die Eingaben hier konstant gehalten.
  (app.providers.fixtures[0].capabilities as { matchStats: boolean }).matchStats = false;
  await app.sync.run(ANCHOR);
  const count = () => ({
    snaps: app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM odds_snapshots')!.n,
    preds: app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM predictions')!.n,
    sigs: app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM value_signals')!.n,
    alerts: app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM alerts_sent')!.n,
  });
  const a = count();
  const s2 = await app.sync.run(ANCHOR);
  assert.equal(s2.newEvents, 0);
  assert.deepEqual(count(), a);
});

test('v0.4.0: neu geladene xG-Statistiken (geänderte Eingaben) erzeugen eine neue Prognose statt der alten', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const preds = app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM predictions')!.n;
  const stats = app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM match_statistics')!.n;
  await app.sync.run(ANCHOR);
  assert.ok(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM match_statistics')!.n > stats, 'Testvoraussetzung: neue Statistiken geladen');
  assert.ok(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM predictions')!.n > preds, 'neue Eingaben → neue Prognosen');
});

test('Quoten-Snapshots sind unveränderlich', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  assert.throws(() => app.db.run("UPDATE odds_snapshots SET market_status = 'closed'"), /unveraenderlich/);
  assert.throws(() => app.db.run('UPDATE odds_prices SET odds = 9.99'), /unveraenderlich/);
});

test('Begonnene Spiele: Signale werden deaktiviert, keine neuen Empfehlungen', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const later = new Date(ANCHOR.getTime() + 60 * 3_600_000);
  await app.sync.run(later);
  const active = app.db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM value_signals s JOIN events e ON e.id = s.event_id WHERE s.active = 1 AND e.kickoff_utc <= ?`, later.toISOString())!.n;
  assert.equal(active, 0);
});

test('Alerts: identische Meldungen werden nur einmal versendet', async () => {
  const app = await mockApp({ ALERT_WEBHOOK_URL: 'https://hook.test/x' });
  const sent: unknown[] = [];
  const al = new AlertEngine(app.db, app.cfg, async (_u, b) => { sent.push(b); });
  const d = [{ kind: 'new_value' as const, dedupeKey: 'k1', title: 't', body: 'b' }];
  assert.equal(await al.dispatch(d), 1);
  assert.equal(await al.dispatch(d), 0);
  assert.equal(sent.length, 1);
});

test('Abrechnung: Ergebnis, CLV-Feld und Performance-Kennzahlen nur aus eingefrorenen Prognosen', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const po = app.db.all<{ id: number; event_id: number }>('SELECT id, event_id FROM prediction_outcomes');
  // Ergebnis simulieren
  for (const p of po) app.db.run("UPDATE events SET status = 'finished', home_goals = 2, away_goals = 1 WHERE id = ?", p.event_id);
  const r = new Settlement(app.db).run(new Date(ANCHOR.getTime() + 72 * 3_600_000));
  assert.equal(r.settled, po.length);
  const m = new PerformanceRepository(app.db).metrics('mock');
  assert.equal(m.settled, po.length);
  assert.equal(new PerformanceRepository(app.db).metrics('real').predictions, 0, 'Mock nie als echte Performance');
});

test('Backtest auf Mock-Daten bleibt UNVALIDATED und nutzt nur Vergangenheit', async () => {
  const app = await mockApp();
  const r = new BacktestingEngine(app.db).run({ includeMock: true, refitDays: 28 });
  assert.equal(r.metrics.validation.status, 'UNVALIDATED');
  assert.ok(r.metrics.validation.reasons.some(x => x.includes('Mock')));
  assert.ok(r.metrics.matches.walkForward > 0 && r.metrics.matches.holdout > 0);
  for (const m of ['1X2', 'OU', 'BTTS'] as const) {
    const w = r.metrics.weights[m]!;
    assert.ok(Math.abs(Object.values(w).reduce((a, b) => a + b, 0) - 1) < 1e-3);
  }
  const mv = app.db.get<{ validation_status: string }>("SELECT validation_status FROM model_versions WHERE id LIKE 'ensemble-1.1.0+bt%'")!;
  assert.equal(mv.validation_status, 'UNVALIDATED');
});

test('Edge Analyst (Regelmodus): Antworten nur mit gespeicherten Zahlen', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const a = new EdgeAnalyst(app.db, app.cfg);
  const top = await a.ask('¿Cuáles son las cinco mejores value bets?', 'es');
  assert.equal(top.mode, 'rules');
  const rep = app.sync.report();
  if (rep.recommendations.length) for (const r of rep.recommendations) assert.ok(top.answer.includes(r.signal.best_odds!.toFixed(2)));
  else assert.match(top.answer, /NO QUALIFIED VALUE BETS/);
  const perf = await a.ask('Wie hat das Modell bisher abgeschnitten?', 'de');
  assert.match(perf.answer, /Noch keine echten abgerechneten Prognosen/);
  const rel = await a.ask('How reliable is this model?', 'en');
  assert.match(rel.answer, /UNVALIDATED/);
});

test('Scheduler: Lock verhindert parallele Läufe desselben Jobs', async () => {
  const app = await mockApp();
  const s = new Scheduler(app);
  const [a, b] = await Promise.all([s.runJob('settlement', ANCHOR), s.runJob('settlement', ANCHOR)]);
  assert.equal([a.started, b.started].filter(Boolean).length, 1);
  assert.equal((b.started ? a : b).error, 'läuft bereits');
});

test('Event-Matching: Fuzzy-Zuordnung, vertauschte Teams und Mehrdeutigkeit werden abgelehnt', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const ev = app.db.get<{ home: string; away: string; kickoff_utc: string; id: number }>(`SELECT th.name AS home, ta.name AS away, e.kickoff_utc, e.id FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id WHERE e.status = 'scheduled' ORDER BY e.kickoff_utc LIMIT 1`)!;
  const m = new EventMatchingEngine(app.db);
  const ok = m.matchRaw('other', 'x1', ev.home.toUpperCase(), ev.away, ev.kickoff_utc);
  assert.equal(ok?.eventId, ev.id);
  assert.equal(m.matchRaw('other', 'x2', ev.away, ev.home, ev.kickoff_utc), null, 'Heim/Gast vertauscht → keine Zuordnung');
  assert.equal(m.matchRaw('other', 'x3', 'Völlig Unbekannt FC', 'Niemand United', ev.kickoff_utc), null);
  assert.ok(app.db.get("SELECT 1 FROM missing_data WHERE kind = 'swapped_home_away'"));
});
