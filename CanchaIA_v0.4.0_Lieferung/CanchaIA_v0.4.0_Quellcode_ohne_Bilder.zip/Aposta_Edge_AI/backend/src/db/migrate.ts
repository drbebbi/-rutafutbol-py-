import { loadConfig } from '../config.js';
import { Db, migrate } from './db.js';

const cfg = loadConfig();
const db = new Db(cfg.dbPath);
const applied = migrate(db);
console.log(applied.length ? `Migrationen angewendet: ${applied.join(', ')}` : 'Datenbank ist aktuell.');
db.close();
