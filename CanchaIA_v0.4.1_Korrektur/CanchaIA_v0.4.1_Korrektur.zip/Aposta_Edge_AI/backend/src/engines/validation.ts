/**
 * Nachvollziehbarer Validierungsablauf für echte historische Daten (v0.3.0).
 *
 *   1. Datenqualität prüfen (dataQuality.ts) – ungeeignete Wettbewerbe werden benannt
 *   2. Backtest (backtest.ts, unverändert in der Methodik): Walk-Forward, fester Holdout (letzte 25 %),
 *      Entscheidungszeitpunkt Anstoß − 60 min, nur Quoten vor diesem Zeitpunkt, Schlusskurse nur als Benchmark
 *   3. Bericht: Log Loss, Brier, Kalibrierung (ECE + Bins), Stichprobe, je Liga und Markt,
 *      Vergleich gegen Basisrate und Markt mit 95-%-Bootstrap-Intervallen, Validierungsstatus mit Gründen
 *   4. Speicherung in diagnostic_runs (kind = 'validation'); Modellversion unveränderlich in model_versions
 *
 * Modellparameter und Ensemble-Gewichte werden NICHT von Hand geändert. Ein im Holdout bestandener Backtest
 * (Status VALIDATED) ist die einzige Quelle neuer Gewichte; sonst bleibt alles UNVALIDATED.
 */
import type { Db } from '../db/db.js';
import { BacktestingEngine, type BacktestMetrics } from './backtest.js';
import { historicalDataQuality, type DataQualityReport } from './dataQuality.js';
import { nowIso } from '../util/core.js';
import type { Strategy } from '../config.js';

export const HISTORICAL_SOURCES = [
  {
    name: 'football-data.co.uk', use: 'Ergebnisse, Pre-Closing- und Schlusskurse (CSV-Import)',
    terms: 'Nutzungsbedingungen der Website beachten. Die Daten werden vom Betreiber selbst heruntergeladen. Eine kommerzielle Weitergabe oder Nutzung in einem kostenpflichtigen Produkt ist vor dem kommerziellen Start schriftlich mit dem Rechteinhaber zu klären (STATUS: NICHT GEKLÄRT).',
  },
  {
    name: 'The Odds API', use: 'aktuelle Quoten, Spielplan und Ergebnisse (/scores) für Live-Betrieb; keine historischen Daten in diesem Projekt',
    terms: 'Nutzungsbedingungen von The Odds API gelten; Weitergabe/Anzeige der Quoten an zahlende Endkunden vor dem kommerziellen Start prüfen (STATUS: NICHT GEKLÄRT).',
  },
  {
    name: 'Highlightly', use: 'gesperrt',
    terms: 'Nutzung für Wettanalysen nur mit schriftlicher Bestätigung (HIGHLIGHTLY_BETTING_USE_CONFIRMED). STATUS: BLOCKED.',
  },
];

export interface ValidationReport {
  id: number; generatedAt: string; status: 'VALIDATED' | 'PARTIAL' | 'UNVALIDATED' | 'FAILED';
  dataQuality: DataQualityReport; backtestRunId: number | null; metrics: BacktestMetrics | null; reasons: string[];
  sources: typeof HISTORICAL_SOURCES; markdown: string;
}

export interface ValidationOptions { includeMock?: boolean; minMatches?: number; now?: Date; strategy?: Strategy; minEv?: number; modelWeight?: number | null; maxRecommendations?: number; timezone?: string }

/**
 * Einziger Weg zu einer neuen validierten Modellversion – manuell (Admin/CLI) UND automatisch (Scheduler, v0.4.0).
 * Vorher rief der Scheduler BacktestingEngine direkt auf und umging die Datenqualitätsprüfung.
 */
export function runValidation(db: Db, opts: ValidationOptions = {}): ValidationReport {
  const started = nowIso();
  const id = Number(db.run("INSERT INTO diagnostic_runs (kind, started_at, status) VALUES ('validation', ?, 'running')", started).lastInsertRowid);
  const dq = historicalDataQuality(db, { includeMock: opts.includeMock, minMatches: opts.minMatches });
  const reasons: string[] = [];
  let metrics: BacktestMetrics | null = null, runId: number | null = null;
  if (!dq.totals.usable && !opts.includeMock) reasons.push('Keine echten historischen Daten in ausreichender Menge und Qualität – Backtest nicht aussagekräftig. CSV-Dateien von football-data.co.uk importieren (mindestens 2–3 Saisons je Liga).');
  try {
    // v0.4.0: harte Datenqualitäts-Befunde blockieren nur den betroffenen Wettbewerb (nicht alle anderen)
    const blockersByCompetition: Record<number, string[]> = {};
    for (const c of dq.competitions) {
      if (c.finishedWithResult < (opts.minMatches ?? 200) || (!opts.includeMock && c.isMock)) continue;
      const b = [...(c.duplicateMatches.length ? [`${c.name}: ${c.duplicateMatches.length} doppelte Spiele`] : []), ...(c.leakageCheck.violations ? [`${c.name}: Data Leakage`] : []), ...(c.implausibleScores ? [`${c.name}: ${c.implausibleScores} unplausible Ergebnisse`] : [])];
      if (b.length) blockersByCompetition[c.competitionId] = b;
    }
    const r = new BacktestingEngine(db).run({ includeMock: opts.includeMock, minMatches: opts.minMatches, now: opts.now, blockersByCompetition,
      strategy: opts.strategy, minEv: opts.minEv, modelWeight: opts.modelWeight, maxRecommendations: opts.maxRecommendations, timezone: opts.timezone });
    metrics = r.metrics; runId = r.runId;
    reasons.push(...metrics.validation.reasons);
  } catch (e) { reasons.push(`Backtest fehlgeschlagen: ${(e as Error).message}`); }
  // Status = Status der gespeicherten (unveränderlichen) Modellversion – eine Quelle der Wahrheit
  const status = metrics?.validation.status ?? 'UNVALIDATED';
  const rep: ValidationReport = { id, generatedAt: started, status, dataQuality: dq, backtestRunId: runId, metrics, reasons: [...new Set(reasons)], sources: HISTORICAL_SOURCES, markdown: '' };
  rep.markdown = toMarkdown(rep);
  db.run("UPDATE diagnostic_runs SET finished_at = ?, status = ?, report = ? WHERE id = ?", nowIso(), status, JSON.stringify(rep).slice(0, 4_000_000), id);
  return rep;
}

const f4 = (x: number | null | undefined) => x == null || !Number.isFinite(x) ? '–' : x.toFixed(4);
const pc = (x: number | null | undefined) => x == null || !Number.isFinite(x) ? '–' : `${(x * 100).toFixed(1)} %`;

export function toMarkdown(r: ValidationReport): string {
  const L: string[] = [];
  L.push(`# Modellvalidierung #${r.id}`, '', `Erstellt: ${r.generatedAt} · **Status: ${r.status}**`, '');
  L.push('Alle Zahlen stammen aus diesem Lauf. Keine Gewinnzusage; eine simulierte Rendite wird nur ausgewiesen, wenn zum Entscheidungszeitpunkt gültige Quoten vorliegen.', '');
  L.push('## Datenqualität', '', '| Wettbewerb | Spiele | Saisons | fehlende Ergebnisse | Duplikate | ähnliche Teams | Heim/Remis/Gast | Pre-Closing 1X2 | nutzbar |', '|---|---|---|---|---|---|---|---|---|');
  for (const c of r.dataQuality.competitions) L.push(`| ${c.name}${c.isMock ? ' (MOCK)' : ''} | ${c.finishedWithResult} | ${c.seasons.length} | ${c.missingResults} | ${c.duplicateMatches.length} | ${c.possibleDuplicateTeams.length} | ${c.homeAway ? `${pc(c.homeAway.homeWin)} / ${pc(c.homeAway.draw)} / ${pc(c.homeAway.awayWin)}` : '–'} | ${pc(c.oddsCoverage.preClosing1x2)} | ${c.usableForBacktest ? 'ja' : 'nein'} |`);
  for (const c of r.dataQuality.competitions) for (const i of c.issues) L.push(`- ${c.name}: ${i}`);
  L.push('');
  const m = r.metrics;
  if (m) {
    L.push('## Holdout je Markt', '', `Walk-Forward ${m.matches.walkForward} · Holdout ${m.matches.holdout} Spiele · Entscheidung ${m.decisionLeadMinutes} min vor Anstoß · Quelle ${m.dataSource}`, '');
    L.push('| Markt | n | Log Loss Ensemble | Basisrate | Markt (n) | Brier Ensemble | ECE | Δ vs. Basisrate (95-%-KI) | Δ vs. Markt (95-%-KI) |', '|---|---|---|---|---|---|---|---|---|');
    for (const k of ['1X2', 'OU', 'BTTS'] as const) {
      const e = m.holdoutEnsemble[k], b = m.baseline[k], mk = m.market[k], c = m.comparisons[k];
      const ci = (x: { diff: number; lo: number; hi: number } | null | undefined) => x ? `${x.diff.toFixed(4)} [${x.lo.toFixed(4)}; ${x.hi.toFixed(4)}]` : '–';
      L.push(`| ${k} | ${e?.n ?? 0} | ${f4(e?.logLoss)} | ${f4(b?.logLoss)} | ${f4(mk?.decision?.logLoss)} (${mk?.n ?? 0}) | ${f4(e?.brier)} | ${f4(e?.ece)} | ${ci(c?.ensembleVsBaseline)} | ${ci(c?.ensembleVsMarket)} |`);
    }
    L.push('', 'Negative Δ = Ensemble besser. Ein Intervall, das 0 enthält, bedeutet: kein nachweisbarer Unterschied.', '');
    L.push('## Je Liga und Markt (Holdout)', '', '| Liga | Markt | n | Ensemble LL | Basis LL | Markt LL | Ensemble Brier | ECE | Marktabdeckung |', '|---|---|---|---|---|---|---|---|---|');
    for (const c of m.byCompetition) for (const [k, v] of Object.entries(c.markets ?? {})) {
      if (!v) continue;
      L.push(`| ${c.name} | ${k} | ${v.n} | ${f4(v.ensemble?.logLoss)} | ${f4(v.baseline?.logLoss)} | ${f4(v.market?.logLoss)} | ${f4(v.ensemble?.brier)} | ${f4(v.ece)} | ${pc(v.marketCoverage)} |`);
    }
    if (m.scopes?.length) {
      L.push('', '## Validierungsstatus je Wettbewerb und Markt', '', '| Wettbewerb | Markt | Status | Vergleich mit Markt | Holdout n | Markt n | ECE | Quotenzeit |', '|---|---|---|---|---|---|---|---|');
      const ev = (e: string) => e === 'BETTER' ? 'Mehrwert belegt' : e === 'NOT_WORSE' ? 'nicht schlechter (kein Mehrwert-Nachweis)' : e === 'WORSE' ? 'schlechter' : 'nicht prüfbar';
      for (const x of m.scopes) L.push(`| ${x.competition} | ${x.market} | **${x.status}** | ${ev(x.marketEvidence)} | ${x.n} | ${x.marketN} | ${f4(x.ece)} | ${x.oddsTimesEstimated ? 'geschätzt' : 'exakt/keine'} |`);
      L.push('', 'Nur Bereiche mit Status VALIDATED gelten live als validiert. „Nicht schlechter als der Markt“ ist kein Nachweis eines Mehrwerts; STRONG_VALUE setzt einen belegten Mehrwert voraus.');
    }
    L.push('', '## Simulierte Wettstrategie', '');
    L.push(m.betting ? `${m.betting.bets} Wetten · ROI ${pc(m.betting.roi)} · max. Drawdown ${m.betting.maxDrawdown} u · ${m.betting.note}` : (m.bettingIncompleteReason ?? 'keine'));
    if (m.betting?.selection) L.push('', `Auswahl: ${m.betting.selection.rule}. Ausgeschlossen: Datenqualität ${m.betting.selection.excluded.insufficientData}, AVOID ${m.betting.selection.excluded.avoid}, korreliert (gleiches Spiel) ${m.betting.selection.excluded.correlatedSameEvent}, nie unter den aktiven ${m.betting.selection.maxActive} ${m.betting.selection.excluded.neverSelected}. Eingeschränkt: ${m.betting.selection.restricted}.`);
    L.push('');
  }
  L.push('## Ergebnis', '', `**${r.status}**`, '', ...r.reasons.map(x => `- ${x}`), '');
  L.push('Ensemble-Gewichte und Mischgewicht werden nur für validierte Bereiche (Wettbewerb × Markt) übernommen; sonst gelten die vorläufigen Standardwerte, Signale sind experimentell und STRONG_VALUE bleibt gesperrt.', '');
  L.push('## Datenquellen und Nutzungsbedingungen', '', ...r.sources.map(s => `- **${s.name}** – ${s.use}. ${s.terms}`), '');
  return L.join('\n');
}
