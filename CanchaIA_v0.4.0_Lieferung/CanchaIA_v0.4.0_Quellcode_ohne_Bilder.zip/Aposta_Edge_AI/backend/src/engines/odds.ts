/**
 * Quoten-Engine: BookmakerRegistry, Validierung, unveränderliche Snapshots, No-Vig und Marktsicht.
 */
import type { Db } from '../db/db.js';
import type { MarketId, ProviderOddsQuote, SelectionId } from '../providers/types.js';
import { MARKET_SELECTIONS } from '../providers/types.js';
import { normName, nowIso, sha, stableStringify } from '../util/core.js';
import { checkFreshness } from './freshness.js';

const SHARP = new Set(['pinnacle', 'betfair_ex_eu', 'betfair_ex_uk', 'betfair', 'sbobet', 'mock-sharp']);

export class BookmakerRegistry {
  constructor(private db: Db) {}
  /** Liefert die interne Buchmacher-ID (provider-unabhängig, aus dem Namen abgeleitet). */
  resolve(provider: string, providerBookmakerId: string, name: string, isMock = false): string {
    const a = this.db.get<{ bookmaker_id: string }>('SELECT bookmaker_id FROM bookmaker_aliases WHERE provider = ? AND provider_bookmaker_id = ?', provider, providerBookmakerId);
    if (a) return a.bookmaker_id;
    const id = provider === 'mock' ? providerBookmakerId : (normName(name).replace(/\s+/g, '_') || `${provider}_${providerBookmakerId}`);
    const sharp = SHARP.has(id) || SHARP.has(providerBookmakerId) || /pinnacle/i.test(name) ? 1 : 0;
    this.db.run('INSERT OR IGNORE INTO bookmakers (id, name, is_sharp, is_mock) VALUES (?, ?, ?, ?)', id, name, sharp, isMock ? 1 : 0);
    this.db.run('INSERT OR IGNORE INTO bookmaker_aliases (provider, provider_bookmaker_id, bookmaker_id) VALUES (?, ?, ?)', provider, providerBookmakerId, id);
    return id;
  }
}

export interface ValidationContext {
  now: Date; maxAgeMinutes: number; kickoffUtc: string; mappingConfidence: number; supportedOuLines?: number[];
  /** Historische Kurse (CSV): nur Strukturprüfung, keine Frische-/Anstoßprüfung. */
  historical?: boolean;
}

/** Prüft einen einzelnen Markt-Snapshot. Leeres Array = gültig. */
export function validateQuote(q: ProviderOddsQuote, ctx: ValidationContext): string[] {
  const errs: string[] = [];
  const sels = MARKET_SELECTIONS[q.market];
  if (!sels) return ['unbekannter Markt'];
  if (ctx.mappingConfidence < 0.9) errs.push(`Spielzuordnung unsicher (${ctx.mappingConfidence.toFixed(2)})`);
  for (const s of sels) {
    const o = q.prices[s];
    if (o == null) errs.push(`Auswahl ${s} fehlt (Markt unvollständig)`);
    else if (!Number.isFinite(o) || o <= 1.0 || o > 1000) errs.push(`unplausible Quote ${s}=${o}`);
  }
  if (Object.keys(q.prices).some(k => !sels.includes(k as SelectionId))) errs.push('fremde Auswahl im Markt');
  if (q.market === 'OU') {
    if (q.line == null) errs.push('Torlinie fehlt');
    else if (!(ctx.supportedOuLines ?? [2.5]).includes(q.line)) errs.push(`Torlinie ${q.line} nicht im MVP (nur 2,5)`);
  } else if (q.line != null) errs.push('Linie bei Markt ohne Linie');
  if (q.marketStatus !== 'open') errs.push(`Markt ${q.marketStatus}`);
  if (!ctx.historical) {
    if ((q.snapshotKind ?? 'live') !== 'live') errs.push(`historischer Snapshot (${q.snapshotKind}) im Live-Pfad`);
    const f = checkFreshness({ retrievedAt: q.retrievedAt, sourceTimestamp: q.sourceTimestamp, kickoffUtc: ctx.kickoffUtc }, ctx.now, ctx.maxAgeMinutes);
    if (!f.ok) errs.push(...f.reasons);
  }
  if (!errs.some(e => e.startsWith('Auswahl') || e.startsWith('unplausible'))) {
    const over = sels.reduce((a, s) => a + 1 / q.prices[s]!, 0) - 1;
    if (over < -0.005) errs.push(`negative Marge ${(over * 100).toFixed(2)} % (veraltete oder vermischte Preise)`);
    if (over > 0.25) errs.push(`Marge ${(over * 100).toFixed(1)} % unplausibel hoch`);
  }
  return errs;
}

export function overround(prices: Partial<Record<SelectionId, number>>, market: MarketId): number {
  return MARKET_SELECTIONS[market].reduce((a, s) => a + 1 / (prices[s] ?? Infinity), 0) - 1;
}

/** Proportionale Margenentfernung. */
export function noVig(prices: Partial<Record<SelectionId, number>>, market: MarketId): Partial<Record<SelectionId, number>> {
  const sels = MARKET_SELECTIONS[market];
  const inv = sels.map(s => 1 / prices[s]!);
  const sum = inv.reduce((a, b) => a + b, 0);
  return Object.fromEntries(sels.map((s, i) => [s, inv[i] / sum]));
}

export class OddsStore {
  private books: BookmakerRegistry;
  constructor(private db: Db) { this.books = new BookmakerRegistry(db); }

  /** Speichert einen Snapshot unveränderlich (INSERT OR IGNORE). Gibt die Snapshot-ID zurück. */
  save(eventId: number, q: ProviderOddsQuote, errors: string[], isMock: boolean): string {
    const bookId = this.books.resolve(q.provider, q.bookmakerProviderId, q.bookmakerName, isMock);
    const id = sha(stableStringify({ eventId, p: q.provider, b: bookId, m: q.market, l: q.line, t: q.retrievedAt, st: q.sourceTimestamp, k: q.snapshotKind ?? 'live', pr: q.prices }), 24);
    const complete = MARKET_SELECTIONS[q.market].every(s => q.prices[s] != null) ? 1 : 0;
    const ov = complete ? overround(q.prices, q.market) : null;
    this.db.tx(() => {
      const ins = this.db.run(`INSERT OR IGNORE INTO odds_snapshots (id, event_id, provider, bookmaker_id, market_id, line, market_status, retrieved_at, source_timestamp, is_complete, validation_errors, overround, processed_at, from_cache, snapshot_kind, time_estimated)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, id, eventId, q.provider, bookId, q.market, q.line, q.marketStatus, q.retrievedAt, q.sourceTimestamp, complete, JSON.stringify(errors), ov,
        nowIso(), q.fromCache ? 1 : 0, q.snapshotKind ?? 'live', q.timeEstimated ? 1 : 0);
      if (ins.changes) for (const [s, o] of Object.entries(q.prices)) if (o != null && o > 1) this.db.run('INSERT INTO odds_prices (snapshot_id, selection_id, odds) VALUES (?, ?, ?)', id, s, o);
    });
    return id;
  }

  /**
   * Jüngster Snapshot je Buchmacher für Event/Markt(/Linie). Standard: nur Live-Snapshots.
   * before = nur Snapshots mit Abruf vor diesem Zeitpunkt (z. B. Entscheidungszeitpunkt im Backtest).
   */
  latestPerBookmaker(eventId: number, market: MarketId, line: number | null, before?: string, kinds: string[] = ['live']): MarketBookView[] {
    const kindSql = `s.snapshot_kind IN (${kinds.map(() => '?').join(',')})`, kindSql2 = `s2.snapshot_kind IN (${kinds.map(() => '?').join(',')})`;
    const rows = this.db.all<{ id: string; bookmaker_id: string; name: string; is_sharp: number; retrieved_at: string; source_timestamp: string | null; market_status: string; validation_errors: string; overround: number | null; from_cache: number; snapshot_kind: string; time_estimated: number; provider: string; processed_at: string | null }>(
      `SELECT s.id, s.bookmaker_id, b.name, b.is_sharp, s.retrieved_at, s.source_timestamp, s.market_status, s.validation_errors, s.overround, s.from_cache, s.snapshot_kind, s.time_estimated, s.provider, s.processed_at
         FROM odds_snapshots s JOIN bookmakers b ON b.id = s.bookmaker_id
        WHERE s.event_id = ? AND s.market_id = ? AND ${line == null ? 's.line IS NULL' : 's.line = ?'} ${before ? 'AND s.retrieved_at < ?' : ''} AND ${kindSql}
          AND s.retrieved_at = (SELECT MAX(s2.retrieved_at) FROM odds_snapshots s2 WHERE s2.event_id = s.event_id AND s2.market_id = s.market_id
                                AND s2.bookmaker_id = s.bookmaker_id AND ${line == null ? 's2.line IS NULL' : 's2.line = s.line'} ${before ? 'AND s2.retrieved_at < ?' : ''} AND ${kindSql2})`,
      ...([eventId, market, ...(line == null ? [] : [line]), ...(before ? [before] : []), ...kinds, ...(before ? [before] : []), ...kinds] as (string | number)[]));
    // Bei gleichem Zeitpunkt mehrere Snapshots desselben Buchmachers (z. B. zwei Provider): den ersten gültigen nehmen
    const seen = new Set<string>();
    return rows.map(r => {
      const prices = Object.fromEntries(this.db.all<{ selection_id: string; odds: number }>('SELECT selection_id, odds FROM odds_prices WHERE snapshot_id = ?', r.id).map(p => [p.selection_id, p.odds])) as Partial<Record<SelectionId, number>>;
      const errors = JSON.parse(r.validation_errors || '[]') as string[];
      return { snapshotId: r.id, bookmakerId: r.bookmaker_id, bookmakerName: r.name, isSharp: !!r.is_sharp, retrievedAt: r.retrieved_at, sourceTimestamp: r.source_timestamp,
        status: r.market_status, errors, valid: errors.length === 0, prices, overround: r.overround, noVig: errors.length === 0 ? noVig(prices, market) : null,
        fromCache: !!r.from_cache, kind: r.snapshot_kind, timeEstimated: !!r.time_estimated, provider: r.provider, processedAt: r.processed_at };
    }).sort((a, b) => Number(b.valid) - Number(a.valid)).filter(v => (seen.has(v.bookmakerId) ? false : (seen.add(v.bookmakerId), true)));
  }
}

export interface MarketBookView {
  snapshotId: string; bookmakerId: string; bookmakerName: string; isSharp: boolean; retrievedAt: string; sourceTimestamp: string | null;
  status: string; errors: string[]; valid: boolean; prices: Partial<Record<SelectionId, number>>; overround: number | null; noVig: Partial<Record<SelectionId, number>> | null;
  fromCache?: boolean; kind?: string; timeEstimated?: boolean; provider?: string; processedAt?: string | null;
}

/**
 * Konsens der fairen Wahrscheinlichkeit: scharfer Buchmacher wenn vorhanden, sonst Median der gültigen No-Vig-Werte.
 * excludeBookmakerId: der bewertete Buchmacher wird aus der Referenz entfernt (keine doppelte Marktinformation).
 */
export function consensusNoVig(views: MarketBookView[], market: MarketId, excludeBookmakerId?: string | null): { probs: Partial<Record<SelectionId, number>>; source: string } | null {
  const valid = views.filter(v => v.valid && v.noVig && v.bookmakerId !== excludeBookmakerId);
  if (!valid.length) return null;
  const sharp = valid.find(v => v.isSharp);
  if (sharp) return { probs: sharp.noVig!, source: `sharp:${sharp.bookmakerId}` };
  const sels = MARKET_SELECTIONS[market];
  const med = (xs: number[]) => { const s = [...xs].sort((a, b) => a - b); const m = s.length >> 1; return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
  const raw = sels.map(s => med(valid.map(v => v.noVig![s]!)));
  const sum = raw.reduce((a, b) => a + b, 0);
  return { probs: Object.fromEntries(sels.map((s, i) => [s, raw[i] / sum])), source: `median:${valid.length}` };
}
