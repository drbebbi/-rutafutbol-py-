/**
 * Abrechnung (Settlement) und PerformanceRepository.
 * Kennzahlen beziehen sich ausschließlich auf tatsächlich eingefrorene, abgerechnete Prognosen.
 * Mock-Daten werden getrennt ausgewiesen und nie mit echten Ergebnissen vermischt.
 */
import type { Db } from '../db/db.js';
import type { MarketId, SelectionId } from '../providers/types.js';
import { OddsStore, consensusNoVig } from './odds.js';
import { nowIso } from '../util/core.js';

export function selectionWon(market: MarketId, sel: SelectionId, line: number | null, hg: number, ag: number): boolean {
  switch (market) {
    case '1X2': return sel === 'HOME' ? hg > ag : sel === 'DRAW' ? hg === ag : hg < ag;
    case 'OU': return sel === 'OVER' ? hg + ag > (line ?? 2.5) : hg + ag < (line ?? 2.5);
    case 'BTTS': return sel === 'YES' ? hg > 0 && ag > 0 : !(hg > 0 && ag > 0);
  }
}

export class Settlement {
  private odds: OddsStore;
  constructor(private db: Db) { this.odds = new OddsStore(db); }

  run(now: Date = new Date()): { settled: number; voided: number } {
    let settled = 0, voided = 0;
    const open = this.db.all<{ id: number; event_id: number; market_id: MarketId; selection_id: SelectionId; line: number | null; odds: number; bookmaker_id: string; status: string; home_goals: number | null; away_goals: number | null; kickoff_utc: string }>(
      `SELECT o.id, o.event_id, o.market_id, o.selection_id, o.line, o.odds, o.bookmaker_id, e.status, e.home_goals, e.away_goals, e.kickoff_utc
         FROM prediction_outcomes o JOIN events e ON e.id = o.event_id WHERE o.outcome IS NULL`);
    for (const o of open) {
      if (o.status === 'finished' && o.home_goals != null && o.away_goals != null) {
        const views = this.odds.latestPerBookmaker(o.event_id, o.market_id, o.line, o.kickoff_utc, ['live', 'closing']);
        const same = views.find(v => v.bookmakerId === o.bookmaker_id && v.valid);
        const cons = consensusNoVig(views, o.market_id);
        const closing = same?.prices[o.selection_id] ?? null;
        const won = selectionWon(o.market_id, o.selection_id, o.line, o.home_goals, o.away_goals);
        this.db.run(`UPDATE prediction_outcomes SET final_home_goals = ?, final_away_goals = ?, outcome = ?, closing_odds = ?, closing_novig_prob = ?, clv = ?, settled_at = ? WHERE id = ?`,
          o.home_goals, o.away_goals, won ? 'WIN' : 'LOSS', closing, cons?.probs[o.selection_id] ?? null, closing ? o.odds / closing - 1 : null, nowIso(now), o.id);
        settled++;
      } else if (['cancelled', 'abandoned'].includes(o.status) || (o.status === 'postponed' && now.getTime() - new Date(o.kickoff_utc).getTime() > 3 * 86_400_000)) {
        this.db.run(`UPDATE prediction_outcomes SET outcome = 'VOID', settled_at = ? WHERE id = ?`, nowIso(now), o.id);
        voided++;
      }
    }
    return { settled, voided };
  }
}

export interface PerformanceMetrics {
  scope: 'real' | 'mock';
  predictions: number; settled: number; open: number; wins: number; losses: number; voids: number;
  winRate: number | null; profit: number; roi: number | null; yield: number | null; avgOdds: number | null;
  brier: number | null; logLoss: number | null; avgClv: number | null; clvPositiveRate: number | null; clvCount: number;
  maxDrawdown: number; calibration: { bin: string; predicted: number; observed: number; n: number }[];
  series: { t: string; cumProfit: number }[];
  byMarket: Record<string, { n: number; profit: number; roi: number | null }>;
  modelVersions: string[];
}

export class PerformanceRepository {
  constructor(private db: Db) {}

  metrics(scope: 'real' | 'mock'): PerformanceMetrics {
    const rows = this.db.all<{ predicted_at: string; settled_at: string | null; market_id: string; odds: number; model_prob: number; outcome: string | null; clv: number | null; model_version: string }>(
      'SELECT predicted_at, settled_at, market_id, odds, COALESCE(decision_prob, model_prob) AS model_prob, outcome, clv, model_version FROM prediction_outcomes WHERE is_mock = ? ORDER BY COALESCE(settled_at, predicted_at)', scope === 'mock' ? 1 : 0);
    const settled = rows.filter(r => r.outcome === 'WIN' || r.outcome === 'LOSS');
    const wins = settled.filter(r => r.outcome === 'WIN').length;
    let profit = 0, peak = 0, maxDd = 0;
    const series: { t: string; cumProfit: number }[] = [];
    const byMarket: PerformanceMetrics['byMarket'] = {};
    for (const r of settled) {
      const pl = r.outcome === 'WIN' ? r.odds - 1 : -1;
      profit += pl; peak = Math.max(peak, profit); maxDd = Math.max(maxDd, peak - profit);
      series.push({ t: r.settled_at ?? r.predicted_at, cumProfit: +profit.toFixed(3) });
      const m = (byMarket[r.market_id] ??= { n: 0, profit: 0, roi: null });
      m.n++; m.profit += pl; m.roi = m.profit / m.n;
    }
    const brier = settled.length ? settled.reduce((a, r) => a + (r.model_prob - (r.outcome === 'WIN' ? 1 : 0)) ** 2, 0) / settled.length : null;
    const logLoss = settled.length ? -settled.reduce((a, r) => a + Math.log(Math.max(1e-6, r.outcome === 'WIN' ? r.model_prob : 1 - r.model_prob)), 0) / settled.length : null;
    const clvs = rows.map(r => r.clv).filter((x): x is number => x != null);
    return {
      scope, predictions: rows.length, settled: settled.length, open: rows.filter(r => !r.outcome).length, wins, losses: settled.length - wins,
      voids: rows.filter(r => r.outcome === 'VOID').length, winRate: settled.length ? wins / settled.length : null, profit: +profit.toFixed(3),
      roi: settled.length ? profit / settled.length : null, yield: settled.length ? profit / settled.length : null,
      avgOdds: settled.length ? settled.reduce((a, r) => a + r.odds, 0) / settled.length : null,
      brier, logLoss, avgClv: clvs.length ? clvs.reduce((a, b) => a + b, 0) / clvs.length : null,
      clvPositiveRate: clvs.length ? clvs.filter(x => x > 0).length / clvs.length : null, clvCount: clvs.length,
      maxDrawdown: +maxDd.toFixed(3), calibration: calibrationBins(settled.map(r => ({ p: r.model_prob, y: r.outcome === 'WIN' ? 1 : 0 }))),
      series, byMarket, modelVersions: [...new Set(rows.map(r => r.model_version))],
    };
  }
}

export function calibrationBins(items: { p: number; y: number }[], bins = 10): { bin: string; predicted: number; observed: number; n: number }[] {
  const out: { bin: string; predicted: number; observed: number; n: number }[] = [];
  for (let b = 0; b < bins; b++) {
    const lo = b / bins, hi = (b + 1) / bins;
    const sel = items.filter(i => i.p >= lo && (b === bins - 1 ? i.p <= hi : i.p < hi));
    if (!sel.length) continue;
    out.push({ bin: `${Math.round(lo * 100)}–${Math.round(hi * 100)} %`, predicted: sel.reduce((a, i) => a + i.p, 0) / sel.length, observed: sel.reduce((a, i) => a + i.y, 0) / sel.length, n: sel.length });
  }
  return out;
}

/** Expected Calibration Error. */
export function ece(items: { p: number; y: number }[]): number {
  const bins = calibrationBins(items);
  const n = items.length || 1;
  return bins.reduce((a, b) => a + (b.n / n) * Math.abs(b.predicted - b.observed), 0);
}
