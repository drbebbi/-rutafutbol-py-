/**
 * v0.4.1 – Fix 1: Der NEUESTE Prüfstand je Wettbewerb und Markt ist maßgeblich für die Freigabe.
 * Ein älterer VALIDATED-Eintrag darf einen neueren FAILED-/UNVALIDATED-Eintrag nicht umgehen.
 * Prognose-Engine (currentModelVersion) und Datenübersicht (competitionCoverage) nutzen denselben wirksamen Stand.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { memDb, testConfig } from './helpers.js';
import { PredictionEngine } from '../src/engines/prediction/index.js';
import { competitionCoverage } from '../src/engines/coverage.js';
import type { Db } from '../src/db/db.js';

type M = '1X2' | 'OU' | 'BTTS';
let seq = 0;
/** Eine Modellversion (aus einem Backtest) mit Scope-Einträgen; created_at aufsteigend. */
function version(db: Db, scopes: { comp: number; market: M; status: 'VALIDATED' | 'UNVALIDATED' | 'FAILED'; evidence?: string; w?: number }[]): string {
  const id = `ensemble-1.1.0+bt${++seq}`;
  const weights = { '1X2': { poisson: seq }, OU: { poisson: seq }, BTTS: { poisson: seq }, blendWeightByMarket: {} };
  db.run('INSERT INTO model_versions (id, description, weights, validation_status, created_at) VALUES (?, ?, ?, ?, ?)', id, 't', JSON.stringify(weights), 'PARTIAL', `2026-10-${String(seq).padStart(2, '0')}T00:00:00Z`);
  for (const s of scopes) db.run(`INSERT INTO model_scope_validations (model_version_id, backtest_run_id, competition_id, market_id, status, market_evidence, holdout_n, market_n, blend_weight, odds_times_estimated, reasons, created_at)
    VALUES (?, ?, ?, ?, ?, ?, 400, 400, ?, 1, '[]', ?)`, id, seq, s.comp, s.market, s.status, s.evidence ?? (s.status === 'VALIDATED' ? 'BETTER' : 'NOT_TESTABLE'), s.w ?? 0.3, `2026-10-${String(seq).padStart(2, '0')}T00:00:00Z`);
  return id;
}
function setup() {
  const db = memDb(); seq = 0;
  for (const id of [1, 2]) {
    db.run('INSERT INTO competitions (id, name, is_mock) VALUES (?, ?, 0)', id, `Liga ${id}`);
    db.run('INSERT OR IGNORE INTO teams (id, name, norm_name) VALUES (?, ?, ?), (?, ?, ?)', id * 10, `A${id}`, `a${id}`, id * 10 + 1, `B${id}`, `b${id}`);
    db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status, home_goals, away_goals) VALUES (?, ?, ?, '2026-01-01T15:00:00Z', 'finished', 1, 0)", id, id * 10, id * 10 + 1);
  }
  return db;
}
const cov = (db: Db, comp: number) => competitionCoverage(db, testConfig({ DATA_MODE: 'live' }), new Date('2026-10-27T12:00:00Z')).competitions.find(c => c.competitionId === comp)!;
/** Datenübersicht und Prognose-Engine müssen denselben wirksamen Stand zeigen. */
function assertConsistent(db: Db, comp: number) {
  const mv = new PredictionEngine(db).currentModelVersion(comp);
  const c = cov(db, comp);
  for (const m of ['1X2', 'OU', 'BTTS'] as M[]) {
    assert.equal(c.validation[m].status === 'VALIDATED', mv.validatedMarkets.includes(m), `${m}: Übersicht ${c.validation[m].status}, Engine ${mv.validatedMarkets.join(',')}`);
    assert.equal(c.validation[m].status === 'VALIDATED' && c.validation[m].marketEvidence === 'BETTER', mv.marketEdgeMarkets.includes(m), `${m}: Marktvorteil`);
  }
  return mv;
}

test('Fix 1: VALIDATED → FAILED – neuerer FAILED-Eintrag hebt die Freigabe auf (keine Gewichte, kein Marktvorteil)', () => {
  const db = setup();
  version(db, [{ comp: 1, market: '1X2', status: 'VALIDATED', evidence: 'BETTER' }]);
  version(db, [{ comp: 1, market: '1X2', status: 'FAILED', evidence: 'WORSE' }]);
  const mv = assertConsistent(db, 1);
  assert.equal(mv.status, 'UNVALIDATED');
  assert.deepEqual(mv.validatedMarkets, []); assert.deepEqual(mv.marketEdgeMarkets, []);
  assert.equal(mv.weights, null, 'Standardgewichte (experimenteller Betrieb)');
  assert.deepEqual(mv.blendWeightByMarket, {});
  assert.equal(mv.id, 'ensemble-1.0.0', 'Basisversion');
});

test('Fix 1: VALIDATED → UNVALIDATED – neuerer UNVALIDATED-Eintrag hebt die Freigabe auf', () => {
  const db = setup();
  version(db, [{ comp: 1, market: 'OU', status: 'VALIDATED' }]);
  version(db, [{ comp: 1, market: 'OU', status: 'UNVALIDATED' }]);
  const mv = assertConsistent(db, 1);
  assert.deepEqual(mv.validatedMarkets, []);
  assert.equal(mv.weights, null);
});

test('Fix 1: FAILED → VALIDATED – neuere Freigabe gilt mit Gewichten der neueren Version', () => {
  const db = setup();
  version(db, [{ comp: 1, market: '1X2', status: 'FAILED' }]);
  const v2 = version(db, [{ comp: 1, market: '1X2', status: 'VALIDATED', evidence: 'NOT_WORSE', w: 0.4 }]);
  const mv = assertConsistent(db, 1);
  assert.equal(mv.status, 'VALIDATED'); assert.equal(mv.id, v2);
  assert.deepEqual(mv.validatedMarkets, ['1X2']); assert.deepEqual(mv.marketEdgeMarkets, [], 'NOT_WORSE ist kein Marktvorteil');
  assert.deepEqual(mv.weights, { '1X2': { poisson: 2 } });
  assert.deepEqual(mv.blendWeightByMarket, { '1X2': 0.4 });
});

test('Fix 1: unterschiedliche Prüfstände bei 1X2, OU und BTTS – jeder Markt nach seinem neuesten Eintrag', () => {
  const db = setup();
  version(db, [{ comp: 1, market: '1X2', status: 'VALIDATED' }, { comp: 1, market: 'OU', status: 'VALIDATED', w: 0.2 }, { comp: 1, market: 'BTTS', status: 'FAILED' }]);
  version(db, [{ comp: 1, market: '1X2', status: 'FAILED' }, { comp: 1, market: 'BTTS', status: 'VALIDATED', evidence: 'NOT_WORSE', w: 0.5 }]);
  const mv = assertConsistent(db, 1);
  assert.deepEqual([...mv.validatedMarkets].sort(), ['BTTS', 'OU'], 'OU bleibt aus Version 1 gültig, 1X2 entzogen, BTTS neu');
  assert.deepEqual(mv.marketEdgeMarkets, ['OU']);
  assert.deepEqual(mv.weights, { OU: { poisson: 1 }, BTTS: { poisson: 2 } }, 'Gewichte je Markt aus der jeweils maßgeblichen Version');
  assert.deepEqual(mv.blendWeightByMarket, { OU: 0.2, BTTS: 0.5 });
  assert.equal((mv.weights as Record<string, unknown>)['1X2'], undefined);
});

test('Fix 1: strikte Trennung der Wettbewerbe', () => {
  const db = setup();
  version(db, [{ comp: 1, market: '1X2', status: 'VALIDATED' }, { comp: 2, market: '1X2', status: 'VALIDATED' }]);
  version(db, [{ comp: 2, market: '1X2', status: 'FAILED' }]);
  const a = assertConsistent(db, 1), b = assertConsistent(db, 2);
  assert.deepEqual(a.validatedMarkets, ['1X2'], 'Liga 1 behält ihre Freigabe');
  assert.deepEqual(b.validatedMarkets, [], 'Liga 2 verliert ihre');
  assert.equal(new PredictionEngine(db).currentModelVersion(3).status, 'UNVALIDATED', 'ungeprüfter Wettbewerb');
});

test('Fix 1: historische Prüfberichte bleiben unverändert und unveränderlich', () => {
  const db = setup();
  version(db, [{ comp: 1, market: '1X2', status: 'VALIDATED' }]);
  version(db, [{ comp: 1, market: '1X2', status: 'FAILED' }]);
  const before = db.all('SELECT * FROM model_scope_validations ORDER BY id');
  new PredictionEngine(db).currentModelVersion(1); cov(db, 1);
  assert.deepEqual(db.all('SELECT * FROM model_scope_validations ORDER BY id'), before);
  assert.throws(() => db.run("UPDATE model_scope_validations SET status = 'VALIDATED'"), /unveraenderlich/);
});
