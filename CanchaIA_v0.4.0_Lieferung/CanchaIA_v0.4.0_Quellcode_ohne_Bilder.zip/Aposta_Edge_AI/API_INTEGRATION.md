# API-Integration (v0.3.0)

## Nutzungsrechte zuerst

Highlightly-Daten dürfen nur mit entsprechenden Nutzungsrechten für Wettanalysen verwendet werden. Der Adapter ist deshalb doppelt gesperrt:

1. ohne `HIGHLIGHTLY_API_KEY` → Status `disabled`
2. ohne `HIGHLIGHTLY_BETTING_USE_CONFIRMED=true` → Status `blocked`, keine einzige Anfrage

Das Flag erst setzen, wenn Highlightly die Nutzung für Wettanalysen **schriftlich** bestätigt hat, und die Bestätigung aufbewahren. Bis dahin: Mock-Modus oder Weg B (The Odds API + CSV-Historie). Die Nutzungsbedingungen von The Odds API und football-data.co.uk gelten ebenso und sind vom Betreiber zu prüfen.

Schlüssel stehen nur in Umgebungsvariablen beziehungsweise `.env` (nicht in Git):

- Logs und Fehlerprotokolle werden geschwärzt (`apiKey`, `token`, `authorization`, `x-rapidapi-key`, Telegram-Bot-Token).
- Cache-Schlüssel und das Request-Log enthalten keine Query-Parameter mit `key`/`token`/`secret`.
- Highlightly: Schlüssel nur im Header. The Odds API verlangt ihn als Query-Parameter. Diese URL verlässt den Server nie.
- Kein Endpunkt liefert Schlüssel aus (Test „Secrets: Antworten enthalten keine API-Schlüssel“).

## Zeitstempel einer Quote

Jeder Snapshot speichert getrennt:

| Feld | Bedeutung |
|---|---|
| `retrieved_at` | Zeitpunkt, zu dem der Server die Antwort **tatsächlich** vom Provider geholt hat. Bei einem Cache-Treffer bleibt das der ursprüngliche Abrufzeitpunkt. |
| `source_timestamp` | Zeitstempel des Providers (z. B. `last_update` bei The Odds API), falls vorhanden |
| `from_cache` | 1, wenn die Antwort aus dem Cache kam |
| `processed_at` | Zeitpunkt der Verarbeitung durch die App |
| `snapshot_kind` | `live` (Abruf vor dem Spiel), `pre_closing` (CSV, vor dem Spiel), `closing` (Schlusskurs) |
| `time_estimated` | 1, wenn der Zeitpunkt geschätzt ist (CSV) |

Signale und Empfehlungen übernehmen `odds_retrieved_at`, `odds_source_timestamp`, `validated_at` und `valid_until`. Die Oberfläche zeigt Alter, Quelle und Gültigkeit an.

## Frische-Regeln

Quelle der Wahrheit: `backend/src/engines/freshness.ts`. Maßgeblich ist der **ältere** von Abruf- und Quellzeitpunkt.

| Zeit bis Anstoß | höchstes Alter |
|---|---|
| > 24 h | 90 min |
| 6–24 h | 60 min |
| 1–6 h | 30 min |
| < 1 h | 10 min |

- `ODDS_MAX_AGE_MINUTES` (Default 90) ist die Grenze für > 24 h. Die Stufen 60/30/10 sind feste Obergrenzen. Ein kleinerer Wert verschärft alle Stufen, ein größerer lockert nur die Stufe > 24 h.
- Ohne Quellzeitstempel gilt die halbe Grenze.
- Zeitstempel mehr als 2 min in der Zukunft oder unlesbare Zeitstempel → ungültig.
- `valid_until` einer Empfehlung ist der früheste der Zeitpunkte „Quote zu alt“ und „Anstoß“. Die Grenze wird minutengenau neu berechnet, weil sie mit Nähe zum Anstoß schrumpft.
- Jede Empfehlung wird **bei jedem Abruf** neu geprüft: Status, Spielbeginn, neueste Prognose, Datenqualität, Snapshot offen, gültig und frisch, Zuordnungssicherheit ≥ 0,9, kein neuerer Snapshot desselben Buchmachers mit gesunkener Quote. Ungültige Empfehlungen werden mit Grund deaktiviert und unter „Kürzlich zurückgezogen“ angezeigt.

## Dynamische Cache-Regel (v0.3.0)

Feste 20 min Cache passten nicht zur 10-min-Grenze in der letzten Stunde vor Anstoß: Eine Cache-Kopie konnte dort schon unbrauchbar sein, bevor der Cache ablief. Jetzt gilt (`oddsCacheMaxAgeSeconds` in `freshness.ts`):

- Ein Cache-Eintrag für Quoten darf **höchstens halb so alt** sein wie die Frische-Grenze des nächsten noch nicht begonnenen Anstoßes **im gecachten Inhalt**.
- Ohne Quellzeitstempel (Highlightly) gilt die halbe Grenze nochmals halbiert.
- Obergrenze 20 min, Untergrenze 2 min.

| Zeit bis Anstoß | Frische-Grenze | max. Cache-Alter (mit / ohne Quellzeit) |
|---|---|---|
| > 6 h | 60–90 min | 20 min |
| 1–6 h | 30 min | 15 min / 7,5 min |
| < 1 h | 10 min | 5 min / 2,5 min |

- Ein zu alter Eintrag wird verworfen und neu abgerufen. Der Grund steht im Abrufprotokoll („Cache verworfen: … s alt, erlaubt … s“).
- Die Freshness-Prüfung bleibt unverändert die letzte Instanz.
- Bei stündlichem Sync greift die Regel vor allem bei manuellen oder kontrollierten Läufen. Empfehlungen für Spiele, die in weniger als 1 h beginnen, laufen weiterhin 10 min nach dem Abruf ab.

## Abrufprotokoll

Jeder API-Abruf wird in `api_requests` gespeichert: Anbieter, Endpunkt, bereinigte Parameter **ohne Schlüssel**, Zweck, Status, Cache-Treffer, Credits, Dauer und Zeitpunkt. Das gilt auch für Cache-Treffer und Fehlversuche.

- Anzeige: Admin → API-Abrufe
- Abruf per API: `GET /api/admin/api-requests?provider=theoddsapi&limit=100`
- Aufbewahrung: 35 Tage (Cleanup-Job)

## Kontingent und Credits

Die ApiQueue (`backend/src/api/apiQueue.ts`) rechnet in **Credits**, nicht in Anfragen:

- Kosten pro Anfrage: aus dem Kosten-Header des Providers, sonst eine Schätzung.
- Tages- und Monatsbudget je Provider, persistiert in `api_requests.cost`. Cache-Treffer kosten 0.
- Gleiche Anfragen gleichzeitig werden zusammengelegt (Dedupe).
- **429:** höchstens **eine** Wiederholung und nur bei `Retry-After` ≤ 60 s. Sonst wird der Provider gesperrt, bis `Retry-After` vergangen ist (ohne Header 15 min). Meldet der Provider ein Restkontingent von 0, gilt die Sperre bis zum nächsten UTC-Tag. Die Sperre steht in `provider_health.paused_until` und überlebt einen Neustart. Ein Admin kann sie unter Admin → Provider aufheben.
- **401/403:** Provider `blocked`, keine Wiederholung.
- **5xx/Netzwerk:** exponentielles Backoff mit Jitter, höchstens 3 Wiederholungen.

Fällt ein Provider aus, laufen bestehende Empfehlungen über `valid_until` ab. Die App zeigt `PROVIDER UNAVAILABLE` statt alter Quoten.

## Highlightly Football API

Quelle: offizielle OpenAPI-Spezifikation `https://highlightly.net/football-api/documentation/docs.json`, API-Version **8.2.7**, gelesen am 12.10.2026.

- Basis: `https://soccer.highlightly.net` (direkt) oder `https://football-highlights-api.p.rapidapi.com` (RapidAPI, dann `HIGHLIGHTLY_RAPIDAPI_HOST` setzen)
- Header: `x-rapidapi-key` (immer), `x-rapidapi-host` (nur RapidAPI)
- Kontingent-Header: `x-ratelimit-requests-limit`, `x-ratelimit-requests-remaining` → `provider_health`. 1 Credit je Anfrage.

| Zweck | Endpunkt | Parameter (laut Spezifikation) | Cache |
|---|---|---|---|
| Spiele je Tag | `GET /matches` | `date`, `timezone`, `limit` ≤ 100, `offset` | 30 min |
| Historie je Liga | `GET /matches` | `leagueId`, `season`, `limit`, `offset` | 12 h |
| Spieldetails / Ergebnis | `GET /matches/{id}` | – | 10 min |
| Letzte 5 Spiele | `GET /last-five-games` | `teamId` | 6 h |
| Direkter Vergleich | `GET /head-2-head` | `teamIdOne`, `teamIdTwo` | 24 h |
| Spielstatistik (xG, Schüsse) | `GET /statistics/{matchId}` | – | 24 h |
| Aufstellungen | `GET /lineups/{matchId}` | – | 20 min |
| Tabelle | `GET /standings` | `leagueId`, `season` | 6 h |
| Quoten | `GET /odds` | `matchId`, `oddsType=prematch` | dynamisch, höchstens 20 min (siehe oben) |
| Buchmacher | `GET /bookmakers` | `limit` ≤ 100, `offset` | 7 d |


Laut Spezifikation **nicht** vorhanden: ein Verletzungs- oder Sperren-Endpunkt. **Nicht dokumentiert** sind die Namen der Odds-Märkte. Unbekannte Märkte landen in Admin → Missing Data (`unmapped_market`).

Budget: `HIGHLIGHTLY_DAILY_BUDGET` (Default 6.500 bei PRO mit 7.500/Tag). Grobe Schätzung bei stündlichem Lauf mit 60 Spielen: 1.500–2.000 Credits/Tag.

Status: **BLOCKED** (Rechte) und **NOT LIVE VERIFIED** (kein Netzwerkzugang). Pfade, Parameter und Feldnamen sind gegen Antworten in Spezifikationsform getestet.

## The Odds API (v4)

The Odds API ist seit v0.3.0 ausdrücklich ein **vollwertiger Fixture-Provider**. Die Diagnose meldet keinen fehlenden Fixture-Provider mehr, wenn nur `THE_ODDS_API_KEY` gesetzt ist. Die Modell-Historie kommt in diesem Fall aus dem CSV-Import.

| Zweck | Endpunkt | Kosten laut Doku | Cache |
|---|---|---|---|
| Wettbewerbe | `GET /v4/sports` | 0 | 6 h |
| Spiele + 1X2 + Über/Unter | `GET /v4/sports/{sport}/odds?regions=eu,uk&markets=h2h,totals` | Märkte × Regionen = **4** | dynamisch ≤ 20 min |
| BTTS (optional) | `GET /v4/sports/{sport}/events/{id}/odds?markets=btts` | gelieferte Märkte × Regionen (leere Antwort 0) | dynamisch ≤ 20 min |
| Ergebnisse | `GET /v4/sports/{sport}/scores?daysFrom=3` | **2** | 30 min |

- **Credits:** tatsächliche Kosten aus `x-requests-last`, Rest aus `x-requests-remaining`. Monatsbudget `THE_ODDS_API_MONTHLY_BUDGET` (Default 500), Tagesbudget = Monatsbudget/30.
- **BTTS:** Standard aus (`THE_ODDS_API_INCLUDE_BTTS=false`). Wenn aktiviert:
  - höchstens `THE_ODDS_API_BTTS_MAX_EVENTS` (Default 5) Spiele je Lauf, nächste Anstöße zuerst
  - nur solange mindestens `THE_ODDS_API_BTTS_RESERVE_PCT` (Default 25 %) des Monatsbudgets frei ist
  - ein Budgetfehler beendet nur BTTS, nicht den Lauf
- **Nicht verfügbare Märkte:** Die Spieldetailseite zeigt je Markt `AVAILABLE`, `MARKET SUSPENDED` oder `NOT AVAILABLE` mit Grund (z. B. „nicht aktiviert“, „Limit erreicht“, „vom Provider nicht geliefert“). Früher stand dort fälschlich „MARKET SUSPENDED“.
- **Ergebnisse:** Über `/scores` gilt nur `completed: true` mit lesbaren Toren als beendet. Damit lassen sich Pilot-Empfehlungen abrechnen (`THE_ODDS_API_RESULTS=true`).
- **Begonnene Spiele:** Liefert der Anbieter ein Spiel mit Anstoß in der Vergangenheit, wird es nicht als Pre-Match angelegt (`startedExcluded` im Sync-Bericht).

**Rechenbeispiel Pilot:** 3 Wettbewerbe, davon 2 aktiv, stündlich: 2 × 4 × 24 ≈ 192 Credits/Tag, also rund 5.800/Monat. Mit dem kostenlosen Plan (500/Monat) ist das nicht machbar: Das Tagesbudget beträgt dann 16 Credits, also reicht es nur für 2 Läufe pro Tag. Danach meldet der Sync `paused_quota`, und Empfehlungen laufen ordnungsgemäß ab. Möglich sind ein längeres Intervall (`SYNC_INTERVAL_MINUTES=360` → ca. 970/Monat), nur eine Region (`THE_ODDS_API_REGIONS=eu` halbiert die Kosten), nur manuelle kontrollierte Läufe oder ein bezahlter Plan.

### Pilotmodus

- `PILOT_MODE=true` beschränkt die Abrufe auf `PILOT_SPORT_KEYS` (Default `soccer_epl,soccer_spain_la_liga,soccer_uefa_champs_league`) und auf höchstens `PILOT_MAX_EVENTS` Spiele je Lauf.
- Die Keys werden gegen `/v4/sports` (kostenlos) geprüft. Unbekannte oder derzeit inaktive Keys werden übersprungen und im Bericht genannt. Es werden nur tatsächlich verfügbare Keys abgefragt.
- **Kontrollierter Sync** (Admin): `POST /api/admin/diagnostics/controlled-sync {maxEvents}`, siehe [LIVE_API_TEST_REPORT.md](LIVE_API_TEST_REPORT.md).

### Verknüpfung mit der CSV-Historie (v0.3.0)

In v0.2.0 entstanden für „Manchester United“ (The Odds API, `soccer_epl`) und „Man United“ (CSV, `E0`) zwei Teams und zwei Wettbewerbe. Live-Spiele hatten dadurch nie Historie (immer INSUFFICIENT DATA). Jetzt:

- **Wettbewerbe:** feste, dokumentierte Zuordnung in `backend/src/engines/linking.ts`:

  | The Odds API | CSV |
  |---|---|
  | `soccer_epl` | `E0` |
  | `soccer_efl_champ` | `E1` |
  | `soccer_spain_la_liga` | `SP1` |
  | `soccer_germany_bundesliga` | `D1` |
  | `soccer_italy_serie_a` | `I1` |
  | `soccer_france_ligue_one` | `F1` |
  | `soccer_netherlands_eredivisie` | `N1` |
  | `soccer_portugal_primeira_liga` | `P1` |

  Die Champions League hat keine CSV-Quelle.
- **Teams:** nur innerhalb desselben Wettbewerbs und mit Teams eines anderen Providers. Bedingungen:
  - Ähnlichkeit ≥ 0,85 nach Normalisierung und Erweiterung bekannter CSV-Abkürzungen („Man United“, „Nott'm Forest“, „Wolves“, „Ath Madrid“ …)
  - Abstand ≥ 0,10 zum zweitbesten Kandidaten

  Alles andere wird **nicht geraten**, sondern als `unlinked_team` gemeldet und per Admin → Team-Aliase zugeordnet.
- Bestehende Doppel-Teams aus v0.2.0 werden nicht automatisch zusammengeführt (zu riskant). Sie erscheinen in der Datenqualitätsprüfung als „mögliche doppelte Teams“.

Status: **IMPLEMENTED, TESTED (nachgebaute Antworten), NOT LIVE VERIFIED**.

## Historische Daten per CSV (football-data.co.uk)

```bash
cd backend && npm run import:csv -- /pfad/E0.csv /pfad/SP1.csv
```

oder Admin → CSV-Import. Unterstützt werden das Hauptligen-Format (`Div, Date, HomeTeam, AwayTeam, FTHG, FTAG, …`) und das Format der Zusatzligen (`Country, League, Season, Home, Away, HG, AG, …`).

| CSV-Spalten | gespeichert als | Zeitpunkt |
|---|---|---|
| `PSH/PSD/PSA`, `B365H/…`, `AvgH/…`, `P>2.5`, `B365>2.5`, `Avg>2.5` | `pre_closing` | Anstoß − 24 h (**geschätzt**, `time_estimated=1`) |
| `PSCH/…`, `B365CH/…`, `AvgCH/…`, `PC>2.5`, `AvgC>2.5` | `closing` | Anstoß − 1 min |

**Anstoßzeit (v0.3.0 korrigiert):** football-data.co.uk gibt britische Ortszeit an. v0.2.0 zog pauschal 1 h ab, im Winter lag der Anstoß dadurch 1 h zu früh. Jetzt gilt die korrekte Umrechnung GMT/BST (letzter Sonntag im März bzw. Oktober, 01:00 UTC). Bei einem erneuten Import bereits importierter Dateien wird die Anstoßzeit des Spiels korrigiert. Die alten Snapshots bleiben unverändert erhalten (unveränderlich), neue kommen mit korrekter Zeit hinzu.

Im Backtest gilt:

- Wettquote und Marktreferenz sind ausschließlich `live`/`pre_closing`-Snapshots, die **vor** dem Entscheidungszeitpunkt (Anstoß − 60 min) abgerufen wurden.
- Schlusskurse dienen nur als Benchmark und für CLV, nie als Wettquote.
- Ohne zeitlich gültige Quoten gibt es keine Rendite. Der Bericht sagt dann „unvollständig“.

Die Dateien lädt der Betreiber selbst herunter, unter den Bedingungen von football-data.co.uk.

## Neuen Provider anbinden

`FootballDataProvider` und/oder `OddsProvider` aus `backend/src/providers/types.ts` implementieren:

- alle HTTP-Aufrufe über `ApiQueue.requestMeta` (Budget, Cache, Backoff), mit `note` (Zweck) und für Quoten mit `maxCacheAgeSeconds` (dynamische Cache-Regel)
- `retrievedAt` = `fetchedAt` aus der Queue, nie „jetzt“
- `sourceTimestamp` übernehmen, falls der Provider einen liefert
- Kosten (`cost`) angeben oder den Kosten-Header registrieren
- in `buildProviders` (`backend/src/app.ts`) mit Budget registrieren und in `providerStates` (`config.ts`) aufnehmen
- optional `lastRunReport()` für die Marktabdeckung implementieren
