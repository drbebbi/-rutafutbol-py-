// E2E-Branding- und Regressionstest + Screenshots der echten React-App (Mock-Modus), CanchaIA v0.3.2.
// Voraussetzung: laufender Server auf :8080 im Mock-Modus mit ADMIN_EMAIL=admin@canchaia.test, ADMIN_PASSWORD=TestPasswort-2026!
// und einem Benutzer usuario@canchaia.test / UsuarioPrueba-2026 (npm --prefix backend run user:create).
// Aufruf: node scripts/e2e-branding.mjs <pfad-zu-playwright> docs/screenshots
import { createRequire } from 'node:module';
import fs from 'node:fs';
const require = createRequire(import.meta.url);
const { chromium } = require(process.argv[2]);
const OUT = process.argv[3];
fs.mkdirSync(OUT, { recursive: true });
const BASE = 'http://localhost:8080';
const ADMIN = ['admin@canchaia.test', 'TestPasswort-2026!'];
const USER = ['usuario@canchaia.test', 'UsuarioPrueba-2026'];
const OLD = /Aposta|EDGE ANALYST|Edge AI|Edge Analyst/;

const results = []; let failed = 0;
const check = (name, ok, info = '') => { results.push(`${ok ? 'PASS' : 'FAIL'}  ${name}${info ? ' – ' + info : ''}`); if (!ok) failed++; };

const browser = await chromium.launch();
async function ctx(viewport, mobile) {
  const c = await browser.newContext({ viewport, deviceScaleFactor: 2, isMobile: mobile, hasTouch: mobile, locale: 'es-PY', timezoneId: 'America/Asuncion' });
  const p = await c.newPage();
  p._errors = [];
  p.on('pageerror', e => p._errors.push(String(e)));
  p.on('console', m => { if (m.type() === 'error' && !/fonts\.g/.test(m.text()) && !/Failed to load resource/.test(m.text())) p._errors.push(m.text()); });
  return p;
}
async function login(p, [e, pw]) {
  await p.goto(BASE + '/#/'); await p.waitForSelector('#email');
  await p.fill('#email', e); await p.fill('#password', pw);
  await p.click('form button.btn.block'); await p.waitForSelector('main.main', { timeout: 15000 });
}
async function settle(p) { await p.waitForLoadState('networkidle').catch(() => {}); await p.waitForTimeout(700); }
async function visit(p, hash) { await p.goto(BASE + '/#' + hash); await settle(p); }
const text = p => p.evaluate(() => document.body.innerText);

const desk = await ctx({ width: 1440, height: 900 }, false);
const mob = await ctx({ width: 390, height: 844 }, true);

// ---------- Anmeldeseite
for (const [p, tag] of [[desk, 'desktop'], [mob, 'mobile']]) {
  await p.goto(BASE + '/'); await p.waitForSelector('#email'); await settle(p);
  check(`[${tag}] Login: Titel`, (await p.title()) === 'CanchaIA · Inteligencia Futbolística', await p.title());
  check(`[${tag}] Login: <html lang=es-PY>`, (await p.getAttribute('html', 'lang')) === 'es-PY');
  const t = await text(p);
  check(`[${tag}] Login: Marke + Slogan sichtbar`, t.includes('CanchaIA') && t.includes('Inteligencia Futbolística'));
  check(`[${tag}] Login: Standardsprache Spanisch`, t.includes('Iniciar sesión'));
  check(`[${tag}] Login: kein alter Markenname`, !OLD.test(t));
  await p.screenshot({ path: `${OUT}/${tag}-login.png`, fullPage: tag === 'desktop' });
}
const fav = await (await fetch(BASE + '/favicon.svg')).text();
check('Favicon neu (CanchaIA)', fav.includes('<title>CanchaIA</title>') && fav.includes('circle'));
check('Apple-Touch-Icon ausgeliefert', (await fetch(BASE + '/apple-touch-icon.png')).headers.get('content-type') === 'image/png');

// ---------- Admin-Login, Sync anstoßen (Mock)
await login(desk, ADMIN);
const syncRes = await desk.evaluate(async () => {
  const me = await (await fetch('/api/auth/me')).json();
  const r = await fetch('/api/admin/jobs/hourly_sync/run', { method: 'POST', headers: { 'content-type': 'application/json', 'x-csrf-token': me.csrfToken } });
  return r.status;
});
check('Mock-Sync über bestehende Admin-API', syncRes === 200, `HTTP ${syncRes}`);
const settings = await desk.evaluate(async () => (await fetch('/api/settings')).json());
check('Benutzer-Standard: language=es, timezone=America/Asuncion', settings.language === 'es' && settings.timezone === 'America/Asuncion', `${settings.language} / ${settings.timezone}`);
const matches = await desk.evaluate(async () => (await fetch('/api/matches?hours=168')).json());
const list = Array.isArray(matches) ? matches : (matches.items ?? matches.matches ?? []);
const matchId = list[0]?.id;
check('Spiele nach Sync vorhanden', !!matchId, `${list.length} Spiele`);

const pages = [['/', 'home', 'CanchaIA · Inteligencia Futbolística'], ['/matches', 'matches', 'Partidos · CanchaIA'], [`/match/${matchId}`, 'match', 'Partidos · CanchaIA'],
  ['/edge', 'analyst', 'Analista IA · CanchaIA'], ['/performance', 'performance', 'Rendimiento · CanchaIA'], ['/settings', 'settings', 'Ajustes · CanchaIA'], ['/admin', 'admin', 'Admin · CanchaIA']];

await login(mob, ADMIN);
for (const [p, tag] of [[desk, 'desktop'], [mob, 'mobile']]) {
  for (const [h, name, title] of pages) {
    await visit(p, h);
    if (name === 'analyst') {
      await p.fill('#chat-q', '¿Cuáles son las cinco mejores value bets?');
      await p.press('#chat-q', 'Enter');
      await p.waitForSelector('.qa', { timeout: 10000 }); await p.waitForTimeout(2500); await settle(p);
    }
    const t = await text(p);
    check(`[${tag}] ${name}: Titel`, (await p.title()) === title, await p.title());
    check(`[${tag}] ${name}: kein alter Markenname`, !OLD.test(t), (t.match(OLD) ?? [''])[0]);
    check(`[${tag}] ${name}: keine Fehlermeldung`, !/No se pudieron cargar|Error:/.test(t));
    if (name === 'home') check(`[${tag}] home: Marke sichtbar`, t.includes('CanchaIA'));
    if (name === 'analyst') check(`[${tag}] analyst: Antwort erhalten`, /Respuesta|VERDICT|MARKET/.test(t));
    if (name === 'settings') {
      check(`[${tag}] settings: Español (Paraguay) gewählt`, await p.$eval('#s-lang', el => el.value === 'es' && el.selectedOptions[0].text === 'Español (Paraguay)'));
      check(`[${tag}] settings: Zeitzone America/Asuncion`, await p.$eval('#s-tz', el => el.value === 'America/Asuncion'));
      check(`[${tag}] settings: Preise in Guaraní (Gs., es-PY)`, /\d{1,3}(\.\d{3})+ Gs\./.test(t), (t.match(/[\d.]+ Gs\./) ?? [''])[0]);
    }
    if (name === 'matches') {
      // Anstoßzeit: angezeigte Uhrzeit = Asunción-Zeit
      const m0 = list[0];
      const expect = new Intl.DateTimeFormat('es-PY', { timeZone: 'America/Asuncion', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(m0.kickoff_utc ?? m0.kickoffUtc ?? m0.kickoff));
      check(`[${tag}] matches: Anstoß in America/Asuncion (${expect})`, t.includes(expect));
    }
    await p.evaluate(() => window.scrollTo(0, 0)); await p.waitForTimeout(400);
    await p.screenshot({ path: `${OUT}/${tag}-${name}.png`, fullPage: tag === 'desktop' });
  }
  check(`[${tag}] keine JS-/Konsolenfehler`, p._errors.length === 0, p._errors.slice(0, 3).join(' | '));
}

// ---------- Sprachwechsel EN / DE / zurück ES (bestehende Funktion)
for (const [code, nav, lang] of [['EN', 'AI Analyst', 'en-GB'], ['DE', 'KI-Analyst', 'de-DE'], ['ES', 'Analista IA', 'es-PY']]) {
  await visit(desk, '/');
  await desk.click(`header .langsel button:has-text("${code}")`); await settle(desk);
  const t = await text(desk);
  check(`Sprache ${code}: Navigation „${nav}“`, t.includes(nav));
  check(`Sprache ${code}: <html lang=${lang}>`, (await desk.getAttribute('html', 'lang')) === lang);
  check(`Sprache ${code}: Slogan bleibt`, t.includes('Inteligencia Futbolística'));
  check(`Sprache ${code}: kein alter Markenname`, !OLD.test(t));
  if (code === 'EN') {
    await desk.screenshot({ path: `${OUT}/desktop-home-en.png`, fullPage: true });
    await visit(desk, '/matches'); await desk.screenshot({ path: `${OUT}/desktop-matches-en.png`, fullPage: true });
    check('EN: internationale Ligen sichtbar', /Matches/.test(await text(desk)));
  }
}

// ---------- Normaler Benutzer (keine Admin-Rechte)
const u = await ctx({ width: 390, height: 844 }, true);
await login(u, USER); await settle(u);
const ut = await text(u);
check('[user] Startseite lädt', ut.includes('CanchaIA') && !OLD.test(ut));
await visit(u, '/admin');
check('[user] /admin nicht erreichbar (zeigt Start)', (await u.title()) === 'CanchaIA · Inteligencia Futbolística');
const adminApi = await u.evaluate(async () => (await fetch('/api/admin/subscriptions')).status);
check('[user] Admin-API weiterhin gesperrt', adminApi === 403, `HTTP ${adminApi}`);
// Logout
await visit(u, '/settings');
await u.locator('main button:visible', { hasText: 'Salir' }).first().click(); await u.waitForSelector('#email');
check('[user] Abmelden funktioniert', true);

await browser.close();
fs.writeFileSync(`${OUT}/../e2e-result.txt`, results.join('\n') + `\n\n${results.length - failed}/${results.length} bestanden\n`);
console.log(results.join('\n')); console.log(`\n${results.length - failed}/${results.length} bestanden`);
process.exit(failed ? 1 : 0);
