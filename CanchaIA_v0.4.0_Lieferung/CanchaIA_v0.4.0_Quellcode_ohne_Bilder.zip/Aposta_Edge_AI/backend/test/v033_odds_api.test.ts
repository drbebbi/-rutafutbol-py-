/**
 * v0.3.3 – The Odds API Integration: automatisierte Integrationstests.
 *
 * WICHTIG: Alle Provider-Antworten sind nach der offiziellen v4-Doku NACHGEBAUT (test/fixtures/theOddsApiSamples.ts
 * und unten). Es gibt keinen Netzwerkzugriff und keinen echten Schlüssel. Diese Tests ersetzen KEINEN Live-Test;
 * der Live-Test ist `npm run odds:check` in der Umgebung mit dem Secret (siehe THE_ODDS_API_INTEGRATION.md).
 *
 * Abgedeckte Prüfpunkte (Auftrag v0.3.3, Abschnitt 7):
 *  1 Schlüssel serverseitig geladen · 2 Authentifizierung · 3 Champions-League-Key · 4 Quotenverarbeitung (LIVE)
 *  5 1X2 inkl. Unentschieden · 6 Über/Unter 2,5 · 7 BTTS · 8 fehlende Märkte nicht erfunden · 9 Limits · 10 Schlüssel nicht im Frontend
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import type { AddressInfo } from 'node:net';
import { loadConfig, configIssues } from '../src/config.js';
import { buildApp, type App } from '../src/app.js';
import { controlledSync } from '../src/engines/diagnostic.js';
import { oddsApiStatus, paidGateReason, testOddsApiConnection, UCL_SPORT_KEY } from '../src/engines/oddsApiStatus.js';
import { convertOaEvent, normalizeOddsApiBase, oddsApiUrl } from '../src/providers/theOddsApi.js';
import { OddsStore, validateQuote } from '../src/engines/odds.js';
import { createServer } from '../src/server.js';
import { memDb, testConfig, TEST_SERVICE_TOKEN } from './helpers.js';
import { fakeFetcher, iso, oddsEvent, bttsEvent } from './fixtures/theOddsApiSamples.js';

const MIN = 60_000, H = 3_600_000;
const KEY = 'test-odds-key-NOT-REAL-7f3a9c';
const UCL = UCL_SPORT_KEY;

const sports = (uclActive = true) => [
  { key: 'soccer_epl', group: 'Soccer', title: 'EPL', description: 'English Premier League', active: true, has_outrights: false },
  { key: UCL, group: 'Soccer', title: 'UEFA Champions League', description: 'European Champions League', active: uclActive, has_outrights: false },
  { key: 'basketball_nba', group: 'Basketball', title: 'NBA', description: 'US Basketball', active: true, has_outrights: false },
];
const quotaHeaders = (last: string, remaining = '498', used = '2') => ({ 'x-requests-last': last, 'x-requests-remaining': remaining, 'x-requests-used': used });

function uclEvents(now: number) {
  return [
    oddsEvent({ id: 'ucl-1', sport: UCL, title: 'UEFA Champions League', home: 'Manchester City', away: 'Paris Saint Germain', kickoff: now + 20 * H, updatedAt: now - 2 * MIN }),
    oddsEvent({ id: 'ucl-2', sport: UCL, title: 'UEFA Champions League', home: 'Real Betis', away: 'FC Porto', kickoff: now + 21 * H, updatedAt: now - 2 * MIN }),
  ];
}

type Routes = Parameters<typeof fakeFetcher>[0];
function liveApp(routes: Routes, env: Record<string, string> = {}, requireOddsConnectionTest = true): { app: App; calls: string[] } {
  const f = fakeFetcher(routes);
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, THE_ODDS_API_SPORT_KEYS: UCL, ...env }), { db: memDb(), fetcher: f.fetcher, requireOddsConnectionTest });
  return { app, calls: f.calls };
}
const standardRoutes = (now: number, extra?: Routes): Routes => (p, q) => {
  const x = extra?.(p, q); if (x) return x;
  if (p === '/v4/sports') return { body: sports(), headers: { 'x-requests-remaining': '500', 'x-requests-used': '0', 'x-requests-last': '0' } };
  if (p === `/v4/sports/${UCL}/events`) return { body: uclEvents(now).map(({ bookmakers, ...event }) => event), headers: quotaHeaders('0', '500', '0') };
  if (p === `/v4/sports/${UCL}/odds`) return { body: uclEvents(now), headers: quotaHeaders('2') };
  return null;
};

// ---------------------------------------------------------------- 1 Schlüssel serverseitig
test('v0.3.3 #1: THE_ODDS_API_KEY wird serverseitig geladen (kein anderer Name im Projekt), Standard eine Region', () => {
  const c = loadConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY } as NodeJS.ProcessEnv);
  assert.equal(c.theOddsApi.apiKey, KEY);
  assert.equal(c.theOddsApi.regions, 'eu', 'v0.3.3: eine Region als Standard');
  assert.equal(c.theOddsApi.monthlyBudget, 500);
  assert.equal(c.theOddsApi.dailyBudget, 16, '500 / 30 = 16 wie bisher');
  assert.equal(loadConfig({ DATA_MODE: 'live' } as NodeJS.ProcessEnv).theOddsApi.apiKey, null, 'ohne Secret kein Schlüssel');
  // Basis-URL wie im Auftrag (mit /v4) erzeugt keine doppelte Version
  assert.equal(normalizeOddsApiBase('https://api.the-odds-api.com/v4'), 'https://api.the-odds-api.com');
  assert.equal(normalizeOddsApiBase('https://api.the-odds-api.com/v4/'), 'https://api.the-odds-api.com');
  assert.equal(new URL(oddsApiUrl('https://api.the-odds-api.com/v4', KEY, '/v4/sports', {})).pathname, '/v4/sports');
  // Warnungen: mehrere Regionen, leere Sport-Keys
  const multi = configIssues(loadConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, THE_ODDS_API_REGIONS: 'eu,uk,us' } as NodeJS.ProcessEnv));
  assert.ok(multi.some(i => /3 Regionen/.test(i)));
  assert.ok(multi.some(i => /SPORT_KEYS leer/.test(i)));
});

// ---------------------------------------------------------------- 2 Authentifizierung
test('v0.3.3 #2: Verbindungstest nutzt nur /v4/sports (kostenlos), liest Kontingent-Header, CONNECTED nur nach Erfolg', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now));
  const before = oddsApiStatus(app);
  assert.equal(before.connection, 'DISCONNECTED');
  assert.match(before.reasons.join(' '), /Noch kein Verbindungstest/);
  const r = await testOddsApiConnection(app, { triggeredBy: 'test' });
  assert.equal(r.ok, true); assert.equal(r.httpStatus, 200);
  assert.equal(calls.length, 1); assert.equal(new URL(calls[0]).pathname, '/v4/sports');
  assert.equal(r.requestsRemaining, 500); assert.equal(r.requestsUsed, 0); assert.equal(r.requestsLast, 0);
  assert.equal(r.soccerActive, 2, 'nur aktive soccer_* gezählt');
  assert.equal(app.queue.usedThisMonth('theoddsapi'), 0, 'Test kostet 0 Credits');
  const st = oddsApiStatus(app);
  assert.equal(st.connection, 'CONNECTED', st.reasons.join(' | '));
  assert.equal(st.credits.providerRemaining, 500); assert.equal(st.credits.providerUsed, 0);
  assert.equal(st.paidAllowed, true);
});

test('v0.3.3 #2: HTTP 401 → DISCONNECTED, genau EIN Versuch, kostenpflichtige Abrufe bleiben gesperrt', async () => {
  const { app, calls } = liveApp(p => p === '/v4/sports' ? { status: 401, body: { message: 'API key is not valid' } } : null);
  const r = await testOddsApiConnection(app, { triggeredBy: 'test' });
  assert.equal(r.ok, false); assert.equal(r.httpStatus, 401);
  assert.match(r.error!, /Authentifizierung fehlgeschlagen/);
  assert.equal(calls.length, 1, 'keine Wiederholung');
  assert.equal(oddsApiStatus(app).connection, 'DISCONNECTED');
  assert.ok(paidGateReason(app));
  const rep = await controlledSync(app, { maxEvents: 5 });
  assert.equal(rep.status, 'NOT CONNECTED');
  assert.equal(calls.length, 1, 'kein kostenpflichtiger Abruf');
});

test('v0.3.3 #2: Netzwerk-/5xx-Fehler beim Test werden nicht wiederholt', async () => {
  const { app, calls } = liveApp(p => p === '/v4/sports' ? { status: 503, body: { message: 'unavailable' } } : null);
  const r = await testOddsApiConnection(app, { triggeredBy: 'test' });
  assert.equal(r.ok, false); assert.equal(r.httpStatus, 503); assert.equal(calls.length, 1);
  const none = buildApp(testConfig({ DATA_MODE: 'live' }), { db: memDb(), fetcher: fakeFetcher(() => ({ body: [] })).fetcher, requireOddsConnectionTest: true });
  const r2 = await testOddsApiConnection(none, { triggeredBy: 'test' });
  assert.equal(r2.ok, false); assert.equal(r2.httpStatus, null); assert.match(r2.error!, /Secret fehlt/); assert.ok(!r2.error!.includes('REDACTED'), 'eigene Meldung nicht verstümmelt');
});

// ---------------------------------------------------------------- 3 Champions League
test('v0.3.3 #3: soccer_uefa_champs_league wird erkannt; inaktiv → DEGRADED', async () => {
  const now = Date.now();
  const a = liveApp(standardRoutes(now));
  assert.equal((await testOddsApiConnection(a.app, { triggeredBy: 'test' })).targetSportStatus, 'ACTIVE');
  const b = liveApp(p => p === '/v4/sports' ? { body: sports(false) } : null);
  const r = await testOddsApiConnection(b.app, { triggeredBy: 'test' });
  assert.equal(r.targetSportStatus, 'INACTIVE');
  const st = oddsApiStatus(b.app);
  assert.equal(st.connection, 'DEGRADED');
  assert.ok(st.reasons.some(x => x.includes(UCL)));
  const c = liveApp(p => p === '/v4/sports' ? { body: sports().filter(s => s.key !== UCL) } : null);
  assert.equal((await testOddsApiConnection(c.app, { triggeredBy: 'test' })).targetSportStatus, 'UNKNOWN_KEY');
});

// ---------------------------------------------------------------- 4 Verarbeitung, LIVE, Sperre vor Test
test('v0.3.3 #4: ohne Verbindungstest kein kostenpflichtiger Abruf (auch nicht im automatischen Sync)', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now));
  const s = await app.sync.run(new Date(now));
  assert.equal(calls.filter(u => new URL(u).pathname.endsWith('/odds')).length, 0);
  assert.ok(s.errors.some(e => /Verbindungstest/.test(e)), s.errors.join(' | '));
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM events')!.n, 2, 'kostenlose echte Fixture-Metadaten dürfen gespeichert werden');
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM odds_snapshots')!.n, 0, 'ohne erfolgreichen Test keine kostenpflichtigen Quoten');
  assert.equal(calls.filter(u => new URL(u).pathname.endsWith('/events')).length, 1, 'kostenlose Spielsuche erlaubt');
});

test('v0.3.3 #4: nach bestandenem Test: EIN kontrollierter UCL-Abruf, Quoten normalisiert und als LIVE gespeichert', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now));
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const rep = await controlledSync(app, { now: new Date(now), maxEvents: 10 });
  assert.equal(rep.status, 'DONE', rep.notes.join(' | '));
  assert.equal(rep.costEstimate!.credits, 2, '1 Wettbewerb × 2 Märkte × 1 Region');
  const paid = calls.filter(u => new URL(u).pathname.endsWith('/odds'));
  assert.equal(paid.length, 1, 'genau ein kostenpflichtiger Abruf');
  const free = calls.filter(u => new URL(u).pathname === `/v4/sports/${UCL}/events`);
  assert.equal(free.length, 1, 'Spielsuche über kostenlosen /events-Endpunkt');
  assert.equal(new URL(free[0]).searchParams.get('markets'), null, '/events hat keine Wettmärkte');
  assert.equal(rep.apiRequests.find(r => r.endpoint.endsWith('/events'))?.cost, 0, 'kostenlose /events-Abfrage');
  const q = new URL(paid[0]).searchParams;
  assert.equal(q.get('regions'), 'eu'); assert.equal(q.get('markets'), 'h2h,totals'); assert.equal(q.get('oddsFormat'), 'decimal');
  assert.equal(rep.creditsUsed.theoddsapi, 2, 'Kosten aus x-requests-last');
  assert.equal(rep.events.length, 2);
  for (const e of rep.events) { assert.equal(e.markets['1X2'].valid, 3); assert.equal(e.markets.OU.valid, 3); assert.equal(e.markets.BTTS.books, 0); }
  assert.equal(rep.liveVerification, 'NOT VERIFIED', 'nachgebaute Antworten sind kein Live-Nachweis');
  const st = oddsApiStatus(app, new Date(now));
  assert.equal(st.mode, 'LIVE');
  assert.equal(st.data.events, 2); assert.equal(st.data.upcomingEvents, 2);
  assert.equal(st.data.bookmakers, 3); assert.deepEqual(st.data.markets, ['1X2', 'OU']);
  assert.ok(st.lastSuccessfulFetchAt);
  assert.equal(st.credits.providerRemaining, 498); assert.equal(st.credits.providerUsed, 2); assert.equal(st.credits.providerLast, 2);
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM events WHERE is_mock = 1')!.n, 0, 'keine Mock-Daten im Live-Modus');
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM odds_snapshots WHERE provider != 'theoddsapi'")!.n, 0);
  // No-Vig aus echten (nachgebauten) Preisen
  const id = app.db.get<{ event_id: number }>("SELECT event_id FROM event_mappings WHERE provider_event_id = 'ucl-1'")!.event_id;
  const views = new OddsStore(app.db).latestPerBookmaker(id, '1X2', null);
  const pin = views.find(v => v.bookmakerId === 'pinnacle')!;
  const inv = 1 / 2.10 + 1 / 3.60 + 1 / 3.55;
  assert.ok(Math.abs(pin.noVig!.HOME! - (1 / 2.10) / inv) < 1e-9);
  assert.ok(Math.abs(pin.noVig!.DRAW! + pin.noVig!.HOME! + pin.noVig!.AWAY! - 1) < 1e-9);
});

test('v0.3.4: /events ohne Spiele kostet null Credits und löst keinerlei /odds-Abfrage aus', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now, p =>
    p === `/v4/sports/${UCL}/events` ? { body: [], headers: quotaHeaders('0', '500', '0') } : null));
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const s = await app.sync.run(new Date(now));
  assert.equal(s.fixturesFound, 0);
  assert.equal(calls.filter(u => new URL(u).pathname.endsWith('/events')).length, 1);
  assert.equal(calls.filter(u => new URL(u).pathname.endsWith('/odds')).length, 0);
  assert.equal(app.queue.usedThisMonth('theoddsapi'), 0);
});

test('v0.3.4: kostenloser /events-Endpunkt filtert ungültige, begonnene und zu späte Spiele', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now, p => {
    if (p !== `/v4/sports/${UCL}/events`) return null;
    const events = uclEvents(now).map(({ bookmakers, ...event }) => event);
    return { body: [...events,
      { ...events[0], id: 'past', commence_time: iso(now - H) },
      { ...events[0], id: 'far', commence_time: iso(now + 70 * H) },
      { ...events[0], id: '', commence_time: iso(now + H) },
    ], headers: quotaHeaders('0') };
  }));
  const provider = app.providers.fixtures.find(p => p.name === 'theoddsapi')!;
  const fixtures = await provider.upcomingFixtures(new Date(now + 5 * MIN), new Date(now + 48 * H));
  assert.deepEqual(fixtures.map(e => e.providerEventId), ['ucl-1', 'ucl-2']);
  assert.equal(calls.length, 1);
  assert.equal(app.queue.usedToday('theoddsapi'), 0);
});

// ---------------------------------------------------------------- 5 1X2 inkl. Unentschieden
test('v0.3.3 #5: 1X2 nur mit allen drei Ausgängen; h2h_3_way als Ersatz, ohne Duplikate', () => {
  const t = '2026-10-14T19:00:00Z', at = '2026-10-14T12:00:00Z';
  const e = { id: 'x', sport_key: UCL, sport_title: 'UCL', commence_time: t, home_team: 'Aston Villa', away_team: 'Fenerbahce', bookmakers: [
    { key: 'two_way_only', title: 'TwoWay', last_update: at, markets: [{ key: 'h2h', outcomes: [{ name: 'Aston Villa', price: 1.4 }, { name: 'Fenerbahce', price: 3.1 }] }] },
    { key: 'three_way', title: 'ThreeWay', last_update: at, markets: [{ key: 'h2h_3_way', outcomes: [{ name: 'Aston Villa', price: 1.65 }, { name: 'Draw', price: 4.1 }, { name: 'Fenerbahce', price: 5.0 }] }] },
    { key: 'both', title: 'Both', last_update: at, markets: [
      { key: 'h2h', outcomes: [{ name: 'Aston Villa', price: 1.64 }, { name: 'Draw', price: 4.1 }, { name: 'Fenerbahce', price: 4.9 }] },
      { key: 'h2h_3_way', outcomes: [{ name: 'Aston Villa', price: 1.6 }, { name: 'Draw', price: 4.0 }, { name: 'Fenerbahce', price: 4.8 }] }] },
  ] };
  const q = convertOaEvent(e, at, { onlyOuLine: 2.5 });
  const x12 = q.filter(x => x.market === '1X2');
  assert.equal(x12.length, 3, 'je Buchmacher genau ein 1X2-Snapshot');
  assert.deepEqual(x12.find(x => x.bookmakerProviderId === 'three_way')!.prices, { HOME: 1.65, DRAW: 4.1, AWAY: 5.0 });
  assert.deepEqual(x12.find(x => x.bookmakerProviderId === 'both')!.prices, { HOME: 1.64, DRAW: 4.1, AWAY: 4.9 }, 'h2h hat Vorrang');
  const ctx = { now: new Date(at), maxAgeMinutes: 90, kickoffUtc: t, mappingConfidence: 1 };
  const two = x12.find(x => x.bookmakerProviderId === 'two_way_only')!;
  assert.ok(validateQuote(two, ctx).some(err => /DRAW fehlt/.test(err)), 'ohne Unentschieden abgelehnt, nicht ergänzt');
  assert.deepEqual(validateQuote(x12.find(x => x.bookmakerProviderId === 'three_way')!, ctx), []);
});

// ---------------------------------------------------------------- 6 Über/Unter 2,5
test('v0.3.3 #6: Über/Unter wird auf Linie 2,5 normalisiert; andere Linien werden nicht übernommen', () => {
  const at = '2026-10-14T12:00:00Z';
  const e = { id: 'y', sport_key: UCL, sport_title: 'UCL', commence_time: '2026-10-14T19:00:00Z', home_team: 'Shakhtar Donetsk', away_team: 'AEK Athens', bookmakers: [
    { key: 'b1', title: 'B1', last_update: at, markets: [{ key: 'totals', outcomes: [
      { name: 'Under', price: 1.92, point: 2.5 }, { name: 'Over', price: 1.88, point: 2.5 }, { name: 'Over', price: 2.6, point: 3.0 }, { name: 'Under', price: 1.45, point: 3.0 }, { name: 'Over', price: 1.3, point: 1.5 }] }] },
    { key: 'b2', title: 'B2', last_update: at, markets: [{ key: 'totals', outcomes: [{ name: 'Over', price: 1.9, point: 2.5 }] }] },
  ] };
  const q = convertOaEvent(e, at, { onlyOuLine: 2.5 });
  const ou = q.filter(x => x.market === 'OU');
  assert.equal(ou.length, 2); assert.ok(ou.every(x => x.line === 2.5));
  assert.deepEqual(ou.find(x => x.bookmakerProviderId === 'b1')!.prices, { OVER: 1.88, UNDER: 1.92 });
  const ctx = { now: new Date(at), maxAgeMinutes: 90, kickoffUtc: e.commence_time, mappingConfidence: 1 };
  assert.ok(validateQuote(ou.find(x => x.bookmakerProviderId === 'b2')!, ctx).some(err => /UNDER fehlt/.test(err)), 'halber Markt abgelehnt');
});

// ---------------------------------------------------------------- 7 BTTS
test('v0.3.3 #7: BTTS über den Event-Odds-Endpunkt, nur wenn aktiviert und vom Anbieter geliefert', async () => {
  const now = Date.now();
  const evs = uclEvents(now);
  const { app, calls } = liveApp(standardRoutes(now, p => {
    if (p === `/v4/sports/${UCL}/events/ucl-1/odds`) return { body: bttsEvent(evs[0], now - MIN), headers: quotaHeaders('1', '497', '3') };
    if (p === `/v4/sports/${UCL}/events/ucl-2/odds`) return { body: { ...evs[1], bookmakers: [] }, headers: quotaHeaders('0', '497', '3') };
    return null;
  }), { THE_ODDS_API_INCLUDE_BTTS: 'true', THE_ODDS_API_BTTS_MAX_EVENTS: '2' });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const rep = await controlledSync(app, { now: new Date(now), maxEvents: 10 });
  assert.equal(rep.status, 'DONE', rep.notes.join(' | '));
  assert.equal(rep.costEstimate!.credits, 4, '2 (odds) + 2 BTTS-Abrufe × 1 Region');
  const ev = calls.filter(u => /\/events\/[^/]+\/odds$/.test(new URL(u).pathname));
  assert.equal(ev.length, 2);
  assert.ok(ev.every(u => new URL(u).searchParams.get('markets') === 'btts'));
  const by = Object.fromEntries(rep.events.map(e => [e.home, e.markets.BTTS]));
  assert.equal(by['Manchester City'].valid, 1, 'BTTS verarbeitet');
  assert.equal(by['Real Betis'].books, 0, 'nicht geliefert → kein BTTS, nichts erfunden');
  assert.equal(rep.creditsUsed.theoddsapi, 3, '2 + 1 + 0 laut x-requests-last');
});

// ---------------------------------------------------------------- 8 fehlende Märkte / keine erfundenen Ergebnisse
test('v0.3.3 #8: fehlende Märkte bleiben fehlend; ohne Historie keine Prognose und keine Value Bet', async () => {
  const now = Date.now();
  const onlyH2h = [oddsEvent({ id: 'ucl-9', sport: UCL, title: 'UEFA Champions League', home: 'Bodo/Glimt', away: 'Borussia Dortmund', kickoff: now + 20 * H, updatedAt: now - MIN,
    books: [{ key: 'pinnacle', title: 'Pinnacle', h: 3.1, d: 4.1, a: 2.1 }] })];
  const { app } = liveApp(standardRoutes(now, p => {
    if (p === `/v4/sports/${UCL}/events`) return { body: onlyH2h.map(({ bookmakers, ...event }) => event), headers: quotaHeaders('0') };
    if (p === `/v4/sports/${UCL}/odds`) return { body: onlyH2h, headers: quotaHeaders('1') };
    return null;
  }));
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const rep = await controlledSync(app, { now: new Date(now), maxEvents: 10 });
  const e = rep.events[0];
  assert.equal(e.markets['1X2'].valid, 1); assert.equal(e.markets.OU.books, 0); assert.equal(e.markets.BTTS.books, 0);
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM odds_snapshots WHERE market_id IN ('OU','BTTS')")!.n, 0);
  assert.equal(app.db.get<{ n: number }>("SELECT COUNT(*) AS n FROM value_signals WHERE status IN ('VALUE','STRONG_VALUE')")!.n, 0);
  assert.equal(app.db.get<{ n: number }>('SELECT COUNT(*) AS n FROM recommendations WHERE active = 1')!.n, 0);
  assert.ok(rep.notes.some(n => /INSUFFICIENT DATA/.test(n)), 'fehlende Historie wird ausdrücklich gemeldet');
  assert.ok(/INSUFFICIENT DATA|insufficient/.test(e.prediction), e.prediction);
});

// ---------------------------------------------------------------- 9 Limits
test('v0.3.3 #9: Kostenvoranschlag über Budget → kein Abruf; Anbieter-Restcredits stoppen vor dem Senden', async () => {
  const now = Date.now();
  // a) internes Tagesbudget kleiner als der Lauf (3 Wettbewerbe × 2 Märkte × 3 Regionen = 18 > 16)
  const a = liveApp(standardRoutes(now), { THE_ODDS_API_SPORT_KEYS: `${UCL},soccer_epl,soccer_spain_la_liga`, THE_ODDS_API_REGIONS: 'eu,uk,us' });
  await testOddsApiConnection(a.app, { triggeredBy: 'test' });
  const ra = await controlledSync(a.app, { maxEvents: 5 });
  assert.equal(ra.status, 'BUDGET', ra.notes.join(' | '));
  assert.equal(a.calls.filter(u => new URL(u).pathname.endsWith('/odds')).length, 0);
  // b) leere Sport-Keys: Kosten unbekannt → kein Lauf
  const b = liveApp(standardRoutes(now), { THE_ODDS_API_SPORT_KEYS: '' });
  await testOddsApiConnection(b.app, { triggeredBy: 'test' });
  assert.equal((await controlledSync(b.app, { maxEvents: 5 })).status, 'BUDGET');
  // c) Anbieter meldet nur 1 Credit: Abruf (2 Credits) wird nicht gesendet
  const c = liveApp((p) => p === '/v4/sports' ? { body: sports(), headers: { 'x-requests-remaining': '1', 'x-requests-used': '499', 'x-requests-last': '0' } } : p.endsWith('/events') ? { body: uclEvents(now).map(({ bookmakers, ...event }) => event), headers: quotaHeaders('0', '1', '499') } : p.endsWith('/odds') ? { body: uclEvents(now), headers: quotaHeaders('2') } : null);
  await testOddsApiConnection(c.app, { triggeredBy: 'test' });
  const rc = await controlledSync(c.app, { maxEvents: 5 });
  assert.equal(rc.status, 'BUDGET', rc.notes.join(' | '));
  assert.equal(c.calls.filter(u => u.includes('/odds')).length, 0);
  // auch direkt über den automatischen Sync: Queue stoppt VOR dem Senden
  const s = await c.app.sync.run(new Date(now));
  assert.equal(c.calls.filter(u => u.includes('/odds')).length, 0);
  assert.ok(s.errors.some(e => /verfügbar 1 \(Anbieter-Restcredits/.test(e)), s.errors.join(' | '));
  // d) Monatsbudget nach x-requests-last
  const d = liveApp(standardRoutes(now, p => p.endsWith('/odds') ? { body: uclEvents(now), headers: quotaHeaders('3') } : null), { THE_ODDS_API_MONTHLY_BUDGET: '4' });
  await testOddsApiConnection(d.app, { triggeredBy: 'test' });
  await controlledSync(d.app, { now: new Date(now), maxEvents: 5 });
  assert.equal(d.app.queue.usedThisMonth('theoddsapi'), 3);
  const rd = await controlledSync(d.app, { now: new Date(now + 30 * MIN), maxEvents: 5 });
  assert.equal(rd.status, 'BUDGET', 'zweiter Lauf (2) passt nicht mehr ins Monatsbudget (4 − 3)');
});

// ---------------------------------------------------------------- 10 Schlüssel nirgends sichtbar
test('v0.3.3 #10: Schlüssel nicht im Frontend, nicht in Admin-Antworten, nicht in Protokoll/DB', async () => {
  // a) Frontend-Quellen und (falls gebaut) Bundle enthalten weder Schlüsselnamen noch apiKey-Parameter
  const fe = path.resolve('..', 'frontend');
  const files: string[] = [];
  const walk = (d: string) => { if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d, { withFileTypes: true })) { if (f.name === 'node_modules') continue; const p = path.join(d, f.name); f.isDirectory() ? walk(p) : files.push(p); } };
  walk(path.join(fe, 'src')); walk(path.join(fe, 'dist')); walk(path.join(fe, 'public'));
  files.push(path.join(fe, 'index.html'));
  assert.ok(files.length > 10, 'Frontend-Dateien gefunden');
  for (const f of files) {
    const t = fs.readFileSync(f, 'utf8');
    assert.ok(!/THE_ODDS_API_KEY|HIGHLIGHTLY_API_KEY|ANTHROPIC_API_KEY/.test(t), `${f} nennt eine Schlüssel-Variable`);
    assert.ok(!/[?&]apiKey=/.test(t), `${f} baut eine Anbieter-URL`);
    assert.ok(!/api\.the-odds-api\.com/.test(t), `${f} spricht den Anbieter direkt an`);
  }
  // b) Admin-Antworten und gespeicherte Daten
  const now = Date.now();
  const { app } = liveApp(standardRoutes(now, p => p === '/v4/sports' ? { status: 401, body: { message: `Invalid apiKey=${KEY}` } } : null));
  const server = createServer(app, null, { clock: () => new Date(now) });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', () => r()));
  try {
    const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
    const auth = { authorization: `Bearer ${TEST_SERVICE_TOKEN}`, 'content-type': 'application/json' };
    const post = await fetch(`${base}/api/admin/providers/theoddsapi/test`, { method: 'POST', headers: auth });
    assert.equal(post.status, 200);
    const pt = await post.text();
    const body = JSON.parse(pt);
    assert.equal(body.result.ok, false); assert.equal(body.status.connection, 'DISCONNECTED');
    for (const p of ['/api/admin/providers/theoddsapi', '/api/admin/diagnostics', '/api/admin/api-requests', '/api/status']) {
      const t = await (await fetch(base + p, { headers: auth })).text();
      assert.ok(!t.includes(KEY), `${p} enthält den Schlüssel`);
    }
    assert.ok(!pt.includes(KEY), 'Testantwort enthält den Schlüssel nicht (auch nicht aus der Fehlermeldung des Anbieters)');
    // Benutzer ohne Admin-Rechte sehen den Status nicht
    assert.equal((await fetch(`${base}/api/admin/providers/theoddsapi`)).status, 401);
  } finally { server.close(); }
  const dump = JSON.stringify([
    app.db.all('SELECT * FROM api_requests'), app.db.all('SELECT * FROM provider_connection_tests'), app.db.all('SELECT * FROM provider_health'),
    app.db.all('SELECT * FROM api_cache'), app.db.all('SELECT * FROM error_logs'),
  ]);
  assert.ok(!dump.includes(KEY), 'Schlüssel in der Datenbank gefunden');
});

test('v0.3.3: Status im Mock-Modus ist nie CONNECTED und ruft nichts ab', async () => {
  const f = fakeFetcher(() => ({ body: sports() }));
  const app = buildApp(testConfig({ DATA_MODE: 'mock', THE_ODDS_API_KEY: KEY }), { db: memDb(), fetcher: f.fetcher });
  const r = await testOddsApiConnection(app, { triggeredBy: 'test' });
  assert.equal(r.ok, false); assert.equal(f.calls.length, 0);
  const st = oddsApiStatus(app);
  assert.equal(st.connection, 'DISCONNECTED'); assert.equal(st.mode, 'MOCK');
  void iso;
});

test('v0.3.3: Zugangsfehler NACH bestandenem Test sperrt erneut (401 beim Quotenabruf)', async () => {
  const now = Date.now();
  const { app, calls } = liveApp(standardRoutes(now, p => p.endsWith('/odds') ? { status: 401, body: { message: 'key revoked' } } : null));
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  assert.equal(paidGateReason(app), null);
  await new Promise(r => setTimeout(r, 5));
  await app.sync.run(new Date(now));
  assert.equal(calls.filter(u => u.includes('/odds')).length, 1, 'kein Wiederholungsversuch bei 401');
  assert.match(paidGateReason(app) ?? '', /Zugang nach dem letzten Test verweigert/);
  assert.equal(oddsApiStatus(app).connection, 'DISCONNECTED');
  await app.sync.run(new Date(now + 5 * MIN));
  assert.equal(calls.filter(u => u.includes('/odds')).length, 1, 'gesperrt bis zum nächsten Test');
});

test('v0.3.3: Log-Bereinigung schwärzt Schlüsselwerte (auch Bearer-Token), lässt Hinweistexte lesbar', async () => {
  const { redact } = await import('../src/util/log.js');
  const cases: [string, string][] = [
    [`https://api.the-odds-api.com/v4/sports?apiKey=${KEY}&regions=eu`, KEY], [`authorization: Bearer ${KEY}`, KEY], [`{"token":"${KEY}"}`, KEY],
    [`x-api-key: ${KEY}`, KEY], [`THE_ODDS_API_KEY=${KEY}`, KEY], [`"apiKey": "${KEY}"`, KEY],
  ];
  for (const [s, secret] of cases) assert.ok(!redact(s).includes(secret), s);
  assert.equal(redact('THE_ODDS_API_KEY fehlt'), 'THE_ODDS_API_KEY fehlt', 'Hinweis bleibt lesbar (v0.3.2 machte daraus "[REDACTED]")');
});
