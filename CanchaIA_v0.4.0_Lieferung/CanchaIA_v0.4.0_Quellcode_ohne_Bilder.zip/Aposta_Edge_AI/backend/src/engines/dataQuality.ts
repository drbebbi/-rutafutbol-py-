/**
 * Datenqualität historischer Daten (v0.3.0) – Voraussetzung für einen aussagekräftigen Backtest.
 *
 * Prüft je Wettbewerb: Stichprobe, Saisons, Zeitraum, fehlende Ergebnisse, doppelte Spiele, mögliche doppelte Teams
 * (Alias-Probleme), unplausible Ergebnisse, Heim/Auswärts-Statistik, Quotenabdeckung (pre_closing/closing),
 * geschätzte Zeitpunkte und ob Prognose-Merkmale zeitlich korrekt sind (nur Spiele vor dem Anstoß).
 * Ändert keine Daten. Ergebnis als JSON für Bericht und Admin-Ansicht.
 */
import type { Db } from '../db/db.js';
import { Repository } from './repository.js';
import { linkSimilarity } from './linking.js';

export interface CompetitionQuality {
  competitionId: number; name: string; providers: string[]; isMock: boolean;
  matches: number; finishedWithResult: number; seasons: string[]; firstKickoff: string | null; lastKickoff: string | null; teams: number;
  missingResults: number; duplicateMatches: { a: number; b: number; pair: string; kickoffA: string; kickoffB: string }[];
  possibleDuplicateTeams: { a: string; b: string; similarity: number }[];
  implausibleScores: number;
  homeAway: { homeWin: number; draw: number; awayWin: number; avgHomeGoals: number; avgAwayGoals: number; over25: number; btts: number } | null;
  oddsCoverage: { preClosing1x2: number; closing1x2: number; preClosingOu: number; estimatedTimes: number };
  leakageCheck: { sampled: number; violations: number };
  usableForBacktest: boolean; issues: string[];
}

export interface DataQualityReport { generatedAt: string; competitions: CompetitionQuality[]; totals: { competitions: number; matches: number; usable: number }; notes: string[] }

export function historicalDataQuality(db: Db, opts: { includeMock?: boolean; minMatches?: number } = {}): DataQualityReport {
  const minM = opts.minMatches ?? 200;
  const repo = new Repository(db);
  const comps = db.all<{ id: number; name: string; is_mock: number }>(`SELECT id, name, is_mock FROM competitions ${opts.includeMock ? '' : 'WHERE is_mock = 0'} ORDER BY name`);
  const out: CompetitionQuality[] = [];
  for (const c of comps) {
    const n = db.get<{ n: number }>('SELECT COUNT(*) AS n FROM events WHERE competition_id = ?', c.id)!.n;
    if (!n) continue;
    const fin = db.all<{ id: number; kickoff_utc: string; home_goals: number; away_goals: number; season: string | null }>(
      "SELECT id, kickoff_utc, home_goals, away_goals, season FROM events WHERE competition_id = ? AND status = 'finished' AND home_goals IS NOT NULL AND away_goals IS NOT NULL ORDER BY kickoff_utc", c.id);
    const missing = db.get<{ n: number }>(`SELECT COUNT(*) AS n FROM events WHERE competition_id = ? AND (
        (status = 'finished' AND (home_goals IS NULL OR away_goals IS NULL)) OR (status IN ('scheduled','live','unknown') AND kickoff_utc < ?))`, c.id, new Date(Date.now() - 3 * 86_400_000).toISOString())!.n;
    const dups = db.all<{ a: number; b: number; pair: string; ka: string; kb: string }>(
      `SELECT x.id AS a, y.id AS b, th.name || ' – ' || ta.name AS pair, x.kickoff_utc AS ka, y.kickoff_utc AS kb FROM events x JOIN events y ON x.id < y.id
          AND x.home_team_id = y.home_team_id AND x.away_team_id = y.away_team_id AND ABS(julianday(x.kickoff_utc) - julianday(y.kickoff_utc)) < 1.5
          JOIN teams th ON th.id = x.home_team_id JOIN teams ta ON ta.id = x.away_team_id
        WHERE x.competition_id = ? AND y.competition_id = ? LIMIT 50`, c.id, c.id);
    const teams = db.all<{ id: number; name: string }>('SELECT DISTINCT t.id, t.name FROM teams t JOIN events e ON e.home_team_id = t.id OR e.away_team_id = t.id WHERE e.competition_id = ?', c.id);
    const simTeams: CompetitionQuality['possibleDuplicateTeams'] = [];
    for (let i = 0; i < teams.length; i++) for (let j = i + 1; j < teams.length; j++) {
      const s = linkSimilarity(teams[i].name, teams[j].name);
      if (s >= 0.85) simTeams.push({ a: teams[i].name, b: teams[j].name, similarity: +s.toFixed(2) });
    }
    const implausible = fin.filter(r => r.home_goals > 15 || r.away_goals > 15 || r.home_goals < 0 || r.away_goals < 0).length;
    const hw = fin.filter(r => r.home_goals > r.away_goals).length, dr = fin.filter(r => r.home_goals === r.away_goals).length;
    const homeAway = fin.length ? {
      homeWin: hw / fin.length, draw: dr / fin.length, awayWin: (fin.length - hw - dr) / fin.length,
      avgHomeGoals: fin.reduce((a, r) => a + r.home_goals, 0) / fin.length, avgAwayGoals: fin.reduce((a, r) => a + r.away_goals, 0) / fin.length,
      over25: fin.filter(r => r.home_goals + r.away_goals > 2.5).length / fin.length, btts: fin.filter(r => r.home_goals > 0 && r.away_goals > 0).length / fin.length,
    } : null;
    const cov = (kind: string, market: string) => fin.length ? db.get<{ n: number }>(`SELECT COUNT(DISTINCT s.event_id) AS n FROM odds_snapshots s JOIN events e ON e.id = s.event_id
        WHERE e.competition_id = ? AND e.status = 'finished' AND s.snapshot_kind = ? AND s.market_id = ? AND s.validation_errors = '[]'`, c.id, kind, market)!.n / fin.length : 0;
    const est = db.get<{ n: number; t: number }>(`SELECT SUM(s.time_estimated) AS n, COUNT(*) AS t FROM odds_snapshots s JOIN events e ON e.id = s.event_id WHERE e.competition_id = ?`, c.id)!;
    // Zeitliche Korrektheit der Merkmale: Historie für ein Spiel enthält nur Spiele mit Anstoß VOR diesem Spiel
    let sampled = 0, violations = 0;
    for (let i = Math.floor(fin.length / 3); i < fin.length && sampled < 25; i += Math.max(1, Math.floor(fin.length / 25))) {
      const h = repo.competitionHistory(c.id, fin[i].kickoff_utc); sampled++;
      if (h.some(m => m.kickoff >= fin[i].kickoff_utc || m.eventId === fin[i].id)) violations++;
    }
    const seasons = [...new Set(fin.map(r => r.season).filter((x): x is string => !!x))].sort();
    const issues: string[] = [];
    if (c.is_mock) issues.push('Mock-Daten: für Validierung ungeeignet');
    if (fin.length < minM) issues.push(`nur ${fin.length} Spiele mit Ergebnis (Backtest ab ${minM})`);
    if (missing) issues.push(`${missing} Spiele ohne Ergebnis`);
    if (dups.length) issues.push(`${dups.length} mögliche doppelte Spiele`);
    if (simTeams.length) issues.push(`${simTeams.length} mögliche doppelte Teams (Alias prüfen)`);
    if (implausible) issues.push(`${implausible} unplausible Ergebnisse`);
    if (violations) issues.push(`${violations} Verletzungen der zeitlichen Trennung (Data Leakage)`);
    const preCov = cov('pre_closing', '1X2');
    if (fin.length && preCov < 0.5) issues.push(`Quoten zum Entscheidungszeitpunkt nur für ${(preCov * 100).toFixed(0)} % der Spiele – Marktvergleich eingeschränkt`);
    const providers = db.all<{ provider: string }>('SELECT DISTINCT provider FROM competition_aliases WHERE competition_id = ?', c.id).map(r => r.provider);
    out.push({
      competitionId: c.id, name: c.name, providers, isMock: !!c.is_mock, matches: n, finishedWithResult: fin.length, seasons,
      firstKickoff: fin[0]?.kickoff_utc ?? null, lastKickoff: fin[fin.length - 1]?.kickoff_utc ?? null, teams: teams.length,
      missingResults: missing, duplicateMatches: dups.map(d => ({ a: d.a, b: d.b, pair: d.pair, kickoffA: d.ka, kickoffB: d.kb })), possibleDuplicateTeams: simTeams,
      implausibleScores: implausible, homeAway,
      oddsCoverage: { preClosing1x2: preCov, closing1x2: cov('closing', '1X2'), preClosingOu: cov('pre_closing', 'OU'), estimatedTimes: est.t ? (est.n ?? 0) / est.t : 0 },
      leakageCheck: { sampled, violations },
      usableForBacktest: !c.is_mock && fin.length >= minM && !violations && !dups.length,
      issues,
    });
  }
  return {
    generatedAt: new Date().toISOString(), competitions: out,
    totals: { competitions: out.length, matches: out.reduce((a, c) => a + c.finishedWithResult, 0), usable: out.filter(c => c.usableForBacktest).length },
    notes: [
      'Pre-Closing-Quoten von football-data.co.uk haben keinen exakten Erfassungszeitpunkt (geschätzt: Anstoß − 24 h).',
      'Schlusskurse werden nie als Wettquote verwendet, nur als Benchmark und für CLV.',
    ],
  };
}
