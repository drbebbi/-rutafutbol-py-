-- v0.3.0 (3/3): benutzerspezifische Benachrichtigungen. Nur ergänzend; alte Meldungen bleiben vollständig erhalten.

-- Persönliche Meldungen (je Benutzer, eigener Lesestatus, Deduplizierung je Benutzer)
CREATE TABLE IF NOT EXISTS user_alerts (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  alert_id INTEGER REFERENCES alerts_sent(id),   -- zugehörige systemweite Meldung (falls vorhanden)
  dedupe_key TEXT NOT NULL,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  ev REAL,
  channels TEXT NOT NULL DEFAULT '["in_app"]',
  created_at TEXT NOT NULL,
  read_at TEXT,
  UNIQUE (user_id, dedupe_key)
);
CREATE INDEX IF NOT EXISTS idx_user_alerts ON user_alerts(user_id, created_at);

-- Persönlicher Lesestatus für systemweite Meldungen (vorher: ein globales read_at für alle)
CREATE TABLE IF NOT EXISTS alert_reads (
  alert_id INTEGER NOT NULL REFERENCES alerts_sent(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  read_at TEXT NOT NULL,
  PRIMARY KEY (alert_id, user_id)
);
-- Bisheriger globaler Lesestatus bleibt für alle bestehenden Konten sichtbar erhalten (alerts_sent.read_at wird nicht verändert)
INSERT OR IGNORE INTO alert_reads (alert_id, user_id, read_at)
  SELECT a.id, u.id, a.read_at FROM alerts_sent a CROSS JOIN users u WHERE a.read_at IS NOT NULL AND u.role IN ('admin','user');

-- Persönliche Einstellungen (Standard: persönliche Meldungen AUS – ausdrückliche Aktivierung durch den Benutzer)
ALTER TABLE user_settings ADD COLUMN personal_alerts_enabled INTEGER NOT NULL DEFAULT 0;
ALTER TABLE user_settings ADD COLUMN notify_ev_change INTEGER NOT NULL DEFAULT 1;
ALTER TABLE user_settings ADD COLUMN alert_min_ev REAL;           -- NULL = Systemwert (MIN_EV)
