# Sicherheitsprüfung (v0.3.0)

Stand 13.10.2026. Dies ist eine **Selbstprüfung** durch den Entwickler (Code-Review und automatisierte Tests), **kein** externer Penetrationstest. Vor einem Betrieb mit Dritten ist eine unabhängige Prüfung zu empfehlen.

## Grundsätze

- Die App platziert **keine Wetten**, speichert keine Wettkonto- oder Zahlungsdaten und führt keine Finanztransaktionen aus. Es gibt weder eine Buchmacher-Schnittstelle zum Wetten noch Code dafür.
- API-Schlüssel existieren nur serverseitig (Umgebungsvariablen). Das Frontend erhält nie einen Schlüssel.
- Mock-Daten werden im Live-Modus nie ausgeliefert.

## Befunde aus v0.1.0 und Behebung

| # | Befund v0.1.0 | Risiko | Behebung v0.2.0 | Test |
|---|---|---|---|---|
| S1 | Ein gemeinsames `ADMIN_TOKEN` für alle Benutzer, im Browser in `localStorage` gespeichert | hoch: jeder Benutzer war Admin; XSS hätte das Token auslesen können | Benutzerkonten mit Rollen `user`/`admin`; Session-Cookie `aea_session` HttpOnly, SameSite=Strict, Secure; kein Token im Browser-Speicher | `Login: Session-Cookie …`, Browser-Prüfung: `localStorage` leer |
| S2 | Kein CSRF-Schutz | mittel | CSRF-Token je Session (Header `x-csrf-token`, nur im Arbeitsspeicher des Frontends), Origin-Prüfung, kein CORS | `CSRF und Origin …` |
| S3 | Keine Rollentrennung | hoch | Jede Route hat eine Zugriffsstufe `public`/`user`/`admin`. Analyse-Einstellungen, Jobs, Import, Benutzer und Diagnose nur für Admins | `Rollen: normaler Benutzer hat keinen Zugriff …` |
| S4 | Kein Schutz gegen Passwort-Raten | mittel | Login-Rate-Limit (10/min je IP), Kontosperre 15 min nach 5 Fehlversuchen, einheitliche Fehlermeldung, Dummy-Hash bei unbekannter E-Mail (gleiche Laufzeit) | `Nicht autorisiert: … Sperre nach 5 Fehlversuchen` |
| S5 | `ADMIN_TOKEN` beliebig kurz | mittel | Service-Token nur noch für Server-zu-Server, mindestens 32 Zeichen, zeitkonstanter Vergleich; kürzere werden ignoriert | `Service-Token …` |
| S6 | Kein Sicherheitsprotokoll | niedrig | Tabelle `security_events`: Login ok/fehlgeschlagen, Sperre, Logout, Rollenwechsel, verbotene Zugriffe, CSRF-Fehler, Passwort-Reset; Anzeige Admin → Sicherheit | indirekt in mehreren Tests |
| S7 | Origin `null` hätte einen Parserfehler ausgelöst | niedrig | Unlesbarer Origin gilt als fremd (403) | `CSRF und Origin …` |

## Neu in v0.3.0: Befunde und Maßnahmen

| # | Befund / Risiko | Maßnahme | Test |
|---|---|---|---|
| S8 | Lesestatus systemweiter Meldungen war global: Benutzer A konnte Meldungen für B als gelesen markieren | Lesestatus je Benutzer (`alert_reads`). Persönliche Meldungen (`user_alerts`) nur für den Eigentümer lesbar und änderbar, fremde IDs → 404 | `V5: Zugriffskontrolle …` |
| S9 | Tarif-Freischaltung durch hochgeladenen Beleg (Betrugsrisiko) | Ein Beleg setzt nur `PROOF_SUBMITTED`. Freischaltung nur durch einen Admin mit Bankreferenz, exaktem Betrag, Eingangsdatum und ausdrücklicher Bestätigung. Bankreferenz nur einmal verwendbar | `V4: Bestellung → Beleg → KEINE automatische Freischaltung …` |
| S10 | Selbstfreigabe durch Admins | Ein Admin kann die eigene Zahlung nicht freigeben (403). Manuelle Freischaltung ohne Zahlung nur mit Begründung und im Protokoll sichtbar | `V4: Sicherheit …` |
| S11 | Manipulation des Änderungsprotokolls | `subscription_events` nur anhängend (Trigger gegen UPDATE und DELETE) | `V4: Sicherheit …` |
| S12 | Schadhafte Uploads | Nur PDF, PNG und JPEG bis 2 MB, Magic-Byte-Prüfung, bereinigter Dateiname, Abruf nur durch Admins (protokolliert). Inhalt wird nach der Aufbewahrungsfrist gelöscht | `V4: Bestellung …` |
| S13 | Bankdaten oder C.I. im Code | Bankdaten nur aus Umgebungsvariablen. Keine C.I.-Nummer im Projekt. Tests verwenden Platzhalter | Secret-Scan |
| S14 | uPay-Belastungen ohne Freigabe | Nur Testmodus ohne Netzwerkzugriff. `UPAY_MODE=live` wird ignoriert und gemeldet | `V4: uPay nur Testmodus …` |
| S15 | Rolle und Tarif vermischt | Getrennte Konzepte: Tarife ändern nie die Rolle. Admin-Endpunkte bleiben rollenbasiert, auch für PREMIUM | `V4: Sicherheit …` |
| S16 | API-Schlüssel im neuen Abrufprotokoll | Query-Parameter mit `key`, `token`, `secret` oder `auth` werden vor dem Speichern entfernt | `V1: … jeder Abruf wird ohne Schlüssel protokolliert` |
| S17 | Persönliche Meldungen über systemweite Kanäle | Persönliche Meldungen nur in der App. Telegram und Webhook werden je Systemmeldung genau einmal genutzt, nie je Benutzer | `V5: Systemweite Kanäle …` |
| S18 | Unveränderlichkeit der Modellversionen | Trigger gegen UPDATE und DELETE in `model_versions` | `V3: … Modellversionen sind unveränderlich` |

## Umsetzung im Detail

**Passwörter**
- scrypt (N = 32768, r = 8, p = 1, 64 MiB), 32 Byte Salt, Parameter im Hash gespeichert (spätere Anhebung möglich)
- zeitkonstanter Vergleich
- Mindestlänge 12 Zeichen

**Sessions**
- 32 Byte Zufall. In der Datenbank steht nur der SHA-256-Hash, ein Datenbank-Leck verrät also keine gültigen Sessions.
- Ablauf absolut nach 12 h, nach 2 h Leerlauf
- Logout, Deaktivierung, Rollenwechsel und Passwort-Reset löschen die Sessions des Kontos

**Admin-Bootstrap**
- Beim ersten Start aus `ADMIN_EMAIL`/`ADMIN_PASSWORD`, danach soll das Passwort aus der Umgebung entfernt werden.
- Selbstregistrierung ist standardmäßig aus (`ALLOW_REGISTRATION=false`) und erzeugt nur Konten mit Rolle `user`.
- Der letzte aktive Admin kann sich weder entmachten noch deaktivieren.

**HTTP-Header**
- `Content-Security-Policy` (`default-src 'self'`, `script-src 'self'`, `frame-ancestors 'none'`, `form-action 'self'`)
- `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`
- `Cross-Origin-Opener-Policy: same-origin`, `Permissions-Policy`, HSTS bei `COOKIE_SECURE=true`

**Eingaben**
- Validierung je Feld (Typ, Bereich, Aufzählung)
- Body-Limit 1 MB (CSV-Import 25 MB), Pfad-Traversal-Schutz bei statischen Dateien
- Ausschließlich parametrisierte SQL-Abfragen

**Rate-Limits**
- allgemein 240/min, Login 10/min, Analyst 12/min, Jobs 6/min je IP
- Hinter einem Proxy `TRUST_PROXY=true`, sonst ist jede Anfrage „127.0.0.1“

**Secrets**
- Log-Schwärzung (`redact`) für Schlüssel, Tokens, Authorization-Header und Telegram-Bot-Token
- Cache-Schlüssel ohne Secret-Parameter
- Test prüft, dass keine API-Antwort Schlüssel enthält

**EDGE ANALYST**
- Das Sprachmodell erhält nur Werkzeuge mit Lesezugriff auf gespeicherte Analysen. Es gibt kein Werkzeug zum Schreiben, Wetten oder für Netzwerkzugriffe.
- Antworten nennen nur Zahlen aus der Datenbank.

**Frontend**
- React escapt Ausgaben, kein `dangerouslySetInnerHTML`
- Schriftarten von Google Fonts sind die einzige externe Quelle

**Zugangsdaten in Tests**
- nur offensichtliche Platzhalter (`admin@example.test`, `test-key-not-real`)
- `.env.example` ohne echte Werte
- Secret-Scan vor der Auslieferung: kein bekannter oder echter Schlüssel im Paket

## Offene Punkte (nicht umgesetzt)

| Punkt | Bewertung |
|---|---|
| Keine Zwei-Faktor-Anmeldung | für einen geschlossenen Testbetrieb vertretbar, vor öffentlichem Betrieb nachrüsten |
| Kein Passwort-Reset per E-Mail | Reset nur durch den Betreiber per CLI (`user:password`) |
| Rate-Limits im Arbeitsspeicher | bei mehreren Instanzen nicht geteilt. Kontosperren sind persistent |
| Abhängigkeiten ohne Lockfile und ohne `npm audit` | Registry war nicht erreichbar. Beim ersten Build Lockfile erzeugen und `npm audit` ausführen |
| Zahlungsbelege unverschlüsselt in der Datenbank | Zugriff nur für Admins, Löschung nach Frist. Für den kommerziellen Betrieb Datenträgerverschlüsselung und Backup-Verschlüsselung vorsehen |
| Nur ein Admin vorhanden | Dessen eigene Zahlungen kann niemand freigeben. Für ihn eine begründete Freischaltung nutzen oder einen zweiten Admin anlegen |
| Kein externer Penetrationstest | empfohlen vor Betrieb mit Dritten |
| CSP erlaubt `style-src 'unsafe-inline'` | nötig für Inline-Styles in React. Kein Skript-Risiko, da `script-src 'self'` |
| The Odds API verlangt den Schlüssel als URL-Parameter | Die URL verlässt den Server nicht und wird in Logs geschwärzt. Beim Provider ist das nicht änderbar |

## Hinweis zum Highlightly-Schlüssel

Ein Highlightly-Schlüssel wurde früher im Chat geteilt. Er ist **nicht** im Code, in Tests, in Beispielen oder im Paket enthalten (Secret-Scan). Er sollte trotzdem beim Anbieter **rotiert** werden, weil er außerhalb eines Secret-Speichers übertragen wurde.
