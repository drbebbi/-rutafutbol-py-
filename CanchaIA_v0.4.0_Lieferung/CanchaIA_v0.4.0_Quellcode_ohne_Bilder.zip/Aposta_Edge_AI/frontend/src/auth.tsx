/** Anmeldung und Registrierung. Registrierung nutzt POST /api/auth/register (in der Beta meist gesperrt → klarer Hinweis). */
import React, { useState } from 'react';
import { DICTS, UI, type Lang } from './i18n';
import { api, setCsrf, HttpError } from './api';
import { BrandMark, BrandWord } from './components';
import { BRAND } from './brand';

export function Auth({ onOk, lang, setLang }: { onOk: () => void; lang: Lang; setLang: (l: Lang) => void }) {
  const t = DICTS[lang], u = UI[lang];
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState(''), [pw, setPw] = useState(''), [err, setErr] = useState(''), [info, setInfo] = useState(''), [busy, setBusy] = useState(false);
  const login = async () => {
    const r = await api<any>('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: email.trim(), password: pw }) });
    setCsrf(r.csrfToken); setPw(''); onOk();
  };
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setErr(''); setInfo(''); setBusy(true);
    try {
      if (mode === 'register') {
        await api('/api/auth/register', { method: 'POST', body: JSON.stringify({ email: email.trim(), password: pw }) });
        await login();
      } else await login();
    } catch (x) {
      if (x instanceof HttpError && x.status === 401) setErr(t.badLogin);
      else if (x instanceof HttpError && x.status === 403 && mode === 'register') setInfo(u.regClosed);
      else setErr((x as Error).message);
    } finally { setBusy(false); }
  };
  return (
    <div className="auth">
      <aside className="aside">
        <span className="brand lg" aria-label={`${BRAND.name} – ${BRAND.slogan}`}><BrandMark /><BrandWord slogan /></span>
        <div><p className="claim">{u.authClaim}</p><p>{u.authText}</p></div>
        <span className="t-3 small">{u.beta} · {t.disclaimer}</span>
      </aside>
      <main className="pane">
        <div className="box">
          <div className="row-flex between">
            <span className="brand only-sm" aria-label={`${BRAND.name} – ${BRAND.slogan}`}><BrandMark /><BrandWord slogan /></span>
            <span className="badge watch">{u.beta}</span>
            <div className="langsel" role="group" aria-label={t.language}>{(['es', 'de', 'en'] as Lang[]).map(l => <button key={l} type="button" aria-pressed={lang === l} onClick={() => setLang(l)}>{l.toUpperCase()}</button>)}</div>
          </div>
          <form className="card" onSubmit={submit} noValidate>
            <div><h1 style={{ fontSize: '1.35rem' }}>{mode === 'login' ? u.signIn : u.createAccount}</h1></div>
            <label className="field">{t.email}<input id="email" type="email" autoComplete="username" required value={email} onChange={e => setEmail(e.target.value)} /></label>
            <label className="field">{t.password}<input id="password" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} required minLength={mode === 'register' ? 12 : undefined} value={pw} onChange={e => setPw(e.target.value)} />
              {mode === 'register' ? <span className="hint">{u.pwHint}</span> : null}</label>
            <button className="btn block" disabled={busy || !email || !pw}>{busy ? t.loading : mode === 'login' ? u.signIn : u.createAccount}</button>
            {err ? <div className="banner error" role="alert"><span>{err}</span></div> : null}
            {info ? <div className="banner warn" role="status"><span>{info}</span></div> : null}
            <p className="small t-2">{mode === 'login' ? u.noAccount : u.haveAccount} <button type="button" className="btn quiet sm" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr(''); setInfo(''); }}>{mode === 'login' ? u.register : u.signIn}</button></p>
          </form>
          <p className="t-3 xs only-sm">{t.disclaimer}</p>
        </div>
      </main>
    </div>
  );
}
