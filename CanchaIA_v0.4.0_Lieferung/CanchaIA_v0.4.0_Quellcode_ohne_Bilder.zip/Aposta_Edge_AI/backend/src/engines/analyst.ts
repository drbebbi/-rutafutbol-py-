/**
 * KI-Analyst (Analista IA, früher EDGE ANALYST): beantwortet Fragen ausschließlich auf Basis gespeicherter Daten und Modellberechnungen.
 * Mit ANTHROPIC_API_KEY: Sprachmodell mit Werkzeugen (Tool Use), das Zahlen nur aus Werkzeug-Ergebnissen
 * übernehmen darf. Ohne Schlüssel: regelbasierter Modus mit denselben Werkzeugen.
 */
import type { Db } from '../db/db.js';
import type { Config } from '../config.js';
import { RecommendationEngine } from './recommendation.js';
import { PerformanceRepository } from './performance.js';
import { BacktestingEngine } from './backtest.js';
import { redact } from '../util/log.js';
import { OddsStore } from './odds.js';
import { checkFreshness } from './freshness.js';
import { json } from '../db/db.js';
import { nameSimilarity, nowIso } from '../util/core.js';
import type { MarketId } from '../providers/types.js';

type Lang = 'es' | 'de' | 'en';
/** mode 'rules' = lokaler Regelmodus ohne externes Sprachmodell; fallbackReason nennt den Grund (v0.4.0). */
export interface AnalystAnswer { answer: string; mode: 'llm' | 'rules'; toolsUsed: string[]; data: unknown[]; model?: string; fallbackReason?: string }

/** Modelle, für die der serverseitige Refusal-Fallback (beta server-side-fallback-2026-07-01, "default") verfügbar ist. */
const SERVER_FALLBACK_MODELS = new Set(['claude-fable-5-1', 'claude-opus-5-5', 'claude-opus-5', 'claude-sonnet-5-5']);

export class EdgeAnalyst {
  private now: Date = new Date();
  private rec: RecommendationEngine; private perf: PerformanceRepository; private bt: BacktestingEngine; private odds: OddsStore;
  constructor(private db: Db, private cfg: Config, private fetcher: typeof fetch = fetch) {
    this.rec = new RecommendationEngine(db, { oddsMaxAgeMinutes: cfg.analysis.oddsMaxAgeMinutes, allowMock: cfg.dataMode === 'mock' }); this.perf = new PerformanceRepository(db); this.bt = new BacktestingEngine(db); this.odds = new OddsStore(db);
  }

  // ---------------------------------------------------------------- Werkzeuge
  readonly tools = {
    get_top_value_bets: () => {
      // revalidiert gegen die aktuelle Uhr: abgelaufene Empfehlungen erscheinen nie
      const r = this.rec.current(this.now);
      return r.length ? r.map(x => ({ ...this.signalView(x.signal.id), odds_age_minutes: x.oddsAgeMinutes, odds_retrieved_at: x.oddsRetrievedAt, valid_until: x.validUntil, provider: x.provider })) : { message: 'NO QUALIFIED VALUE BETS' };
    },
    search_signals: (a: { min_ev?: number; status?: string }) => {
      const minEv = Number(a.min_ev ?? 0.05);
      // nur Signale mit gültigem Datenstand (valid_until in der Zukunft)
      const rows = this.db.all<{ id: number }>(`SELECT s.id FROM value_signals s JOIN events e ON e.id = s.event_id WHERE s.active = 1 AND e.kickoff_utc > ? AND s.valid_until > ? AND s.ev >= ? ${a.status ? 'AND s.status = ?' : ''} ${this.cfg.dataMode === 'live' ? 'AND e.is_mock = 0' : ''} ORDER BY s.ev_low DESC LIMIT 15`,
        ...([nowIso(this.now), nowIso(this.now), minEv, ...(a.status ? [a.status] : [])] as (string | number)[]));
      return rows.map(r => this.signalView(r.id));
    },
    find_event: (a: { query: string }) => {
      const evs = this.db.all<{ id: number; home: string; away: string; kickoff_utc: string; comp: string }>(`SELECT e.id, th.name AS home, ta.name AS away, e.kickoff_utc, c.name AS comp FROM events e
        JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id WHERE e.status = 'scheduled' AND e.kickoff_utc > ?`, nowIso(this.now));
      const q = String(a.query || '');
      return evs.map(e => ({ ...e, score: Math.max(nameSimilarity(q, e.home), nameSimilarity(q, e.away), nameSimilarity(q, `${e.home} ${e.away}`)) }))
        .filter(e => e.score >= 0.6).sort((x, y) => y.score - x.score).slice(0, 5);
    },
    get_event_analysis: (a: { event_id: number }) => this.eventAnalysis(Number(a.event_id), this.now),
    get_odds_age: (a: { event_id: number }) => {
      const ev = this.db.get<{ kickoff_utc: string }>('SELECT kickoff_utc FROM events WHERE id = ?', Number(a.event_id));
      if (!ev) return { error: 'Spiel nicht gefunden' };
      return (['1X2', 'OU', 'BTTS'] as MarketId[]).flatMap(m => this.odds.latestPerBookmaker(Number(a.event_id), m, m === 'OU' ? 2.5 : null).map(v => {
        const f = checkFreshness({ retrievedAt: v.retrievedAt, sourceTimestamp: v.sourceTimestamp, kickoffUtc: ev.kickoff_utc, snapshotKind: v.kind }, this.now, this.cfg.analysis.oddsMaxAgeMinutes);
        return { market: m, bookmaker: v.bookmakerName, provider: v.provider, retrieved_at: v.retrievedAt, source_timestamp: v.sourceTimestamp, from_cache: v.fromCache, age_minutes: f.ageMinutes, limit_minutes: f.limitMinutes, current: f.ok, issues: f.reasons };
      }));
    },
    get_best_odds: (a: { event_id: number; market: MarketId }) => {
      const m = (['1X2', 'OU', 'BTTS'].includes(a.market) ? a.market : '1X2') as MarketId;
      return this.odds.latestPerBookmaker(Number(a.event_id), m, m === 'OU' ? 2.5 : null).map(v => ({ bookmaker: v.bookmakerName, prices: v.prices, retrievedAt: v.retrievedAt, valid: v.valid, errors: v.errors, overround: v.overround }));
    },
    get_performance: () => ({ real: this.perf.metrics('real'), mock: this.perf.metrics('mock') }),
    get_model_status: () => {
      const mv = this.db.all('SELECT id, validation_status, validated_by_backtest, created_at FROM model_versions ORDER BY created_at DESC LIMIT 3');
      const b = this.bt.latest();
      return { modelVersions: mv, latestBacktest: b ? { id: b.id, status: b.status, dataSource: b.data_source, validation: b.metrics?.validation, matches: b.metrics?.matches } : null };
    },
  };

  private signalView(id: number) {
    const s = this.db.get<Record<string, any>>(`SELECT s.*, th.name AS home, ta.name AS away, c.name AS competition, e.kickoff_utc, e.is_mock, b.name AS bookmaker FROM value_signals s
      JOIN events e ON e.id = s.event_id JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id
      LEFT JOIN bookmakers b ON b.id = s.best_bookmaker_id WHERE s.id = ?`, id);
    if (!s) return null;
    return { signal_id: s.id, event_id: s.event_id, match: `${s.home} – ${s.away}`, competition: s.competition, kickoff_utc: s.kickoff_utc, mock: !!s.is_mock,
      market: s.market_id, selection: s.selection_id, line: s.line, status: s.status, model_prob: s.model_prob, decision_prob: s.decision_prob, model_weight: s.model_weight, prob_low: s.prob_low, novig_prob: s.novig_prob,
      fair_odds: s.fair_odds, best_odds: s.best_odds, bookmaker: s.bookmaker, ev: s.ev, ev_low: s.ev_low, edge: s.edge, quality_score: s.quality_score, reasons: json.parse(s.reasons, []) };
  }

  eventAnalysis(eventId: number, now: Date = new Date()) {
    this.now = now;
    const ev = this.db.get<Record<string, any>>(`SELECT e.*, th.name AS home, ta.name AS away, c.name AS competition FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id WHERE e.id = ?`, eventId);
    if (!ev) return { error: 'Spiel nicht gefunden' };
    const p = this.db.get<Record<string, any>>('SELECT * FROM predictions WHERE event_id = ? ORDER BY created_at DESC, id DESC LIMIT 1', eventId);
    const sigs = this.db.all<{ id: number }>('SELECT id FROM value_signals WHERE event_id = ? AND active = 1', eventId).map(r => this.signalView(r.id));
    const lineups = this.db.all('SELECT team_id, status, formation FROM lineups WHERE event_id = ?', eventId);
    return {
      event: { id: ev.id, match: `${ev.home} – ${ev.away}`, competition: ev.competition, kickoff_utc: ev.kickoff_utc, status: ev.status, mock: !!ev.is_mock },
      prediction: p ? { model_version: p.model_version, created_at: p.created_at, lambda_home: p.lambda_home, lambda_away: p.lambda_away, probs: json.parse(p.probs, {}), uncertainty: json.parse(p.uncertainty, {}), data_quality: json.parse(p.data_quality, {}),
        components: json.parse<any[]>(p.components, []).map(c => ({ model: c.model, available: c.available, reason: c.reason, lambdaHome: c.lambdaHome, lambdaAway: c.lambdaAway, probs: c.probs })) } : null,
      signals: sigs, lineups,
      injuries: 'Keine Verletzungs-/Sperrdaten angebunden (Highlightly 8.2.7 bietet keinen Endpunkt dafür).',
    };
  }

  // ---------------------------------------------------------------- Antwort
  async ask(question: string, lang: Lang = 'es', history: { role: 'user' | 'assistant'; content: string }[] = [], now: Date = new Date()): Promise<AnalystAnswer> {
    this.now = now;
    let fallbackReason = 'kein KI-Schlüssel konfiguriert: lokaler Regelmodus';
    if (this.cfg.anthropic.apiKey) {
      try { return await this.askLlm(question, lang, history); }
      catch (e) { fallbackReason = `Sprachmodell nicht verfügbar (${redact((e as Error).message).slice(0, 160)}): lokaler Regelmodus`; }
    }
    return { ...this.askRules(question, lang), fallbackReason };
  }

  private toolSchemas() {
    return [
      { name: 'get_top_value_bets', description: 'Aktuelle Top-Empfehlungen (max. 5) mit allen Kennzahlen. Liefert NO QUALIFIED VALUE BETS, wenn keine qualifiziert sind.', input_schema: { type: 'object', properties: {} } },
      { name: 'search_signals', description: 'Aktive Signale mit EV ≥ min_ev (Dezimal, 0.05 = 5 %), optional nach Status filtern.', input_schema: { type: 'object', properties: { min_ev: { type: 'number' }, status: { type: 'string', enum: ['STRONG_VALUE', 'VALUE', 'WATCH', 'NO_VALUE', 'INSUFFICIENT_DATA', 'STALE', 'AVOID', 'MARKET_SUSPENDED'] } } } },
      { name: 'find_event', description: 'Bevorstehendes Spiel per Teamname suchen. Liefert event_id.', input_schema: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } },
      { name: 'get_event_analysis', description: 'Vollständige Analyse eines Spiels: Prognose je Modell, Unsicherheit, Datenqualität, Signale, Aufstellungsstatus, Verletzungsdatenlage.', input_schema: { type: 'object', properties: { event_id: { type: 'number' } }, required: ['event_id'] } },
      { name: 'get_best_odds', description: 'Letzte Quoten je Buchmacher für Spiel und Markt (1X2, OU = Über/Unter 2,5, BTTS).', input_schema: { type: 'object', properties: { event_id: { type: 'number' }, market: { type: 'string', enum: ['1X2', 'OU', 'BTTS'] } }, required: ['event_id', 'market'] } },
      { name: 'get_performance', description: 'Historische Performance der eingefrorenen Prognosen, getrennt nach echt und Mock.', input_schema: { type: 'object', properties: {} } },
      { name: 'get_model_status', description: 'Validierungsstatus der Modellversionen und letzter Backtest.', input_schema: { type: 'object', properties: {} } },
      { name: 'get_odds_age', description: 'Alter und Herkunft der letzten Quoten je Buchmacher für ein Spiel (Abrufzeit, Quellzeit, Cache, Grenze, aktuell ja/nein).', input_schema: { type: 'object', properties: { event_id: { type: 'number' } }, required: ['event_id'] } },
    ];
  }

  private async askLlm(question: string, lang: Lang, history: { role: 'user' | 'assistant'; content: string }[]): Promise<AnalystAnswer> {
    const system = `Du bist der KI-Analyst (Analista IA) von CanchaIA – Inteligencia Futbolística. Antworte in der Sprache "${lang}" (es = Spanisch (Paraguay), de = Deutsch, en = Englisch).
Regeln:
- Nenne Wahrscheinlichkeiten, Quoten, EV und Kennzahlen NUR, wenn sie in einem Werkzeug-Ergebnis stehen. Erfinde oder schätze niemals Zahlen.
- Fehlen Daten, sag das ausdrücklich (z. B. "keine Verletzungsdaten angebunden").
- Kennzeichne Mock-Daten immer als MOCK. Modelle mit Status UNVALIDATED sind nicht historisch validiert: sag das, wenn nach Zuverlässigkeit gefragt wird.
- Keine Gewinngarantien, keine Martingale, keine Aufforderung zum Wetten. Mehrere Auswahlen aus demselben Spiel sind korreliert.
- Quoten mit current=false oder Empfehlungen außerhalb valid_until sind NICHT aktuell: nie als aktuelle Value Bet ausgeben. Nenne bei Quoten immer ihr Alter.
- Behaupte keine Backtests oder Ergebnisse, die get_model_status/get_performance nicht liefern. Platziere nie Wetten.
- Prozentwerte im Ergebnis sind Dezimalzahlen (0.071 = 7,1 %).
- model_prob ist die unabhängige Modellwahrscheinlichkeit; decision_prob = model_weight · Modell + (1 − model_weight) · fairer Marktpreis. EV basiert auf decision_prob.`;
    const msgs: any[] = [...history.slice(-6).map(h => ({ role: h.role, content: h.content })), { role: 'user', content: question }];
    const used: string[] = [], data: unknown[] = [];
    // Serverseitiger Refusal-Fallback nur für Modelle, die ihn unterstützen (abschaltbar über ANTHROPIC_SERVER_FALLBACK=false)
    const fallback = this.cfg.anthropic.serverFallback && SERVER_FALLBACK_MODELS.has(this.cfg.anthropic.model);
    for (let round = 0; round < 6; round++) {
      const r = await this.fetcher('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': this.cfg.anthropic.apiKey!, 'anthropic-version': '2023-06-01', ...(fallback ? { 'anthropic-beta': 'server-side-fallback-2026-07-01' } : {}) },
        body: JSON.stringify({ model: this.cfg.anthropic.model, max_tokens: this.cfg.anthropic.maxTokens, system, tools: this.toolSchemas(), messages: msgs,
          ...(this.cfg.anthropic.effort ? { output_config: { effort: this.cfg.anthropic.effort } } : {}), ...(fallback ? { fallbacks: 'default' } : {}) }),
        signal: AbortSignal.timeout(60_000),
      });
      if (!r.ok) throw new Error(`LLM HTTP ${r.status}`);
      const body = await r.json() as { content: any[]; stop_reason: string; model?: string };
      // Ablehnung oder abgeschnittene Antwort nie als Analyse ausgeben → Regelmodus mit Grund
      if (body.stop_reason === 'refusal') throw new Error('Anfrage vom Modell abgelehnt (refusal)');
      if (body.stop_reason === 'max_tokens') throw new Error('Antwort abgeschnitten (max_tokens)');
      msgs.push({ role: 'assistant', content: body.content });  // unverändert zurückgeben (inkl. thinking-Blöcke)
      const calls = body.content.filter(c => c.type === 'tool_use');
      if (!calls.length || body.stop_reason !== 'tool_use') {
        const answer = body.content.filter(c => c.type === 'text').map(c => c.text).join('\n').trim();
        if (!answer) throw new Error('leere Antwort');
        return { answer, mode: 'llm', toolsUsed: used, data, model: body.model ?? this.cfg.anthropic.model };
      }
      const results = calls.map(c => {
        const fn = (this.tools as Record<string, (a: any) => unknown>)[c.name];
        let out: unknown;
        try { out = fn ? fn(c.input ?? {}) : { error: 'unbekanntes Werkzeug' }; } catch (e) { out = { error: (e as Error).message }; }
        used.push(c.name); data.push(out);
        return { type: 'tool_result', tool_use_id: c.id, content: JSON.stringify(out).slice(0, 30_000) };
      });
      msgs.push({ role: 'user', content: results });
    }
    throw new Error('zu viele Werkzeug-Runden');
  }

  private askRules(q: string, lang: Lang): AnalystAnswer {
    const t = T[lang];
    const s = q.toLowerCase();
    const fmt = (x: any) => `${x.mock ? '[MOCK] ' : ''}${x.match} · ${x.market} ${x.selection}${x.line ? ' ' + x.line : ''} @ ${num(x.best_odds)} (${x.bookmaker ?? '–'}) · ${t.prob} ${pc(x.model_prob)} → ${pc(x.decision_prob)} · ${t.fair} ${num(x.fair_odds)} · EV ${pc(x.ev)} (${t.low} ${pc(x.ev_low)}) · ${x.status}`;
    if (/(perform|rendim|leistung|abgeschnitten|bisher|roi|histor|resultad)/.test(s)) {
      const p = this.tools.get_performance();
      const r = p.real;
      return { mode: 'rules', toolsUsed: ['get_performance'], data: [p], answer: r.settled
        ? `${t.perf}: ${r.settled} ${t.settled}, ${t.winrate} ${pc(r.winRate)}, ROI ${pc(r.roi)}, Brier ${num(r.brier, 4)}, CLV ${pc(r.avgClv)}, Max-DD ${r.maxDrawdown}u.`
        : `${t.noPerf}${p.mock.settled ? ` (${t.mockOnly}: ${p.mock.settled})` : ''}` };
    }
    if (/(fiab|zuverl|reliab|valid|confian)/.test(s)) {
      const m = this.tools.get_model_status();
      const st = (m.modelVersions as any[])[0]?.validation_status ?? 'UNVALIDATED';
      return { mode: 'rules', toolsUsed: ['get_model_status'], data: [m], answer: `${t.modelStatus}: ${st}. ${m.latestBacktest ? `${t.backtest} #${m.latestBacktest.id} (${m.latestBacktest.dataSource}): ${(m.latestBacktest.validation?.reasons ?? []).join('; ')}` : t.noBacktest}` };
    }
    const found = this.tools.find_event({ query: q.replace(/[¿?]/g, '') });
    if (/(wie alt|alter der quote|how old|odds age|antig|qué tan vieja|que tan vieja|edad de la cuota)/.test(s)) {
      const target = found[0]?.id ?? (this.tools.get_top_value_bets() as any[])?.[0]?.event_id;
      if (!target) return { mode: 'rules', toolsUsed: ['find_event'], data: [], answer: t.none };
      const ages = this.tools.get_odds_age({ event_id: target }) as any[];
      if (!Array.isArray(ages) || !ages.length) return { mode: 'rules', toolsUsed: ['get_odds_age'], data: [ages], answer: t.none };
      const evn = this.db.get<{ h: string; a: string }>('SELECT th.name AS h, ta.name AS a FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id WHERE e.id = ?', target);
      return { mode: 'rules', toolsUsed: ['get_odds_age'], data: [ages], answer: `${evn ? `${evn.h} – ${evn.a}\n` : ''}` + ages.map(a => `${a.market} · ${a.bookmaker} (${a.provider}${a.from_cache ? ', cache' : ''}): ${a.age_minutes ?? '–'} min / ${a.limit_minutes} min → ${a.current ? 'OK' : 'STALE ODDS'}`).join('\n') };
    }
    if (found.length && /(warum|por qu|why|porque|lesion|verletz|injur|fair|cuota|quote|odds|análisis|analyse|analysis)/.test(s)) {
      const a = this.eventAnalysis(found[0].id) as any;
      const best = (a.signals as any[]).filter(Boolean).sort((x, y) => (y.ev_low ?? -9) - (x.ev_low ?? -9))[0];
      return { mode: 'rules', toolsUsed: ['find_event', 'get_event_analysis'], data: [a], answer:
        `${a.event.match}: ${a.prediction ? `λ ${num(a.prediction.lambda_home, 2)}–${num(a.prediction.lambda_away, 2)}, ${t.dq} ${a.prediction.data_quality.score} (${a.prediction.data_quality.status})` : t.noPred}. ` +
        (best ? `${t.bestSignal}: ${fmt(best)}. ${t.reasons}: ${(best.reasons as string[]).join('; ')}. ` : '') + `${t.injuries}` };
    }
    if (/(ev|value|valor|mindestens|al menos|at least)/.test(s) && /\d/.test(s)) {
      const m = /(\d+(?:[.,]\d+)?)\s*%/.exec(s);
      const minEv = m ? Number(m[1].replace(',', '.')) / 100 : 0.05;
      const r = this.tools.search_signals({ min_ev: minEv });
      return { mode: 'rules', toolsUsed: ['search_signals'], data: [r], answer: r.length ? r.filter(Boolean).map(fmt).join('\n') : t.none };
    }
    const top = this.tools.get_top_value_bets();
    return { mode: 'rules', toolsUsed: ['get_top_value_bets'], data: [top], answer: Array.isArray(top) ? top.filter(Boolean).map((x, i) => `${i + 1}. ${fmt(x)}`).join('\n') : 'NO QUALIFIED VALUE BETS' };
  }
}

const pc = (x: number | null | undefined) => x == null ? '–' : `${(x * 100).toFixed(1)} %`;
const num = (x: number | null | undefined, d = 2) => x == null ? '–' : x.toFixed(d);
const T: Record<Lang, Record<string, string>> = {
  es: { prob: 'prob.', fair: 'cuota justa', low: 'mín.', perf: 'Rendimiento real', settled: 'pronósticos liquidados', winrate: 'acierto', noPerf: 'Todavía no hay pronósticos reales liquidados.', mockOnly: 'solo MOCK', modelStatus: 'Estado del modelo', backtest: 'Backtest', noBacktest: 'Sin backtest todavía.', dq: 'calidad de datos', noPred: 'sin pronóstico', bestSignal: 'Mejor señal', reasons: 'Motivos', injuries: 'No hay fuente de lesiones/sanciones conectada.', none: 'Ninguna señal cumple ese EV.' },
  de: { prob: 'Wahrsch.', fair: 'faire Quote', low: 'unten', perf: 'Echte Performance', settled: 'abgerechnete Prognosen', winrate: 'Trefferquote', noPerf: 'Noch keine echten abgerechneten Prognosen.', mockOnly: 'nur MOCK', modelStatus: 'Modellstatus', backtest: 'Backtest', noBacktest: 'Noch kein Backtest.', dq: 'Datenqualität', noPred: 'keine Prognose', bestSignal: 'Bestes Signal', reasons: 'Gründe', injuries: 'Keine Verletzungs-/Sperrdaten angebunden.', none: 'Kein Signal erfüllt diesen EV.' },
  en: { prob: 'prob.', fair: 'fair odds', low: 'low', perf: 'Real performance', settled: 'settled predictions', winrate: 'win rate', noPerf: 'No real settled predictions yet.', mockOnly: 'MOCK only', modelStatus: 'Model status', backtest: 'Backtest', noBacktest: 'No backtest yet.', dq: 'data quality', noPred: 'no prediction', bestSignal: 'Best signal', reasons: 'Reasons', injuries: 'No injury/suspension source connected.', none: 'No signal meets that EV.' },
};
