-- v0.3.0 (2/3): Tarifverwaltung und Zahlungsprüfung (TESTMODUS). Nur ergänzend.
-- Rollen (users.role: user/admin) bleiben unverändert; Tarife sind ein getrenntes Konzept.

CREATE TABLE IF NOT EXISTS plans (
  id TEXT PRIMARY KEY,                 -- FREE | PRO | PREMIUM
  name TEXT NOT NULL,
  price_monthly_pyg INTEGER NOT NULL,  -- Guaraní, ganze Zahl
  price_yearly_pyg INTEGER NOT NULL,
  entitlements TEXT NOT NULL,          -- JSON, siehe subscriptions.ts
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
INSERT OR IGNORE INTO plans (id, name, price_monthly_pyg, price_yearly_pyg, entitlements) VALUES
  ('FREE', 'Free', 0, 0, '{"maxRecommendations":1,"edgeAnalystPerDay":0,"personalAlerts":false,"customAlertMinEv":false,"backtestReports":false}'),
  ('PRO', 'Pro', 79000, 790000, '{"maxRecommendations":5,"edgeAnalystPerDay":20,"personalAlerts":true,"customAlertMinEv":false,"backtestReports":false}'),
  ('PREMIUM', 'Premium', 139000, 1200000, '{"maxRecommendations":5,"edgeAnalystPerDay":100,"personalAlerts":true,"customAlertMinEv":true,"backtestReports":true}');

CREATE TABLE IF NOT EXISTS subscriptions (
  id INTEGER PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id),
  plan_id TEXT NOT NULL REFERENCES plans(id),
  billing_period TEXT NOT NULL CHECK (billing_period IN ('monthly','yearly','complimentary')),
  status TEXT NOT NULL CHECK (status IN ('ACTIVE','PENDING','EXPIRED','CANCELLED')),
  started_at TEXT,                      -- erst bei Freischaltung gesetzt
  expires_at TEXT,
  cancelled_at TEXT,
  created_by INTEGER,                   -- users.id (Benutzer selbst oder Admin)
  note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sub_user ON subscriptions(user_id, status);

CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY,
  subscription_id INTEGER NOT NULL REFERENCES subscriptions(id),
  user_id INTEGER NOT NULL REFERENCES users(id),
  method TEXT NOT NULL CHECK (method IN ('bank_transfer','upay')),
  provider_mode TEXT NOT NULL DEFAULT 'test' CHECK (provider_mode IN ('test','manual')),
  amount_pyg INTEGER NOT NULL,
  currency TEXT NOT NULL DEFAULT 'PYG',
  reference TEXT NOT NULL UNIQUE,       -- Verwendungszweck für die Überweisung, z. B. AEA-7K3Q9P
  status TEXT NOT NULL CHECK (status IN ('AWAITING_PAYMENT','PROOF_SUBMITTED','VERIFIED','REJECTED','CANCELLED')),
  provider_ref TEXT,                    -- z. B. Test-Referenz eines späteren uPay-Checkouts
  proof_submitted_at TEXT,
  verified_by INTEGER, verified_at TEXT,
  bank_reference TEXT,                  -- vom Admin aus dem Kontoauszug übernommen
  received_amount_pyg INTEGER,
  received_at TEXT,
  decision_note TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pay_status ON payments(status, created_at);

-- Hochgeladene Zahlungsbestätigungen: getrennt gespeichert, nur für Admins abrufbar; nie automatische Freischaltung
CREATE TABLE IF NOT EXISTS payment_proofs (
  id INTEGER PRIMARY KEY,
  payment_id INTEGER NOT NULL REFERENCES payments(id),
  uploaded_by INTEGER NOT NULL,
  file_name TEXT NOT NULL,
  mime TEXT NOT NULL,
  size INTEGER NOT NULL,
  sha256 TEXT NOT NULL,
  content BLOB,                         -- wird nach Ablauf der Aufbewahrungsfrist gelöscht (sha256 bleibt)
  note TEXT,
  created_at TEXT NOT NULL
);

-- Änderungsprotokoll (nur anhängen)
CREATE TABLE IF NOT EXISTS subscription_events (
  id INTEGER PRIMARY KEY,
  subscription_id INTEGER,
  payment_id INTEGER,
  user_id INTEGER,                      -- betroffener Benutzer
  actor_id INTEGER,                     -- handelnde Person (NULL = System)
  action TEXT NOT NULL,                 -- checkout | proof_submitted | payment_verified | payment_rejected | activated | expired | cancelled | granted
  from_status TEXT, to_status TEXT,
  detail TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_subev_user ON subscription_events(user_id, created_at);
CREATE TRIGGER IF NOT EXISTS subscription_events_append_only BEFORE UPDATE ON subscription_events
BEGIN SELECT RAISE(ABORT, 'subscription_events sind unveraenderlich'); END;
CREATE TRIGGER IF NOT EXISTS subscription_events_no_delete BEFORE DELETE ON subscription_events
BEGIN SELECT RAISE(ABORT, 'subscription_events sind unveraenderlich'); END;

-- Tagesnutzung je Benutzer (z. B. EDGE-ANALYST-Anfragen) für tarifabhängige Grenzen
CREATE TABLE IF NOT EXISTS usage_counters (
  user_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  feature TEXT NOT NULL,
  n INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, day, feature)
);
