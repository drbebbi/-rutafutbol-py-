/**
 * v0.4.1 – Fix 3: Wettbewerbs-IDs bleiben von der Datenbank bis zum Quotenabruf erhalten.
 * Vollständiger Ablauf: kostenlose Spielsuche → DB → Priorisierung → fixturesForEvents() → oddsForFixtures().
 * Antworten nach der offiziellen v4-Doku NACHGEBAUT; keine echten Abrufe.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildApp, type App } from '../src/app.js';
import { testOddsApiConnection } from '../src/engines/oddsApiStatus.js';
import { memDb, testConfig } from './helpers.js';
import { fakeFetcher, oddsEvent } from './fixtures/theOddsApiSamples.js';

const H = 3_600_000, MIN = 60_000;
const path = (u: string) => new URL(u).pathname;
const SPORTS = ['soccer_epl', 'soccer_spain_la_liga'];

function liveApp(events: Record<string, ReturnType<typeof oddsEvent>[]>, env: Record<string, string> = {}): { app: App; calls: string[] } {
  const f = fakeFetcher((p) => {
    if (p === '/v4/sports') return { body: SPORTS.map(key => ({ key, active: true, has_outrights: false })) };
    for (const s of SPORTS) {
      if (p === `/v4/sports/${s}/events`) return { body: (events[s] ?? []).map(({ bookmakers, ...e }) => e) };
      if (p === `/v4/sports/${s}/odds`) return { body: events[s] ?? [], headers: { 'x-requests-last': '2' } };
    }
    return null;
  });
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: 'test-key-NOT-REAL-fix3', THE_ODDS_API_SPORT_KEYS: SPORTS.join(','), ...env }), { db: memDb(), fetcher: f.fetcher, requireOddsConnectionTest: true });
  return { app, calls: f.calls };
}
const oddsCalls = (calls: string[]) => calls.map(path).filter(p => p.endsWith('/odds'));

test('Fix 3: nur EPL-Spiele priorisiert → kein Quotenabruf anderer Wettbewerbe; Sport-Key bleibt über die DB erhalten', async () => {
  const now = Date.now();
  const { app, calls } = liveApp({ soccer_epl: [oddsEvent({ id: 'e1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now - MIN })] });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const s = await app.sync.run(new Date(now));
  assert.deepEqual(oddsCalls(calls), ['/v4/sports/soccer_epl/odds'], `Abrufe: ${oddsCalls(calls).join(', ')} · ${s.errors.join(' | ')}`);
  assert.ok(s.oddsSnapshots > 0, 'Quoten für das EPL-Spiel gespeichert');
});

test('Fix 3: zwei benötigte Wettbewerbe, Budget für einen → der mit dem nächsten Anstoß wird gewählt', async () => {
  const now = Date.now();
  const { app, calls } = liveApp({
    soccer_epl: [oddsEvent({ id: 'e1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 30 * H, updatedAt: now - MIN })],
    soccer_spain_la_liga: [oddsEvent({ id: 'l1', sport: 'soccer_spain_la_liga', title: 'La Liga', home: 'Sevilla', away: 'Betis', kickoff: now + 6 * H, updatedAt: now - MIN })],
  }, { THE_ODDS_API_DAILY_BUDGET: '3' });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const s = await app.sync.run(new Date(now));
  assert.deepEqual(oddsCalls(calls), ['/v4/sports/soccer_spain_la_liga/odds'], `Abrufe: ${oddsCalls(calls).join(', ')}`);
  const rep = s.providerReports.find(r => r.provider === 'theoddsapi')!;
  assert.ok(rep.skippedSportKeys.some(k => k.key === 'soccer_epl' && /Budget/.test(k.reason)), JSON.stringify(rep.skippedSportKeys));
});

test('Fix 3: fehlende Wettbewerbszuordnung → kein pauschaler kostenpflichtiger Abruf, Grund protokolliert', async () => {
  const now = Date.now();
  const { app, calls } = liveApp({ soccer_epl: [oddsEvent({ id: 'e1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now - MIN })] });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  await app.sync.discover(new Date(now));
  // Zuordnung des Wettbewerbs zum Sport-Key fehlt (z. B. manuell entfernte oder nie angelegte Verknüpfung)
  app.db.run("DELETE FROM competition_aliases WHERE provider = 'theoddsapi'");
  const s = await app.sync.run(new Date(now + MIN));
  assert.deepEqual(oddsCalls(calls), [], `kein Quotenabruf: ${oddsCalls(calls).join(', ')}`);
  const rep = s.providerReports.find(r => r.provider === 'theoddsapi')!;
  assert.ok(rep.notes.some(n => /keine eindeutige Wettbewerbszuordnung/.test(n)), JSON.stringify(rep.notes));
  assert.equal(app.queue.usedThisMonth('theoddsapi'), 0);
});

test('Fix 3: mehrdeutige Zuordnung (zwei Sport-Keys für einen Wettbewerb) → keine ID geraten, kein Abruf', async () => {
  const now = Date.now();
  const { app, calls } = liveApp({ soccer_epl: [oddsEvent({ id: 'e1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now - MIN })] });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  await app.sync.discover(new Date(now));
  const comp = app.db.get<{ competition_id: number }>("SELECT competition_id FROM competition_aliases WHERE provider = 'theoddsapi' AND provider_id = 'soccer_epl'")!.competition_id;
  app.db.run("INSERT INTO competition_aliases (competition_id, provider, provider_id, alias_name) VALUES (?, 'theoddsapi', 'soccer_spain_la_liga', 'x')", comp);
  const s = await app.sync.run(new Date(now + MIN));
  assert.deepEqual(oddsCalls(calls), []);
  assert.ok(s.providerReports.find(r => r.provider === 'theoddsapi')!.notes.some(n => /keine eindeutige Wettbewerbszuordnung/.test(n)));
});
