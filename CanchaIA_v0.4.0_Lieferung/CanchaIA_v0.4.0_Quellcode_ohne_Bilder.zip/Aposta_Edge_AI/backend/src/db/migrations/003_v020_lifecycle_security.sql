-- v0.2.0: Zeitstempel-Herkunft, Empfehlungs-Lifecycle, persistente Provider-Sperren, Credits,
-- Scheduler-Heartbeat, Systemeinstellungen, Benutzer/Rollen/Sessions, Sicherheitsprotokoll.
-- Bestehende Daten bleiben erhalten; nur ergänzende Spalten/Tabellen.

-- Quoten-Snapshots (weiterhin unveränderlich): Herkunft der Zeitpunkte
--   retrieved_at     = tatsächlicher HTTP-Abruf beim Provider (bei Cache-Treffer: Zeitpunkt des ursprünglichen Abrufs)
--   source_timestamp = Zeitpunkt der Quote beim Anbieter (falls geliefert)
--   processed_at     = Verarbeitung in unserer Anwendung
--   from_cache       = 1, wenn die Antwort aus unserem Cache kam
--   snapshot_kind    = live | pre_closing | closing  (historische CSV-Kurse sind nie "live")
--   time_estimated   = 1, wenn der Zeitpunkt geschätzt ist (z. B. CSV ohne Erfassungszeit)
ALTER TABLE odds_snapshots ADD COLUMN processed_at TEXT;
ALTER TABLE odds_snapshots ADD COLUMN from_cache INTEGER NOT NULL DEFAULT 0;
ALTER TABLE odds_snapshots ADD COLUMN snapshot_kind TEXT NOT NULL DEFAULT 'live';
ALTER TABLE odds_snapshots ADD COLUMN time_estimated INTEGER NOT NULL DEFAULT 0;
-- v0.1.0 hat CSV-Schlusskurse als normale Snapshots gespeichert → nachträglich klassifizieren (Trigger kurz aussetzen)
DROP TRIGGER IF EXISTS odds_snapshots_immutable;
UPDATE odds_snapshots SET snapshot_kind = 'closing', time_estimated = 1 WHERE provider = 'football-data-csv';
CREATE TRIGGER odds_snapshots_immutable BEFORE UPDATE ON odds_snapshots
BEGIN SELECT RAISE(ABORT, 'odds_snapshots sind unveraenderlich'); END;
CREATE INDEX IF NOT EXISTS idx_snap_kind ON odds_snapshots(event_id, snapshot_kind, market_id);

-- Signale: Datenstand und Gültigkeit
ALTER TABLE value_signals ADD COLUMN odds_retrieved_at TEXT;
ALTER TABLE value_signals ADD COLUMN odds_source_timestamp TEXT;
ALTER TABLE value_signals ADD COLUMN validated_at TEXT;
ALTER TABLE value_signals ADD COLUMN valid_until TEXT;
ALTER TABLE value_signals ADD COLUMN market_ref_source TEXT;

-- Empfehlungen: vollständiger Lebenszyklus
ALTER TABLE recommendations ADD COLUMN predicted_at TEXT;
ALTER TABLE recommendations ADD COLUMN odds_retrieved_at TEXT;
ALTER TABLE recommendations ADD COLUMN odds_source_timestamp TEXT;
ALTER TABLE recommendations ADD COLUMN last_validated_at TEXT;
ALTER TABLE recommendations ADD COLUMN valid_until TEXT;
ALTER TABLE recommendations ADD COLUMN deactivated_at TEXT;
ALTER TABLE recommendations ADD COLUMN deactivation_reason TEXT;
CREATE INDEX IF NOT EXISTS idx_rec_active ON recommendations(active, valid_until);

-- Provider: persistente Sperren (überleben Neustarts)
ALTER TABLE provider_health ADD COLUMN paused_until TEXT;
ALTER TABLE provider_health ADD COLUMN pause_reason TEXT;
ALTER TABLE provider_health ADD COLUMN credits_used_last REAL;

-- API-Kosten (Credits) je Anfrage
ALTER TABLE api_requests ADD COLUMN cost REAL NOT NULL DEFAULT 1;
ALTER TABLE api_requests ADD COLUMN month TEXT;
UPDATE api_requests SET month = substr(day, 1, 7) WHERE month IS NULL;
CREATE INDEX IF NOT EXISTS idx_apireq_month ON api_requests(provider, month);

-- Scheduler-Heartbeat
ALTER TABLE sync_runs ADD COLUMN heartbeat_at TEXT;
ALTER TABLE job_locks ADD COLUMN heartbeat_at TEXT;

-- Systemweite Analyse-Einstellungen (nur Admin). Werte aus v0.1.0 (user 1) übernehmen.
CREATE TABLE IF NOT EXISTS system_settings (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  min_ev REAL NOT NULL DEFAULT 0.05,
  strategy TEXT NOT NULL DEFAULT 'BALANCED' CHECK (strategy IN ('CONSERVATIVE','BALANCED','AGGRESSIVE')),
  model_weight REAL,
  preferred_bookmakers TEXT NOT NULL DEFAULT '[]',
  enabled_competitions TEXT NOT NULL DEFAULT '[]',   -- leer = alle mit ausreichender Datenlage
  max_fixtures_per_run INTEGER NOT NULL DEFAULT 60,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
INSERT OR IGNORE INTO system_settings (id, min_ev, strategy, model_weight, preferred_bookmakers)
  SELECT 1, min_ev, strategy, model_weight, preferred_bookmakers FROM user_settings WHERE user_id = 1;
INSERT OR IGNORE INTO system_settings (id) VALUES (1);

-- Benutzer, Rollen, Sessions
ALTER TABLE users ADD COLUMN email TEXT;
ALTER TABLE users ADD COLUMN password_hash TEXT;
ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user';
ALTER TABLE users ADD COLUMN active INTEGER NOT NULL DEFAULT 1;
ALTER TABLE users ADD COLUMN failed_logins INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN locked_until TEXT;
ALTER TABLE users ADD COLUMN last_login_at TEXT;
CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL;
-- Der v0.1.0-Platzhalter "owner" hat kein Passwort und kann sich nicht anmelden; er bleibt als Systemkonto.
UPDATE users SET role = 'system', active = 0 WHERE id = 1 AND email IS NULL;

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,               -- SHA-256 des Session-Tokens (das Token selbst wird nie gespeichert)
  user_id INTEGER NOT NULL REFERENCES users(id),
  csrf_token TEXT NOT NULL,
  created_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  last_seen_at TEXT NOT NULL,
  ip TEXT,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,                -- login_ok | login_failed | locked | logout | user_created | role_changed | forbidden | csrf_failed | token_auth
  user_id INTEGER,
  email TEXT,
  ip TEXT,
  detail TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_secev_time ON security_events(created_at);

-- Eingefrorene Prognosen: Datenstand der Quote zum Empfehlungszeitpunkt
ALTER TABLE prediction_outcomes ADD COLUMN odds_retrieved_at TEXT;
ALTER TABLE prediction_outcomes ADD COLUMN odds_source_timestamp TEXT;
