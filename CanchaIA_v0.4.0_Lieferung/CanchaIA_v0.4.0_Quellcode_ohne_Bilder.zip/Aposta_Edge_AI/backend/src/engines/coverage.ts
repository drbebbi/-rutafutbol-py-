/**
 * Datengrundlage je Wettbewerb (v0.4.0) – ehrliche Übersicht für Betrieb und Admin.
 *
 * Je Wettbewerb: Spielplan verfügbar? Quoten verfügbar? Historie vorhanden? Teams eindeutig zugeordnet?
 * Modelle berechenbar? Markt und Wettbewerb validiert?
 * Ausschließlich aus der Datenbank und der Konfiguration abgeleitet; nichts wird geschätzt oder ergänzt.
 *
 * Wettbewerbe ohne geeignete eigene Historie (z. B. UEFA Champions League – football-data.co.uk bietet keine CSV)
 * erhalten INSUFFICIENT DATA mit Erklärung. Modelle nationaler Ligen werden NICHT übertragen: die Prognose nutzt
 * ausschließlich die Historie desselben (verknüpften) Wettbewerbs.
 */
import type { Db } from '../db/db.js';
import type { Config } from '../config.js';
import { effectiveSportKeys } from '../config.js';
import type { MarketId } from '../providers/types.js';
import { linkSimilarity } from './linking.js';

export const MIN_LEAGUE_HISTORY = 80;   // Dixon-Coles/Feature-Modell: mindestens 80 Ligaspiele
export const MIN_TEAM_GAMES = 6;        // alle Modelle: mindestens 6 Spiele je Team
const MARKETS: MarketId[] = ['1X2', 'OU', 'BTTS'];

export type CoverageStatus = 'READY' | 'PARTIAL' | 'INSUFFICIENT DATA' | 'NO FIXTURES';
export interface CompetitionCoverage {
  competitionId: number | null; name: string; providers: string[]; sportKey: string | null; isMock: boolean;
  fixtures: { available: boolean; upcoming: number; nextKickoff: string | null };
  odds: { available: boolean; eventsWithOdds: number; byMarket: Record<MarketId, number>; newestRetrievedAt: string | null };
  history: { available: boolean; finishedMatches: number; seasons: number; sources: string[] };
  teams: { unique: boolean; upcomingTeams: number; withoutHistory: string[]; unlinked: number; possibleDuplicates: number };
  models: { computable: boolean; eventsComputable: number; eventsTotal: number; reason: string | null };
  validation: Record<MarketId, { status: 'VALIDATED' | 'UNVALIDATED' | 'FAILED'; marketEvidence: string | null; modelVersion: string | null }>;
  status: CoverageStatus; explanation: string[];
}

const isIntlClubCup = (name: string, key: string | null) => /champions league|europa league|conference league|libertadores|sudamericana|club world/i.test(name) || /uefa|conmebol|fifa/i.test(key ?? '');

export function competitionCoverage(db: Db, cfg: Config, now: Date = new Date()): { generatedAt: string; competitions: CompetitionCoverage[]; notes: string[] } {
  const live = cfg.dataMode === 'live';
  const horizon = new Date(now.getTime() + cfg.analysis.horizonHours * 3_600_000).toISOString(), t = now.toISOString();
  const comps = db.all<{ id: number; name: string; is_mock: number }>(`SELECT id, name, is_mock FROM competitions ${live ? 'WHERE is_mock = 0' : ''} ORDER BY name`);
  const out: CompetitionCoverage[] = [];
  for (const c of comps) {
    const aliases = db.all<{ provider: string; provider_id: string }>('SELECT provider, provider_id FROM competition_aliases WHERE competition_id = ?', c.id);
    const sportKey = aliases.find(a => a.provider === 'theoddsapi')?.provider_id ?? null;
    const up = db.all<{ id: number; kickoff_utc: string; home_team_id: number; away_team_id: number; home: string; away: string }>(
      `SELECT e.id, e.kickoff_utc, e.home_team_id, e.away_team_id, th.name AS home, ta.name AS away FROM events e JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id
        WHERE e.competition_id = ? AND e.status = 'scheduled' AND e.kickoff_utc > ? AND e.kickoff_utc <= ? ORDER BY e.kickoff_utc`, c.id, t, horizon);
    const fin = db.get<{ n: number; seasons: number }>("SELECT COUNT(*) AS n, COUNT(DISTINCT season) AS seasons FROM events WHERE competition_id = ? AND status = 'finished' AND home_goals IS NOT NULL", c.id)!;
    if (!up.length && !fin.n) continue;
    const histSources = db.all<{ provider: string }>(`SELECT DISTINCT m.provider FROM event_mappings m JOIN events e ON e.id = m.event_id WHERE e.competition_id = ? AND e.status = 'finished'`, c.id).map(r => r.provider);
    // Quoten: gültige Live-Snapshots je Markt für anstehende Spiele (Mock nie als Live-Quote im Live-Modus)
    const byMarket = Object.fromEntries(MARKETS.map(m => [m, up.length ? db.get<{ n: number }>(`SELECT COUNT(DISTINCT s.event_id) AS n FROM odds_snapshots s WHERE s.event_id IN (${up.map(() => '?').join(',')})
        AND s.market_id = ? AND s.snapshot_kind = 'live' AND s.validation_errors = '[]' ${m === 'OU' ? 'AND s.line = 2.5' : ''}`, ...up.map(e => e.id), m)!.n : 0])) as Record<MarketId, number>;
    const withOdds = up.length ? db.get<{ n: number; t: string | null }>(`SELECT COUNT(DISTINCT s.event_id) AS n, MAX(s.retrieved_at) AS t FROM odds_snapshots s WHERE s.event_id IN (${up.map(() => '?').join(',')}) AND s.snapshot_kind = 'live' AND s.validation_errors = '[]'`, ...up.map(e => e.id))! : { n: 0, t: null };
    // Teams: Historie je Team im SELBEN Wettbewerb; nicht verknüpfte Teams aus missing_data
    const games = (team: number) => db.get<{ n: number }>("SELECT COUNT(*) AS n FROM events WHERE competition_id = ? AND status = 'finished' AND home_goals IS NOT NULL AND (home_team_id = ? OR away_team_id = ?)", c.id, team, team)!.n;
    const teamIds = new Map<number, string>(); for (const e of up) { teamIds.set(e.home_team_id, e.home); teamIds.set(e.away_team_id, e.away); }
    const withoutHistory = [...teamIds].filter(([id]) => games(id) < MIN_TEAM_GAMES).map(([, n]) => n);
    const unlinked = db.get<{ n: number }>("SELECT COUNT(*) AS n FROM missing_data WHERE kind = 'unlinked_team' AND detail LIKE ?", `%(Wettbewerb ${c.id})%`)!.n;
    const names = db.all<{ name: string }>('SELECT DISTINCT t.name FROM teams t JOIN events e ON e.home_team_id = t.id OR e.away_team_id = t.id WHERE e.competition_id = ?', c.id).map(r => r.name);
    let dupes = 0; for (let i = 0; i < names.length && names.length < 200; i++) for (let j = i + 1; j < names.length; j++) if (linkSimilarity(names[i], names[j]) >= 0.85) dupes++;
    // Modelle: genau die Voraussetzungen der Prognose (Ligahistorie, Teamhistorie im selben Wettbewerb)
    const eventsComputable = up.filter(e => games(e.home_team_id) >= MIN_TEAM_GAMES && games(e.away_team_id) >= MIN_TEAM_GAMES).length;
    const computable = fin.n >= MIN_LEAGUE_HISTORY && (up.length ? eventsComputable > 0 : true);
    const modelReason = fin.n === 0 ? 'keine Historie für diesen Wettbewerb' : fin.n < MIN_LEAGUE_HISTORY ? `nur ${fin.n} Spiele Historie (mindestens ${MIN_LEAGUE_HISTORY})`
      : up.length && !eventsComputable ? `keine anstehende Partie mit ≥ ${MIN_TEAM_GAMES} Spielen Teamhistorie je Team` : null;
    // Validierung je Markt: jüngster Scope-Eintrag dieses Wettbewerbs
    const validation = Object.fromEntries(MARKETS.map(m => {
      const v = db.get<{ status: 'VALIDATED' | 'UNVALIDATED' | 'FAILED'; market_evidence: string; model_version_id: string }>(
        'SELECT status, market_evidence, model_version_id FROM model_scope_validations WHERE competition_id = ? AND market_id = ? ORDER BY id DESC LIMIT 1', c.id, m);
      return [m, v ? { status: v.status, marketEvidence: v.market_evidence, modelVersion: v.model_version_id } : { status: 'UNVALIDATED' as const, marketEvidence: null, modelVersion: null }];
    })) as CompetitionCoverage['validation'];
    const explanation: string[] = [];
    if (c.is_mock) explanation.push('MOCK-Daten: fiktiv, nur Entwicklungsmodus.');
    if (!up.length) explanation.push('Keine anstehenden Spiele im Analysefenster.');
    if (up.length && !withOdds.n) explanation.push('Keine gültigen Live-Quoten für anstehende Spiele.');
    if (!computable) {
      if (isIntlClubCup(c.name, sportKey) && fin.n < MIN_LEAGUE_HISTORY) explanation.push(`${c.name}: keine geeignete Historie dieses Wettbewerbs vorhanden (football-data.co.uk bietet dafür keine CSV). Die Teams spielen in unterschiedlichen nationalen Ligen; deren Modelle werden nicht ungeprüft übertragen. Es werden deshalb keine Wahrscheinlichkeiten berechnet.`);
      else explanation.push(`Modelle nicht berechenbar: ${modelReason}.`);
    }
    if (withoutHistory.length && computable) explanation.push(`${withoutHistory.length} Teams ohne ausreichende Historie in diesem Wettbewerb (z. B. Aufsteiger oder nicht zugeordnete Namen).`);
    if (unlinked) explanation.push(`${unlinked} Teamnamen konnten nicht eindeutig zugeordnet werden (Admin → Missing Data).`);
    if (MARKETS.every(m => validation[m].status !== 'VALIDATED')) explanation.push('Kein Markt dieses Wettbewerbs ist validiert: Signale sind experimentell.');
    else if (MARKETS.some(m => validation[m].status === 'VALIDATED' && validation[m].marketEvidence !== 'BETTER')) explanation.push('Validiert heißt hier: besser als die Basisrate und kalibriert. Ein Mehrwert gegenüber dem Markt ist nur bei „BETTER“ belegt.');
    if (!byMarket.BTTS && up.length) explanation.push('BTTS: keine Quoten (Event-Odds optional und budgetbegrenzt).');
    const status: CoverageStatus = !computable ? 'INSUFFICIENT DATA' : !up.length ? 'NO FIXTURES' : withOdds.n && eventsComputable === up.length && !unlinked ? 'READY' : 'PARTIAL';
    out.push({
      competitionId: c.id, name: c.name, providers: [...new Set(aliases.map(a => a.provider))], sportKey, isMock: !!c.is_mock,
      fixtures: { available: up.length > 0, upcoming: up.length, nextKickoff: up[0]?.kickoff_utc ?? null },
      odds: { available: withOdds.n > 0, eventsWithOdds: withOdds.n, byMarket, newestRetrievedAt: withOdds.t },
      history: { available: fin.n >= MIN_LEAGUE_HISTORY, finishedMatches: fin.n, seasons: fin.seasons, sources: histSources },
      teams: { unique: !unlinked && !dupes && !withoutHistory.length, upcomingTeams: teamIds.size, withoutHistory: withoutHistory.slice(0, 20), unlinked, possibleDuplicates: dupes },
      models: { computable, eventsComputable, eventsTotal: up.length, reason: modelReason },
      validation, status, explanation,
    });
  }
  // Konfigurierte Sport-Keys ohne bisher bekannten Wettbewerb (z. B. noch keine Spielsuche gelaufen)
  if (live) for (const k of effectiveSportKeys(cfg)) {
    if (out.some(o => o.sportKey === k)) continue;
    const ucl = isIntlClubCup('', k);
    out.push({ competitionId: null, name: k, providers: ['theoddsapi'], sportKey: k, isMock: false,
      fixtures: { available: false, upcoming: 0, nextKickoff: null }, odds: { available: false, eventsWithOdds: 0, byMarket: { '1X2': 0, OU: 0, BTTS: 0 }, newestRetrievedAt: null },
      history: { available: false, finishedMatches: 0, seasons: 0, sources: [] }, teams: { unique: false, upcomingTeams: 0, withoutHistory: [], unlinked: 0, possibleDuplicates: 0 },
      models: { computable: false, eventsComputable: 0, eventsTotal: 0, reason: 'keine Historie für diesen Wettbewerb' },
      validation: { '1X2': { status: 'UNVALIDATED', marketEvidence: null, modelVersion: null }, OU: { status: 'UNVALIDATED', marketEvidence: null, modelVersion: null }, BTTS: { status: 'UNVALIDATED', marketEvidence: null, modelVersion: null } },
      status: 'INSUFFICIENT DATA',
      explanation: ['Noch keine Spiele abgerufen (kostenlose Spielsuche ausführen).', ucl ? 'Für diesen Wettbewerb ist keine geeignete Historie vorhanden; Modelle nationaler Ligen werden nicht übertragen. Es werden keine Wahrscheinlichkeiten berechnet.' : 'Historie über CSV-Import (football-data.co.uk) nötig.'] });
  }
  return { generatedAt: t, competitions: out, notes: [
    'Alle Angaben aus der Datenbank. Validiert = im Holdout besser als die Basisrate und kalibriert (je Markt); das ist kein Gewinnnachweis.',
    'Prognosen nutzen ausschließlich die Historie desselben (verknüpften) Wettbewerbs.',
  ] };
}
