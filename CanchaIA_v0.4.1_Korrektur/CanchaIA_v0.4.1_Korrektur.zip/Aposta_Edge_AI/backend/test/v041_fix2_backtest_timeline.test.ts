/**
 * v0.4.1 – Fix 2: Backtest zeitlich korrekt wie der Live-Ablauf.
 * Synthetische Daten prüfen nur die LOGIK, keine Modellqualität.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ANCHOR, insertSyntheticLeague, memDb, mockApp } from './helpers.js';
import { BacktestingEngine, DECISION_LEAD_MS, knownAt } from '../src/engines/backtest.js';
import { selectTop, simulateTimeline } from '../src/engines/recommendation.js';
import { decide, releaseSettings, ValueBettingEngine, weightFor, validatedFor, marketEdgeFor, type ValueSettings } from '../src/engines/value.js';
import { PredictionEngine, scopeRelease } from '../src/engines/prediction/index.js';
import { OddsStore } from '../src/engines/odds.js';
import { Repository } from '../src/engines/repository.js';
import type { Db } from '../src/db/db.js';

const H = 3_600_000;
const iso = (h: number) => new Date(Date.UTC(2025, 0, 1) + h * H).toISOString();
const cand = (id: number, ev: number, evLow: number, fromH: number, koH: number, key = `${ev}|1X2|HOME`) =>
  ({ id, event_id: ev, ev_low: evLow, quality_score: 80, availableFrom: iso(fromH), validUntil: iso(koH), key });

test('Fix 2: ein späterer Kandidat verändert eine frühere Auswahl nicht (vorher: Tagesfenster wählte rückwirkend)', () => {
  // Fünf frühe Kandidaten (Entscheidung 10 h), sechs bessere spätere (Entscheidung 20 h), alle derselbe Kalendertag
  const early = [1, 2, 3, 4, 5].map(i => cand(i, 100 + i, 0.01, 10, 11));
  const late = [6, 7, 8, 9, 10, 11].map(i => cand(i, 100 + i, 0.05, 20, 21));
  const tl = simulateTimeline([...early, ...late], 5);
  const sel = tl.selected.map(x => x.cand.id).sort((a, b) => a - b);
  assert.deepEqual(sel.filter(i => i <= 5), [1, 2, 3, 4, 5], 'frühe Auswahl bleibt bestehen');
  assert.ok(tl.selected.filter(x => x.cand.id <= 5).every(x => x.at === iso(10)), 'zum frühen Zeitpunkt eingefroren');
  // Gegenprobe alte Regel: Tagesauswahl hätte nur die späteren genommen
  assert.deepEqual(selectTop([...early, ...late], 5).map(t => t.pick.id).every(i => i > 5), true);
});

test('Fix 2: höchstens fünf gleichzeitig aktiv, höchstens eine je Spiel, wiederholte Zeitpunkte zählen nicht doppelt', () => {
  // 8 gleichzeitig gültige Kandidaten auf 7 Spielen; Kandidat 1 bleibt über viele Entscheidungszeitpunkte gültig
  const cs = [cand(1, 1, 0.09, 0, 50), cand(2, 1, 0.08, 0, 50, '1|OU|OVER'), ...[3, 4, 5, 6, 7, 8].map(i => cand(i, i, 0.01 * i, i, 50))];
  const tl = simulateTimeline(cs, 5);
  assert.ok(tl.maxActiveObserved <= 5);
  const perEvent = new Map<number, number>(); for (const x of tl.selected) perEvent.set(x.cand.event_id, (perEvent.get(x.cand.event_id) ?? 0) + 1);
  assert.ok([...perEvent.values()].every(n => n === 1), 'eine je Spiel');
  assert.equal(tl.selected.filter(x => x.cand.id === 1).length, 1, 'Kandidat 1 trotz 7 Zeitpunkten genau einmal gezählt');
  assert.equal(tl.decisionPoints, 7);
  assert.equal(new Set(tl.selected.map(x => x.cand.key)).size, tl.selected.length);
});

test('Fix 2: Kandidaten erst ab ihrem Entscheidungszeitpunkt und nur bis Anstoß gültig', () => {
  const tl = simulateTimeline([cand(1, 1, 0.05, 10, 11), cand(2, 2, 0.01, 12, 13)], 1);
  assert.deepEqual(tl.selected.map(x => [x.cand.id, x.at]), [[1, iso(10)], [2, iso(12)]], 'abgelaufener Kandidat blockiert nicht');
});

function league(db: Db) { insertSyntheticLeague(db, { teams: 14, seasons: 3, spacingHours: 2, marketNoise: 0.08, seed: 'fix2' }); }

test('Fix 2: später eingetroffene Quote wird vorher nicht verwendet; noch nicht verfügbare Ergebnisse bleiben ausgeschlossen', () => {
  const db = memDb(); league(db);
  const eng = new BacktestingEngine(db);
  eng.run({ refitDays: 60, minMatches: 200 });
  const target = eng.lastRows.filter(r => r.segment === 'holdout')[10];
  // Quote mit Fantasiepreis NACH dem Entscheidungszeitpunkt (aber vor Anstoß) nachträglich einfügen
  const late = new Date(Date.parse(target.decisionAt) + 20 * 60_000).toISOString();
  new OddsStore(db).save(target.eventId, { provider: 'synthetic-test', providerEventId: 'late', bookmakerProviderId: 'latebook', bookmakerName: 'latebook', market: '1X2', line: null,
    prices: { HOME: 40, DRAW: 3.4, AWAY: 1.4 }, marketStatus: 'open', retrievedAt: late, sourceTimestamp: null, snapshotKind: 'pre_closing', timeEstimated: false }, [], false);
  const eng2 = new BacktestingEngine(db);
  eng2.run({ refitDays: 60, minMatches: 200 });
  const row = eng2.lastRows.find(r => r.eventId === target.eventId)!;
  assert.ok(row.market['1X2']!.views.every(v => v.retrievedAt < row.decisionAt && v.bookmakerId !== 'latebook'), 'spätere Quote nicht sichtbar');
  // Ergebnisse: Teamhistorie der Zeile nur aus Spielen, deren Ergebnis zur Entscheidung vorlag
  const hist = new Repository(db).competitionHistory(row.competitionId);
  const home = hist.find(m => m.eventId === row.eventId)!.home;
  assert.equal(row.dq.homeGames, knownAt(hist, row.decisionAt).filter(m => m.home === home || m.away === home).length);
  // Jede Auswahl liegt zwischen Entscheidungszeitpunkt und Anstoß
  for (const s of eng2.lastSimulation!.selected) {
    const c = eng2.lastSimulation!.candidates.find(x => x.id === s.id)!;
    assert.ok(c.availableFrom <= s.at && s.at < c.validUntil);
    assert.equal(Date.parse(c.validUntil) - Date.parse(c.availableFrom), DECISION_LEAD_MS);
  }
});

function scope(db: Db, comp: number, market: string, blend: number, createdAt: string) {
  const id = `ensemble-1.1.0+test-${market}-${createdAt.slice(0, 4)}`;
  db.run("INSERT OR IGNORE INTO model_versions (id, description, weights, validation_status, created_at) VALUES (?, 't', '{}', 'PARTIAL', ?)", id, createdAt);
  db.run(`INSERT INTO model_scope_validations (model_version_id, competition_id, market_id, status, market_evidence, holdout_n, market_n, blend_weight, odds_times_estimated, reasons, created_at)
    VALUES (?, ?, ?, 'VALIDATED', 'NOT_WORSE', 400, 400, ?, 1, '[]', ?)`, id, comp, market, blend, createdAt);
}

test('Fix 2: Modellgewicht wie live – damals freigegebenes Mischgewicht je Markt, nie aus der Zukunft; manuelles Gewicht hat Vorrang', () => {
  const db = memDb(); league(db);
  const comp = db.get<{ competition_id: number }>("SELECT competition_id FROM competition_aliases WHERE provider_id = 'syn'")!.competition_id;
  scope(db, comp, '1X2', 0.8, '2000-01-01T00:00:00Z');   // existierte vor allen Entscheidungszeitpunkten
  scope(db, comp, 'OU', 0.7, '2099-01-01T00:00:00Z');    // „Zukunft“ aus Sicht des Backtests
  const eng = new BacktestingEngine(db);
  const r = eng.run({ refitDays: 60, minMatches: 200 });
  const cs = eng.lastSimulation!.candidates;
  assert.ok(cs.some(c => c.market === '1X2') && cs.some(c => c.market === 'OU'), 'Testvoraussetzung: Kandidaten in beiden Märkten');
  assert.ok(cs.filter(c => c.market === '1X2').every(c => c.weight === 0.8), '1X2: damals freigegebenes Gewicht');
  assert.ok(cs.filter(c => c.market === 'OU').every(c => c.weight === 0.35), 'OU: Freigabe aus der Zukunft wird nicht verwendet → Standard');
  assert.match(r.metrics.betting!.decisionRule, /freigegeben/);
  const man = new BacktestingEngine(db);
  man.run({ refitDays: 60, minMatches: 200, modelWeight: 0.5 });
  assert.ok(man.lastSimulation!.candidates.every(c => c.weight === 0.5), 'manuelles Gewicht hat Vorrang (wie live)');
});

test('Fix 2: gleiche Eingaben und Einstellungen → Live- und Backtest-Entscheidung identisch, einschließlich Modellgewicht', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const ev = app.db.get<{ event_id: number; competition_id: number }>(`SELECT v.event_id, e.competition_id FROM value_signals v JOIN events e ON e.id = v.event_id
     WHERE v.active = 1 AND v.novig_prob IS NOT NULL AND v.market_id = '1X2' LIMIT 1`)!;
  scope(app.db, ev.competition_id, '1X2', 0.6, '2000-01-01T00:00:00Z');
  const pe = new PredictionEngine(app.db);
  const pred = pe.predictEvent(ev.event_id, ANCHOR)!;
  const mv = pe.currentModelVersion(ev.competition_id);
  // Live-Weg (discovery): releaseSettings(currentModelVersion) → ValueBettingEngine.evaluate
  const live: ValueSettings = { minEv: 0.05, strategy: 'BALANCED', oddsMaxAgeMinutes: 90, preferredBookmakers: [], isMock: true, ...releaseSettings(mv, null) };
  const sigs = new ValueBettingEngine(app.db).evaluate(pred, live, ANCHOR).filter(s => s.market === '1X2' && s.decisionProb != null);
  assert.ok(sigs.length);
  // Backtest-Weg: releaseSettings(scopeRelease(…, Entscheidungszeitpunkt)) → decide mit denselben Eingaben
  const bt = { ...releaseSettings(scopeRelease(app.db, ev.competition_id, ANCHOR.toISOString()), null) };
  for (const s of sigs) {
    assert.equal(s.modelWeight, 0.6, 'live nutzt das freigegebene Gewicht');
    const d = decide({ p: s.modelProb!, sd: pred.ensemble.sd['1X2']![s.selection]!, bestOdds: s.bestOdds!, novig: s.novigProb, strategy: 'BALANCED', minEv: 0.05, modelWeight: weightFor(bt, '1X2'),
      dqScore: pred.dataQuality.score, agreement: pred.ensemble.agreement, modelValidated: validatedFor(bt, '1X2'), marketEdgeProven: marketEdgeFor(bt, '1X2'), isMock: true,
      freshness: 0, freshBooks: s.bookCount, marketRefSource: s.marketRefSource });
    assert.equal(d.modelWeight, s.modelWeight);
    assert.equal(d.decisionProb, s.decisionProb); assert.equal(d.ev, s.ev); assert.equal(d.evLow, s.evLow);
    assert.equal(d.status === 'VALUE' || d.status === 'STRONG_VALUE', s.status === 'VALUE' || s.status === 'STRONG_VALUE', `${s.selection}: ${d.status} vs ${s.status}`);
  }
});
