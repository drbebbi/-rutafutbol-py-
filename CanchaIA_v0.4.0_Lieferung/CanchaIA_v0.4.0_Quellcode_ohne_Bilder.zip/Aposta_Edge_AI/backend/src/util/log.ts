import type { Db } from '../db/db.js';
import { nowIso } from './core.js';

type Level = 'debug' | 'info' | 'warn' | 'error';
const order: Record<Level, number> = { debug: 10, info: 20, warn: 30, error: 40 };
const min = order[(process.env.LOG_LEVEL as Level) || 'info'] ?? 20;

/**
 * Entfernt alles, was wie ein Schlüssel aussieht, bevor etwas geloggt wird.
 * v0.3.3: nur Zuweisungen (= oder :) werden geschwärzt – Sätze wie „THE_ODDS_API_KEY fehlt“ bleiben lesbar;
 * bei authorization wird das Verfahren (Bearer/Basic) übersprungen und der eigentliche Token geschwärzt.
 */
export function redact(s: string): string {
  return s
    .replace(/(apiKey|api_key|x-rapidapi-key|x-api-key|token|authorization)(["']?\s*[=:]\s*["']?)((?:Bearer|Basic)\s+)?([^"'&\s,}]+)/gi, '$1$2$3[REDACTED]')
    .replace(/bot\d+:[A-Za-z0-9_-]{20,}/g, 'bot[REDACTED]');
}

function out(level: Level, msg: string, extra?: unknown) {
  if (order[level] < min) return;
  const line = JSON.stringify({ t: nowIso(), level, msg: redact(msg), ...(extra ? { extra: JSON.parse(redact(JSON.stringify(extra))) } : {}) });
  (level === 'error' || level === 'warn' ? process.stderr : process.stdout).write(line + '\n');
}

export const log = {
  debug: (m: string, e?: unknown) => out('debug', m, e),
  info: (m: string, e?: unknown) => out('info', m, e),
  warn: (m: string, e?: unknown) => out('warn', m, e),
  error: (m: string, e?: unknown) => out('error', m, e),
};

export function logError(db: Db, source: string, err: unknown): void {
  const message = err instanceof Error ? err.message : String(err);
  const detail = err instanceof Error ? (err.stack || '') : '';
  log.error(`[${source}] ${message}`);
  try {
    db.run('INSERT INTO error_logs (source, message, detail, created_at) VALUES (?, ?, ?, ?)', source, redact(message), redact(detail).slice(0, 4000), nowIso());
  } catch { /* Logging darf nie den Ablauf brechen */ }
}

export function noteMissing(db: Db, kind: string, ref: string, detail?: string): void {
  const t = nowIso();
  db.run(`INSERT INTO missing_data (kind, ref, detail, first_seen, last_seen) VALUES (?, ?, ?, ?, ?)
          ON CONFLICT(kind, ref) DO UPDATE SET last_seen = excluded.last_seen, count = count + 1, detail = COALESCE(excluded.detail, detail)`,
    kind, ref, detail ?? null, t, t);
}
