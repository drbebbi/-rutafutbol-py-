-- Aposta Edge AI – Grundschema (SQLite)
-- Zeitstempel: ISO-8601 in UTC (TEXT). Geldbeträge in Einheiten (u).

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id INTEGER PRIMARY KEY REFERENCES users(id),
  language TEXT NOT NULL DEFAULT 'es' CHECK (language IN ('es','de','en')),
  timezone TEXT NOT NULL DEFAULT 'America/Asuncion',
  min_ev REAL NOT NULL DEFAULT 0.05,
  strategy TEXT NOT NULL DEFAULT 'BALANCED' CHECK (strategy IN ('CONSERVATIVE','BALANCED','AGGRESSIVE')),
  preferred_bookmakers TEXT NOT NULL DEFAULT '[]',   -- JSON-Array von bookmaker.id
  notify_new_value INTEGER NOT NULL DEFAULT 1,
  notify_odds_change INTEGER NOT NULL DEFAULT 1,
  notify_removed INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS user_watchlist (
  user_id INTEGER NOT NULL REFERENCES users(id),
  event_id INTEGER NOT NULL REFERENCES events(id),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (user_id, event_id)
);

-- Stammdaten -----------------------------------------------------------------

CREATE TABLE IF NOT EXISTS competitions (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  country_code TEXT,
  country_name TEXT,
  region TEXT,                     -- europe | south_america | paraguay | asia | north_america | international | other
  data_quality TEXT NOT NULL DEFAULT 'unknown',
  is_mock INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS competition_aliases (
  competition_id INTEGER NOT NULL REFERENCES competitions(id),
  provider TEXT NOT NULL,
  provider_id TEXT NOT NULL,
  alias_name TEXT,
  PRIMARY KEY (provider, provider_id)
);

CREATE TABLE IF NOT EXISTS teams (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  norm_name TEXT NOT NULL,
  country_code TEXT,
  team_type TEXT NOT NULL DEFAULT 'club',
  is_mock INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_teams_norm ON teams(norm_name);

CREATE TABLE IF NOT EXISTS team_aliases (
  team_id INTEGER NOT NULL REFERENCES teams(id),
  provider TEXT NOT NULL,
  provider_id TEXT,
  alias_norm TEXT NOT NULL,
  PRIMARY KEY (provider, alias_norm)
);
CREATE INDEX IF NOT EXISTS idx_team_alias_pid ON team_aliases(provider, provider_id);

-- Spiele -----------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS events (
  id INTEGER PRIMARY KEY,
  competition_id INTEGER NOT NULL REFERENCES competitions(id),
  season TEXT,
  round TEXT,
  home_team_id INTEGER NOT NULL REFERENCES teams(id),
  away_team_id INTEGER NOT NULL REFERENCES teams(id),
  kickoff_utc TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'scheduled', -- scheduled | live | finished | postponed | cancelled | abandoned | unknown
  home_goals INTEGER,
  away_goals INTEGER,
  neutral_venue INTEGER NOT NULL DEFAULT 0,
  venue TEXT,
  analysis_status TEXT NOT NULL DEFAULT 'new', -- new | analysed | insufficient_data | skipped
  last_analysed_at TEXT,
  is_mock INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE (home_team_id, away_team_id, kickoff_utc)
);
CREATE INDEX IF NOT EXISTS idx_events_kickoff ON events(kickoff_utc);
CREATE INDEX IF NOT EXISTS idx_events_status ON events(status);
CREATE INDEX IF NOT EXISTS idx_events_teams ON events(home_team_id, away_team_id);

CREATE TABLE IF NOT EXISTS provider_events (
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  raw_home TEXT NOT NULL,
  raw_away TEXT NOT NULL,
  raw_competition TEXT,
  kickoff_utc TEXT NOT NULL,
  payload TEXT,
  fetched_at TEXT NOT NULL,
  PRIMARY KEY (provider, provider_event_id)
);

CREATE TABLE IF NOT EXISTS event_mappings (
  provider TEXT NOT NULL,
  provider_event_id TEXT NOT NULL,
  event_id INTEGER NOT NULL REFERENCES events(id),
  confidence REAL NOT NULL,
  method TEXT NOT NULL,           -- id | alias | fuzzy
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (provider, provider_event_id)
);

-- Quoten ----------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS bookmakers (
  id TEXT PRIMARY KEY,            -- provider-unabhängiger Schlüssel, z.B. 'pinnacle'
  name TEXT NOT NULL,
  is_sharp INTEGER NOT NULL DEFAULT 0,
  is_mock INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS bookmaker_aliases (
  provider TEXT NOT NULL,
  provider_bookmaker_id TEXT NOT NULL,
  bookmaker_id TEXT NOT NULL REFERENCES bookmakers(id),
  PRIMARY KEY (provider, provider_bookmaker_id)
);

CREATE TABLE IF NOT EXISTS markets (
  id TEXT PRIMARY KEY,            -- '1X2' | 'OU' | 'BTTS'
  name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS selections (
  market_id TEXT NOT NULL REFERENCES markets(id),
  id TEXT NOT NULL,               -- 'HOME','DRAW','AWAY','OVER','UNDER','YES','NO'
  PRIMARY KEY (market_id, id)
);

-- Ein Snapshot = ein vollständiger Markt eines Buchmachers zu einem Zeitpunkt. Unveränderlich.
CREATE TABLE IF NOT EXISTS odds_snapshots (
  id TEXT PRIMARY KEY,            -- Snapshot-ID (Hash)
  event_id INTEGER NOT NULL REFERENCES events(id),
  provider TEXT NOT NULL,
  bookmaker_id TEXT NOT NULL REFERENCES bookmakers(id),
  market_id TEXT NOT NULL REFERENCES markets(id),
  line REAL,                      -- Torlinie bei OU (2.5), sonst NULL
  market_status TEXT NOT NULL DEFAULT 'open', -- open | suspended | closed
  retrieved_at TEXT NOT NULL,
  source_timestamp TEXT,
  is_complete INTEGER NOT NULL,
  validation_errors TEXT,         -- JSON-Array, leer = gültig
  overround REAL
);
CREATE INDEX IF NOT EXISTS idx_snap_event ON odds_snapshots(event_id, market_id, retrieved_at);

CREATE TABLE IF NOT EXISTS odds_prices (
  snapshot_id TEXT NOT NULL REFERENCES odds_snapshots(id),
  selection_id TEXT NOT NULL,
  odds REAL NOT NULL CHECK (odds > 1.0),
  PRIMARY KEY (snapshot_id, selection_id)
);

CREATE TRIGGER IF NOT EXISTS odds_snapshots_immutable BEFORE UPDATE ON odds_snapshots
BEGIN SELECT RAISE(ABORT, 'odds_snapshots sind unveraenderlich'); END;
CREATE TRIGGER IF NOT EXISTS odds_prices_immutable BEFORE UPDATE ON odds_prices
BEGIN SELECT RAISE(ABORT, 'odds_prices sind unveraenderlich'); END;

-- Statistik ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS match_statistics (
  event_id INTEGER NOT NULL REFERENCES events(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  stat_key TEXT NOT NULL,         -- normalisiert: shots, shots_on_target, xg, possession, ...
  value REAL NOT NULL,
  provider TEXT NOT NULL,
  PRIMARY KEY (event_id, team_id, stat_key)
);

CREATE TABLE IF NOT EXISTS team_statistics (
  team_id INTEGER NOT NULL REFERENCES teams(id),
  competition_id INTEGER,
  season TEXT,
  scope TEXT NOT NULL,            -- total | home | away
  played INTEGER, wins INTEGER, draws INTEGER, losses INTEGER,
  goals_for INTEGER, goals_against INTEGER,
  provider TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  PRIMARY KEY (team_id, competition_id, season, scope, provider)
);

CREATE TABLE IF NOT EXISTS lineups (
  event_id INTEGER NOT NULL REFERENCES events(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  status TEXT NOT NULL,           -- confirmed | expected
  formation TEXT,
  players TEXT NOT NULL,          -- JSON
  provider TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  PRIMARY KEY (event_id, team_id)
);

-- Modelle & Prognosen ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS model_versions (
  id TEXT PRIMARY KEY,            -- z.B. 'ensemble-1.0.0'
  description TEXT NOT NULL,
  weights TEXT,                   -- JSON {market: {model: weight}}
  validation_status TEXT NOT NULL DEFAULT 'UNVALIDATED', -- UNVALIDATED | VALIDATED | FAILED
  validated_by_backtest INTEGER,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS predictions (
  id INTEGER PRIMARY KEY,
  event_id INTEGER NOT NULL REFERENCES events(id),
  model_version TEXT NOT NULL,
  created_at TEXT NOT NULL,
  lambda_home REAL, lambda_away REAL,
  probs TEXT NOT NULL,            -- JSON {market:{selection:p}}
  components TEXT NOT NULL,       -- JSON je Teilmodell
  uncertainty TEXT NOT NULL,      -- JSON {market:{selection:sd}}
  data_quality TEXT NOT NULL,     -- JSON {score, status, issues[]}
  inputs_hash TEXT NOT NULL,
  UNIQUE (event_id, inputs_hash)
);
CREATE INDEX IF NOT EXISTS idx_pred_event ON predictions(event_id, created_at);

CREATE TABLE IF NOT EXISTS value_signals (
  id INTEGER PRIMARY KEY,
  event_id INTEGER NOT NULL REFERENCES events(id),
  prediction_id INTEGER NOT NULL REFERENCES predictions(id),
  market_id TEXT NOT NULL,
  selection_id TEXT NOT NULL,
  line REAL,
  status TEXT NOT NULL,           -- STRONG_VALUE | VALUE | WATCH | NO_VALUE | INSUFFICIENT_DATA | STALE | AVOID | MARKET_SUSPENDED
  model_prob REAL,
  prob_low REAL,
  implied_prob REAL,
  novig_prob REAL,
  fair_odds REAL,
  best_odds REAL,
  best_bookmaker_id TEXT,
  best_snapshot_id TEXT,
  edge REAL,
  ev REAL,
  ev_low REAL,
  quality_score REAL,
  reasons TEXT NOT NULL,          -- JSON-Array
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  deactivated_at TEXT,
  deactivation_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_sig_active ON value_signals(active, status);
CREATE INDEX IF NOT EXISTS idx_sig_event ON value_signals(event_id);

CREATE TABLE IF NOT EXISTS recommendations (
  id INTEGER PRIMARY KEY,
  signal_id INTEGER NOT NULL REFERENCES value_signals(id),
  event_id INTEGER NOT NULL REFERENCES events(id),
  rank INTEGER NOT NULL,
  report_run_id INTEGER,
  rank_score REAL NOT NULL,
  correlated_signal_ids TEXT NOT NULL DEFAULT '[]',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

-- Jede veröffentlichte (qualifizierte) Prognose wird für die Auswertung eingefroren.
CREATE TABLE IF NOT EXISTS prediction_outcomes (
  id INTEGER PRIMARY KEY,
  signal_id INTEGER NOT NULL UNIQUE REFERENCES value_signals(id),
  event_id INTEGER NOT NULL REFERENCES events(id),
  predicted_at TEXT NOT NULL,
  market_id TEXT NOT NULL,
  selection_id TEXT NOT NULL,
  line REAL,
  odds REAL NOT NULL,
  bookmaker_id TEXT NOT NULL,
  model_prob REAL NOT NULL,
  ev REAL NOT NULL,
  model_version TEXT NOT NULL,
  data_quality_score REAL NOT NULL,
  is_mock INTEGER NOT NULL DEFAULT 0,
  final_home_goals INTEGER,
  final_away_goals INTEGER,
  outcome TEXT,                    -- WIN | LOSS | PUSH | VOID
  closing_odds REAL,
  closing_novig_prob REAL,
  clv REAL,
  settled_at TEXT
);

CREATE TABLE IF NOT EXISTS backtest_runs (
  id INTEGER PRIMARY KEY,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL,            -- running | done | failed
  data_source TEXT NOT NULL,       -- mock | csv | provider
  config TEXT NOT NULL,
  metrics TEXT,                    -- JSON
  error TEXT
);

-- Betrieb ------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS provider_health (
  provider TEXT PRIMARY KEY,
  status TEXT NOT NULL,            -- ok | degraded | down | disabled | blocked
  last_success_at TEXT,
  last_error_at TEXT,
  last_error TEXT,
  quota_remaining INTEGER,
  quota_limit INTEGER,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS api_requests (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL,
  day TEXT NOT NULL,               -- YYYY-MM-DD (UTC)
  endpoint TEXT NOT NULL,
  status INTEGER,
  duration_ms INTEGER,
  from_cache INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_apireq_day ON api_requests(provider, day);

CREATE TABLE IF NOT EXISTS api_cache (
  cache_key TEXT PRIMARY KEY,
  provider TEXT NOT NULL,
  body TEXT NOT NULL,
  fetched_at TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sync_runs (
  id INTEGER PRIMARY KEY,
  job TEXT NOT NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  status TEXT NOT NULL,            -- running | done | failed | skipped | paused_quota
  steps TEXT NOT NULL DEFAULT '{}',-- JSON Fortschritt je Schritt
  summary TEXT,
  error TEXT
);

CREATE TABLE IF NOT EXISTS job_locks (
  name TEXT PRIMARY KEY,
  holder TEXT NOT NULL,
  expires_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS alerts_sent (
  id INTEGER PRIMARY KEY,
  dedupe_key TEXT NOT NULL UNIQUE,
  kind TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  channels TEXT NOT NULL,          -- JSON
  created_at TEXT NOT NULL,
  read_at TEXT
);

CREATE TABLE IF NOT EXISTS error_logs (
  id INTEGER PRIMARY KEY,
  source TEXT NOT NULL,
  message TEXT NOT NULL,
  detail TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS missing_data (
  id INTEGER PRIMARY KEY,
  kind TEXT NOT NULL,              -- unmapped_market | unmapped_team | missing_history | missing_odds | missing_lineup
  ref TEXT NOT NULL,
  detail TEXT,
  first_seen TEXT NOT NULL,
  last_seen TEXT NOT NULL,
  count INTEGER NOT NULL DEFAULT 1,
  UNIQUE (kind, ref)
);

INSERT OR IGNORE INTO markets (id, name) VALUES ('1X2','Match Result'), ('OU','Over/Under'), ('BTTS','Both Teams To Score');
INSERT OR IGNORE INTO selections (market_id, id) VALUES
  ('1X2','HOME'),('1X2','DRAW'),('1X2','AWAY'),('OU','OVER'),('OU','UNDER'),('BTTS','YES'),('BTTS','NO');
INSERT OR IGNORE INTO users (id, name) VALUES (1, 'owner');
INSERT OR IGNORE INTO user_settings (user_id) VALUES (1);
