/**
 * Einheitliche Provider-Schnittstellen. Jeder Adapter liefert normalisierte Objekte;
 * die Zuordnung zu internen IDs übernimmt die EventMatchingEngine.
 */
export type MarketId = '1X2' | 'OU' | 'BTTS';
export type SelectionId = 'HOME' | 'DRAW' | 'AWAY' | 'OVER' | 'UNDER' | 'YES' | 'NO';
export const MARKET_SELECTIONS: Record<MarketId, SelectionId[]> = {
  '1X2': ['HOME', 'DRAW', 'AWAY'],
  OU: ['OVER', 'UNDER'],
  BTTS: ['YES', 'NO'],
};

export type EventStatus = 'scheduled' | 'live' | 'finished' | 'postponed' | 'cancelled' | 'abandoned' | 'unknown';

export interface ProviderTeam { providerId: string; name: string; type?: 'club' | 'national'; countryCode?: string | null }
export interface ProviderCompetition { providerId: string; name: string; countryCode?: string | null; countryName?: string | null; season?: string | null }

export interface ProviderFixture {
  provider: string;
  providerEventId: string;
  competition: ProviderCompetition;
  round?: string | null;
  home: ProviderTeam;
  away: ProviderTeam;
  kickoffUtc: string;
  status: EventStatus;
  homeGoals?: number | null;
  awayGoals?: number | null;
  venue?: string | null;
  isMock?: boolean;
}

export interface ProviderOddsQuote {
  provider: string;
  providerEventId: string;
  /** Wenn der Odds-Provider andere Event-IDs nutzt: Rohdaten zum Matching. */
  rawHome?: string; rawAway?: string; rawCompetition?: string; kickoffUtc?: string;
  bookmakerProviderId: string;
  bookmakerName: string;
  market: MarketId;
  line: number | null;
  marketStatus: 'open' | 'suspended' | 'closed';
  prices: Partial<Record<SelectionId, number>>;
  /** Zeitpunkt des echten HTTP-Abrufs beim Provider (bei Cache-Treffer der ursprüngliche Abruf). */
  retrievedAt: string;
  /** Zeitpunkt der Quote beim Anbieter, falls geliefert. */
  sourceTimestamp: string | null;
  /** true, wenn die Antwort aus unserem Cache stammt. */
  fromCache?: boolean;
  /** live = aktuelle Pre-Match-Quote; pre_closing/closing = historische Kurse (CSV). */
  snapshotKind?: 'live' | 'pre_closing' | 'closing';
  /** true, wenn retrievedAt geschätzt ist (z. B. CSV ohne Erfassungszeit). */
  timeEstimated?: boolean;
}

export interface ProviderMatchStat { teamProviderId: string; key: string; value: number }

export interface ProviderLineup {
  teamProviderId: string;
  status: 'confirmed' | 'expected';
  formation: string | null;
  players: { name: string; number?: number | null; position?: string | null; starter: boolean }[];
}

export interface ProviderTeamStats {
  teamProviderId: string;
  competitionProviderId: string | null;
  season: string | null;
  scope: 'total' | 'home' | 'away';
  played: number; wins: number; draws: number; losses: number; goalsFor: number; goalsAgainst: number;
}

export interface ProviderStanding { teamProviderId: string; teamName: string; position: number; points: number; played: number; goalsFor: number; goalsAgainst: number }

export interface ProviderCapabilities {
  fixtures: boolean; history: boolean; teamStats: boolean; standings: boolean;
  lineups: boolean; matchStats: boolean; injuries: boolean; odds: boolean; liveScores: boolean;
}

export interface FootballDataProvider {
  readonly name: string;
  readonly capabilities: ProviderCapabilities;
  /** Spiele mit Anstoß im Fenster [fromUtc, toUtc]. */
  upcomingFixtures(fromUtc: Date, toUtc: Date): Promise<ProviderFixture[]>;
  /** Abgeschlossene Spiele eines Wettbewerbs/Saison (für Modelle). */
  historicalResults(competition: ProviderCompetition, season: string | null): Promise<ProviderFixture[]>;
  lastGames?(teamProviderId: string): Promise<ProviderFixture[]>;
  headToHead?(teamA: string, teamB: string): Promise<ProviderFixture[]>;
  matchDetails?(providerEventId: string): Promise<ProviderFixture | null>;
  /**
   * v0.4.0: Ergebnisse gebündelt je Wettbewerb (ein Abruf je Wettbewerb statt je Spiel).
   * competitionProviderId = Wettbewerbs-ID dieses Providers (The Odds API: sport_key).
   */
  resultsFor?(items: { providerEventId: string; competitionProviderId: string | null; kickoffUtc: string }[]): Promise<ProviderFixture[]>;
  matchStatistics?(providerEventId: string): Promise<ProviderMatchStat[]>;
  lineups?(providerEventId: string): Promise<ProviderLineup[]>;
  teamStatistics?(teamProviderId: string, fromDate: string): Promise<ProviderTeamStats[]>;
  standings?(competitionProviderId: string, season: string): Promise<ProviderStanding[]>;
}

export interface OddsProvider {
  readonly name: string;
  /** true, wenn die Event-IDs identisch mit dem Fixture-Provider sind (kein Fuzzy-Matching nötig). */
  readonly sharesEventIdsWith: string | null;
  oddsForFixtures(fixtures: ProviderFixture[]): Promise<ProviderOddsQuote[]>;
  /** Nur Mock: simulierte Uhr für reproduzierbare Tests. Echte Provider ignorieren das. */
  setNow?(now: Date): void;
  bookmakers?(): Promise<{ providerId: string; name: string }[]>;
  /** Bericht des letzten Laufs: welche Märkte angefragt wurden, welche nicht und warum (für die Anzeige "nicht verfügbar"). */
  lastRunReport?(): ProviderRunReport;
}

export interface MarketCoverage { requested: boolean; events: number; reason: string | null }
export interface ProviderRunReport { provider: string; markets: Record<MarketId, MarketCoverage>; sportKeys: string[]; skippedSportKeys: { key: string; reason: string }[]; notes: string[] }

export class ProviderBlockedError extends Error {
  constructor(public provider: string, message: string) { super(message); }
}
export class QuotaExhaustedError extends Error {
  constructor(public provider: string, message: string) { super(message); }
}
