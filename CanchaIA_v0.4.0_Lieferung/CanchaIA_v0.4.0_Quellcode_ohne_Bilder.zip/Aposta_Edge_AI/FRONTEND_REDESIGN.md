# Frontend-Redesign v0.3.1 „Professional Analytics“

Reines Frontend- und UX-Redesign auf Basis von v0.3.0. **Backend, API, Datenmodell, Scheduler, Tarif-Logik und Prognosemodelle sind unverändert.** Im Ordner `backend/` wurde keine einzige Datei angefasst.

## Designentscheidungen

| Bereich | Entscheidung |
|---|---|
| Fläche | tiefes Navy-Schiefer: Hintergrund `#0c1420`, Karten `#121c2a`, Eingaben `#182436`, Ränder `#233247` |
| Text | `#e6edf5` / `#9eadc0` / `#6c7d93` (drei Stufen) |
| Interaktion | weiches Cyan `#4fc3e3` (nur Buttons, Fokus, Auswahl, beste Quote) |
| Marktreferenz | Türkis `#2fb9a5` (fairer Preis ohne Marge) |
| Bedeutung | VALUE grün `#3fd18c` · WATCH/Warnung bernstein `#f0b545` · AVOID/veraltet/Fehler rot `#ee6a64` |
| Schrift | IBM Plex Sans (Oberfläche), IBM Plex Sans Condensed für Kennzahlen; überall tabellarische Ziffern |
| Leitmotiv | **Edge-Meter**: zeigt auf einer Skala die in der Quote enthaltene Wahrscheinlichkeit (weißer Strich), den fairen Marktpreis (türkis) und die Entscheidungswahrscheinlichkeit. Der grüne Abschnitt ist der Edge, aus dem der EV kommt. Die Werte stammen aus dem Backend; nur 1/Quote wird im Browser berechnet. Das Motiv steckt auch im Markenzeichen. |
| Ton | Texte im Satzbau statt Großbuchstaben. Feste Fachcodes (VALUE, STALE ODDS, NO QUALIFIED VALUE BETS, UNVALIDATED MODEL …) bleiben als Codes erhalten, weil sie im Produkt definierte Zustände sind. |
| Keine Effekte | keine Glows, keine Verläufe als Dekoration, keine Einblend-Animationen. Nur Skeleton-Ladezustand (respektiert `prefers-reduced-motion`). |

Von v0.3.0 entfernt: das Lila (`#6d4ae8`) und die Rajdhani-Schrift. Beides wirkte eher nach Gaming als nach Analyse.

## UI-Kit (`frontend/src/ui.tsx`, Styles in `styles.css`)

| Komponente | Zweck |
|---|---|
| `Button` | primary / secondary / quiet / danger, optional Icon, Größe `sm` |
| `Card` | Karte mit Titel, Untertitel, Aktionen |
| `Badge`, `SignalBadge`, `StatusBadge`, `statusTone()` | Status in einheitlicher Farblogik |
| `Banner` | info / warn / error mit Icon und optionaler Aktion |
| `PageHeader`, `SectionHeader` | Seiten- und Abschnittsköpfe |
| `Kpi`, `Tiles` | KPI-Karten (mit Hinweis, Ton, Badge) und kleine Kacheln |
| `Tabs`, `Segmented` | Tabs (Rolle `tablist`) und Umschalter |
| `Field`, `Check` | Formularfelder mit Label und Hinweis |
| `EmptyState`, `Skeleton`, `Loading`, `ErrorBox` | Leer-, Lade- und Fehlerzustand (Fehler mit „Erneut versuchen“) |
| `ProbBar` | Wahrscheinlichkeitsbalken 1/X/2, Über/Unter, BTTS |
| `EdgeMeter` | Leitmotiv (siehe oben) |

Weitere neue Bausteine: `components.tsx` (Kontext, Icons, `BrandMark`, Diagramme), `hooks.ts` (`useLoad`, unverändert aus v0.3.0), `pages/shared.tsx` (`ValueCard`, `MatchRow`).

## Seiten

| Seite | Datei | Inhalt |
|---|---|---|
| Shell | `main.tsx` | Seitenleiste (Desktop), untere Tab-Leiste (Handy), Kopfzeile mit Beta, Mock/Live, Tarif, letzter Sync, Sprache |
| Anmeldung | `auth.tsx` | zweispaltig (Desktop), Anmelden / Konto erstellen. Ist die Registrierung gesperrt, erscheint ein klarer Beta-Hinweis (Server antwortet 403) |
| Übersicht | `pages/home.tsx` | 6 KPI (anstehende Spiele, aktive Empfehlungen, Ø EV, Modellstatus, Quotenstand, Performance), Top Value Bets als Karten mit Edge-Meter, nächste Spiele, Schnellzugriff, Systemzustand |
| Spiele | `pages/matches.tsx` | Filterleiste (Team/Liga, Wettbewerb, Region, Zeitraum, Signal, Mindest-EV), Zähler, Zurücksetzen. Handy: Karten-Liste; ab 900 px: Tabelle |
| Spieldetail | `pages/match.tsx` | Kopf mit Teams, Wettbewerb, Anstoß, Status. 6 Kennzahlen (Modell-Wahrscheinlichkeit, faire Quote, beste Quote, EV, Konfidenz, Datenqualität). Tabs Überblick, Quoten, Statistik, Modell, Verlauf, KI-Analyse |
| EDGE ANALYST | `pages/edge.tsx` | Analyse-Konsole mit Vorschlägen und Antwortblöcken MATCH, MARKET, MODEL, DATA, RISKS, VERDICT |
| Performance | `pages/performance.tsx` | KPI (ROI, Yield, Trefferquote, Ø Quote, CLV, Drawdown, Brier, Log Loss), Verlauf, Kalibrierung, je Markt, Backtest |
| Einstellungen | `pages/settings.tsx` | Profil, Sprache und Zeitzone, Benachrichtigungen (System + persönlich), Tarif, Sicherheit, Analyse (nur Admin) |
| Admin | `pages/admin.tsx` | alle v0.3.0-Funktionen, im UI-Kit dargestellt |

## Konflikte und gewählte kleinere Lösung

| Wunsch | Konflikt | Lösung |
|---|---|---|
| Antwortblöcke MATCH … VERDICT in EDGE ANALYST | Das Backend liefert die Antwort als freien Text. Den Prompt oder das Antwortformat zu ändern wäre eine Backend-Änderung. | Die Blöcke werden aus den Werkzeug-Daten gebaut, die das Backend schon mitliefert (`response.data`). Der Originaltext steht unverändert unter VERDICT. Fehlen Daten (z. B. eine reine Textantwort), gibt es nur VERDICT mit dem Hinweis „Antwort ohne strukturierte Daten“. Es wird nichts ergänzt oder geschätzt. |
| „Confidence“ im Spieldetail | Das Backend hat kein eigenes Konfidenzmaß. | „Konfidenz“ zeigt die vorhandene Signalqualität (`quality_score`), ausdrücklich als „Signalqualität“ beschriftet. |
| Filter Status und Mindest-EV | `/api/matches` filtert serverseitig nur nach Zeitraum, Region und Wettbewerb. | Signal und Mindest-EV werden im Browser auf das bereits geladene Top-Signal je Spiel angewendet. |
| Registrierung | Kein öffentlicher Endpunkt verrät, ob die Registrierung offen ist. | Formular immer verfügbar; bei 403 erscheint der Beta-Hinweis. |
| Yield | Bei 1 Einheit je Tipp ist Yield gleich ROI (so berechnet es das Backend). | Beide Werte werden angezeigt, Yield mit dem Hinweis „= ROI · 1u“. |
| Passwort ändern | Dafür gibt es keinen Endpunkt (nur CLI `user:password`). | Im Bereich Sicherheit steht ein ehrlicher Hinweis, dass ein Admin das Passwort zurücksetzt. |
| Analyse-Einstellungen | v0.3.0 zeigte sie Benutzern schreibgeschützt. | Gemäß Auftrag „Admin-Bereiche nur für Admins“ sind sie für Benutzer ausgeblendet. |

## Geänderte Dateien

- **Neu:** `frontend/src/ui.tsx`, `hooks.ts`, `auth.tsx`, `pages/home.tsx`, `pages/matches.tsx`, `pages/match.tsx`, `pages/edge.tsx`, `pages/performance.tsx`, `pages/settings.tsx`, `pages/admin.tsx`, `pages/shared.tsx`, `FRONTEND_REDESIGN.md`, `docs/screenshots/*`
- **Geändert:** `frontend/src/styles.css` (komplett neu), `components.tsx`, `main.tsx`, `i18n.ts` (neue Texte ES/DE/EN, bestehende unverändert), `v030.tsx` (Konto-Bereich in `PlanSection` und `PersonalAlertsSection` aufgeteilt, Logik gleich), `index.html` (Schriften, Theme-Farbe), `public/favicon.svg`, Versionsnummern
- **Entfernt:** `frontend/src/pages.tsx`; der Inhalt ist auf `pages/*` verteilt
- **Backend:** keine Änderung

## Qualitätssicherung (tatsächlich ausgeführt)

| Prüfung | Ergebnis |
|---|---|
| Frontend-Build (esbuild) | ✅ main.js 334 kB (v0.3.0: 293 kB) |
| Backend-Tests (unverändertes Backend) | ✅ 121/121 |
| Browser, Mock-Modus, Admin, 1440 × 900 und 390 × 844 | ✅ alle Seiten und alle Spieldetail-Tabs, EDGE-ANALYST-Anfragen: 0 JS-Fehler, 0 px horizontaler Überlauf (nach zwei Korrekturen, siehe unten) |
| Browser, Benutzerrolle | ✅ kein Admin-Link sichtbar, Analyse-Einstellungen ausgeblendet, `/admin` zeigt für Benutzer die Übersicht |
| Admin-Funktionen | ✅ kontrollierter Sync (DONE), Validierung (UNVALIDATED), Zahlungsliste, Sync-Knopf (meldet sauber „Scheduler deaktiviert“, wenn er aus ist) |
| Tarif/Zahlung als Benutzer | ✅ Bestellung bis „AWAITING_PAYMENT“ mit Überweisungsdaten |
| Sprache | ✅ Wechsel auf DE in den Einstellungen, alle Seiten in DE geprüft |
| Live-Modus ohne Provider | ✅ alle Seiten ohne Fehler; Status NOT CONFIGURED sichtbar; der Live-Badge ist neutral, nicht grün |
| Registrierung | ✅ Hinweis „Registrierung in der Beta geschlossen“ |
| Frontend-Typprüfung | ⚠️ nicht ausführbar (`@types/react` in der Umgebung nicht installierbar), wie in v0.3.0 |

Während der Prüfung behoben:
- horizontaler Überlauf der Konsole auf dem Handy (Grid-Spalte ohne `minmax(0, 1fr)`)
- Namenskollision der CSS-Klasse `.block` (Antwortblöcke) mit `.btn.block`
- zu enge Value-Karten
- Silbentrennung der Teamnamen auf dem Handy
- doppelte Provider-Zeilen
- grüner Live-Badge ohne konfigurierten Provider

## Offene Risiken

- **Keine Typprüfung des Frontends.** Fehler, die nur TypeScript fände, sind nicht ausgeschlossen. Die Laufzeitprüfung im Browser deckt die geprüften Wege ab.
- **Nicht in echten Mobilbrowsern getestet** (iOS Safari, Android Chrome), nur in Chromium mit Handy-Viewport.
- **Schriften kommen von Google Fonts** (wie bisher, CSP erlaubt das). Offline greifen Systemschriften.
- **Bundle größer:** 334 kB statt 293 kB (minifiziert, ohne gzip).
- **Antwortblöcke** hängen von der Form der Werkzeug-Daten ab. Ändert sich das Backend-Format, fällt die Anzeige auf VERDICT (Text) zurück, ohne Absturz.
- **Barrierefreiheit:** Tastaturfokus und Rollen sind gesetzt. Ein vollständiger Screenreader-Test ist nicht erfolgt.
- **Mobile Ganzseiten-Screenshots** zeigen die feste Tab-Leiste mitten im Bild. Das ist ein Effekt des Screenshot-Werkzeugs; im Browser liegt die Leiste unten.
