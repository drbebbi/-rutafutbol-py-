/** Dashboard: KPI-Leiste, Top Value Bets, nächste Spiele, Systemzustand, Schnellzugriff. Datenquellen wie v0.3.0. */
import React, { useEffect, useState } from 'react';
import { api, pct, signed, localTime, ago } from '../api';
import { fmt } from '../i18n';
import { tr } from '../reasons';
import { useApp } from '../components';
import { useLoad } from '../hooks';
import { Banner, Button, Card, EmptyState, ErrorBox, Kpi, Loading, PageHeader, SectionHeader, Skeleton, StatusBadge } from '../ui';
import { MatchRow, ValueCard } from './shared';

const BAD = ['down', 'blocked', 'paused', 'degraded'];

export function Home() {
  const { t, u, lang, tz, go, role, isMock } = useApp();
  const status = useLoad<any>('/api/status'), rec = useLoad<any>('/api/recommendations'), matches = useLoad<any[]>('/api/matches?hours=48'), perf = useLoad<any>('/api/performance');
  const [busy, setBusy] = useState(false), [syncErr, setSyncErr] = useState('');
  // Empfehlungen werden serverseitig bei jedem Abruf revalidiert; alle 5 min neu laden
  useEffect(() => { const id = setInterval(() => { rec.reload(); status.reload(); }, 5 * 60_000); return () => clearInterval(id); }, []);
  const runSync = async () => { setBusy(true); setSyncErr(''); try { await api('/api/admin/jobs/hourly_sync/run', { method: 'POST' }); rec.reload(); status.reload(); matches.reload(); } catch (e) { setSyncErr((e as Error).message); } finally { setBusy(false); } };
  const s = status.data;
  const recs: any[] = rec.data?.recommendations ?? [];
  const avgEv = recs.length ? recs.reduce((a, r) => a + (r.signal.ev ?? 0), 0) / recs.length : null;
  const mv = s?.modelValidation?.status ?? 'UNVALIDATED';
  const pm = perf.data ? (isMock ? perf.data.mock ?? perf.data.real : perf.data.real) : null;
  const badProviders = (s?.providers ?? []).filter((p: any) => BAD.includes(p.status));
  const sync = (s?.scheduler ?? []).find((j: any) => j.name === 'hourly_sync');

  return (
    <>
      <PageHeader title={u.dashboard} lead={u.dashboardLead}
        actions={role === 'admin' ? <Button variant="secondary" icon="refresh" onClick={runSync} disabled={busy}>{busy ? t.loading : t.runSync}</Button> : null} />
      {syncErr ? <Banner tone="error" title={t.error}>{syncErr}</Banner> : null}
      {s?.configIssues?.length ? <Banner tone="error" title="Config">{s.configIssues.map((i: string) => <div key={i}>{i}</div>)}</Banner> : null}
      {s && mv !== 'VALIDATED' ? <Banner tone="warn" title={`UNVALIDATED MODEL · ${u.unvalidatedTitle}`}>{t.unvalidatedHint}</Banner> : null}
      {s && !isMock && badProviders.length ? <Banner tone="error" title={`PROVIDER UNAVAILABLE · ${u.providerIssue}`}>{badProviders.map((p: any) => `${p.provider}: ${p.pause_reason ?? p.last_error ?? p.status}`).join(' · ')}</Banner> : null}

      {/* KPI-Leiste */}
      {status.err ? <ErrorBox e={status.err} onRetry={status.reload} /> : !s ? <Skeleton lines={2} height={64} /> : (
        <div className="kpis six">
          <Kpi label={u.kUpcoming} value={s.upcoming ?? '–'} hint={fmt(u.kUpcomingH, { h: 48 })} />
          <Kpi label={u.kActive} value={rec.data ? recs.length : '–'} hint={u.kActiveH} tone={recs.length ? 'value' : undefined} />
          <Kpi label={u.kAvgEv} value={avgEv != null ? signed(avgEv) : '–'} hint={u.kAvgEvH} />
          <Kpi label={u.kModel} value={mv} size="md" hint={s.modelValidation?.dataSource ?? '–'} tone={mv === 'VALIDATED' ? 'value' : mv === 'FAILED' ? 'avoid' : 'watch'} />
          <Kpi label={u.kFresh} value={s.lastOddsUpdate ? ago(s.lastOddsUpdate, lang) : '–'} size="md" hint={s.lastOddsUpdate ? localTime(s.lastOddsUpdate, tz, lang) : u.kFreshH} />
          <Kpi label={u.kPerf} value={pm && pm.settled ? signed(pm.roi) : '–'} size="md" tone={pm?.settled ? (pm.roi >= 0 ? 'value' : 'avoid') : undefined}
            hint={pm?.settled ? `ROI · ${fmt(u.kPerfH, { n: pm.settled })}${pm.settled < 30 ? ` · ${u.smallSample}` : ''}` : u.kPerfNone} />
        </div>
      )}

      {/* Top Value Bets */}
      <section className="stack">
        <SectionHeader title={u.topValue} count={rec.data ? recs.length : null} />
        <p className="t-3 small" style={{ marginTop: -6 }}>{u.topValueLead}</p>
        {rec.err ? <ErrorBox e={rec.err} onRetry={rec.reload} /> : !rec.data ? <Loading lines={4} /> : recs.length ? (
          <div className="vgrid">{recs.map(r => <ValueCard key={r.signalId} r={r} />)}</div>
        ) : (
          <EmptyState title={t.noValue} text={fmt(t.noValueSub, { ev: pct(s?.minEv ?? 0.05, 0) })} icon="ok" />
        )}
        {rec.data?.plan?.hidden ? <Banner tone="info" action={<a className="btn secondary sm" href="#/settings">{u.sPlan}</a>}>{fmt(u.hiddenByPlan, { n: rec.data.plan.hidden })}</Banner> : null}
        {rec.data?.recentlyDeactivated?.length ? <details className="card tight small"><summary>{t.recentlyDeactivated} ({rec.data.recentlyDeactivated.length})</summary>
          <ul className="reasons">{rec.data.recentlyDeactivated.map((d: any) => <li key={d.id}>{d.home} – {d.away} · {localTime(d.deactivated_at, tz, lang)} · {tr(d.deactivation_reason ?? '', lang)}</li>)}</ul></details> : null}
        <p className="t-3 xs">{t.disclaimer}</p>
      </section>

      <div className="grid main-side">
        <section className="stack">
          <SectionHeader title={u.upcoming} count={matches.data?.length ?? null} actions={<Button variant="quiet" icon="next" onClick={() => go('/matches')}>{u.allMatches}</Button>} />
          {matches.err ? <ErrorBox e={matches.err} onRetry={matches.reload} /> : !matches.data ? <Loading /> : matches.data.length ? (
            <div className="mlist">{matches.data.slice(0, 8).map(m => <MatchRow key={m.id} m={m} />)}</div>
          ) : <EmptyState title={u.emptyMatches} text={u.emptyMatchesText} icon="matches" />}
        </section>

        <aside className="stack lg">
          <Card title={u.quick}>
            <div className="qactions">
              <Button variant="secondary" icon="edge" onClick={() => go('/edge')}>{u.qaAsk}</Button>
              <Button variant="secondary" icon="matches" onClick={() => go('/matches')}>{u.qaMatches}</Button>
              <Button variant="secondary" icon="perf" onClick={() => go('/performance')}>{u.qaPerf}</Button>
              {role === 'admin' ? <Button variant="secondary" icon="admin" onClick={() => go('/admin')}>{u.qaAdmin}</Button> : null}
            </div>
          </Card>
          <Card title={u.health}>
            {!s ? <Skeleton /> : <div className="stack">
              <dl className="kv">
                <dt>{t.lastSync}</dt><dd>{s.lastSync ? <span className="row-flex"><StatusBadge s={s.lastSync.status} /><span className="small">{localTime(s.lastSync.started_at, tz, lang)}</span></span> : '–'}</dd>
                {s.lastSync?.summary ? <><dt>{t.dataQuality}</dt><dd className="small">{fmt(u.syncResult, { f: s.lastSync.summary.fixturesFound, o: s.lastSync.summary.oddsSnapshots, p: s.lastSync.summary.predictions })}{s.lastSync.summary.oddsRejected ? ` · ${s.lastSync.summary.oddsRejected} ✗` : ''}</dd></> : null}
                <dt>{t.schedulerStatus}</dt><dd className="small">{sync ? `${sync.running ? u.running : sync.lastStatus ?? t.never}${sync.nextDue && sync.nextDue !== 'sofort' ? ` · ${u.nextRun} ${localTime(sync.nextDue, tz, lang, false)}` : ''}` : 'off'}</dd>
              </dl>
              <div className="divider" />
              <div className="stack" style={{ gap: 6 }}>
                {(s.providerStates ?? []).filter((p: any) => p.status !== 'READY').map((p: any) => <div key={'ps' + p.provider} className="row-flex between small"><span>{p.provider}</span><StatusBadge s={p.status} /></div>)}
                {(s.providers ?? []).filter((p: any) => p.provider !== 'app' && !(s.providerStates ?? []).some((q: any) => q.provider === p.provider && q.status !== 'READY')).map((p: any) => <div key={p.provider} className="row-flex between small" title={p.last_error ?? ''}>
                  <span>{p.provider}{p.quota_remaining != null ? <span className="t-3"> · {p.quota_remaining}/{p.quota_limit}</span> : null}</span><StatusBadge s={p.status} /></div>)}
              </div>
              <div className="divider" />
              <div className="stack" style={{ gap: 6 }}>{(s.models ?? []).slice(0, 3).map((m: any) => <div key={m.id} className="row-flex between small"><span className="t-2">{m.id}</span><StatusBadge s={m.validation_status} /></div>)}</div>
            </div>}
          </Card>
        </aside>
      </div>
    </>
  );
}
