/**
 * v0.3.0 – Verbesserung 3: historische Datenqualität und Validierungsablauf.
 * Synthetische Daten (insertSyntheticLeague) prüfen nur die LOGIK; sie sind kein Qualitätsnachweis.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { insertSyntheticLeague, memDb, mockApp, ANCHOR } from './helpers.js';
import { historicalDataQuality } from '../src/engines/dataQuality.js';
import { runValidation } from '../src/engines/validation.js';
import { BacktestingEngine } from '../src/engines/backtest.js';
import { importFootballDataCsv } from '../src/providers/footballDataCsv.js';
import { e0Csv } from './fixtures/theOddsApiSamples.js';

test('V3: Datenqualität erkennt fehlende Ergebnisse, doppelte Spiele und mögliche doppelte Teams', () => {
  const db = memDb();
  importFootballDataCsv(db, e0Csv(['Arsenal', 'Chelsea', 'Everton', 'Fulham', 'Man United', 'Liverpool'], 2), 'E0.csv');
  const comp = db.get<{ competition_id: number }>("SELECT competition_id FROM competition_aliases WHERE provider_id = 'div:E0'")!.competition_id;
  // Duplikat derselben Paarung (anderer Provider-Schlüssel, 2 h später) und ein Spiel ohne Ergebnis
  const e = db.get<{ home_team_id: number; away_team_id: number; kickoff_utc: string }>('SELECT home_team_id, away_team_id, kickoff_utc FROM events WHERE competition_id = ? LIMIT 1', comp)!;
  db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status, home_goals, away_goals) VALUES (?, ?, ?, ?, 'finished', 1, 1)", comp, e.home_team_id, e.away_team_id, new Date(Date.parse(e.kickoff_utc) + 2 * 3_600_000).toISOString());
  db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status) VALUES (?, ?, ?, '2025-01-01T15:00:00Z', 'finished')", comp, e.away_team_id, e.home_team_id);
  // zweites Team mit fast gleichem Namen (typisches Alias-Problem)
  const dupTeam = db.run("INSERT INTO teams (name, norm_name) VALUES ('Manchester United', 'manchester united')").lastInsertRowid;
  db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status, home_goals, away_goals) VALUES (?, ?, ?, '2025-02-01T15:00:00Z', 'finished', 0, 0)", comp, dupTeam, e.home_team_id);
  const q = historicalDataQuality(db, { minMatches: 20 }).competitions.find(c => c.competitionId === comp)!;
  assert.equal(q.missingResults, 1);
  assert.equal(q.duplicateMatches.length, 1);
  assert.ok(q.possibleDuplicateTeams.some(p => [p.a, p.b].includes('Man United') && [p.a, p.b].includes('Manchester United')), JSON.stringify(q.possibleDuplicateTeams));
  assert.equal(q.leakageCheck.violations, 0, 'Merkmale nur aus Spielen vor dem Anstoß');
  assert.ok(q.leakageCheck.sampled > 0);
  assert.equal(q.usableForBacktest, false, 'Duplikate → nicht nutzbar');
  assert.ok(q.homeAway && q.homeAway.homeWin + q.homeAway.draw + q.homeAway.awayWin > 0.999);
  assert.ok(q.oddsCoverage.preClosing1x2 > 0.9, 'Pre-Closing-Quoten aus der CSV');
});

test('V3: Datenqualitäts-Befunde verhindern VALIDATED (auch wenn die Modellwerte gut wären)', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 14, seasons: 3 });
  const r = new BacktestingEngine(db).run({ refitDays: 60, minMatches: 200, blockers: ['Liga X: 3 doppelte Spiele'] });
  assert.notEqual(r.metrics.validation.status, 'VALIDATED');
  assert.ok(r.metrics.validation.reasons.some(x => /Datenqualität: Liga X/.test(x)));
});

test('V3: Validierungsablauf – Bericht mit Log Loss, Brier, Kalibrierung, Stichprobe je Liga und Markt, Quellen', () => {
  const db = memDb();
  insertSyntheticLeague(db, { teams: 14, seasons: 3 });
  const rep = runValidation(db, { minMatches: 200 });
  assert.notEqual(rep.status, 'VALIDATED', 'synthetische Daten mit kleinem Holdout');
  assert.ok(rep.metrics);
  const c = rep.metrics!.byCompetition[0];
  for (const m of ['1X2', 'OU', 'BTTS'] as const) {
    const x = c.markets![m]!;
    assert.ok(x.n > 0 && x.ensemble && x.baseline, m);
    assert.ok(x.ensemble!.brier > 0 && x.ensemble!.logLoss > 0);
    assert.ok(x.ece != null);
  }
  assert.ok(c.markets!['1X2']!.market, 'Markt zum Entscheidungszeitpunkt');
  assert.equal(c.markets!.BTTS!.market, null, 'keine BTTS-Quoten → kein Marktvergleich, nichts erfunden');
  for (const s of ['Log Loss', 'Brier', 'ECE', 'Je Liga und Markt', 'Basisrate', 'football-data.co.uk', 'NICHT GEKLÄRT']) assert.ok(rep.markdown.includes(s), s);
  assert.ok(db.get("SELECT 1 FROM diagnostic_runs WHERE kind = 'validation' AND id = ?", rep.id));
});

test('V3: Mock-Daten bleiben UNVALIDATED; Modellversionen sind unveränderlich', async () => {
  const app = await mockApp();
  await app.sync.run(ANCHOR);
  const rep = runValidation(app.db, { includeMock: true });
  assert.equal(rep.status, 'UNVALIDATED');
  assert.ok(rep.reasons.some(r => /Mock/.test(r)));
  assert.equal(rep.metrics!.betting, null, 'keine Rendite ohne Quoten zum Entscheidungszeitpunkt');
  const mv = app.db.get<{ id: string }>("SELECT id FROM model_versions WHERE id LIKE 'ensemble-1.1.0+bt%'")!;
  assert.throws(() => app.db.run("UPDATE model_versions SET validation_status = 'VALIDATED' WHERE id = ?", mv.id), /unveraenderlich/);
  assert.throws(() => app.db.run('DELETE FROM model_versions WHERE id = ?', mv.id), /unveraenderlich/);
});
