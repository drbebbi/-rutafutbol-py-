import crypto from 'node:crypto';

export const nowIso = (d: Date = new Date()): string => d.toISOString();
export const addMinutes = (d: Date, m: number): Date => new Date(d.getTime() + m * 60_000);
export const addHours = (d: Date, h: number): Date => new Date(d.getTime() + h * 3_600_000);
export const dayUtc = (d: Date = new Date()): string => d.toISOString().slice(0, 10);
export const minutesBetween = (a: string | Date, b: string | Date): number =>
  (new Date(b).getTime() - new Date(a).getTime()) / 60_000;

export function sha(s: string, len = 16): string {
  return crypto.createHash('sha256').update(s).digest('hex').slice(0, len);
}

/** Stabiler JSON-String (Schlüssel sortiert) für Hashes. */
export function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return '[' + v.map(stableStringify).join(',') + ']';
  const o = v as Record<string, unknown>;
  return '{' + Object.keys(o).sort().map(k => JSON.stringify(k) + ':' + stableStringify(o[k])).join(',') + '}';
}

export const sleep = (ms: number) => new Promise<void>(r => setTimeout(r, ms));
export const clamp = (x: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, x));
export const round = (x: number, d = 4) => Math.round(x * 10 ** d) / 10 ** d;

/** Lokale Zeit in einer IANA-Zeitzone als lesbarer String. */
export function fmtLocal(iso: string, tz: string, locale = 'es-PY'): string {
  return new Intl.DateTimeFormat(locale, { timeZone: tz, weekday: 'short', day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(iso));
}

/** Normalisiert Team-/Wettbewerbsnamen für das Matching. */
export function normName(s: string): string {
  let t = s.normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase();
  t = t.replace(/ø/g, 'o').replace(/æ/g, 'ae').replace(/ß/g, 'ss').replace(/&/g, ' and ');
  t = t.replace(/[^a-z0-9 ]+/g, ' ');
  const stop = new Set(['fc', 'cf', 'sc', 'ac', 'afc', 'cd', 'club', 'de', 'the', 'sk', 'fk', 'ss', 'ssc', 'as', 'us', 'rc', 'bk', 'if', 'sv', 'vfb', 'vfl', 'tsg', 'osc', 'losc', 'calcio', 'football', 'futbol', 'cp', 'ca', 'cs', 'kv', 'kaa', 'nk', 'hnk', 'gnk', 'fbc', 'ud', 'sd', 'rcd']);
  const words = t.split(/\s+/).filter(Boolean);
  const kept = words.filter(w => !stop.has(w));
  return (kept.length ? kept : words).join(' ').trim();
}

/** Ähnlichkeit 0..1 aus Token-Überlappung und Levenshtein. */
export function nameSimilarity(a: string, b: string): number {
  const na = normName(a), nb = normName(b);
  if (!na || !nb) return 0;
  if (na === nb) return 1;
  const ta = new Set(na.split(' ')), tb = new Set(nb.split(' '));
  const inter = [...ta].filter(x => tb.has(x)).length;
  const jacc = inter / new Set([...ta, ...tb]).size;
  const contains = na.includes(nb) || nb.includes(na) ? 0.85 : 0;
  const lev = 1 - levenshtein(na, nb) / Math.max(na.length, nb.length);
  return Math.max(jacc, contains, lev);
}

export function levenshtein(a: string, b: string): number {
  const m = a.length, n = b.length;
  if (!m) return n; if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}

export class AppError extends Error {
  constructor(public code: string, message: string, public httpStatus = 400) { super(message); }
}
