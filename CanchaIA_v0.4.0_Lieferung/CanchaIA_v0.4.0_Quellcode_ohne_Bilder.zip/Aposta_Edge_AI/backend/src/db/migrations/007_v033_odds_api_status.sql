-- v0.3.3 – The Odds API: Verbindungstests und vom Anbieter gemeldeter Verbrauch. Nur ergänzend, keine Datenänderung.

-- Vom Anbieter gemeldete verbrauchte Credits (Header x-requests-used)
ALTER TABLE provider_health ADD COLUMN quota_used INTEGER;

-- Ergebnis jedes Verbindungstests (kostenloser Endpunkt GET /v4/sports). Nie mit Schlüssel.
CREATE TABLE IF NOT EXISTS provider_connection_tests (
  id INTEGER PRIMARY KEY,
  provider TEXT NOT NULL,
  tested_at TEXT NOT NULL,
  ok INTEGER NOT NULL,                 -- 1 = authentifiziert und echte Sportdaten erhalten
  http_status INTEGER,                 -- NULL = kein Abruf (z. B. kein Schlüssel)
  error TEXT,                          -- bereinigt, ohne Schlüssel
  sports_total INTEGER,
  soccer_active INTEGER,
  target_sport_key TEXT,               -- z. B. soccer_uefa_champs_league
  target_sport_status TEXT,            -- ACTIVE | INACTIVE | UNKNOWN_KEY | NOT_CHECKED
  sport_keys_status TEXT,              -- JSON [{key,status}] der konfigurierten Sport-Keys
  requests_remaining INTEGER,          -- x-requests-remaining
  requests_used INTEGER,               -- x-requests-used
  requests_last INTEGER,               -- x-requests-last
  triggered_by TEXT                    -- admin:<userId> | cli
);
CREATE INDEX IF NOT EXISTS idx_conn_tests ON provider_connection_tests(provider, tested_at);
