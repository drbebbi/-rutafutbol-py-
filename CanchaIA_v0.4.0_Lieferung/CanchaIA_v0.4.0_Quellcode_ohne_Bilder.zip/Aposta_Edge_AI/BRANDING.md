# Marke CanchaIA (ab v0.3.2)

> ⚠️ **Rechtlich nicht bestätigt:** Die Verfügbarkeit des Namens **„CanchaIA“** sowie eine Markenregistrierung sind **noch nicht geprüft und nicht bestätigt**. Das gilt insbesondere für Paraguay (DINAPI – Dirección Nacional de Propiedad Intelectual, Klassen z. B. 9, 41, 42), für Domains (z. B. `canchaia.com`, `canchaia.com.py`) und für Social-Media-Handles. Vor einem öffentlichen Start ist eine Recherche/Anmeldung durch eine fachkundige Stelle nötig. Bis dahin ist „CanchaIA“ ein **Arbeitsname**.

## Vorgaben und Umsetzung

| Vorgabe | Umsetzung |
|---|---|
| Sichtbarer Name | **CanchaIA**: Wortmarke „Cancha“ + „IA“ in Akzent-Cyan (`BrandWord`) |
| Slogan | **Inteligencia Futbolística**: in Seitenleiste, Anmeldeseite, Seitentitel und Meta-Daten; in allen Sprachen spanisch (Markenbestandteil) |
| Standardsprache | Español (Paraguay): `<html lang="es-PY">`, Datums-/Zahlenformat `es-PY`, Auswahl „Español (Paraguay)“ |
| Preise | weiterhin Guaraní, immer paraguayisches Format (`79.000 Gs.`), unabhängig von der UI-Sprache |
| Zeitzone | `America/Asuncion` (Frontend-Standard, Backend-Standard und DB-Default unverändert) |
| Design | „Professional Analytics“ unverändert (Tokens, Farben, Typografie, Layout) |
| Logo / Favicon | neues Zeichen: Spielfeld von oben, Mittelkreis in Cyan (Analyse), grüner Strafraum (Vorteil/Value-Signal); `favicon.svg`, `apple-touch-icon.png` (180 px) |
| Seitentitel | `CanchaIA · Inteligencia Futbolística` (Start/Anmeldung), sonst `Seite · CanchaIA` |
| Navigation | „Edge AI“ / „EDGE ANALYST“ → **Analista IA** (es), **AI Analyst** (en), **KI-Analyst** (de) |
| Weitere Sprachen | Englisch und Deutsch bleiben vollständig verfügbar, internationale Ligen unverändert |

Einzige Quelle für Name, Slogan, Locale und Analyst-Namen: `frontend/src/brand.ts`.

## Bewusst NICHT geändert (technische Kennungen)

Diese Kennungen sind nicht öffentlich sichtbar, oder eine Änderung wäre nicht migrationssicher. Keine davon ist für das Rebranding zwingend:

| Kennung | Grund |
|---|---|
| Paketnamen `aposta-edge-ai*` | rein intern; Änderung bringt keinen Nutzen |
| DB-Pfad `aposta-edge.sqlite`, Docker-Volume `aposta-data`, Service `aposta-edge-ai` | Umbenennung würde bestehende Daten „verlieren“ (neue leere DB/neues Volume) |
| Session-Cookie `aea_session` | Umbenennung meldet alle Benutzer ab |
| Browser-Event `aea:unauthorized` | intern |
| Sprachcodes `'es' \| 'de' \| 'en'` | DB-CHECK-Constraint; „es“ wird als es-PY dargestellt |
| Zahlungsreferenz-Präfix `AEA-…` | **sichtbar** im Überweisungs-Verwendungszweck, aber Backend-Logik; bestehende Referenzen müssen gültig bleiben. Siehe offene Punkte |
| Migrationsdateien (`001_init.sql` u. a.) | angewendete Migrationen werden nie verändert |
| Interne Doku (BASE44_INTEGRATION.md u. a.) | beschreibt das technische Projekt; Projektname dort = technischer Name |

## Backend-Änderungen (nur Text, keine Funktion)

- `engines/analyst.ts`: Identitätszeile des KI-Prompts nennt jetzt „KI-Analyst (Analista IA) von CanchaIA“ statt „EDGE ANALYST … Aposta Edge AI“, damit ein angebundenes Sprachmodell nicht den alten Namen ausgibt; Spanisch wird als „Spanisch (Paraguay)“ präzisiert. Regeln, Werkzeuge und Zahlen unverändert. Im Regelmodus (ohne KI-Schlüssel) ohne Wirkung.
- `main.ts`: Startmeldung im Log.

Datenbank, API-Routen, Prognosemodelle, EV-Berechnung, Authentifizierung und Abonnements sind unverändert (121/121 Tests grün).

## Offene Punkte / Empfehlungen

1. **Rechtliche Prüfung** von Name und Marke (siehe Hinweis oben), bevor Logo und Name öffentlich genutzt werden.
2. **Lesbarkeit „IA“:** In serifenlosen Schriften kann „CanchaIA“ in Fließtext wie „CanchalA“ wirken. In der Wortmarke löst die Cyan-Hervorhebung von „IA“ das; in reinem Text (E-Mail, SMS) ggf. „Cancha IA“ oder „CanchaIA®“ prüfen.
3. **Zahlungsreferenz-Präfix:** Wenn gewünscht, später neues Präfix (z. B. `CAN-`) nur für neue Bestellungen einführen. Alte `AEA-`-Referenzen bleiben gültig. Das ist eine Backend-Änderung mit eigenem Test.
4. **Anrede:** Spanische Texte verwenden „tú“. Für Paraguay ist im Alltag Voseo („tocá“, „preguntá“) üblich; eine Umstellung wäre reine Textarbeit in `i18n.ts`.
5. **Domain und E-Mail-Absender** nach der Markenprüfung festlegen; Meta-Tags enthalten bewusst keine URL.
