/**
 * Zusammenbau der Anwendung: Datenbank, API-Queue, Provider-Auswahl, Dienste.
 */
import { effectiveSportKeys, type Config } from './config.js';
import { openDb, type Db } from './db/db.js';
import { ApiQueue, type Fetcher } from './api/apiQueue.js';
import { HighlightlyProvider } from './providers/highlightly.js';
import { TheOddsApiProvider } from './providers/theOddsApi.js';
import { MockProvider } from './providers/mock.js';
import { SyncService, type ProviderSet } from './engines/discovery.js';
import { noteMissing } from './util/log.js';
import { nowIso } from './util/core.js';
import { AuthService } from './auth.js';
import { log } from './util/log.js';
import { paidGateReason } from './engines/oddsApiStatus.js';

export interface App {
  cfg: Config; db: Db; queue: ApiQueue; providers: ProviderSet; sync: SyncService; mock: MockProvider | null;
  /** true nur mit dem echten Netzwerk-Fetcher. Mit eingespieltem Test-Fetcher kann nichts als LIVE VERIFIED gelten. */
  liveNetwork: boolean;
  /**
   * v0.3.3: Kostenpflichtige The-Odds-API-Abrufe erst nach bestandenem kostenlosem Verbindungstest.
   * Standard: an mit echtem Netzwerk (echte Credits), aus mit eingespieltem Test-Fetcher (keine Kosten).
   */
  requireOddsConnectionTest: boolean;
}

export function buildProviders(cfg: Config, db: Db, queue: ApiQueue, mockAnchor?: Date, paidGate?: () => string | null): { set: ProviderSet; mock: MockProvider | null } {
  const blocked: ProviderSet['blocked'] = [];
  const setHealth = (provider: string, status: string, err: string | null) => queue.setHealth(provider, status, err);
  if (cfg.dataMode === 'mock') {
    const m = new MockProvider(mockAnchor ?? new Date());
    queue.register({ provider: 'mock', dailyBudget: 1e9, maxConcurrent: 4, minIntervalMs: 0 });
    setHealth('mock', 'ok', null);
    if (cfg.highlightly.apiKey) setHealth('highlightly', 'disabled', 'DATA_MODE=mock');
    return { set: { fixtures: [m], odds: [m], isMock: true, blocked }, mock: m };
  }
  const fixtures: ProviderSet['fixtures'] = [], odds: ProviderSet['odds'] = [];
  queue.register({ provider: 'highlightly', dailyBudget: cfg.highlightly.dailyBudget, maxConcurrent: 2, minIntervalMs: 250, remainingHeader: 'x-ratelimit-requests-remaining', limitHeader: 'x-ratelimit-requests-limit' });
  if (!cfg.highlightly.apiKey) { blocked.push({ provider: 'highlightly', reason: 'HIGHLIGHTLY_API_KEY fehlt' }); setHealth('highlightly', 'disabled', 'kein API-Schlüssel'); }
  else if (!cfg.highlightly.bettingUseConfirmed) { blocked.push({ provider: 'highlightly', reason: 'Nutzungsrechte für Wettanalysen nicht bestätigt (HIGHLIGHTLY_BETTING_USE_CONFIRMED)' }); setHealth('highlightly', 'blocked', 'Nutzungsrechte für Wettanalysen nicht bestätigt'); }
  else {
    const hl = new HighlightlyProvider(queue, { apiKey: cfg.highlightly.apiKey, baseUrl: cfg.highlightly.baseUrl, rapidApiHost: cfg.highlightly.rapidApiHost, bettingUseConfirmed: true,
      onUnmappedMarket: (mk, sample) => noteMissing(db, 'unmapped_market', `highlightly:${mk}`, sample) });
    fixtures.push(hl); odds.push(hl);
  }
  queue.register({ provider: 'theoddsapi', dailyBudget: cfg.theOddsApi.dailyBudget, maxConcurrent: 1, minIntervalMs: 1000, remainingHeader: 'x-requests-remaining', usedHeader: 'x-requests-used', costHeader: 'x-requests-last', monthlyBudget: cfg.theOddsApi.monthlyBudget });
  if (cfg.theOddsApi.apiKey) {
    const oa = new TheOddsApiProvider(queue, {
      apiKey: cfg.theOddsApi.apiKey, baseUrl: cfg.theOddsApi.baseUrl, regions: cfg.theOddsApi.regions, sportKeys: effectiveSportKeys(cfg), pilot: cfg.pilot.enabled,
      includeBtts: cfg.theOddsApi.includeBtts, bttsMaxEventsPerRun: cfg.theOddsApi.bttsMaxEventsPerRun, bttsReservePct: cfg.theOddsApi.bttsReservePct,
      resultsEnabled: cfg.theOddsApi.resultsEnabled, oddsMaxAgeMinutes: cfg.analysis.oddsMaxAgeMinutes, paidGate,
    });
    odds.push(oa);
    if (!fixtures.length) fixtures.push(oa); // Ohne Highlightly: Spielplan aus The Odds API, Historie aus CSV-Import
  } else setHealth('theoddsapi', 'disabled', 'kein API-Schlüssel');
  return { set: { fixtures, odds, isMock: false, blocked }, mock: null };
}

export function buildApp(cfg: Config, opts: { fetcher?: Fetcher; mockAnchor?: Date; db?: Db; requireOddsConnectionTest?: boolean } = {}): App {
  const db = opts.db ?? openDb(cfg.dbPath);
  const queue = new ApiQueue(db, opts.fetcher);
  const requireOddsConnectionTest = opts.requireOddsConnectionTest ?? !opts.fetcher;
  // Spät gebunden: die Sperre liest den jeweils letzten Verbindungstest aus der DB
  let appRef: App | null = null;
  const paidGate = requireOddsConnectionTest ? () => (appRef ? paidGateReason(appRef) : 'App nicht initialisiert') : undefined;
  const { set, mock } = buildProviders(cfg, db, queue, opts.mockAnchor, paidGate);
  const sync = new SyncService(db, cfg, set);
  db.run(`INSERT INTO provider_health (provider, status, updated_at) VALUES ('app', 'ok', ?) ON CONFLICT(provider) DO UPDATE SET updated_at = excluded.updated_at`, nowIso());
  const boot = new AuthService(db, cfg.adminToken).bootstrapAdmin(cfg.adminEmail, cfg.adminPassword);
  if (boot === 'created') log.info(`Admin-Konto ${cfg.adminEmail} angelegt (ADMIN_PASSWORD kann jetzt aus der Umgebung entfernt werden).`);
  if (boot === 'missing') log.warn('Kein Admin-Konto vorhanden: ADMIN_EMAIL/ADMIN_PASSWORD setzen oder "npm run user:create -- <email> admin" ausführen.');
  appRef = { cfg, db, queue, providers: set, sync, mock, liveNetwork: !opts.fetcher, requireOddsConnectionTest };
  return appRef;
}

/** Mock-Modus: komplette Historie der Mock-Ligen laden (einmalig, idempotent). */
export async function seedMock(app: App): Promise<number> {
  if (!app.mock) return 0;
  const { EventMatchingEngine } = await import('./engines/matching.js');
  const { Repository } = await import('./engines/repository.js');
  const match = new EventMatchingEngine(app.db), repo = new Repository(app.db);
  const hist = await app.mock.allHistory();
  const created: { eventId: number; pid: string }[] = [];
  app.db.tx(() => {
    for (const f of hist) {
      const r = match.upsertFixture(f);
      if (r.method === 'created') created.push({ eventId: r.eventId, pid: f.providerEventId });
    }
  });
  // xG/Schüsse für die Hälfte der Spiele (realistische Datenlücken)
  for (const c of created) {
    if (Number(c.pid.split('-').pop()) % 2 !== 0) continue;
    const st = await app.mock.matchStatistics(c.pid);
    repo.saveMatchStats(c.eventId, 'mock', st, pid => repo.findTeamByProviderId('mock', pid));
  }
  return hist.length;
}
