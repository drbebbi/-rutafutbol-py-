/**
 * Dünne Datenbankschicht über dem in Node eingebauten SQLite (node:sqlite).
 * Keine externen Abhängigkeiten. WAL-Modus, Fremdschlüssel aktiv.
 */
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export type Param = string | number | bigint | null | Uint8Array;
export type Row = Record<string, any>;

export class Db {
  readonly raw: DatabaseSync;
  private txDepth = 0;

  constructor(file: string) {
    if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
    this.raw = new DatabaseSync(file);
    this.raw.exec('PRAGMA foreign_keys = ON;');
    if (file !== ':memory:') this.raw.exec('PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
  }

  run(sql: string, ...params: Param[]): { changes: number; lastInsertRowid: number } {
    const r = this.raw.prepare(sql).run(...params);
    return { changes: Number(r.changes), lastInsertRowid: Number(r.lastInsertRowid) };
  }
  get<T = Row>(sql: string, ...params: Param[]): T | undefined {
    return this.raw.prepare(sql).get(...params) as T | undefined;
  }
  all<T = Row>(sql: string, ...params: Param[]): T[] {
    return this.raw.prepare(sql).all(...params) as T[];
  }
  exec(sql: string): void { this.raw.exec(sql); }

  /** Verschachtelbare Transaktion (Savepoints). */
  tx<T>(fn: () => T): T {
    const sp = `sp_${this.txDepth}`;
    this.raw.exec(this.txDepth === 0 ? 'BEGIN IMMEDIATE' : `SAVEPOINT ${sp}`);
    this.txDepth++;
    try {
      const out = fn();
      this.txDepth--;
      this.raw.exec(this.txDepth === 0 ? 'COMMIT' : `RELEASE ${sp}`);
      return out;
    } catch (e) {
      this.txDepth--;
      this.raw.exec(this.txDepth === 0 ? 'ROLLBACK' : `ROLLBACK TO ${sp}; RELEASE ${sp}`);
      throw e;
    }
  }

  close(): void { this.raw.close(); }
}

function migrationsDir(): string {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [
    path.join(here, 'migrations'),                         // ts-Quelle
    path.resolve(here, '../../../src/db/migrations'),      // dist/src/db -> src/db/migrations
  ];
  for (const c of candidates) if (fs.existsSync(c) && fs.readdirSync(c).some(f => f.endsWith('.sql'))) return c;
  throw new Error('Migrationsverzeichnis nicht gefunden');
}

/** Führt alle noch nicht angewendeten SQL-Migrationen in Dateinamen-Reihenfolge aus. Idempotent. */
export function migrate(db: Db): string[] {
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)`);
  const dir = migrationsDir();
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  const applied: string[] = [];
  for (const f of files) {
    if (db.get('SELECT 1 FROM schema_migrations WHERE name = ?', f)) continue;
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    db.tx(() => {
      db.exec(sql);
      db.run('INSERT INTO schema_migrations (name, applied_at) VALUES (?, ?)', f, new Date().toISOString());
    });
    applied.push(f);
  }
  return applied;
}

export function openDb(file: string): Db {
  const db = new Db(file);
  migrate(db);
  return db;
}

export const json = {
  parse<T>(s: string | null | undefined, fallback: T): T {
    if (!s) return fallback;
    try { return JSON.parse(s) as T; } catch { return fallback; }
  },
};
