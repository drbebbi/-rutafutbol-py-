/**
 * v0.4.0 – Priorität 3: The Odds API – kostenlose Discovery, budgetgesteuerte Quoten, gebündelte Ergebnisse, Cache-Schlüssel.
 * Alle Provider-Antworten sind nach der offiziellen v4-Doku NACHGEBAUT (kein Netzwerk, kein echter Schlüssel).
 * Diese Tests ersetzen KEINEN Live-Test.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildApp, type App } from '../src/app.js';
import { ApiQueue } from '../src/api/apiQueue.js';
import { TheOddsApiProvider, hourWindow } from '../src/providers/theOddsApi.js';
import { oddsApiStatus, testOddsApiConnection, UCL_SPORT_KEY } from '../src/engines/oddsApiStatus.js';
import { Scheduler } from '../src/scheduler.js';
import { loadConfig } from '../src/config.js';
import { memDb, testConfig } from './helpers.js';
import { fakeFetcher, oddsEvent, scoresRow } from './fixtures/theOddsApiSamples.js';

const MIN = 60_000, H = 3_600_000;
const KEY = 'test-odds-key-NOT-REAL-p3';
const sports = () => [
  { key: 'soccer_epl', group: 'Soccer', title: 'EPL', active: true, has_outrights: false },
  { key: UCL_SPORT_KEY, group: 'Soccer', title: 'UEFA Champions League', active: true, has_outrights: false },
];
type Routes = Parameters<typeof fakeFetcher>[0];
function liveApp(routes: Routes, env: Record<string, string> = {}): { app: App; calls: string[] } {
  const f = fakeFetcher(routes);
  const app = buildApp(testConfig({ DATA_MODE: 'live', THE_ODDS_API_KEY: KEY, THE_ODDS_API_SPORT_KEYS: `soccer_epl,${UCL_SPORT_KEY}`, ...env }), { db: memDb(), fetcher: f.fetcher, requireOddsConnectionTest: true });
  return { app, calls: f.calls };
}
const path = (u: string) => new URL(u).pathname;

test('P3: Konfiguration – Discovery- und Quotenintervall getrennt, mit Mindestwerten', () => {
  const c = loadConfig({ THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES: '20', THE_ODDS_API_ODDS_INTERVAL_MINUTES: '120' } as NodeJS.ProcessEnv);
  assert.equal(c.theOddsApi.discoveryIntervalMinutes, 20);
  assert.equal(c.analysis.syncIntervalMinutes, 120);
  const d = loadConfig({ THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES: '1', THE_ODDS_API_ODDS_INTERVAL_MINUTES: '1' } as NodeJS.ProcessEnv);
  assert.equal(d.theOddsApi.discoveryIntervalMinutes, 10);
  assert.equal(d.analysis.syncIntervalMinutes, 15);
  assert.equal(loadConfig({ SYNC_INTERVAL_MINUTES: '90' } as NodeJS.ProcessEnv).analysis.syncIntervalMinutes, 90, 'Altname bleibt gültig');
});

test('P3: Discovery-Job ist kostenlos – nur /sports und /events, keine /odds- oder /scores-Abrufe, auch ohne Verbindungstest', async () => {
  const now = Date.now();
  const { app, calls } = liveApp((p) => {
    if (p === '/v4/sports') return { body: sports() };
    if (p.endsWith('/events')) return { body: [oddsEvent({ id: 'd1', sport: 'soccer_epl', title: 'EPL', home: 'Arsenal', away: 'Chelsea', kickoff: now + 20 * H, updatedAt: now })].map(({ bookmakers, ...e }) => e), headers: { 'x-requests-last': '0' } };
    return { body: [] };
  }, { THE_ODDS_API_DISCOVERY_INTERVAL_MINUTES: '15' });
  const sch = new Scheduler(app);
  const jobs = sch.status(new Date(now));
  assert.equal(jobs.find(j => j.name === 'discovery')!.intervalMin, 15);
  assert.equal(jobs.find(j => j.name === 'hourly_sync')!.intervalMin, 60);
  const r = await sch.runJob('discovery', new Date(now));
  assert.equal(r.started, true, r.error);
  assert.ok(calls.length > 0);
  assert.ok(calls.every(u => /\/v4\/sports(\/[^/]+\/events)?$/.test(path(u))), calls.map(path).join(', '));
  assert.equal(app.queue.usedThisMonth('theoddsapi'), 0, '0 Credits');
  assert.equal((r.result as { newEvents: number }).newEvents, 1);
  assert.ok(app.db.get("SELECT 1 FROM event_mappings WHERE provider = 'theoddsapi' AND provider_event_id = 'd1'"));
});

test('P3: Cache-Schlüssel mit wechselnden Zeitfenstern – zwei Spielsuchen im Abstand von 2 min nutzen denselben Cache', async () => {
  const db = memDb(); let clock = new Date('2026-10-12T12:01:00Z'); const urls: string[] = [];
  const q = new ApiQueue(db, async (url) => { urls.push(url); return { status: 200, headers: { get: () => null }, text: async () => '[]' }; }, () => clock, 0.001);
  q.register({ provider: 'theoddsapi', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0 });
  const p = new TheOddsApiProvider(q, { apiKey: 'k', baseUrl: 'https://api.the-odds-api.com', regions: 'eu', sportKeys: ['soccer_epl'] });
  await p.upcomingFixtures(new Date(clock.getTime() + 5 * MIN), new Date(clock.getTime() + 48 * H));
  clock = new Date('2026-10-12T12:03:00Z');
  await p.upcomingFixtures(new Date(clock.getTime() + 5 * MIN), new Date(clock.getTime() + 48 * H));
  assert.equal(urls.length, 1, 'zweiter Aufruf aus dem Cache (vorher sekundengenaues Fenster → immer neuer Schlüssel)');
  const w = hourWindow(new Date('2026-10-12T12:08:00Z'), new Date('2026-10-14T12:03:00Z'));
  assert.equal(w.from.toISOString(), '2026-10-12T12:00:00.000Z');
  assert.equal(w.to.toISOString(), '2026-10-14T13:00:00.000Z');
  assert.equal(db.get<{ n: number }>('SELECT COUNT(*) AS n FROM api_cache')!.n, 1, 'kein Anwachsen des Caches mit neuen Schlüsseln');
});

test('P3: lastEvents – begonnene oder außerhalb des Fensters liegende Spiele aus (gecachten) Quotenantworten werden verworfen', async () => {
  const db = memDb(); const clock = new Date('2026-10-12T12:00:00Z');
  const t = clock.getTime();
  const body = [
    oddsEvent({ id: 'ok', sport: 'soccer_epl', title: 'EPL', home: 'A', away: 'B', kickoff: t + 5 * H, updatedAt: t - MIN }),
    oddsEvent({ id: 'started', sport: 'soccer_epl', title: 'EPL', home: 'C', away: 'D', kickoff: t - 30 * MIN, updatedAt: t - MIN }),
    oddsEvent({ id: 'far', sport: 'soccer_epl', title: 'EPL', home: 'E', away: 'F', kickoff: t + 30 * H, updatedAt: t - MIN }),
  ];
  const q = new ApiQueue(db, async () => ({ status: 200, headers: { get: (n: string) => n === 'x-requests-last' ? '2' : null }, text: async () => JSON.stringify(body) }), () => clock, 0.001);
  q.register({ provider: 'theoddsapi', dailyBudget: 100, maxConcurrent: 1, minIntervalMs: 0, costHeader: 'x-requests-last' });
  const p = new TheOddsApiProvider(q, { apiKey: 'k', baseUrl: 'https://api.the-odds-api.com', regions: 'eu', sportKeys: ['soccer_epl'] });
  // Fremd-Provider-Fixture → alle Spiele der Antwort kämen in Frage (Fuzzy-Matching erst danach)
  // v0.4.1: mit Sport-Key, wie ihn fixturesForEvents() jetzt aus der DB liefert (ohne Zuordnung gäbe es gar keinen Abruf)
  const qs = await p.oddsForFixtures([{ provider: 'highlightly', providerEventId: 'x', competition: { providerId: 'soccer_epl', name: 'EPL' }, home: { providerId: '', name: 'A' }, away: { providerId: '', name: 'B' }, kickoffUtc: new Date(t + 5 * H).toISOString(), status: 'scheduled' }]);
  assert.deepEqual([...new Set(qs.map(x => x.providerEventId))], ['ok']);
});

test('P3: Ergebnisse gebündelt – ein /scores-Abruf je Wettbewerb mit offenen Spielen, keiner für ältere oder fremde Wettbewerbe', async () => {
  const now = Date.now();
  const ev = (id: string, k: number) => ({ id, sport_key: 'soccer_epl', commence_time: new Date(k).toISOString(), home_team: 'H' + id, away_team: 'A' + id });
  const recent1 = ev('r1', now - 5 * H), recent2 = ev('r2', now - 6 * H), old = ev('o1', now - 5 * 86_400_000);
  const { app, calls } = liveApp((p) => {
    if (p === '/v4/sports') return { body: sports() };
    if (p === '/v4/sports/soccer_epl/scores') return { body: [scoresRow(recent1, 2, 1, true), scoresRow(recent2, 0, 0, true)], headers: { 'x-requests-last': '2' } };
    if (p.endsWith('/events')) return { body: [] };
    if (p.endsWith('/odds')) return { body: [] };
    return null;
  });
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  // drei offene Spiele (zwei innerhalb von 3 Tagen) im Wettbewerb soccer_epl
  for (const e of [recent1, recent2, old]) {
    app.db.run('INSERT OR IGNORE INTO competitions (id, name, is_mock) VALUES (900, \'EPL\', 0)');
    app.db.run("INSERT OR IGNORE INTO competition_aliases (competition_id, provider, provider_id, alias_name) VALUES (900, 'theoddsapi', 'soccer_epl', 'EPL')");
    const h = Number(app.db.run('INSERT INTO teams (name, norm_name) VALUES (?, ?)', e.home_team, e.home_team.toLowerCase()).lastInsertRowid);
    const a = Number(app.db.run('INSERT INTO teams (name, norm_name) VALUES (?, ?)', e.away_team, e.away_team.toLowerCase()).lastInsertRowid);
    const id = Number(app.db.run("INSERT INTO events (competition_id, home_team_id, away_team_id, kickoff_utc, status) VALUES (900, ?, ?, ?, 'scheduled')", h, a, e.commence_time).lastInsertRowid);
    app.db.run("INSERT INTO provider_events (provider, provider_event_id, raw_home, raw_away, raw_competition, kickoff_utc, fetched_at) VALUES ('theoddsapi', ?, ?, ?, 'EPL', ?, ?)", e.id, e.home_team, e.away_team, e.commence_time, new Date().toISOString());
    app.db.run("INSERT INTO event_mappings (event_id, provider, provider_event_id, confidence, method) VALUES (?, 'theoddsapi', ?, 1, 'test')", id, e.id);
  }
  const s = await app.sync.run(new Date(now));
  const scoreCalls = calls.filter(u => path(u).endsWith('/scores'));
  assert.equal(scoreCalls.length, 1, `genau ein gebündelter Abruf: ${scoreCalls.map(path).join(', ')} · ${s.errors.join(' | ')}`);
  assert.equal(path(scoreCalls[0]), '/v4/sports/soccer_epl/scores');
  const st = app.db.all<{ status: string; home_goals: number | null }>("SELECT e.status, e.home_goals FROM events e WHERE e.competition_id = 900 ORDER BY kickoff_utc DESC");
  assert.deepEqual(st.map(x => x.status), ['finished', 'finished', 'scheduled'], 'Ergebnisse übernommen; >3 Tage altes Spiel ohne Abruf');
});

test('P3: Verbindungstest belegt keine Quoten/Prognosen; Admin-Status zeigt Belege, letzten HTTP-Status und Zeitplan getrennt', async () => {
  const now = Date.now();
  const { app } = liveApp((p) => p === '/v4/sports' ? { body: sports(), headers: { 'x-requests-remaining': '500', 'x-requests-used': '0', 'x-requests-last': '0' } } : null);
  await testOddsApiConnection(app, { triggeredBy: 'test' });
  const sch = new Scheduler(app);
  const st = oddsApiStatus(app, new Date(now), sch.status(new Date(now)));
  assert.equal(st.connection, 'CONNECTED');
  assert.equal(st.verification.connection.verified, true);
  assert.equal(st.verification.odds.verified, false, 'kostenloser Test ist KEIN Quoten-Nachweis');
  assert.equal(st.verification.predictions.verified, false);
  assert.match(st.verification.odds.note, /NOT VERIFIED/);
  assert.match(st.verification.connection.note, /KEINE Quoten/);
  assert.equal(st.lastHttp!.endpoint, '/v4/sports'); assert.equal(st.lastHttp!.status, 200); assert.equal(st.lastHttp!.costCredits, 0);
  assert.ok(st.schedule?.discovery && st.schedule.odds, 'nächste geplante Läufe');
  assert.equal(st.schedule!.odds!.intervalMin, 60);
  assert.equal(st.lastSuccessfulFetchAt, null, 'kein erfolgreicher Quotenabruf');
});
