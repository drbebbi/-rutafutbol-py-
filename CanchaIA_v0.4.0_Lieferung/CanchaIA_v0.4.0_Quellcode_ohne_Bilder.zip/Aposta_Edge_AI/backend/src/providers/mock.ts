/**
 * Geschützter Entwicklungsmodus: deterministische, klar als MOCK gekennzeichnete Daten.
 * Fiktive Ligen, Teams und Buchmacher. Ergebnisse werden aus verborgenen Teamstärken simuliert,
 * Quoten aus den wahren Wahrscheinlichkeiten plus Marge und Rauschen. Einzelne Buchmacher setzen
 * gelegentlich fehlerhafte Preise, damit die Value-Engine Ende-zu-Ende testbar ist.
 * Nichts davon ist echte Performance und darf nie so dargestellt werden.
 */
import type { FootballDataProvider, OddsProvider, ProviderCapabilities, ProviderCompetition, ProviderFixture, ProviderLineup, ProviderMatchStat, ProviderOddsQuote, SelectionId } from './types.js';
import { sha } from '../util/core.js';
import { scoreMatrix, marketsFromMatrix } from '../engines/prediction/poisson.js';

export function rng(seed: string): () => number {
  let a = parseInt(sha(seed, 8), 16) >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function poissonSample(lambda: number, r: () => number): number {
  const L = Math.exp(-lambda); let k = 0, p = 1;
  do { k++; p *= r(); } while (p > L);
  return k - 1;
}

const LEAGUES = [
  { id: 'm-py', name: 'Liga Mock Paraguay', cc: 'PY', country: 'Paraguay', teams: ['Club Ribera', 'Sportivo Lambaré Norte', 'Atlético Ypacaraí', 'Deportivo Itauguá', 'Unión Capiatá', 'Club Mariscal', 'General Areguá', 'Sol del Chaco', 'Fernando Mora FC', 'Club Tacumbú', 'Libertad Sur', 'Rubio Ñu Mock'] },
  { id: 'm-eu', name: 'Mock Premier Division', cc: 'GB', country: 'England', teams: ['Northbridge Albion', 'Kingsport City', 'Ashford Rovers', 'Millbrook United', 'Harwick Town', 'Eastvale Athletic', 'Redcliffe FC', 'Stonegate Wanderers', 'Brookhaven City', 'Westmoor Rangers', 'Ironside United', 'Fairhaven Town'] },
  { id: 'm-sa', name: 'Mock Primera Sudamericana', cc: 'AR', country: 'Argentina', teams: ['Atlético Pampa', 'Club Riachuelo', 'Defensores del Plata', 'Estudiantes del Sur', 'Unión Cordillera', 'Racing Andino', 'Independiente Norte', 'Talleres Mock', 'Gimnasia Litoral', 'Huracán Patagonia', 'Belgrano Serrano', 'Colón Mock'] },
  { id: 'm-as', name: 'Mock J1 League', cc: 'JP', country: 'Japan', teams: ['Kawa Sakura', 'Hoshi United', 'Minato FC', 'Yama Thunder', 'Kaze Rovers', 'Tsuru City', 'Umi Marines', 'Kita Blaze', 'Shiro Phoenix', 'Mori Antlers', 'Sora Gamba', 'Taka Reysol'] },
];
export const MOCK_BOOKS = [
  { id: 'mock-sharp', name: 'MockSharp (MOCK)', margin: 0.025, noise: 0.01, sharp: true },
  { id: 'mock-a', name: 'MockBet A (MOCK)', margin: 0.06, noise: 0.03, sharp: false },
  { id: 'mock-b', name: 'MockBet B (MOCK)', margin: 0.07, noise: 0.035, sharp: false },
  { id: 'mock-c', name: 'MockBet C (MOCK)', margin: 0.05, noise: 0.05, sharp: false },
];

interface MockMatch { fx: ProviderFixture; lh: number; la: number }

export class MockProvider implements FootballDataProvider, OddsProvider {
  readonly name = 'mock';
  readonly sharesEventIdsWith = 'mock';
  readonly capabilities: ProviderCapabilities = { fixtures: true, history: true, teamStats: true, standings: true, lineups: true, matchStats: true, injuries: false, odds: true, liveScores: true };
  private matches: MockMatch[] = [];
  private strength = new Map<string, { att: number; def: number }>();
  private clock: Date | null = null;
  setNow(now: Date): void { this.clock = now; }

  /** anchor: Referenzzeitpunkt (Default: jetzt). Die Liga-Saison wird relativ dazu erzeugt. */
  constructor(private anchor: Date = new Date()) { this.build(); }

  private build() {
    const day0 = new Date(Date.UTC(this.anchor.getUTCFullYear(), this.anchor.getUTCMonth(), this.anchor.getUTCDate()));
    for (const L of LEAGUES) {
      const r = rng('strength:' + L.id);
      L.teams.forEach((t, i) => this.strength.set(`${L.id}:${i}`, { att: 0.75 + r() * 0.6, def: 0.75 + r() * 0.6 }));
      const n = L.teams.length;
      // Doppelrunde (Kreismethode): 2*(n-1) Spieltage je Saison, zwei Saisons
      const rounds: [number, number][][] = [];
      const idx = [...Array(n).keys()];
      for (let rd = 0; rd < n - 1; rd++) {
        const pairs: [number, number][] = [];
        for (let k = 0; k < n / 2; k++) { const a = idx[k], b = idx[n - 1 - k]; pairs.push(rd % 2 ? [b, a] : [a, b]); }
        rounds.push(pairs);
        idx.splice(1, 0, idx.pop()!);
      }
      const all = [...rounds, ...rounds.map(p => p.map(([a, b]) => [b, a] as [number, number]))];
      const li = LEAGUES.indexOf(L);
      const anchorHour = Math.floor(this.anchor.getTime() / 3_600_000) * 3_600_000;
      // 2 Saisons * 22 Spieltage im 4-Tage-Rhythmus; die letzten drei Spieltage liegen in der Zukunft
      const totalRounds = all.length * 2;
      const playedRounds = totalRounds - 3;
      for (let g = 0; g < totalRounds; g++) {
        const season = g < all.length ? '2025' : '2026';
        all[g % all.length].forEach(([h, a], k) => {
          const kickoff = g < playedRounds
            ? new Date(day0.getTime() + ((g - playedRounds) * 4 - 1) * 86_400_000 + (14 + li * 2 + (k % 3) * 2) * 3_600_000)
            : new Date(anchorHour + (4 + li * 9 + (k % 3) * 2) * 3_600_000 + (g - playedRounds) * 96 * 3_600_000);
          const sh = this.strength.get(`${L.id}:${h}`)!, sa = this.strength.get(`${L.id}:${a}`)!;
          const lh = 1.45 * sh.att / sa.def * 1.0, la = 1.15 * sa.att / sh.def;
          const id = `${L.id}-${season}-${g}-${k}`;
          const finished = kickoff.getTime() < this.anchor.getTime() - 2 * 3_600_000;
          const rr = rng('score:' + id);
          const hg = finished ? poissonSample(lh, rr) : null, ag = finished ? poissonSample(la, rr) : null;
          this.matches.push({ lh, la, fx: {
            provider: 'mock', providerEventId: id, isMock: true,
            competition: { providerId: L.id, name: L.name, countryCode: L.cc, countryName: L.country, season },
            round: `Fecha ${(g % all.length) + 1}`,
            home: { providerId: `${L.id}:${h}`, name: L.teams[h], type: 'club', countryCode: L.cc },
            away: { providerId: `${L.id}:${a}`, name: L.teams[a], type: 'club', countryCode: L.cc },
            kickoffUtc: kickoff.toISOString(), status: finished ? 'finished' : 'scheduled', homeGoals: hg, awayGoals: ag,
            venue: `Estadio ${L.teams[h]}`,
          } });
        });
      }
    }
  }

  async upcomingFixtures(fromUtc: Date, toUtc: Date): Promise<ProviderFixture[]> {
    return this.matches.map(m => m.fx).filter(f => f.status === 'scheduled' && new Date(f.kickoffUtc) >= fromUtc && new Date(f.kickoffUtc) <= toUtc);
  }
  async historicalResults(c: ProviderCompetition, season: string | null): Promise<ProviderFixture[]> {
    return this.matches.map(m => m.fx).filter(f => f.competition.providerId === c.providerId && f.status === 'finished' && (!season || f.competition.season === season));
  }
  async allHistory(): Promise<ProviderFixture[]> { return this.matches.map(m => m.fx).filter(f => f.status === 'finished'); }
  async lastGames(team: string): Promise<ProviderFixture[]> {
    return this.matches.map(m => m.fx).filter(f => f.status === 'finished' && (f.home.providerId === team || f.away.providerId === team))
      .sort((a, b) => b.kickoffUtc.localeCompare(a.kickoffUtc)).slice(0, 5);
  }
  async matchDetails(id: string): Promise<ProviderFixture | null> { return this.matches.find(m => m.fx.providerEventId === id)?.fx ?? null; }
  async matchStatistics(id: string): Promise<ProviderMatchStat[]> {
    const m = this.matches.find(x => x.fx.providerEventId === id);
    if (!m || m.fx.status !== 'finished') return [];
    const r = rng('stats:' + id);
    const xgH = Math.max(0.1, m.lh * (0.8 + r() * 0.4)), xgA = Math.max(0.1, m.la * (0.8 + r() * 0.4));
    return [
      { teamProviderId: m.fx.home.providerId, key: 'xg', value: +xgH.toFixed(2) },
      { teamProviderId: m.fx.away.providerId, key: 'xg', value: +xgA.toFixed(2) },
      { teamProviderId: m.fx.home.providerId, key: 'shots', value: Math.round(xgH * 9 + r() * 4) },
      { teamProviderId: m.fx.away.providerId, key: 'shots', value: Math.round(xgA * 9 + r() * 4) },
    ];
  }
  async lineups(id: string): Promise<ProviderLineup[]> {
    const m = this.matches.find(x => x.fx.providerEventId === id);
    if (!m) return [];
    const hoursTo = (new Date(m.fx.kickoffUtc).getTime() - this.anchor.getTime()) / 3_600_000;
    if (hoursTo > 24) return [];
    const status = hoursTo < 1 ? 'confirmed' as const : 'expected' as const;
    return [m.fx.home, m.fx.away].map(t => ({
      teamProviderId: t.providerId, status, formation: '4-3-3',
      players: Array.from({ length: 11 }, (_, i) => ({ name: `${t.name} #${i + 1}`, number: i + 1, position: i === 0 ? 'Goalkeeper' : i < 5 ? 'Defender' : i < 8 ? 'Midfielder' : 'Forward', starter: true })),
    }));
  }

  async bookmakers() { return MOCK_BOOKS.map(b => ({ providerId: b.id, name: b.name })); }

  async oddsForFixtures(fixtures: ProviderFixture[]): Promise<ProviderOddsQuote[]> {
    const out: ProviderOddsQuote[] = [];
    // Simulierter Abrufzeitpunkt = aktuelle (ggf. simulierte) Uhr, auf 10 min gerundet → reproduzierbare Snapshots
    const nowMs = (this.clock ?? new Date()).getTime();
    const retrievedAt = new Date(Math.floor(nowMs / 600_000) * 600_000).toISOString();
    for (const f of fixtures) {
      const m = this.matches.find(x => x.fx.providerEventId === f.providerEventId);
      if (!m || m.fx.status !== 'scheduled') continue;
      const truth = marketsFromMatrix(scoreMatrix(m.lh, m.la, 10, -0.08));
      for (const b of MOCK_BOOKS) {
        const r = rng(`odds:${b.id}:${f.providerEventId}`);
        const priced = (sels: [SelectionId, number][], allowError: boolean) => {
          const noisy = sels.map(([s, p]) => [s, Math.max(0.01, p * (1 + (r() - 0.5) * 2 * b.noise))] as [SelectionId, number]);
          const sum = noisy.reduce((a, [, p]) => a + p, 0);
          const prices: Partial<Record<SelectionId, number>> = {};
          for (const [s, p] of noisy) {
            let o = 1 / ((p / sum) * (1 + b.margin));
            if (allowError && b.id === 'mock-c' && r() < 0.12) o *= 1.12; // gelegentliche Fehlbepreisung
            prices[s] = Math.max(1.01, Math.round(o * 100) / 100);
          }
          return prices;
        };
        const common = { provider: 'mock', providerEventId: f.providerEventId, bookmakerProviderId: b.id, bookmakerName: b.name, marketStatus: 'open' as const, retrievedAt, sourceTimestamp: retrievedAt, snapshotKind: 'live' as const };
        out.push({ ...common, market: '1X2', line: null, prices: priced([['HOME', truth['1X2'].HOME], ['DRAW', truth['1X2'].DRAW], ['AWAY', truth['1X2'].AWAY]], true) });
        out.push({ ...common, market: 'OU', line: 2.5, prices: priced([['OVER', truth.OU.OVER], ['UNDER', truth.OU.UNDER]], true) });
        if (b.id !== 'mock-b') out.push({ ...common, market: 'BTTS', line: null, prices: priced([['YES', truth.BTTS.YES], ['NO', truth.BTTS.NO]], true) });
      }
    }
    return out;
  }
}
