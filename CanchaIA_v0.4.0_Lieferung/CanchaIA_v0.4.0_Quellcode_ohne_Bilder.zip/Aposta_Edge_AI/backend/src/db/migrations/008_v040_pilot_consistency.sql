-- v0.4.0 – Konsistenz für den kontrollierten Pilotbetrieb. Nur ergänzend: keine bestehenden Daten werden geändert oder gelöscht.

-- Signatur aller Berechnungswerte eines Signals (Prognose, Quote, Marktreferenz, EV, Konfiguration).
-- Alte Zeilen behalten NULL: beim nächsten Lauf entsteht genau eine neue Version mit Signatur.
ALTER TABLE value_signals ADD COLUMN calc_signature TEXT;

-- Validierungsstatus je Wettbewerb × Markt einer Modellversion (append-only, wie model_versions).
-- Live gilt ein Markt eines Wettbewerbs nur dann als validiert, wenn hier ein VALIDATED-Eintrag existiert.
CREATE TABLE IF NOT EXISTS model_scope_validations (
  id INTEGER PRIMARY KEY,
  model_version_id TEXT NOT NULL REFERENCES model_versions(id),
  backtest_run_id INTEGER,
  competition_id INTEGER NOT NULL REFERENCES competitions(id),
  market_id TEXT NOT NULL,                 -- 1X2 | OU | BTTS
  status TEXT NOT NULL,                    -- VALIDATED | UNVALIDATED | FAILED
  market_evidence TEXT NOT NULL,           -- BETTER | NOT_WORSE | WORSE | NOT_TESTABLE
  holdout_n INTEGER NOT NULL,
  market_n INTEGER NOT NULL,
  blend_weight REAL,
  odds_times_estimated INTEGER NOT NULL DEFAULT 0,
  reasons TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (model_version_id, competition_id, market_id)
);
CREATE INDEX IF NOT EXISTS idx_scope_val ON model_scope_validations(competition_id, market_id, status);
CREATE TRIGGER IF NOT EXISTS model_scope_validations_immutable BEFORE UPDATE ON model_scope_validations
BEGIN SELECT RAISE(ABORT, 'model_scope_validations sind unveraenderlich'); END;
CREATE TRIGGER IF NOT EXISTS model_scope_validations_no_delete BEFORE DELETE ON model_scope_validations
BEGIN SELECT RAISE(ABORT, 'model_scope_validations sind unveraenderlich'); END;
