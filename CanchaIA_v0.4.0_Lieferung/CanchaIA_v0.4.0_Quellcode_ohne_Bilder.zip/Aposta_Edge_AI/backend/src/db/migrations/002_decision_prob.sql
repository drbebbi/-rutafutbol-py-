-- Entscheidungswahrscheinlichkeit = w · Modell + (1 − w) · fairer Marktpreis (scharfer Buchmacher oder Median).
-- model_prob bleibt die unabhängige Modellwahrscheinlichkeit.
ALTER TABLE value_signals ADD COLUMN decision_prob REAL;
ALTER TABLE value_signals ADD COLUMN model_weight REAL;
ALTER TABLE prediction_outcomes ADD COLUMN decision_prob REAL;
ALTER TABLE user_settings ADD COLUMN model_weight REAL;
