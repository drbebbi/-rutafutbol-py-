import { LOCALE } from './brand';
/**
 * API-Zugriff mit Session-Cookie (HttpOnly, vom Server gesetzt). Im Browser wird KEIN Token gespeichert.
 * Das CSRF-Token liegt nur im Arbeitsspeicher und wird bei schreibenden Anfragen mitgeschickt.
 */
let csrf: string | null = null;
export function setCsrf(t: string | null) { csrf = t; }

export class HttpError extends Error { constructor(public status: number, message: string, public code?: string) { super(message); } }

export async function api<T = any>(path: string, init: RequestInit = {}): Promise<T> {
  const writing = ['POST', 'PUT', 'DELETE'].includes((init.method ?? 'GET').toUpperCase());
  const r = await fetch(path, { ...init, credentials: 'same-origin', headers: { 'content-type': 'application/json', ...(writing && csrf ? { 'x-csrf-token': csrf } : {}), ...(init.headers ?? {}) } });
  const body = await r.json().catch(() => ({}));
  if (!r.ok) {
    if (r.status === 401) window.dispatchEvent(new Event('aea:unauthorized'));
    throw new HttpError(r.status, body?.message ?? `HTTP ${r.status}`, body?.error);
  }
  return body as T;
}

export const pct = (x: number | null | undefined, d = 1) => x == null || !Number.isFinite(x) ? '–' : `${(x * 100).toFixed(d)} %`;
export const fx = (x: number | null | undefined, d = 2) => x == null || !Number.isFinite(x) ? '–' : x.toFixed(d);
export const signed = (x: number | null | undefined, d = 1) => x == null ? '–' : `${x >= 0 ? '+' : ''}${(x * 100).toFixed(d)} %`;
export function localTime(iso: string, tz: string, lang: string, withDay = true) {
  const loc = LOCALE[lang as keyof typeof LOCALE] ?? LOCALE.es;
  return new Intl.DateTimeFormat(loc, { timeZone: tz, ...(withDay ? { weekday: 'short', day: '2-digit', month: '2-digit' } : {}), hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date(iso));
}
/** "vor 12 min" / "hace 12 min" / "12 min ago" */
export function ago(iso: string | null | undefined, lang: string, now = Date.now()): string {
  if (!iso) return '–';
  const m = Math.round((now - new Date(iso).getTime()) / 60_000);
  const v = m < 120 ? `${m} min` : `${Math.round(m / 60)} h`;
  return lang === 'de' ? `vor ${v}` : lang === 'en' ? `${v} ago` : `hace ${v}`;
}
