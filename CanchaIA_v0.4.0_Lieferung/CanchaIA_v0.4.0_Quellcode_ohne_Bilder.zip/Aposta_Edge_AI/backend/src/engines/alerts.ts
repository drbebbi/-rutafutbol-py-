/**
 * AlertEngine: Benachrichtigungen bei relevanten Änderungen, ohne Wiederholungen.
 * Kanäle: In-App (immer), Telegram und Webhook (optional per Konfiguration).
 */
import type { Db } from '../db/db.js';
import type { Config } from '../config.js';
import type { StoredSignal } from './value.js';
import { QUALIFIED } from './value.js';
import { fmtLocal, nowIso } from '../util/core.js';
import { logError } from '../util/log.js';

export interface AlertDraft { kind: 'new_value' | 'odds_change' | 'ev_change' | 'removed' | 'data_change' | 'system'; dedupeKey: string; title: string; body: string;
  /** v0.3.0: für persönliche Filter (Mindest-EV) */ ev?: number | null; eventId?: number }

const SEL_LABEL: Record<string, string> = { HOME: '1', DRAW: 'X', AWAY: '2', OVER: 'Más de 2,5', UNDER: 'Menos de 2,5', YES: 'Ambos marcan: Sí', NO: 'Ambos marcan: No' };

export class AlertEngine {
  constructor(private db: Db, private cfg: Config, private send: (url: string, body: unknown) => Promise<void> = postJson) {}

  private settings() {
    // Systemweite Benachrichtigungen folgen den Einstellungen des ersten aktiven Admins (Fallback: Systemkonto)
    return this.db.get<{ notify_new_value: number; notify_odds_change: number; notify_removed: number; timezone: string }>(
      `SELECT notify_new_value, notify_odds_change, notify_removed, timezone FROM user_settings WHERE user_id = COALESCE((SELECT id FROM users WHERE role = 'admin' AND active = 1 ORDER BY id LIMIT 1), 1)`)
      ?? { notify_new_value: 1, notify_odds_change: 1, notify_removed: 1, timezone: this.cfg.timezone };
  }

  private describe(s: StoredSignal): string {
    const e = this.db.get<{ home: string; away: string; kickoff_utc: string; comp: string; is_mock: number }>(`SELECT th.name AS home, ta.name AS away, e.kickoff_utc, c.name AS comp, e.is_mock FROM events e
      JOIN teams th ON th.id = e.home_team_id JOIN teams ta ON ta.id = e.away_team_id JOIN competitions c ON c.id = e.competition_id WHERE e.id = ?`, s.event_id)!;
    const book = this.db.get<{ name: string }>('SELECT name FROM bookmakers WHERE id = ?', s.best_bookmaker_id ?? '')?.name ?? '–';
    return `${e.is_mock ? '[MOCK] ' : ''}${e.home} – ${e.away} (${e.comp}, ${fmtLocal(e.kickoff_utc, this.settings().timezone)})\n${s.market_id}: ${SEL_LABEL[s.selection_id] ?? s.selection_id} @ ${s.best_odds?.toFixed(2) ?? '–'} (${book})\nEV ${pct(s.ev)} · EV mín. ${pct(s.ev_low)} · Calidad ${s.quality_score}`;
  }

  /** Erzeugt Entwürfe aus Signal-Änderungen (systemweite Meldungen, Einstellungen des ersten Admins – unverändert seit v0.2.0). */
  draft(changes: { prev: StoredSignal | null; next: StoredSignal }[]): AlertDraft[] { return this.build(changes, this.settings()); }

  /** v0.3.0: dieselbe Event-Erkennung ohne Systemfilter – Grundlage für persönliche Meldungen. */
  detect(changes: { prev: StoredSignal | null; next: StoredSignal }[]): AlertDraft[] {
    return this.build(changes, { notify_new_value: 1, notify_odds_change: 1, notify_removed: 1 });
  }

  private build(changes: { prev: StoredSignal | null; next: StoredSignal }[], st: { notify_new_value: number; notify_odds_change: number; notify_removed: number }): AlertDraft[] {
    const out: AlertDraft[] = [];
    for (const { prev, next } of changes) {
      const wasQ = !!prev && QUALIFIED.includes(prev.status), isQ = QUALIFIED.includes(next.status);
      const id = `${next.event_id}:${next.market_id}:${next.selection_id}:${next.line ?? ''}`;
      if (isQ && !wasQ && st.notify_new_value) out.push({ kind: 'new_value', dedupeKey: `new:${id}:${next.status}:${next.best_odds?.toFixed(2)}`, title: `${next.status === 'STRONG_VALUE' ? 'STRONG VALUE' : 'Nueva value bet'}`, body: this.describe(next), ev: next.ev, eventId: next.event_id });
      else if (wasQ && !isQ && st.notify_removed) out.push({ kind: 'removed', dedupeKey: `rm:${id}:${prev!.id}`, title: 'Value bet retirada', body: `${this.describe(next)}\nMotivo: ${JSON.parse(next.reasons).slice(-1)[0] ?? next.status}`, ev: next.ev, eventId: next.event_id });
      else if (wasQ && isQ && st.notify_odds_change && prev!.best_odds && next.best_odds && Math.abs(next.best_odds / prev!.best_odds - 1) >= 0.05)
        out.push({ kind: 'odds_change', dedupeKey: `odds:${id}:${next.best_odds.toFixed(2)}`, title: 'Cambio de cuota relevante', body: `${prev!.best_odds.toFixed(2)} → ${next.best_odds.toFixed(2)}\n${this.describe(next)}`, ev: next.ev, eventId: next.event_id });
      else if (wasQ && isQ && prev!.ev != null && next.ev != null && Math.abs(next.ev - prev!.ev) >= 0.03)
        out.push({ kind: 'ev_change', dedupeKey: `ev:${id}:${Math.round(next.ev * 100)}`, title: 'EV cambió significativamente', body: `EV ${pct(prev!.ev)} → ${pct(next.ev)}\n${this.describe(next)}`, ev: next.ev, eventId: next.event_id });
    }
    return out;
  }

  /** Speichert und versendet nur neue Meldungen (Dedupe über eindeutigen Schlüssel). */
  async dispatch(drafts: AlertDraft[]): Promise<number> {
    let sent = 0;
    for (const d of drafts) {
      const channels = ['in_app'];
      const ins = this.db.run('INSERT OR IGNORE INTO alerts_sent (dedupe_key, kind, title, body, channels, created_at) VALUES (?, ?, ?, ?, ?, ?)', d.dedupeKey, d.kind, d.title, d.body, '[]', nowIso());
      if (!ins.changes) continue;
      const text = `${d.title}\n${d.body}`;
      if (this.cfg.alerts.telegramBotToken && this.cfg.alerts.telegramChatId) {
        try { await this.send(`https://api.telegram.org/bot${this.cfg.alerts.telegramBotToken}/sendMessage`, { chat_id: this.cfg.alerts.telegramChatId, text, disable_web_page_preview: true }); channels.push('telegram'); }
        catch (e) { logError(this.db, 'alerts.telegram', e); }
      }
      if (this.cfg.alerts.webhookUrl) {
        try { await this.send(this.cfg.alerts.webhookUrl, { kind: d.kind, title: d.title, body: d.body }); channels.push('webhook'); }
        catch (e) { logError(this.db, 'alerts.webhook', e); }
      }
      this.db.run('UPDATE alerts_sent SET channels = ? WHERE dedupe_key = ?', JSON.stringify(channels), d.dedupeKey);
      sent++;
    }
    return sent;
  }
}

/**
 * Persönliche Benachrichtigungen (v0.3.0): nur In-App, nur für Benutzer mit eingeschalteter Option,
 * gefiltert nach eigenen Meldungstypen und optionalem Mindest-EV, dedupliziert je Benutzer.
 * Telegram/Webhook (systemweite Kanäle) werden für persönliche Meldungen NICHT verwendet.
 * entitled(userId) entscheidet über die Tarifberechtigung (personalAlerts / customAlertMinEv).
 */
export function dispatchPersonal(db: Db, drafts: AlertDraft[], entitled: (userId: number, role: string) => { personalAlerts: boolean; customAlertMinEv: boolean }, systemMinEv: number): number {
  if (!drafts.length) return 0;
  const users = db.all<{ user_id: number; role: string; notify_new_value: number; notify_odds_change: number; notify_removed: number; notify_ev_change: number; alert_min_ev: number | null }>(
    `SELECT s.user_id, u.role, s.notify_new_value, s.notify_odds_change, s.notify_removed, s.notify_ev_change, s.alert_min_ev FROM user_settings s JOIN users u ON u.id = s.user_id
      WHERE s.personal_alerts_enabled = 1 AND u.active = 1 AND u.role IN ('user','admin')`);
  let n = 0;
  const now = nowIso();
  for (const u of users) {
    const ent = entitled(u.user_id, u.role);
    if (!ent.personalAlerts) continue;
    const minEv = ent.customAlertMinEv && u.alert_min_ev != null ? u.alert_min_ev : systemMinEv;
    for (const d of drafts) {
      const on = d.kind === 'new_value' ? u.notify_new_value : d.kind === 'odds_change' ? u.notify_odds_change : d.kind === 'removed' ? u.notify_removed : d.kind === 'ev_change' ? u.notify_ev_change : 0;
      if (!on) continue;
      // Mindest-EV gilt für positive Meldungen; "zurückgezogen" wird immer zugestellt, wenn aktiviert
      if (d.kind !== 'removed' && (d.ev == null || d.ev < minEv)) continue;
      const sys = db.get<{ id: number }>('SELECT id FROM alerts_sent WHERE dedupe_key = ?', d.dedupeKey);
      const r = db.run('INSERT OR IGNORE INTO user_alerts (user_id, alert_id, dedupe_key, kind, title, body, ev, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        u.user_id, sys?.id ?? null, d.dedupeKey, d.kind, d.title, d.body, d.ev ?? null, now);
      n += r.changes;
    }
  }
  return n;
}

const pct = (x: number | null) => x == null ? '–' : `${(x * 100).toFixed(1)} %`;

async function postJson(url: string, body: unknown): Promise<void> {
  const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(10_000) });
  if (!r.ok) throw new Error(`Benachrichtigung fehlgeschlagen: HTTP ${r.status}`);
}
